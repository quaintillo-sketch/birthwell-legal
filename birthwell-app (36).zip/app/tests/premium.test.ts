// BirthWell Free vs Premium: what's included, and that free coaching stays supportive.
//   npm test
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { test } from 'node:test';
import { FREE_AMBIENCE, FREE_COACH, FREE_MAREN_PHRASES, FREE_MEDITATION_WEEKS } from '../src/config/premium.ts';
import { COACHING, type Mode } from '../src/data/coaching.ts';
import { effectiveAmbience, effectiveCoach, isAmbienceFree, isCoachFree, isMeditationFree, nextEntitlement, scriptForTier } from '../src/lib/access.ts';
import { randomLabor, report, simulate } from './simulateLabor.ts';

const MODES: Mode[] = ['grounded', 'faith'];
const maren = COACHING[FREE_COACH];
const free = scriptForTier(maren, false);
const lib = (mode: Mode) => free.phrases.filter(p => p.modes.includes(mode));

test('free coaching uses only existing Maren recordings (nothing new to generate)', () => {
  assert.equal(maren.slug, 'maren');
  const ids = new Set(maren.phrases.map(p => p.id));
  for (const id of FREE_MAREN_PHRASES) assert.ok(ids.has(id), `${id} is not one of Maren's lines`);
  assert.equal(free.phrases.length, FREE_MAREN_PHRASES.length);
});

test('free library per mode: 2 openers, 2 breathing, 2 encouragements, 2 resting, 2 acknowledgments', () => {
  for (const mode of MODES) {
    const l = lib(mode);
    const n = (...cats: string[]) => l.filter(p => cats.includes(p.category)).length;
    assert.equal(n('start'), 2, `${mode} start`);
    assert.equal(n('breathe'), 2, `${mode} breathe`);
    assert.equal(n('affirm', 'encourage'), 2, `${mode} encouragement`);
    assert.equal(n('rest'), 2, `${mode} rest`);
    assert.equal(n('ack'), 2, `${mode} ack`);
    assert.equal(n('preview'), 1, `${mode} preview`);
    assert.equal(n('volume'), 1, `${mode} volume`);
  }
});

test('free Grounded has no religious language; free Faith-Centered includes faith lines', () => {
  const religious = /\b(God|Lord|Jesus|Christ|Holy Spirit|pray|prayer|grace|bless|amen|faith|Him)\b/;
  for (const p of lib('grounded')) assert.doesNotMatch(p.text, religious, p.id);
  assert.ok(lib('faith').some(p => /Jesus|Lord/.test(p.text)));
});

test('Premium gets every coach’s full library; Free never uses another coach', () => {
  for (const c of COACHING) assert.equal(scriptForTier(c, true).phrases.length, c.phrases.length);
  for (let i = 0; i < 5; i++) {
    assert.equal(effectiveCoach(i, false), FREE_COACH);
    assert.equal(effectiveCoach(i, true), i);
    assert.equal(isCoachFree(i), i === FREE_COACH);
  }
});

test('soundscapes and meditations: the approved free ones unlock, the rest need Premium', () => {
  assert.ok(isAmbienceFree('desert') && isAmbienceFree('rain') && isAmbienceFree('own') && isAmbienceFree('off'));
  for (const id of ['hearth', 'golden', 'spirit', 'grace'] as const) {
    assert.ok(!isAmbienceFree(id));
    assert.equal(effectiveAmbience(id, false), FREE_AMBIENCE[0]);
    assert.equal(effectiveAmbience(id, true), id);
  }
  assert.equal(FREE_MEDITATION_WEEKS.length, 3);
  for (let w = 6; w <= 42; w++) assert.equal(isMeditationFree(w), FREE_MEDITATION_WEEKS.includes(w));
});

test('Premium is never removed just because the store can’t be reached', () => {
  const owned = { premium: true, verifiedAt: 1 };
  assert.deepEqual(nextEntitlement(owned, { kind: 'unavailable' }, 5), owned);
  assert.deepEqual(nextEntitlement(null, { kind: 'unavailable' }, 5), { premium: false, verifiedAt: 0 });
  assert.deepEqual(nextEntitlement(owned, { kind: 'verified', premium: false }, 5), { premium: false, verifiedAt: 5 }); // e.g. refunded
  assert.deepEqual(nextEntitlement(null, { kind: 'verified', premium: true }, 5), { premium: true, verifiedAt: 5 });
});

test('free coaching keeps going through a whole labor, without stacking or back-to-back repeats', () => {
  for (const seed of [2026, 7, 99]) {
    const labor = randomLabor(2 * 60 * 60, seed);
    for (const mode of MODES)
      for (const freq of ['balanced', 'more', 'frequent'] as const) {
        const played = simulate(free, mode, freq, labor, seed);
        const r = report(free, mode, labor, played);
        // An opening phrase every contraction and one end phrase every time: never cut off.
        assert.equal(played.filter(p => p.moment === 'start').length, labor.length, `${mode} ${freq} openers`);
        assert.equal(r.restPhrasesPerRest, 1, `${mode} ${freq} end phrases`);
        assert.equal(r.backToBack, 0, `${mode} ${freq} back-to-back`);
        for (let i = 1; i < played.length; i++) assert.ok(played[i].t >= played[i - 1].end - 1e-9, `${mode} ${freq} overlap`);
        for (const p of played) assert.ok(FREE_MAREN_PHRASES.includes(p.phrase.id), `${p.phrase.id} isn't free`);
      }
  }
});

test('the purchase screen is never opened from labor mode', () => {
  const labor = readFileSync(new URL('../src/app/labor/index.tsx', import.meta.url), 'utf8');
  assert.doesNotMatch(labor, /\/premium/);
  // The Voice & sound panel only links to Premium outside labor mode.
  const sheet = readFileSync(new URL('../src/components/AudioSheet.tsx', import.meta.url), 'utf8');
  const link = sheet.indexOf("router.push('/premium')");
  assert.ok(link > 0 && sheet.lastIndexOf("mode !== 'labor'", link) > 0 && link - sheet.lastIndexOf("mode !== 'labor'", link) < 300);
});
