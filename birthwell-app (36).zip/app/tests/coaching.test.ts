// Run with: npm test
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { COACHING, COACH_SLUGS, DISTRIBUTION, type Mode } from '../src/data/coaching.ts';
import {
  EMPTY_ROTATION,
  endTransition,
  FINISH_WITHIN_S,
  midOffsets,
  nextSlot,
  pendingRest,
  pickPhrase,
  REST_PAUSE_S,
  REST_STALE_S,
  variationFor,
  type Frequency,
} from '../src/lib/coachingEngine.ts';

const MODES: Mode[] = ['grounded', 'faith'];
const lib = (c: (typeof COACHING)[number], mode: Mode) => c.phrases.filter(p => p.modes.includes(mode));

test('each coach has two complete libraries in the approved split (Grounded 31, Faith-Centered 33)', () => {
  assert.deepEqual(COACHING.map(c => c.slug), COACH_SLUGS);
  for (const c of COACHING)
    for (const mode of MODES) {
      const l = lib(c, mode);
      assert.equal(l.length, mode === 'grounded' ? 31 : 33, `${c.slug} ${mode}`);
      for (const [cat, n] of Object.entries(DISTRIBUTION[mode])) assert.equal(l.filter(p => p.category === cat).length, n, `${c.slug} ${mode} ${cat}`);
    }
});

test('acknowledgments: 3 shared Grounded lines + 2 Faith-Centered per coach, 25 recordings in all, exact approved wording', () => {
  const APPROVED: Record<string, string[]> = {
    maren: ['You did wonderfully.', 'There you go. Beautifully done.', 'You made it through that one.', 'There you go. God is with you.', 'You did beautifully. Thank You, Jesus.'],
    jo: ['You did it!', 'There you go. That was wonderful.', 'Another one behind you!', 'You did it! Praise God.', 'There you go. Jesus is with you.'],
    esme: ['Beautifully done.', 'There you go. Now rest.', 'You made it through.', 'Beautifully done. Rest in Him.', 'There you go. Thank You, Lord.'],
    ines: ['You did beautifully.', 'There you go. The wave has passed.', 'Beautiful. Now take your rest.', 'There you go. Rest in His love.', 'You did beautifully. God is near.'],
    della: ['Yes! You did it!', 'Look at you. Beautifully done!', 'There you go! You did wonderfully.', 'You did it! Thank You, Jesus!', 'Yes! God’s right here with you!'],
  };
  let total = 0;
  for (const c of COACHING) {
    const acks = c.phrases.filter(p => p.category === 'ack');
    total += acks.length;
    assert.deepEqual(acks.map(p => p.text), APPROVED[c.slug], c.slug);
    assert.deepEqual(acks.map(p => p.id), ['both-ack-01', 'both-ack-02', 'both-ack-03', 'faith-ack-01', 'faith-ack-02'], c.slug);
  }
  assert.equal(total, 25);
});

test('filenames are unique and match their mode prefix', () => {
  for (const c of COACHING) {
    assert.equal(new Set(c.phrases.map(p => p.id)).size, c.phrases.length, `${c.slug} duplicate ids`);
    for (const p of c.phrases) {
      const prefix = p.modes.length === 2 ? 'both' : p.modes[0];
      assert.ok(p.id.startsWith(`${prefix}-${p.category}-`), `${c.slug}/${p.id}`);
    }
  }
});

test('unique recordings: 320 phrases, fewer files thanks to shared lines', () => {
  const unique = COACHING.reduce((n, c) => n + c.phrases.length, 0);
  const shared = COACHING.reduce((n, c) => n + c.phrases.filter(p => p.modes.length === 2).length, 0);
  assert.equal(unique + shared, 320);
  assert.equal(unique, 269);
});

test('no phrase uses banned stage, progress, medical or battle wording', () => {
  const banned = /\b(almost there|halfway|nearly done|peak|crest|push|transition|dilat|baby is coming|won'?t hurt|doesn'?t hurt|final stretch|last one|conquer|fight|beat this|battle)\b/i;
  for (const c of COACHING) for (const p of c.phrases) assert.doesNotMatch(p.text, banned, `${c.slug}/${p.id}: ${p.text}`);
});

test('faith phrases make no promises about outcomes and never tie them to faith', () => {
  const promises = /\b(safe(ly)?|painless|no pain|easy birth|perfect birth|nothing will go wrong|everything will be (fine|okay)|enough faith|if you (just )?(pray|believe)|instead of|don'?t need (a |the )?(doctor|midwife|nurse|medic))/i;
  for (const c of COACHING) for (const p of lib(c, 'faith')) assert.doesNotMatch(p.text, promises, `${c.slug}/${p.id}: ${p.text}`);
});

// A prayer addresses God directly: "Lord, …", "Jesus… be my peace", "Thank You, Lord", "Holy Spirit, steady me".
const isPrayer = (t: string) => /\b(Lord( Jesus)?|Jesus|Holy Spirit)(,|…)\s/.test(t) || /\bThank You\b|\bI praise You\b|\bCome, Holy Spirit\b/.test(t);

const sacred = /\b(God|Lord|Jesus|Christ|Holy Spirit|Spirit|He|His|Him)\b|\bgrace\b|\bpray/i;

test('Faith-Centered feels Christian throughout, but not every phrase is religious', () => {
  for (const c of COACHING) {
    const l = lib(c, 'faith');
    const spiritual = l.filter(p => sacred.test(p.text)).length;
    // Roughly 55–75%: clearly Christian, with room for plain practical and warm lines.
    assert.ok(spiritual >= 0.55 * l.length && spiritual <= 0.75 * l.length, `${c.slug}: ${spiritual} of ${l.length} faith phrases are spiritual`);
    const text = l.map(p => p.text).join(' ');
    assert.match(text, /Jesus|Christ/, `${c.slug} never mentions Jesus`);
    assert.match(text, /Holy Spirit|the Spirit/, `${c.slug} never mentions the Holy Spirit`);
    // Short prayers addressed to God, Jesus or the Holy Spirit (not only speaking about Him).
    const prayers = l.filter(p => isPrayer(p.text));
    assert.ok(prayers.length >= 5, `${c.slug} has only ${prayers.length} prayers`);
    // Practical breathing guidance is still present.
    assert.ok(l.filter(p => p.category === 'breathe' && !sacred.test(p.text)).length >= 2, `${c.slug} lacks practical breathing lines`);
  }
});

test('"God is with you" and its close variants are not overused', () => {
  const presence = /\b(God|Jesus|Christ|He|Lord)( is|’s|'s) (with you|right here|here|near)\b/i;
  for (const c of COACHING) {
    const n = lib(c, 'faith').filter(p => presence.test(p.text)).length;
    assert.ok(n <= 3, `${c.slug}: ${n} presence phrases`);
  }
});

test('Grounded phrases contain no religious language', () => {
  const religious = /\b(God|Lord|Jesus|Christ|Holy Spirit|pray|prayer|grace|bless|amen|faith)\b/i;
  for (const c of COACHING) for (const p of lib(c, 'grounded')) assert.doesNotMatch(p.text, religious, `${c.slug}/${p.id}: ${p.text}`);
});

test('no two coaches share a phrase', () => {
  const seen = new Map<string, string>();
  for (const c of COACHING)
    for (const p of c.phrases) {
      const k = p.text.toLowerCase();
      assert.ok(!seen.has(k), `"${p.text}" used by ${seen.get(k)} and ${c.slug}`);
      seen.set(k, c.slug);
    }
});

function phrasesDuring(freq: Frequency, lengthS: number) {
  if (freq === 'off') return 0;
  return 1 + midOffsets(freq).filter(o => o <= lengthS).length;
}

test('Balanced gives 1–2 phrases in a one-minute contraction, plus one resting phrase', () => {
  assert.equal(phrasesDuring('balanced', 30), 1);
  assert.equal(phrasesDuring('balanced', 60), 2);
  assert.equal(phrasesDuring('balanced', 90), 2);
  assert.equal(phrasesDuring('edges', 60), 1);
  assert.equal(phrasesDuring('more', 60), 3);
  assert.equal(phrasesDuring('frequent', 60), 5);
  assert.equal(phrasesDuring('off', 60), 0);
});

test('a slot plays when due, and is dropped if more than 6 seconds late', () => {
  assert.deepEqual(nextSlot('balanced', 20, -1), { kind: 'none' });
  assert.deepEqual(nextSlot('balanced', 36, -1), { kind: 'play', slot: 0 });
  assert.deepEqual(nextSlot('balanced', 36, 0), { kind: 'none' });
  assert.deepEqual(nextSlot('balanced', 50, -1), { kind: 'skip', slot: 0 });
});

test('after a long suspension only the latest slot is considered, so prompts never pile up', () => {
  assert.deepEqual(nextSlot('frequent', 76, -1), { kind: 'play', slot: 4 });
  assert.deepEqual(nextSlot('frequent', 88, -1), { kind: 'skip', slot: 4 });
});

function seeded(seed: number) {
  return () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
}

test('each mode only ever plays its own library', () => {
  const rand = seeded(5);
  for (const c of COACHING)
    for (const mode of MODES) {
      let state = EMPTY_ROTATION;
      for (let i = 0; i < 300; i++) {
        const moment = (['start', 'mid', 'end'] as const)[i % 3];
        const r = pickPhrase(c, mode, moment, 40, state, rand)!;
        assert.ok(r.phrase.modes.includes(mode), `${c.slug} ${mode} played ${r.phrase.id}`);
        assert.ok(!['preview', 'volume'].includes(r.phrase.category), `${c.slug} rotated ${r.phrase.id}`);
        state = r.state;
      }
    }
});

test('rotation plays every phrase in a group before repeating any', () => {
  const rand = seeded(7);
  for (const c of COACHING)
    for (const mode of MODES) {
      let state = EMPTY_ROTATION;
      const seen: string[] = [];
      for (let i = 0; i < 3; i++) {
        const r = pickPhrase(c, mode, 'start', 0, state, rand)!;
        state = r.state;
        seen.push(r.phrase.id);
      }
      assert.equal(new Set(seen).size, 3, `${c.slug} ${mode} start phrases repeat early: ${seen}`);
    }
});

test('the same phrase never plays twice in a row across a long session, even after switching mode', () => {
  const rand = seeded(42);
  for (const c of COACHING) {
    let state = EMPTY_ROTATION;
    let last = '';
    for (let i = 0; i < 800; i++) {
      const mode: Mode = i < 400 ? 'grounded' : 'faith';
      const moment = (['start', 'mid', 'mid', 'end'] as const)[i % 4];
      const r = pickPhrase(c, mode, moment, moment === 'mid' ? 40 : 0, state, rand)!;
      assert.notEqual(r.phrase.id, last, `${c.slug} repeated ${last}`);
      last = r.phrase.id;
      state = r.state;
    }
  }
});

test('mid-contraction phrases are mostly breathing guidance, sprinkled with small encouragements and occasional reassurance', () => {
  const rand = seeded(11);
  for (const mode of MODES)
    for (const elapsed of [15, 40]) {
      let state = EMPTY_ROTATION;
      const tally: Record<string, number> = {};
      for (let i = 0; i < 3000; i++) {
        const r = pickPhrase(COACHING[0], mode, 'mid', elapsed, state, rand)!;
        tally[r.phrase.category] = (tally[r.phrase.category] ?? 0) + 1;
        state = r.state;
      }
      const share = (k: string) => (tally[k] ?? 0) / 3000;
      assert.ok(share('breathe') > 0.45, `${mode} @${elapsed}s ${JSON.stringify(tally)}`);
      assert.ok(share('affirm') > 0.2, `${mode} @${elapsed}s small encouragements ${JSON.stringify(tally)}`);
      assert.ok(share('encourage') > 0.08 && share('ground') > 0.04, `${mode} @${elapsed}s ${JSON.stringify(tally)}`);
    }
});

test('within a group, a phrase only returns after most of the others (openers: at least 4 contractions apart)', () => {
  const rand = seeded(3);
  for (const c of COACHING)
    for (const mode of MODES)
      for (const category of ['start', 'breathe', 'rest'] as const) {
        const size = c.phrases.filter(p => p.category === category && p.modes.includes(mode)).length;
        let state = EMPTY_ROTATION;
        const seen = new Map<string, number>();
        for (let i = 0; i < 500; i++) {
          const moment = category === 'start' ? 'start' : category === 'rest' ? 'end' : 'mid';
          const r = pickPhrase(c, mode, moment, 15, state, rand)!;
          state = r.state;
          if (r.phrase.category !== category) continue;
          const n = [...seen.values()].length ? Math.max(...seen.values()) + 1 : 0;
          const prev = seen.get(r.phrase.id);
          if (prev !== undefined) assert.ok(n - prev >= size - 1, `${c.slug} ${mode} ${category}: ${r.phrase.id} back after ${n - prev}`);
          seen.set(r.phrase.id, n);
        }
      }
});

test('Balanced timing varies by contraction: 30–42 s, and some contractions get only the opener', () => {
  let quiet = 0;
  const offsets = new Set<number>();
  const N = 2000;
  for (let i = 0; i < N; i++) {
    const o = midOffsets('balanced', variationFor(1_760_000_000_000 + i * 263_417));
    assert.ok(o.length <= 1);
    if (!o.length) quiet++;
    else {
      assert.ok(o[0] >= 30 && o[0] <= 42, String(o[0]));
      offsets.add(Math.round(o[0]));
    }
  }
  assert.ok(quiet / N > 0.08 && quiet / N < 0.25, `quiet share ${quiet / N}`);
  assert.ok(offsets.size >= 10, `only ${offsets.size} distinct offsets`);
  // Stable within a contraction.
  assert.equal(variationFor(123456789), variationFor(123456789));
});

test('contraction end: a nearly finished phrase finishes (a longer one fades), then one end phrase follows after a pause or is skipped', () => {
  assert.equal(endTransition(0), 'play-now');
  assert.equal(endTransition(1.5), 'finish-then-play');
  assert.equal(endTransition(FINISH_WITHIN_S + 0.5), 'fade-then-play');
  // End tap at t=100; previous phrase still playing.
  assert.equal(pendingRest(101, 100, false, 0), 'wait');
  // It finished at 102: wait for the pause, then play.
  assert.equal(pendingRest(102.5, 100, true, 102), 'wait');
  assert.equal(pendingRest(102 + REST_PAUSE_S + 0.01, 100, true, 102), 'play');
  // Too late (e.g. the app was suspended): skip rather than play late.
  assert.equal(pendingRest(100 + REST_STALE_S + 1, 100, true, 102), 'drop');
});


test('every quoted verse carries a Scripture reference; Psalm 46:5 is no longer used', () => {
  for (const c of COACHING)
    for (const p of c.phrases) {
      if (/[“"]/.test(p.text)) assert.ok(p.scripture, `${c.slug}/${p.id} quotes without a reference: ${p.text}`);
      assert.doesNotMatch(p.text, /within her|will not fall/i, `${c.slug}/${p.id}`);
      assert.ok(!p.scripture?.includes('46:5'), `${c.slug}/${p.id}`);
    }
});

test('no phrase assumes how she feels or adds needless negativity', () => {
  const assumed = /\b(hate|I know\. I know|fears?|worr(y|ies)|scared|afraid|awful|terrible|than you feel|this is hard)\b/i;
  for (const c of COACHING) for (const p of c.phrases) assert.doesNotMatch(p.text, assumed, `${c.slug}/${p.id}: ${p.text}`);
});

test('breathing cues invite rather than prescribe one technique', () => {
  const prescriptive = /\b(through your nose|into your belly|low and slow|let the breath fill)\b/i;
  for (const c of COACHING) for (const p of c.phrases) assert.doesNotMatch(p.text, prescriptive, `${c.slug}/${p.id}: ${p.text}`);
});

test('no pressure to be strong, brave or in control', () => {
  const pressure = /(?<!don’t |don't )\b(have to|must|need to) be (strong|brave)\b|\btrust yourself\b|\byou know how to do this\b|\bin control\b/i;
  for (const c of COACHING) for (const p of c.phrases) assert.doesNotMatch(p.text, pressure, `${c.slug}/${p.id}: ${p.text}`);
});

test('"wave" is used selectively in both modes, without a fixed rise-and-fall shape', () => {
  for (const c of COACHING)
    for (const mode of MODES) {
      // Approved acknowledgments are taken word for word, so they're not counted here.
      const n = lib(c, mode).filter(p => p.category !== 'ack' && /\bwaves?\b/i.test(p.text)).length;
      assert.ok(n >= 1 && n <= 4, `${c.slug} ${mode}: ${n} wave phrases`);
    }
  for (const c of COACHING) for (const p of c.phrases) assert.doesNotMatch(p.text, /\b(rises|rising|crest|peaks?)\b/i, `${c.slug}/${p.id}: ${p.text}`);
});

import { randomLabor, report, simulate } from './simulateLabor.ts';

test('two-hour simulation: Balanced stays quiet, rests get one phrase, openers never repeat back-to-back', () => {
  for (const seed of [2026, 7, 99]) {
    const labor = randomLabor(2 * 60 * 60, seed);
    for (const c of COACHING)
      for (const mode of MODES)
        for (const freq of ['balanced', 'more', 'frequent'] as const) {
          const played = simulate(c, mode, freq, labor, seed);
          const r = report(c, mode, labor, played);
          // Exactly one phrase per end, never two.
          assert.equal(r.restPhrasesPerRest, 1, `${c.slug} ${mode} ${freq} end phrases`);
          assert.equal(r.restsSkipped, 0, `${c.slug} ${mode} ${freq} resting phrase skipped`);
          assert.ok(r.maxRestDelayS <= REST_STALE_S, `${c.slug} ${mode} ${freq} late resting phrase ${r.maxRestDelayS}`);
          assert.ok(r.openerRepeatEveryContractions.min >= 2, `${c.slug} ${mode} ${freq}: opener repeated in consecutive contractions`);
          assert.equal(r.backToBack, 0, `${c.slug} ${mode} ${freq} back-to-back`);
          assert.ok(r.talkShareInRests < 0.05, `${c.slug} ${mode} ${freq} talks during rests`);
          // Never two phrases at once.
          for (let i = 1; i < played.length; i++) assert.ok(played[i].t >= played[i - 1].end - 1e-9, `${c.slug} overlap at ${played[i].t}`);
          if (freq === 'balanced') {
            assert.ok(r.duringMax <= 2, `${c.slug} ${mode} balanced: ${r.duringMax} phrases in one contraction`);
            assert.ok(r.maxPhrasesInAnyMinute <= 3, `${c.slug} ${mode} balanced busiest minute ${r.maxPhrasesInAnyMinute}`);
            // One phrase per end: mostly acknowledgments, sometimes a resting phrase instead.
            assert.ok(r.ackShare > 0.45 && r.ackShare < 0.97, `${c.slug} ${mode} acknowledgment share ${r.ackShare}`);
            assert.ok(r.openerRepeatEveryContractions.min >= 4, `${c.slug} ${mode} balanced: opener back after ${r.openerRepeatEveryContractions.min} contractions`);
            assert.ok(r.distinctSequences >= 3, `${c.slug} ${mode} balanced: only ${r.distinctSequences} patterns`);
          }
        }
  }
});

test('a mis-tapped, very short contraction gets no acknowledgment; a real one gets exactly one end phrase', () => {
  const labor = [
    { start: 60, end: 64 }, // tapped by accident
    { start: 300, end: 360 },
  ];
  for (const c of COACHING)
    for (const mode of MODES) {
      const played = simulate(c, mode, 'balanced', labor, 3);
      const ends = played.filter(p => p.moment === 'end');
      assert.equal(ends.filter(p => p.contraction === 0).length, 0, `${c.slug} ${mode} spoke after a mis-tap`);
      assert.equal(ends.filter(p => p.contraction === 1).length, 1, `${c.slug} ${mode}`);
      for (let i = 1; i < played.length; i++) assert.ok(played[i].t >= played[i - 1].end - 1e-9, `${c.slug} overlap`);
    }
});
