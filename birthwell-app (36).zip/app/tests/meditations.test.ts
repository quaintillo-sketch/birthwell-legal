// Meditation recorder: the text sent to ElevenLabs must be the approved scripts, word for word.
//   npm test
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { test } from 'node:test';
import { fileURLToPath } from 'node:url';
import {
  applyPronunciations,
  approvedWords,
  buildUnits,
  checkIntegrity,
  estimateSeconds,
  loadScripts,
  MAREN_PACE,
  parseScript,
  reversePronunciations,
} from '../scripts/meditation-scripts.mjs';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const scripts = loadScripts(root);
const pronounce = { Zephaniah: 'Zeff-uh-NYE-uh', Elihu: 'Ee-LYE-hew', Ebenezer: 'Eb-en-EE-zer' };

test('all 74 approved scripts are read: weeks 6–42, Grounded and Faith-centered', () => {
  assert.equal(scripts.length, 74);
  for (let week = 6; week <= 42; week++) {
    for (const version of ['grounded', 'faith']) {
      assert.ok(scripts.some(s => s.week === week && s.version === version), `week ${week} ${version}`);
    }
  }
});

test('every request matches the approved words exactly, by paragraph and by block', () => {
  for (const unit of ['paragraph', 'block']) {
    for (const s of scripts) assert.deepEqual(checkIntegrity(root, s, { unit, pronounce }), [], `week ${s.week} ${s.version} (${unit})`);
  }
});

test('the integrity check catches a changed, missing or extra word', () => {
  const s = scripts[0];
  const paras = s.items.filter(i => i.kind === 'para');
  const altered = (change: (t: string) => string) => ({
    ...s,
    items: s.items.map(i => (i === paras[2] ? { ...i, text: change(i.text) } : i)),
  });
  assert.ok(checkIntegrity(root, altered(t => t.replace('gentle', 'soft'))).length);
  assert.ok(checkIntegrity(root, altered(t => t.split(' ').slice(1).join(' '))).length);
  assert.ok(checkIntegrity(root, altered(t => `${t} Now.`)).length);
  assert.ok(checkIntegrity(root, { ...s, items: s.items.filter(i => i !== paras[4]) }).length);
});

test('nothing unspoken is sent: no markers, italics, quotation marks or headings', () => {
  for (const s of scripts) {
    for (const u of buildUnits(s)) {
      assert.doesNotMatch(u.sent, /\[(pause|music)|\*|[“”"]|\*\*|^#/, `week ${s.week} ${s.version} ${u.id}`);
      assert.match(u.sent, /^\[[a-z][a-z ,-]*\] \S/, `week ${s.week} ${s.version} ${u.id} starts with its tone tag`);
      assert.equal((u.sent.match(/\[/g) ?? []).length, 1, `one tag per paragraph request: week ${s.week} ${s.version} ${u.id}`);
    }
  }
});

test('recording only: Scripture lines ending mid-sentence are sent with a full stop; the scripts are unchanged', () => {
  const ends: Record<number, string> = { 26: 'My peace I give to you.', 31: 'When you pass through the waters, I will be with you.', 37: 'and a time for every purpose under heaven.' };
  for (const [week, end] of Object.entries(ends)) {
    const s = scripts.find(x => x.week === Number(week) && x.version === 'faith')!;
    assert.ok(buildUnits(s).some(u => u.sent.endsWith(end)), `week ${week} sends "${end}"`);
    const file = readFileSync(join(root, 'docs/meditations', s.file), 'utf8');
    assert.ok(/[,;:]\*$/m.test(file.split(`## Week ${week} · Faith-centered`)[1].split('\n---')[0]), `week ${week} script keeps its punctuation`);
  }
  // Nothing else changes: every other sent paragraph is the script's own text.
  for (const s of scripts) for (const u of buildUnits(s)) {
    const p = s.items.find(i => i.kind === 'para' && i.n === u.paras[0]) as { text: string; scripture: boolean };
    if (!p.scripture) assert.ok(u.sent.endsWith(p.text), `week ${s.week} ${s.version} ${u.id}`);
  }
});

test('tone tags carry forward until the next tag', () => {
  const s = parseScript('Week 99 · Grounded\n\n[music 8s]\n\n[warm] One.\n\nTwo.\n\n[pause 4s]\n\n[calm] Three.\n\n[music 8s]\n')!;
  assert.deepEqual(buildUnits(s).map(u => u.sent), ['[warm] One.', '[warm] Two.', '[calm] Three.']);
  assert.deepEqual(buildUnits(s, { unit: 'block' }).map(u => u.sent), ['[warm] One.\n\nTwo.', '[calm] Three.']);
  // 8 s music, "One." (1 word), a 1 s breath, "Two.", 4 s pause on top of the breath, "Three.", 8 s music
  assert.equal(estimateSeconds(s), 8 + 0.5 + 1 + 0.5 + 4 + 1 + 0.5 + 8);
  assert.equal(estimateSeconds(s, 1, 0.5), 8 + 0.25 + 1 + 0.25 + 4 + 1 + 0.25 + 8);
});

test('pronunciation fixes change only what is sent, and undo exactly', () => {
  const ebenezer = scripts.find(s => s.items.some(i => i.kind === 'para' && i.text.includes('Ebenezer')))!;
  const sent = buildUnits(ebenezer, { pronounce }).map(u => u.sent).join(' ');
  assert.ok(sent.includes('Eb-en-EE-zer') && !sent.includes('Ebenezer'));
  assert.ok(approvedWords(root, ebenezer).includes('Ebenezer'), 'the approved script itself is unchanged');
  assert.equal(applyPronunciations('Hur and Hurry', { Hur: 'Her' }), 'Her and Hurry', 'whole words only');
  assert.equal(reversePronunciations(applyPronunciations('Elihu said', pronounce), pronounce), 'Elihu said');
});

test("scripts fit Leah's length targets at Maren's pace (Grounded 4:15–5:30, Faith-centered 4:15–6:00, ±10 s)", () => {
  for (const s of scripts) {
    const sec = estimateSeconds(s, 1, MAREN_PACE);
    const max = s.version === 'faith' ? 360 : 330;
    assert.ok(sec >= 245 && sec <= max + 10, `week ${s.week} ${s.version}: ${Math.round(sec)} s`);
  }
});

test("the app's titles, descriptions and lengths match the approved scripts", async () => {
  // @ts-expect-error: plain JavaScript module
  const { buildLibrary, renderLibrary } = await import('../scripts/export-meditation-library.mjs');
  const current = readFileSync(join(root, 'src/data/meditationLibrary.ts'), 'utf8');
  assert.equal(current, renderLibrary(buildLibrary(root)), 'run: node scripts/export-meditation-library.mjs');
  const { MEDITATION_LIBRARY: lib } = await import('../src/data/meditationLibrary.ts');
  assert.deepEqual(lib[6].faith.title, ['Known', 'before', 'the beginning.']);
  assert.deepEqual(lib[6].grounded.title, ['Simply', 'to', 'arrive.']);
  assert.deepEqual(lib[37].grounded.title, ['Open', 'hands.'], 'two-part titles are kept as written');
  for (let week = 6; week <= 42; week++) for (const v of ['grounded', 'faith'] as const) assert.ok(lib[week][v].desc && lib[week][v].seconds > 240, `week ${week} ${v}`);
});
