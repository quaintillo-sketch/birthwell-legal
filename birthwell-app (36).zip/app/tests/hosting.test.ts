// Meditation hosting: free weeks are public, Premium weeks need a RevenueCat-checked link.
//   npm test
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { FREE_MEDITATION_WEEKS } from '../src/config/premium.ts';
import { entryFor, hostingUrls, isStale, parseManifest } from '../src/lib/meditationHosting.ts';
import { handle, hasPremium } from '../supabase/functions/meditation-url/index.ts';

const manifest = parseManifest({
  format: 2,
  narrator: 'maren',
  files: {
    faith: { '6': { path: 'maren/faith/week-06.m4a', rev: 'aaa', free: true }, '7': { path: 'maren/faith/week-07.m4a', rev: 'bbb' } },
  },
});

test('the manifest lists what is uploaded, and old or broken manifests are ignored', () => {
  assert.equal(entryFor(manifest, 6, 'faith')?.free, true);
  assert.equal(entryFor(manifest, 7, 'faith')?.free, undefined);
  assert.equal(entryFor(manifest, 8, 'faith'), null, 'not uploaded yet');
  assert.equal(entryFor(manifest, 6, 'secular'), null);
  assert.equal(parseManifest({ faith: { '6': 'faith/week-06.m4a' } }), null);
  assert.equal(parseManifest(null), null);
});

test('free weeks play from the public bucket, and updated recordings are fetched again', () => {
  const u = hostingUrls('https://abcd.supabase.co/');
  assert.equal(u.manifest, 'https://abcd.supabase.co/storage/v1/object/public/meditations-free/manifest.json');
  assert.equal(u.publicFile(entryFor(manifest, 6, 'faith')!), 'https://abcd.supabase.co/storage/v1/object/public/meditations-free/maren/faith/week-06.m4a?v=aaa');
  assert.equal(u.signer, 'https://abcd.supabase.co/functions/v1/meditation-url');
  assert.equal(hostingUrls('https://abcd.supabase.co/rest/v1/').manifest, u.manifest, 'a pasted API URL still works');
  assert.equal(isStale('aaa', entryFor(manifest, 6, 'faith')), false);
  assert.equal(isStale('old', entryFor(manifest, 6, 'faith')), true);
  assert.equal(isStale('old', null), false, 'keeps a download that is no longer listed');
  assert.deepEqual(FREE_MEDITATION_WEEKS, [6, 21, 36]);
});

// ---- The meditation-url function, with RevenueCat and Storage simulated ----

const SECRETS: Record<string, string> = {
  REVENUECAT_SECRET_KEY: 'sk_test_revenuecat',
  SUPABASE_URL: 'https://abcd.supabase.co',
  SUPABASE_SERVICE_ROLE_KEY: 'service-role',
};
const env = (extra: Record<string, string | undefined> = {}) => ({ get: (k: string) => ({ ...SECRETS, ...extra })[k] });
const customers: Record<string, unknown> = {
  owner: { premium: { expires_date: null } },
  refunded: {},
  expired: { premium: { expires_date: '2020-01-01T00:00:00Z' } },
};
const uploaded = new Set(['maren/faith/week-07.m4a', 'maren/secular/week-20.m4a']);
const calls: string[] = [];
const fakeFetch = (async (input: string | URL, init?: RequestInit) => {
  const url = String(input);
  calls.push(url);
  const rc = /api\.revenuecat\.com\/v1\/subscribers\/(.+)$/.exec(url);
  if (rc) {
    assert.equal((init?.headers as Record<string, string>).Authorization, 'Bearer sk_test_revenuecat');
    const id = decodeURIComponent(rc[1]);
    if (id === 'rc-down') return new Response('', { status: 503 });
    return Response.json({ subscriber: { entitlements: customers[id] ?? {} } });
  }
  const sign = /\/storage\/v1\/object\/sign\/meditations\/(.+)$/.exec(url);
  if (sign) {
    if (!uploaded.has(sign[1])) return Response.json({ error: 'not found' }, { status: 400 });
    return Response.json({ signedURL: `/object/sign/meditations/${sign[1]}?token=t` });
  }
  throw new Error(`unexpected request ${url}`);
}) as typeof fetch;

const ask = (body: unknown, e = env()) =>
  handle(new Request('https://x/functions/v1/meditation-url', { method: 'POST', body: JSON.stringify(body) }), e, fakeFetch);

test('a Premium owner gets a short-lived link to the private file', async () => {
  const res = await ask({ week: 7, version: 'faith', appUserId: 'owner' });
  assert.equal(res.status, 200);
  const { url, expiresIn } = await res.json();
  assert.equal(url, 'https://abcd.supabase.co/storage/v1/object/sign/meditations/maren/faith/week-07.m4a?token=t');
  assert.ok(expiresIn > 0 && expiresIn <= 24 * 3600);
});

test('no link without Premium: never bought, refunded, expired, or no customer ID', async () => {
  for (const appUserId of ['stranger', 'refunded', 'expired', '', undefined]) {
    const res = await ask({ week: 7, version: 'faith', appUserId });
    assert.equal(res.status, 403, String(appUserId));
  }
  assert.equal(await hasPremium('owner', 'sk_test_revenuecat', fakeFetch), true);
  assert.equal(await hasPremium('expired', 'sk_test_revenuecat', fakeFetch), false);
});

test('the file path is built by the server, never taken from the app', async () => {
  for (const body of [
    { week: 5, version: 'faith', appUserId: 'owner' },
    { week: 43, version: 'faith', appUserId: 'owner' },
    { week: '7/../../x', version: 'faith', appUserId: 'owner' },
    { week: 7, version: '../coaching', appUserId: 'owner' },
  ]) {
    assert.equal((await ask(body)).status, 400, JSON.stringify(body));
  }
});

test('clear answers when something is missing', async () => {
  assert.equal((await ask({ week: 8, version: 'faith', appUserId: 'owner' })).status, 404, 'not uploaded');
  assert.equal((await ask({ week: 7, version: 'faith', appUserId: 'rc-down' })).status, 502, 'RevenueCat unreachable');
  assert.equal((await ask({ week: 7, version: 'faith', appUserId: 'owner' }, env({ REVENUECAT_SECRET_KEY: undefined }))).status, 500);
  const get = await handle(new Request('https://x', { method: 'GET' }), env(), fakeFetch);
  assert.equal(get.status, 405);
});

test('the Expo Go preview code works only while it is set in Supabase, and only if long', async () => {
  const code = 'preview-code-0123456789';
  assert.equal((await ask({ week: 20, version: 'secular', previewCode: code }, env({ MEDITATION_PREVIEW_CODE: code }))).status, 200);
  assert.equal((await ask({ week: 20, version: 'secular', previewCode: code })).status, 403, 'secret deleted: stops working');
  assert.equal((await ask({ week: 20, version: 'secular', previewCode: 'wrong' }, env({ MEDITATION_PREVIEW_CODE: code }))).status, 403);
  assert.equal((await ask({ week: 20, version: 'secular', previewCode: 'short' }, env({ MEDITATION_PREVIEW_CODE: 'short' }))).status, 403);
});
