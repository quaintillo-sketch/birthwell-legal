// Simulates a labor session against the real coaching rules (coachingEngine), on a
// virtual clock, to measure how talkative coaching is and how phrases repeat.
// Used by `npm run simulate` and by tests. No React Native dependencies.

import type { CoachScript, Mode, Phrase } from '../src/data/coaching.ts';
import {
  EMPTY_ROTATION,
  endTransition,
  estimateSeconds,
  FADE_OUT_S,
  MIN_ACK_CONTRACTION_S,
  MIN_GAP_S,
  nextSlot,
  pendingRest,
  pickPhrase,
  variationFor,
  type Frequency,
  type Moment,
  type RotationState,
} from '../src/lib/coachingEngine.ts';

export type Played = {
  t: number;
  end: number;
  phrase: Phrase;
  moment: Moment;
  contraction: number;
  cut?: 'by-end-tap' | 'by-start-tap' | 'faded-at-end';
  finishedAfterEndTap?: boolean;
  restDelayS?: number; // resting phrases: seconds after the end tap
};
export type Contraction = { start: number; end: number };

// Approximate speaking pace per coach, in words per second (Esme is the slowest).
export const PACE: Record<string, number> = { maren: 2.4, jo: 2.7, esme: 1.8, ines: 2.0, della: 2.6 };

export function phraseSeconds(p: Phrase, wordsPerSecond: number) {
  return estimateSeconds(p.text, wordsPerSecond);
}

function rng(seed: number) {
  return () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
}

// Contractions of varying length and spacing, with no assumed progression.
export function randomLabor(seconds: number, seed: number): Contraction[] {
  const rand = rng(seed);
  const list: Contraction[] = [];
  let t = 60;
  while (t < seconds) {
    const length = 30 + rand() * 70; // 30–100 s
    const apart = 150 + rand() * 390; // 2.5–9 min start to start
    if (t + length > seconds) break;
    list.push({ start: t, end: t + length });
    t += Math.max(apart, length + 45);
  }
  return list;
}

export function simulate(script: CoachScript, mode: Mode, freq: Frequency, labor: Contraction[], seed = 1) {
  const rand = rng(seed);
  const pace = PACE[script.slug] ?? 2.3;
  let rotation: RotationState = EMPTY_ROTATION;
  let current: Played | null = null;
  let lastEnded = -Infinity;
  const played: Played[] = [];
  let restTap: number | null = null;
  const stats = { restsSkipped: 0 };

  const say = (t: number, moment: Moment, elapsed: number, interrupt: boolean, contraction: number, cutReason?: Played['cut']) => {
    if (freq === 'off') return false;
    if (current && current.end > t) {
      if (!interrupt) return false;
      current.cut = cutReason;
      current.end = t;
    }
    const pick = pickPhrase(script, mode, moment, elapsed, rotation, rand);
    if (!pick) return false;
    rotation = pick.state;
    current = { t, end: t + phraseSeconds(pick.phrase, pace), phrase: pick.phrase, moment, contraction };
    if (moment === 'end') current.restDelayS = restTap !== null ? t - restTap : 0;
    played.push(current);
    return true;
  };

  const step = 0.25;
  const endT = (labor.at(-1)?.end ?? 0) + 120;
  let ci = 0;
  let active = false;
  let handled = -1;
  for (let t = 0; t <= endT; t += step) {
    if (current && t >= current.end) {
      lastEnded = current.end;
      current = null;
    }
    // The end phrase waiting for the previous phrase to finish or fade (same rule as the app).
    if (restTap !== null) {
      const d = pendingRest(t, restTap, !current, lastEnded);
      if (d !== 'wait') {
        if (d === 'play') say(t, 'end', 0, false, ci - 1);
        else stats.restsSkipped++;
        restTap = null;
      }
    }
    const c = labor[ci];
    if (!c) continue;
    if (!active && t >= c.start) {
      active = true;
      handled = -1;
      if (restTap !== null) stats.restsSkipped++;
      restTap = null;
      say(t, 'start', 0, true, ci, 'by-start-tap');
    } else if (active && t >= c.end) {
      active = false;
      const cur = current as Played | null;
      const tr = endTransition(cur ? cur.end - t : 0);
      if (c.end - c.start < MIN_ACK_CONTRACTION_S || freq === 'off') {
        // Mis-tap: nothing is said.
      } else if (tr === 'play-now') say(t, 'end', 0, true, ci, 'by-end-tap');
      else {
        if (tr === 'fade-then-play') {
          cur!.cut = 'faded-at-end';
          cur!.end = t + FADE_OUT_S;
        } else cur!.finishedAfterEndTap = true;
        restTap = t;
      }
      ci++;
    } else if (active && freq !== 'edges') {
      const elapsed = t - c.start;
      const d = nextSlot(freq, elapsed, handled, variationFor(c.start * 1000));
      if (d.kind === 'skip') handled = d.slot;
      else if (d.kind === 'play' && !current && t - lastEnded >= MIN_GAP_S) {
        handled = d.slot;
        say(t, 'mid', elapsed, false, ci);
      }
    }
  }
  return Object.assign(played, { restsSkipped: stats.restsSkipped });
}

export function report(script: CoachScript, mode: Mode, labor: Contraction[], played: Played[] & { restsSkipped?: number }) {
  const during = played.filter(p => p.moment === 'start' || p.moment === 'mid');
  const rests = played.filter(p => p.moment === 'end');
  const perContraction = labor.map((_, i) => during.filter(p => p.contraction === i).length);

  // Speaking time inside contractions vs rests.
  const spoken = (from: number, to: number) => played.reduce((s, p) => s + Math.max(0, Math.min(p.end, to) - Math.max(p.t, from)), 0);
  const contractionTime = labor.reduce((s, c) => s + (c.end - c.start), 0);
  const restTime = labor.slice(0, -1).reduce((s, c, i) => s + (labor[i + 1].start - c.end), 0);
  const talkInContractions = labor.reduce((s, c) => s + spoken(c.start, c.end), 0);
  const talkInRests = labor.slice(0, -1).reduce((s, c, i) => s + spoken(c.end, labor[i + 1].start), 0);

  // Busiest minute.
  let maxPerMinute = 0;
  for (const p of played) maxPerMinute = Math.max(maxPerMinute, played.filter(q => q.t >= p.t && q.t < p.t + 60).length);

  // Repeats.
  const byId = new Map<string, Played[]>();
  for (const p of played) byId.set(p.phrase.id, [...(byId.get(p.phrase.id) ?? []), p]);
  const gaps: number[] = [];
  const openerGapsContractions: number[] = [];
  for (const list of byId.values())
    for (let i = 1; i < list.length; i++) {
      gaps.push(list[i].t - list[i - 1].t);
      if (list[i].moment === 'start') openerGapsContractions.push(list[i].contraction - list[i - 1].contraction);
    }
  const backToBack = played.filter((p, i) => i > 0 && played[i - 1].phrase.id === p.phrase.id).length;

  const categories: Record<string, number> = {};
  for (const p of played) categories[p.phrase.category] = (categories[p.phrase.category] ?? 0) + 1;

  // Longest silence inside each rest (from end of resting phrase to next contraction).
  const restSilences = labor.slice(0, -1).map((c, i) => {
    const restPhrase = rests.find(p => p.contraction === i);
    return labor[i + 1].start - (restPhrase ? restPhrase.end : c.end);
  });

  const avg = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0);
  return {
    coach: script.slug,
    mode,
    contractions: labor.length,
    total: played.length,
    duringAvg: avg(perContraction),
    duringMax: Math.max(...perContraction),
    perContractionCounts: perContraction,
    restPhrasesPerRest: rests.length / labor.length,
    ackShare: rests.filter(p => p.phrase.category === 'ack').length / Math.max(1, rests.length),
    distinct: byId.size,
    maxPlaysOfOnePhrase: Math.max(...[...byId.values()].map(l => l.length)),
    minMinutesBetweenRepeats: gaps.length ? Math.min(...gaps) / 60 : null,
    avgMinutesBetweenRepeats: avg(gaps) / 60,
    openerRepeatEveryContractions: { min: Math.min(...openerGapsContractions), avg: avg(openerGapsContractions) },
    backToBack,
    categories,
    talkShareInContractions: talkInContractions / contractionTime,
    talkShareInRests: talkInRests / restTime,
    avgQuietAfterRestPhraseS: avg(restSilences),
    maxPhrasesInAnyMinute: maxPerMinute,
    cutByEndTap: played.filter(p => p.cut === 'by-end-tap' || p.cut === 'faded-at-end').length,
    cutByStartTap: played.filter(p => p.cut === 'by-start-tap').length,
    finishedAfterEndTap: played.filter(p => p.finishedAfterEndTap).length,
    restsSkipped: played.restsSkipped ?? 0,
    maxRestDelayS: Math.max(0, ...rests.map(p => p.restDelayS ?? 0)),
    openOnlyContractions: perContraction.filter((n, i) => n === 1 && labor[i].end - labor[i].start >= 45).length,
    longContractions: labor.filter(c => c.end - c.start >= 45).length,
    distinctSequences: new Set(labor.map((_, i) => played.filter(p => p.contraction === i).map(p => p.phrase.category).join('>'))).size,
  };
}
