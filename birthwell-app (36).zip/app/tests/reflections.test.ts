// Daily encouragement: Scripture accuracy, writing rules, and the daily rotation.
//   npm test
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, join } from 'node:path';
import { test } from 'node:test';
import { FAITH, GROUNDED, reflectionForDay, stageForWeek } from '../src/data/reflections.ts';

// ---- World English Bible lookup (dev-only package, not bundled into the app) ----
const require = createRequire(import.meta.url);
const webDir = join(dirname(require.resolve('world-english-bible/package.json')), 'json');
const books = new Map<string, { chapterNumber?: number; verseNumber?: number; value?: string }[]>();
function passage(ref: string) {
  const m = ref.match(/^(\d?\s?[A-Za-z ]+?)\s+(\d+):(\d+)(?:-(\d+))?$/);
  assert.ok(m, `bad reference ${ref}`);
  let book = m[1].toLowerCase().replace(/\s/g, '');
  if (book === 'psalm') book = 'psalms';
  if (!books.has(book)) books.set(book, JSON.parse(readFileSync(join(webDir, `${book}.json`), 'utf8')));
  const ch = Number(m[2]), v1 = Number(m[3]), v2 = Number(m[4] ?? m[3]);
  const text = books
    .get(book)!
    .filter(x => x.chapterNumber === ch && x.verseNumber !== undefined && x.verseNumber >= v1 && x.verseNumber <= v2 && x.value)
    .map(x => x.value)
    .join('');
  assert.ok(text.trim(), `no text for ${ref}`);
  return text;
}
// Compare ignoring case, quotation marks and spacing, with the divine name shown as "Lord"
// (WEB "Yahweh" → "the Lord"; "Lord Yahweh" → "Lord God"; vocative "the Lord," → "Lord,").
const norm = (t: string) =>
  t
    .replace(/\bLord Yahweh\b/g, 'Lord God')
    .replace(/\bYahweh\b/g, 'the Lord')
    .toLowerCase()
    .replace(/[“”"‘’']/g, '')
    .replace(/\bthe lord\b/g, 'lord')
    .replace(/\s+/g, ' ')
    .trim();
const stripEnds = (t: string) => t.replace(/^[\s.,;:!?]+|[\s.,;:!?]+$/g, '');

test('every Scripture quote matches the World English Bible exactly', () => {
  for (const r of FAITH) {
    assert.ok(r.ref, `missing reference: ${r.text}`);
    const source = norm(passage(r.ref!));
    let from = 0;
    for (const part of r.text.split('…')) {
      const p = stripEnds(norm(part));
      if (!p) continue;
      const at = source.indexOf(p, from);
      assert.ok(at >= 0, `${r.ref}: “${part.trim()}” is not in the WEB text: ${source}`);
      from = at + p.length;
    }
  }
});

test('the divine name is shown as “Lord”, never “Yahweh”', () => {
  for (const r of FAITH) assert.doesNotMatch(r.text, /Yahweh/, r.ref);
});

test('enough variety: ~120 or more per mode, with every stage covered', () => {
  for (const list of [GROUNDED, FAITH]) {
    assert.ok(list.length >= 120, `${list.length} entries`);
    for (const s of ['early', 'middle', 'late', 'birth', 'any'] as const) assert.ok(list.filter(r => r.stage === s).length >= 15, s);
    assert.equal(new Set(list.map(r => r.text)).size, list.length, 'duplicate entries');
  }
  assert.equal(new Set(FAITH.map(r => r.ref)).size, FAITH.length, 'a verse is used twice');
});

test('Grounded has no religious language; neither mode promises outcomes or pressures her', () => {
  const religious = /\b(God|Lord|Jesus|Christ|Holy Spirit|pray|prayer|grace|bless|blessed|amen|faith|Scripture)\b/i;
  for (const r of GROUNDED) assert.doesNotMatch(r.text, religious, r.text);
  const risky = /\b(be strong|be brave|stay strong|you must|painless|nothing will go wrong|everything will be (fine|okay)|safe(ly)? deliver|perfect birth)\b/i;
  for (const r of [...GROUNDED, ...FAITH]) assert.doesNotMatch(r.text, risky, r.text);
});

test('a new entry every day, matched to the stage, with no repeats for months', () => {
  for (const mode of ['sec', 'faith'] as const) {
    const days = Array.from({ length: 301 }, (_, d) => reflectionForDay(mode, d));
    // Stage-specific entries only appear in their stage.
    days.forEach((r, d) => r.stage === 'any' || assert.equal(r.stage, stageForWeek(Math.floor(d / 7)), `${mode} day ${d}`));
    // Nothing comes back within ten weeks.
    const lastSeen = new Map<object, number>();
    days.forEach((r, d) => {
      if (lastSeen.has(r)) assert.ok(d - lastSeen.get(r)! >= 70, `${mode} day ${d} repeats day ${lastSeen.get(r)}`);
      lastSeen.set(r, d);
    });
    // Same answer every time (stable across app launches).
    assert.equal(reflectionForDay(mode, 150), reflectionForDay(mode, 150));
  }
});
