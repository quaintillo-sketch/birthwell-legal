# BirthWell coaching scripts

Generated from `src/data/coaching.ts` by `npm run scripts:export`; edit that file, not this one.

Two complete libraries per coach, **Grounded** and **Faith-Centered**, 24 phrases each: 320 phrases in all. 51 lines work in both modes and share one recording (marked ↔), so **269 unique recordings** are needed. The **ID** is the audio filename (`assets/voices/<coach>/<id>.m4a`).

| Coach | Grounded | Faith-Centered | Shared | Unique recordings |
|---|---|---|---|---|
| Maren · the midwife | 24 | 24 | 10 | 54 |
| Jo · the best friend | 24 | 24 | 11 | 53 |
| Esme · the anchor | 24 | 24 | 10 | 54 |
| Ines · the poet | 24 | 24 | 10 | 54 |
| Della · the champion | 24 | 24 | 10 | 54 |

## Per mode, per coach

| Category | Phrases | When it plays |
|---|---|---|
| Beginning of a contraction | 5 | When “Contraction started” is tapped |
| Breathing & relaxing | 5 | Most of what the coach says during a contraction |
| Small encouragements | 4 | Sprinkled through a contraction, between breathing cues |
| Encouragement for hard moments | 4 | Now and then during a contraction, a little more often after ~30 seconds |
| Resting between contractions | 4 | Sometimes when “Contraction ended” is tapped, in place of the acknowledgment |
| Grounding & reassurance (Faith-Centered: reassurance & prayer) | 4 | Occasionally, during a contraction or when it ends |
| Voice preview | 1 | Coach picker and the Voice & sound panel |
| Volume test | 1 | When the coach volume is adjusted in Settings |
| End-of-contraction acknowledgment | 3 Grounded / 5 Faith-Centered | Most of the time when “Contraction ended” is tapped (on its own, never followed by another phrase) |

---

## Maren · the midwife

*Delivery (same voice in both modes):* Calm, practical, quietly certain. An experienced midwife: plain words, unhurried, warm but never sugary. In prayer, simple and sincere, never performed.

### Grounded

**Beginning of a contraction**

| ID | Phrase |
|---|---|
| `both-start-01` | Okay. Breathe in slowly… and let it out long. ↔ |
| `grounded-start-01` | I’m here. Soften your shoulders, and breathe. |
| `grounded-start-02` | Let’s meet this one together. Slow breath in. |
| `grounded-start-03` | Here’s a wave. Unclench your jaw, and breathe. |
| `grounded-start-04` | Easy now. Find a comfortable breath, and stay with it. |

**Breathing & relaxing**

| ID | Phrase |
|---|---|
| `both-breathe-01` | If it helps, let your out-breath be a little longer. ↔ |
| `both-breathe-02` | Unclench your hands. Let your fingers go loose. ↔ |
| `grounded-breathe-01` | Soften your jaw. Let your lips part. |
| `grounded-breathe-02` | Let your breath find whatever rhythm feels right. |
| `grounded-breathe-03` | Let your shoulders drop away from your ears. |

**Small encouragements**

| ID | Phrase |
|---|---|
| `both-affirm-01` | You’re doing well. ↔ |
| `both-affirm-02` | That’s it. Just like that. ↔ |
| `both-affirm-03` | Good. Stay with it. ↔ |
| `grounded-affirm-01` | You’re doing exactly what you need to. |

**Encouragement for hard moments**

| ID | Phrase |
|---|---|
| `grounded-encourage-01` | If it feels hard, that’s okay. You’re meeting it one breath at a time. |
| `grounded-encourage-02` | Stay with your breath. Just this wave. |
| `grounded-encourage-03` | Make whatever sound helps. Low and open. |
| `grounded-encourage-04` | For now, just focus on your next breath. |

**Resting between contractions**

| ID | Phrase |
|---|---|
| `grounded-rest-01` | That wave has passed. Let your whole body go heavy. |
| `grounded-rest-02` | Rest now. Have a sip of water if you’d like. |
| `grounded-rest-03` | Change position if you need to, then let yourself rest. |
| `grounded-rest-04` | Let your breathing find its own pace again. |

**Grounding & reassurance**

| ID | Phrase |
|---|---|
| `grounded-ground-01` | Feel where your body is supported, and let it hold you. |
| `grounded-ground-02` | Whatever you’re feeling right now is allowed. |
| `grounded-ground-03` | You don’t have to do this perfectly. There isn’t a perfect way. |
| `grounded-ground-04` | The people caring for you are here to help. Lean on them. |

**Voice preview**

| ID | Phrase |
|---|---|
| `grounded-preview-01` | I’m Maren. I’ll keep things calm and simple, one breath at a time. |

**Volume test**

| ID | Phrase |
|---|---|
| `both-volume-01` | This is how loud I’ll be. Adjust me until I feel comfortable. ↔ |

**End-of-contraction acknowledgment**

| ID | Phrase |
|---|---|
| `both-ack-01` | You did wonderfully. ↔ |
| `both-ack-02` | There you go. Beautifully done. ↔ |
| `both-ack-03` | You made it through that one. ↔ |

### Faith-Centered

**Beginning of a contraction**

| ID | Phrase |
|---|---|
| `both-start-01` | Okay. Breathe in slowly… and let it out long. ↔ |
| `faith-start-01` | I’m here, and so is Jesus. Soften your shoulders, and breathe. |
| `faith-start-02` | Let’s bring this one to God together. Slow breath in. |
| `faith-start-03` | Here’s a wave. Unclench your jaw, and breathe. Lord, be near. |
| `faith-start-04` | Lord Jesus, walk with me through this one. Slow breath in. |

**Breathing & relaxing**

| ID | Phrase |
|---|---|
| `both-breathe-01` | If it helps, let your out-breath be a little longer. ↔ |
| `both-breathe-02` | Unclench your hands. Let your fingers go loose. ↔ |
| `faith-breathe-01` | Soften your jaw, and breathe in His peace. |
| `faith-breathe-02` | Breathe at your own pace. Holy Spirit, steady me. |
| `faith-breathe-03` | Let your shoulders soften. Rest in His peace. |

**Small encouragements**

| ID | Phrase |
|---|---|
| `both-affirm-01` | You’re doing well. ↔ |
| `both-affirm-02` | That’s it. Just like that. ↔ |
| `both-affirm-03` | Good. Stay with it. ↔ |
| `faith-affirm-01` | You’re doing well, and you’re not alone in this. |

**Encouragement for hard moments**

| ID | Phrase |
|---|---|
| `faith-encourage-01` | You don’t have to find all the strength yourself. Lean on Jesus. |
| `faith-encourage-02` | Stay with your breath. His grace is enough for this wave. |
| `faith-encourage-03` | Lord Jesus, give me strength for this moment. |
| `faith-encourage-04` | Make whatever sound helps. God hears every one. |

**Resting between contractions**

| ID | Phrase |
|---|---|
| `faith-rest-01` | That wave has passed. Let your body go heavy, and rest in Him. |
| `faith-rest-02` | Thank You, Lord, for carrying me through that one. |
| `faith-rest-03` | Have a sip of water. Jesus is with you in the quiet, too. |
| `faith-rest-04` | Let your breathing settle. Jesus, stay with me in this rest. |

**Reassurance & prayer**

| ID | Phrase |
|---|---|
| `faith-ground-01` | Whatever you’re feeling is allowed. God understands all of it. |
| `faith-ground-02` | Lord, I give You this moment. Help me trust You with it. |
| `faith-ground-03` | You are His beloved, right now, exactly as you are. |
| `faith-ground-04` | “The Lord is my strength and my shield.” Let that be enough for now. |

**Voice preview**

| ID | Phrase |
|---|---|
| `faith-preview-01` | I’m Maren. I’ll keep things calm and simple, and I’ll pray with you as we go. |

**Volume test**

| ID | Phrase |
|---|---|
| `both-volume-01` | This is how loud I’ll be. Adjust me until I feel comfortable. ↔ |

**End-of-contraction acknowledgment**

| ID | Phrase |
|---|---|
| `both-ack-01` | You did wonderfully. ↔ |
| `both-ack-02` | There you go. Beautifully done. ↔ |
| `both-ack-03` | You made it through that one. ↔ |
| `faith-ack-01` | There you go. God is with you. |
| `faith-ack-02` | You did beautifully. Thank You, Jesus. |

---

## Jo · the best friend

*Delivery (same voice in both modes):* Warm, casual, gently funny. A best friend holding your hand: relaxed and affectionate, never jokey when things are hard. With Jesus, warm and sincere, never flippant.

### Grounded

**Beginning of a contraction**

| ID | Phrase |
|---|---|
| `both-start-01` | Okay, here we go. I’m right here with you. ↔ |
| `grounded-start-01` | Big breath with me. You and me, okay? |
| `grounded-start-02` | Alright, this one’s ours. Breathe with me. |
| `grounded-start-03` | Here comes a wave. Squeeze something if it helps, and breathe with me. |
| `grounded-start-04` | Okay, love. Find your breath. I’m with you. |

**Breathing & relaxing**

| ID | Phrase |
|---|---|
| `both-breathe-01` | Breathe in… and let it all out. ↔ |
| `both-breathe-02` | Breathe with me. Slow in… slower out. ↔ |
| `grounded-breathe-01` | Shoulders down, love. There you go. |
| `grounded-breathe-02` | Loosen your grip a little. You don’t have to hold on so tight. |
| `grounded-breathe-03` | Let your face go soft. Yep, even your forehead. |

**Small encouragements**

| ID | Phrase |
|---|---|
| `both-affirm-01` | You’re doing so good. ↔ |
| `both-affirm-02` | Yes. That’s it. ↔ |
| `both-affirm-03` | Look at you go. ↔ |
| `grounded-affirm-01` | You’ve so got this. |

**Encouragement for hard moments**

| ID | Phrase |
|---|---|
| `grounded-encourage-01` | Breathe through this wave with me. I’ve got you. |
| `grounded-encourage-02` | You’re doing this. You’re really doing it. |
| `grounded-encourage-03` | It’s okay if this feels hard. Just take the next breath. I’m right here. |
| `grounded-encourage-04` | Breathe it out. You don’t have to be quiet about it. |

**Resting between contractions**

| ID | Phrase |
|---|---|
| `both-rest-01` | Have a sip of water. Seriously, I’ll wait. ↔ |
| `grounded-rest-01` | Phew. That wave’s behind you. Shake it out. |
| `grounded-rest-02` | Okay, breathe however feels good. This bit is yours. |
| `grounded-rest-03` | Get comfy. Pillow, blanket, whatever you need. |

**Grounding & reassurance**

| ID | Phrase |
|---|---|
| `grounded-ground-01` | You can ask for anything. Ice chips, quiet, a hand to squeeze. |
| `grounded-ground-02` | There’s no wrong way to do this. Do whatever helps. |
| `grounded-ground-03` | However this goes, you’re doing something incredible. |
| `grounded-ground-04` | I’m right here with you, every step of the way. |

**Voice preview**

| ID | Phrase |
|---|---|
| `grounded-preview-01` | Hi, I’m Jo. Think of me as your best friend in the room. |

**Volume test**

| ID | Phrase |
|---|---|
| `both-volume-01` | Can you hear me okay? This is how loud I’ll be. ↔ |

**End-of-contraction acknowledgment**

| ID | Phrase |
|---|---|
| `both-ack-01` | You did it! ↔ |
| `both-ack-02` | There you go. That was wonderful. ↔ |
| `both-ack-03` | Another one behind you! ↔ |

### Faith-Centered

**Beginning of a contraction**

| ID | Phrase |
|---|---|
| `both-start-01` | Okay, here we go. I’m right here with you. ↔ |
| `faith-start-01` | Big breath with me. Jesus is right here, and so am I. |
| `faith-start-02` | Alright, let’s give this one to God. Breathe with me. |
| `faith-start-03` | Here comes a wave. Jesus, be near. Breathe with me. |
| `faith-start-04` | Okay, love. Find your breath. You’re held in God’s love. |

**Breathing & relaxing**

| ID | Phrase |
|---|---|
| `both-breathe-01` | Breathe in… and let it all out. ↔ |
| `both-breathe-02` | Breathe with me. Slow in… slower out. ↔ |
| `faith-breathe-01` | Shoulders down, love. Let His peace in. |
| `faith-breathe-02` | Loosen your grip. You don’t have to hold on so tight. He’s holding you. |
| `faith-breathe-03` | Let your face go soft, and breathe in God’s peace. |

**Small encouragements**

| ID | Phrase |
|---|---|
| `both-affirm-01` | You’re doing so good. ↔ |
| `both-affirm-02` | Yes. That’s it. ↔ |
| `both-affirm-03` | Look at you go. ↔ |
| `faith-affirm-01` | You’re doing amazing, friend. God’s got you. |

**Encouragement for hard moments**

| ID | Phrase |
|---|---|
| `faith-encourage-01` | Lean on Jesus, and lean on me. You don’t have to carry this alone. |
| `faith-encourage-02` | Pray with me: Jesus, stay close. Give me peace and courage. |
| `faith-encourage-03` | It’s okay if this feels really hard. Jesus is right here with you. |
| `faith-encourage-04` | One wave at a time, friend. His grace is enough for this one. |

**Resting between contractions**

| ID | Phrase |
|---|---|
| `both-rest-01` | Have a sip of water. Seriously, I’ll wait. ↔ |
| `faith-rest-01` | Phew. Thank You, Jesus, for getting us through that wave. |
| `faith-rest-02` | Get comfy. Jesus, carry some of this for me for a while. |
| `faith-rest-03` | Breathe however feels good. He’s in this quiet bit, too. |

**Reassurance & prayer**

| ID | Phrase |
|---|---|
| `faith-ground-01` | You can ask for anything. Ice chips, quiet, a hand to squeeze, a prayer. |
| `faith-ground-02` | “She is clothed with strength and dignity.” That’s you, friend. |
| `faith-ground-03` | However this goes, you are so loved by God. And by me. |
| `faith-ground-04` | Holy Spirit, fill this room with Your peace. |

**Voice preview**

| ID | Phrase |
|---|---|
| `faith-preview-01` | Hi, I’m Jo. Think of me as your best friend in the room, praying right alongside you. |

**Volume test**

| ID | Phrase |
|---|---|
| `both-volume-01` | Can you hear me okay? This is how loud I’ll be. ↔ |

**End-of-contraction acknowledgment**

| ID | Phrase |
|---|---|
| `both-ack-01` | You did it! ↔ |
| `both-ack-02` | There you go. That was wonderful. ↔ |
| `both-ack-03` | Another one behind you! ↔ |
| `faith-ack-01` | You did it! Praise God. |
| `faith-ack-02` | There you go. Jesus is with you. |

---

## Esme · the anchor

*Delivery (same voice in both modes):* Deep, slow, grounded. Very few words with long, comfortable pauses. Steady as stone; never rushed, never bright. Prayer is quiet and still, almost whispered.

### Grounded

**Beginning of a contraction**

| ID | Phrase |
|---|---|
| `both-start-01` | Breathe in… and down. ↔ |
| `grounded-start-01` | I’m here. Heavy, and slow. |
| `grounded-start-02` | Find your support. Take a gentle breath. |
| `grounded-start-03` | A wave. Let it come… and breathe. |
| `grounded-start-04` | Still. Soft. Breathe. |

**Breathing & relaxing**

| ID | Phrase |
|---|---|
| `both-breathe-01` | Long breath out… all the way. ↔ |
| `both-breathe-02` | Slow… slower still. ↔ |
| `grounded-breathe-01` | Let your breath sink low. |
| `grounded-breathe-02` | Heavy shoulders. Heavy arms. |
| `grounded-breathe-03` | Let the floor take your weight. |

**Small encouragements**

| ID | Phrase |
|---|---|
| `both-affirm-01` | Good. ↔ |
| `both-affirm-02` | Yes… like that. ↔ |
| `both-affirm-03` | Steady. You’re doing it. ↔ |
| `grounded-affirm-01` | Soft. Steady. Good. |

**Encouragement for hard moments**

| ID | Phrase |
|---|---|
| `grounded-encourage-01` | Stay. Breathe. I’m here. |
| `grounded-encourage-02` | Nothing to fix. Just breathe. |
| `grounded-encourage-03` | Underneath all this, you are steady. |
| `grounded-encourage-04` | Let this wave be what it is. You can be still inside it. |

**Resting between contractions**

| ID | Phrase |
|---|---|
| `grounded-rest-01` | The wave has passed. Be still now. |
| `grounded-rest-02` | Rest. Let the ground hold you. |
| `grounded-rest-03` | Quiet now. Breathe however you like. |
| `grounded-rest-04` | Soft hands. Soft face. Rest. |

**Grounding & reassurance**

| ID | Phrase |
|---|---|
| `grounded-ground-01` | Feel the weight of your body. You are here. |
| `grounded-ground-02` | Notice one thing you can touch. Stay with it. |
| `grounded-ground-03` | This moment is the only one you need to meet. |
| `grounded-ground-04` | Rooted. Present. Here. |

**Voice preview**

| ID | Phrase |
|---|---|
| `grounded-preview-01` | I’m Esme. I’ll speak slowly, and I won’t fill the quiet. |

**Volume test**

| ID | Phrase |
|---|---|
| `both-volume-01` | This is my voice. Make it as soft as you need. ↔ |

**End-of-contraction acknowledgment**

| ID | Phrase |
|---|---|
| `both-ack-01` | Beautifully done. ↔ |
| `both-ack-02` | There you go. Now rest. ↔ |
| `both-ack-03` | You made it through. ↔ |

### Faith-Centered

**Beginning of a contraction**

| ID | Phrase |
|---|---|
| `both-start-01` | Breathe in… and down. ↔ |
| `faith-start-01` | I’m here. God is here. Slow. |
| `faith-start-02` | Find your support. Rest in Him. |
| `faith-start-03` | A wave. Jesus… stay near. |
| `faith-start-04` | Still. Soft. You are held. |

**Breathing & relaxing**

| ID | Phrase |
|---|---|
| `both-breathe-01` | Long breath out… all the way. ↔ |
| `both-breathe-02` | Slow… slower still. ↔ |
| `faith-breathe-01` | Let your breath sink low… into His peace. |
| `faith-breathe-02` | Heavy shoulders. You are held. |
| `faith-breathe-03` | Let the floor take your weight. Lord, carry what I can’t. |

**Small encouragements**

| ID | Phrase |
|---|---|
| `both-affirm-01` | Good. ↔ |
| `both-affirm-02` | Yes… like that. ↔ |
| `both-affirm-03` | Steady. You’re doing it. ↔ |
| `faith-affirm-01` | Good. You are held. |

**Encouragement for hard moments**

| ID | Phrase |
|---|---|
| `faith-encourage-01` | Stay. Breathe. Christ is near. |
| `faith-encourage-02` | Jesus… be my peace. |
| `faith-encourage-03` | Underneath all this, His love holds steady. |
| `faith-encourage-04` | Be still inside this wave. You are not alone in it. |

**Resting between contractions**

| ID | Phrase |
|---|---|
| `faith-rest-01` | The wave has passed. Be still, and rest in Him. |
| `faith-rest-02` | Thank You, Lord… for this quiet. |
| `faith-rest-03` | Rest. Holy Spirit… settle over me. |
| `faith-rest-04` | Soft hands. Soft face. Breathe in grace. |

**Reassurance & prayer**

| ID | Phrase |
|---|---|
| `faith-ground-01` | “Be still, and know that I am God.” Rest in that. |
| `faith-ground-02` | Lord, I am here. You are here. That is enough. |
| `faith-ground-03` | Feel the weight of your body. Let God hold all of it. |
| `faith-ground-04` | Come, Holy Spirit. Fill this room with stillness. |

**Voice preview**

| ID | Phrase |
|---|---|
| `faith-preview-01` | I’m Esme. I’ll speak slowly, leave room for quiet, and rest in God with you. |

**Volume test**

| ID | Phrase |
|---|---|
| `both-volume-01` | This is my voice. Make it as soft as you need. ↔ |

**End-of-contraction acknowledgment**

| ID | Phrase |
|---|---|
| `both-ack-01` | Beautifully done. ↔ |
| `both-ack-02` | There you go. Now rest. ↔ |
| `both-ack-03` | You made it through. ↔ |
| `faith-ack-01` | Beautifully done. Rest in Him. |
| `faith-ack-02` | There you go. Thank You, Lord. |

---

## Ines · the poet

*Delivery (same voice in both modes):* Gentle and unhurried, with simple imagery of water and air. Soft-spoken, clear and concrete, never flowery. Contemplative in prayer, like speaking in a quiet chapel.

### Grounded

**Beginning of a contraction**

| ID | Phrase |
|---|---|
| `both-start-01` | Open your hands, and breathe. ↔ |
| `grounded-start-01` | Here’s a wave. Breathe with it. |
| `grounded-start-02` | Let it come. Your breath goes with it. |
| `grounded-start-03` | Breathe gently through this wave. |
| `grounded-start-04` | Let your breath be soft, like air through an open window. |

**Breathing & relaxing**

| ID | Phrase |
|---|---|
| `both-breathe-01` | Soften your belly, and let your breath be easy. ↔ |
| `both-breathe-02` | With each breath out, let a little more go. ↔ |
| `grounded-breathe-01` | Breathe out slowly, like a tide going out. |
| `grounded-breathe-02` | Let your breath move like water. Nothing held. |
| `grounded-breathe-03` | Just follow your breath, wherever it goes. |

**Small encouragements**

| ID | Phrase |
|---|---|
| `both-affirm-01` | That’s it, gently. ↔ |
| `both-affirm-02` | You’re doing beautifully. ↔ |
| `both-affirm-03` | Just like that… easy. ↔ |
| `grounded-affirm-01` | You’re moving with it so well. |

**Encouragement for hard moments**

| ID | Phrase |
|---|---|
| `grounded-encourage-01` | You can rest inside this breath, even now. |
| `grounded-encourage-02` | You don’t need to hold back the wave. Let it move through you. |
| `grounded-encourage-03` | Soft shoulders, soft hands. Nothing to hold on to. |
| `grounded-encourage-04` | Let the sound of your breath carry you. |

**Resting between contractions**

| ID | Phrase |
|---|---|
| `grounded-rest-01` | That wave has passed. Let yourself float for a while. |
| `grounded-rest-02` | Breathe into the quiet. |
| `grounded-rest-03` | Let the stillness settle over you. |
| `grounded-rest-04` | Let your body be heavy, like warm sand. |

**Grounding & reassurance**

| ID | Phrase |
|---|---|
| `grounded-ground-01` | Notice the air on your skin, and the light in the room. |
| `grounded-ground-02` | Nothing to hurry toward. Just this breath. |
| `grounded-ground-03` | Let anything you’re carrying wait outside the door for now. |
| `grounded-ground-04` | You don’t need to figure anything out right now. |

**Voice preview**

| ID | Phrase |
|---|---|
| `grounded-preview-01` | I’m Ines. I’ll guide you with gentle pictures and slow, steady breath. |

**Volume test**

| ID | Phrase |
|---|---|
| `both-volume-01` | This is how I’ll sound. Let my voice sit just above the quiet. ↔ |

**End-of-contraction acknowledgment**

| ID | Phrase |
|---|---|
| `both-ack-01` | You did beautifully. ↔ |
| `both-ack-02` | There you go. The wave has passed. ↔ |
| `both-ack-03` | Beautiful. Now take your rest. ↔ |

### Faith-Centered

**Beginning of a contraction**

| ID | Phrase |
|---|---|
| `both-start-01` | Open your hands, and breathe. ↔ |
| `faith-start-01` | Here’s a wave. Breathe with it, and let God hold you. |
| `faith-start-02` | Let it come. Holy Spirit, be near me now. |
| `faith-start-03` | Jesus, hold me gently through this wave. |
| `faith-start-04` | Let your breath be soft. The Lord is near. |

**Breathing & relaxing**

| ID | Phrase |
|---|---|
| `both-breathe-01` | Soften your belly, and let your breath be easy. ↔ |
| `both-breathe-02` | With each breath out, let a little more go. ↔ |
| `faith-breathe-01` | Breathe out slowly, like a tide going out. Let it carry anything heavy to Him. |
| `faith-breathe-02` | Let your breath move like water. His peace is flowing in. |
| `faith-breathe-03` | Breathe in grace. Let the rest go. |

**Small encouragements**

| ID | Phrase |
|---|---|
| `both-affirm-01` | That’s it, gently. ↔ |
| `both-affirm-02` | You’re doing beautifully. ↔ |
| `both-affirm-03` | Just like that… easy. ↔ |
| `faith-affirm-01` | Gently now. You are held in love. |

**Encouragement for hard moments**

| ID | Phrase |
|---|---|
| `faith-encourage-01` | You can rest in Jesus, even inside this breath. |
| `faith-encourage-02` | Lord, be my calm in the middle of this wave. |
| `faith-encourage-03` | You don’t need to hold it back. Let it move through you, held by love. |
| `faith-encourage-04` | His grace is wide enough to hold this moment. |

**Resting between contractions**

| ID | Phrase |
|---|---|
| `faith-rest-01` | It’s eased. Let His peace wash over you, slow and quiet. |
| `faith-rest-02` | Thank You, Jesus, for every breath that brought me here. |
| `faith-rest-03` | Let the stillness settle. The Holy Spirit is near. |
| `faith-rest-04` | Let your body be heavy, held in His hands. |

**Reassurance & prayer**

| ID | Phrase |
|---|---|
| `faith-ground-01` | “He leads me beside still waters.” Rest there a moment. |
| `faith-ground-02` | Jesus, I give You whatever I’m carrying. Hold it for me. |
| `faith-ground-03` | “I praise You, for I am fearfully and wonderfully made.” |
| `faith-ground-04` | Holy Spirit, breathe Your peace into me. |

**Voice preview**

| ID | Phrase |
|---|---|
| `faith-preview-01` | I’m Ines. I’ll guide you with gentle pictures, slow breath, and quiet prayer. |

**Volume test**

| ID | Phrase |
|---|---|
| `both-volume-01` | This is how I’ll sound. Let my voice sit just above the quiet. ↔ |

**End-of-contraction acknowledgment**

| ID | Phrase |
|---|---|
| `both-ack-01` | You did beautifully. ↔ |
| `both-ack-02` | There you go. The wave has passed. ↔ |
| `both-ack-03` | Beautiful. Now take your rest. ↔ |
| `faith-ack-01` | There you go. Rest in His love. |
| `faith-ack-02` | You did beautifully. God is near. |

---

## Della · the champion

*Delivery (same voice in both modes):* Bright, confident and direct, with real warmth. Believes in you completely; encouraging, never loud or pushy, and never treats labor as a battle. Speaks of faith with joyful conviction, not preaching.

### Grounded

**Beginning of a contraction**

| ID | Phrase |
|---|---|
| `both-start-01` | Let’s breathe through this one together. ↔ |
| `grounded-start-01` | Here we go. Breathe with me. |
| `grounded-start-02` | I’m with you. Find your breath. |
| `grounded-start-03` | Here comes a wave. Shoulders down, and breathe. |
| `grounded-start-04` | I’m right beside you. Easy breath in. |

**Breathing & relaxing**

| ID | Phrase |
|---|---|
| `both-breathe-01` | Lips loose, shoulders down. Good. ↔ |
| `both-breathe-02` | Find your rhythm, and stay with it. ↔ |
| `grounded-breathe-01` | Big breath in… and let it all go. |
| `grounded-breathe-02` | Keep your breath steady. That’s it. |
| `grounded-breathe-03` | Breathe out slow and full. |

**Small encouragements**

| ID | Phrase |
|---|---|
| `both-affirm-01` | You’re doing great. ↔ |
| `both-affirm-02` | That’s it. Nice and steady. ↔ |
| `both-affirm-03` | Look at you. You’re doing it. ↔ |
| `grounded-affirm-01` | You’ve got this. I believe in you. |

**Encouragement for hard moments**

| ID | Phrase |
|---|---|
| `grounded-encourage-01` | One breath, then the next. I’m with you. |
| `grounded-encourage-02` | That’s it. Keep going. I’m right here. |
| `grounded-encourage-03` | You don’t have to be brave. Just breathe. |
| `grounded-encourage-04` | Breathe into this wave. You’re meeting it one breath at a time. |

**Resting between contractions**

| ID | Phrase |
|---|---|
| `grounded-rest-01` | That wave’s behind you. Breathe easy. |
| `grounded-rest-02` | Nicely done. Let your body rest. |
| `grounded-rest-03` | Take a moment for you. Water, a stretch, whatever helps. |
| `grounded-rest-04` | Reset. Roll your shoulders, and soften. |

**Grounding & reassurance**

| ID | Phrase |
|---|---|
| `grounded-ground-01` | Notice what you need right now, and let yourself have it. |
| `grounded-ground-02` | You can ask for what you need. No apologies. |
| `grounded-ground-03` | You’re surrounded by support, and I’m part of it. |
| `grounded-ground-04` | However today unfolds, you are doing something powerful. |

**Voice preview**

| ID | Phrase |
|---|---|
| `grounded-preview-01` | I’m Della. I’ll bring steady, upbeat encouragement and stay right beside you. |

**Volume test**

| ID | Phrase |
|---|---|
| `both-volume-01` | Here’s how loud I’ll be. Turn me up or down until it feels right. ↔ |

**End-of-contraction acknowledgment**

| ID | Phrase |
|---|---|
| `both-ack-01` | Yes! You did it! ↔ |
| `both-ack-02` | Look at you. Beautifully done! ↔ |
| `both-ack-03` | There you go! You did wonderfully. ↔ |

### Faith-Centered

**Beginning of a contraction**

| ID | Phrase |
|---|---|
| `both-start-01` | Let’s breathe through this one together. ↔ |
| `faith-start-01` | Here we go. Breathe with me. The Lord is your strength. |
| `faith-start-02` | I’m with you, and so is Jesus. Find your breath. |
| `faith-start-03` | Here comes a wave. Lord, fill me with Your peace. |
| `faith-start-04` | Shoulders down. Breathe in His strength. |

**Breathing & relaxing**

| ID | Phrase |
|---|---|
| `both-breathe-01` | Lips loose, shoulders down. Good. ↔ |
| `both-breathe-02` | Find your rhythm, and stay with it. ↔ |
| `faith-breathe-01` | Big breath in… and give it all to God. |
| `faith-breathe-02` | Keep your breath steady. He’s steady too. |
| `faith-breathe-03` | Breathe out slow and full. Rest in His power. |

**Small encouragements**

| ID | Phrase |
|---|---|
| `both-affirm-01` | You’re doing great. ↔ |
| `both-affirm-02` | That’s it. Nice and steady. ↔ |
| `both-affirm-03` | Look at you. You’re doing it. ↔ |
| `faith-affirm-01` | You’re doing great. The Lord is your strength. |

**Encouragement for hard moments**

| ID | Phrase |
|---|---|
| `faith-encourage-01` | Christ strengthens you for whatever this moment holds. |
| `faith-encourage-02` | You don’t have to be brave. Just breathe, and let Him be your strength. |
| `faith-encourage-03` | Lord Jesus, give me courage for this moment. |
| `faith-encourage-04` | That’s it. Breathe through this wave. God is right here in it with you. |

**Resting between contractions**

| ID | Phrase |
|---|---|
| `faith-rest-01` | That wave’s behind you. Thank You, Lord, for Your strength. |
| `faith-rest-02` | Nicely done. Rest now, and receive His peace. |
| `faith-rest-03` | Take a moment for you. Water, a stretch, a quiet prayer. |
| `faith-rest-04` | Reset. Holy Spirit, renew me. |

**Reassurance & prayer**

| ID | Phrase |
|---|---|
| `faith-ground-01` | Lord, You are my strength. I’m leaning on You right now. |
| `faith-ground-02` | You can ask for what you need. No apologies. God sees you. |
| `faith-ground-03` | However today unfolds, you and your baby are surrounded by God’s love. |
| `faith-ground-04` | Holy Spirit, fill me with courage and calm. |

**Voice preview**

| ID | Phrase |
|---|---|
| `faith-preview-01` | I’m Della. I’ll bring steady, faith-filled encouragement and stay right beside you. |

**Volume test**

| ID | Phrase |
|---|---|
| `both-volume-01` | Here’s how loud I’ll be. Turn me up or down until it feels right. ↔ |

**End-of-contraction acknowledgment**

| ID | Phrase |
|---|---|
| `both-ack-01` | Yes! You did it! ↔ |
| `both-ack-02` | Look at you. Beautifully done! ↔ |
| `both-ack-03` | There you go! You did wonderfully. ↔ |
| `faith-ack-01` | You did it! Thank You, Jesus! |
| `faith-ack-02` | Yes! God’s right here with you! |

---

## Scripture in the Faith-Centered library

Every quotation and close paraphrase, checked for wording, attribution and context. Psalm 46:5 (“God is within her; she will not fall”) has been removed: it describes the city of God, not a person.

| Coach | ID | Phrase | Reference | Context and use |
|---|---|---|---|---|
| maren | `faith-encourage-02` | Stay with your breath. His grace is enough for this wave. | 2 Corinthians 12:9 (allusion) | “My grace is sufficient for you, for my power is made perfect in weakness.” Alluded to (“His grace is enough”) as comfort in hard moments, not a promise of ease. |
| maren | `faith-ground-04` | “The Lord is my strength and my shield.” Let that be enough for now. | Psalm 28:7 | David’s psalm of trust: “The Lord is my strength and my shield; my heart trusts in him, and he helps me.” Quoted as a statement of trust, not a promise about outcome. |
| jo | `faith-encourage-04` | One wave at a time, friend. His grace is enough for this one. | 2 Corinthians 12:9 (allusion) | “My grace is sufficient for you, for my power is made perfect in weakness.” Alluded to (“His grace is enough”) as comfort in hard moments, not a promise of ease. |
| jo | `faith-ground-02` | “She is clothed with strength and dignity.” That’s you, friend. | Proverbs 31:25 | From the portrait of a woman of strong character. Only the first half is quoted; “she laughs at the days to come” is left out so nothing implies how labor will go. |
| esme | `faith-ground-01` | “Be still, and know that I am God.” Rest in that. | Psalm 46:10 | God’s call to stillness amid upheaval: “Be still, and know that I am God.” Used as an invitation to rest in God, the way it is commonly prayed devotionally. |
| ines | `faith-encourage-04` | His grace is wide enough to hold this moment. | 2 Corinthians 12:9 (allusion) | “My grace is sufficient for you, for my power is made perfect in weakness.” Alluded to (“His grace is enough”) as comfort in hard moments, not a promise of ease. |
| ines | `faith-ground-01` | “He leads me beside still waters.” Rest there a moment. | Psalm 23:2 | The shepherd psalm: “He leads me beside still waters.” Used for rest and comfort. |
| ines | `faith-ground-03` | “I praise You, for I am fearfully and wonderfully made.” | Psalm 139:14 | Quoted accurately in the first person, as the psalmist prays it: “I praise You, for I am fearfully and wonderfully made.” |
| della | `faith-start-01` | Here we go. Breathe with me. The Lord is your strength. | Psalm 28:7 (allusion) | David’s psalm of trust: “The Lord is my strength and my shield; my heart trusts in him, and he helps me.” Quoted as a statement of trust, not a promise about outcome. |
| della | `faith-encourage-01` | Christ strengthens you for whatever this moment holds. | Philippians 4:13 (paraphrase) | Paul writes about being content and sustained in every circumstance, plenty or need. Paraphrased as strength “for whatever this moment holds”, which is closer to Paul’s meaning than the common “achieve anything” reading. Not quoted. |
