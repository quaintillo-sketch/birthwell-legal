# Meditation hosting: Supabase setup

The meditations aren't built into the app. They're stored in Supabase, and the app downloads them.

- **Free weeks (6, 21 and 36)** are in a public folder that anyone with the app can download.
- **Premium weeks** are in a private folder. To play one, the app asks a small Supabase function for a temporary link. That function first checks with RevenueCat that this person bought Premium.
- Each week is saved on the phone after downloading, so it plays offline. If a recording is redone later, phones fetch the new one automatically.

You'll do steps 1 to 5 once, which takes about 20 minutes. Step 6 is repeated each time new recordings are approved.

**Keys at a glance.** You'll handle three keys. None of them goes in a chat or email.

| Key | Where it lives | Secret? |
|---|---|---|
| Supabase project URL | the app's `.env` | No, it's fine in the app |
| Supabase **secret** key (`sb_secret_…`) | only typed into Terminal when uploading | **Yes** |
| RevenueCat **secret** key (`sk_…`) | only in Supabase → Edge Functions → Secrets | **Yes** |

---

## 1. Create the project

1. Go to **supabase.com** and sign in (or sign up; the Free plan is enough to start).
2. Click **New project**. Name it **BirthWell**, choose a strong database password (save it in your password manager; you won't need it for this), and pick the region closest to most of your users (for example, *East US*).
3. Wait a minute or two while it sets up.

## 2. Create the two storage folders ("buckets")

In the left menu, go to **Storage**, then **New bucket**.

1. Name it `meditations-free`. Turn **Public bucket ON**. Click **Create**.
2. Click **New bucket** again. Name it `meditations`. Leave **Public bucket OFF**. Click **Create**.

The names must be exactly as written, lowercase, with the dash. You don't need to make any folders inside them; the upload creates them.

> The upload script double-checks this. If `meditations` were ever public, it stops and uploads nothing.

## 3. Add the Premium check (the "meditation-url" function)

1. In the left menu, go to **Edge Functions**, then **Deploy a new function**, then **Via Editor**.
2. Name it exactly `meditation-url`.
3. Delete the sample code. Open `supabase/functions/meditation-url/index.ts` from the `birthwell` folder (TextEdit is fine), copy all of it, and paste it in.
4. Click **Deploy function**.
5. Open the function's **Details** (or **Settings**) tab, and turn **Verify JWT** (sometimes called "Enforce JWT verification") **OFF**. Save.
   The app has no Supabase login, so this has to be off. The function does its own check with RevenueCat instead.

## 4. Add the secrets

In **Edge Functions**, go to **Secrets**, and add:

| Name | Value |
|---|---|
| `REVENUECAT_SECRET_KEY` | Your RevenueCat secret key. In RevenueCat, go to your project, then **API keys**, then **+ New secret API key**. Name it "Supabase meditations" and choose **V1**. It starts with `sk_`. |
| `MEDITATION_PREVIEW_CODE` | *Only for testing in Expo Go.* A long random code. On your Mac, run `openssl rand -hex 16` and copy what it prints. |

If RevenueCat isn't set up yet, add just the preview code for now and come back for the RevenueCat key (see `docs/premium-setup.md`).

## 5. Connect the app

1. In Supabase, go to **Project Settings**, then **Data API** (or **API**), and copy the **Project URL**. It looks like `https://abcd1234.supabase.co`.
2. Open the `.env` file in the `birthwell` folder. If you don't have one, copy `.env.example` and name the copy `.env`. Add these two lines (with your URL and the same preview code as in step 4):
   ```
   EXPO_PUBLIC_SUPABASE_URL=https://abcd1234.supabase.co
   EXPO_PUBLIC_MEDITATION_PREVIEW_CODE=paste-the-preview-code-here
   ```
3. Restart the app (`npx expo start --tunnel`).

## 6. Upload recordings (each time a batch is approved)

Only upload weeks you've listened to and approved. In Terminal:

```
cd ~/birthwell
read -rs SUPABASE_SECRET_KEY && export SUPABASE_SECRET_KEY
```

Then paste your Supabase **secret** key and press Return. Nothing shows while you paste; that's normal. To find the key, go to **Project Settings**, then **API Keys**, then **Secret keys**, and copy the key that starts with `sb_secret_`. Don't use the "publishable" key.

```
npm run meditations:upload
```

It lists every finished meditation as *new*, *changed* or *already uploaded*, and marks each one free or Premium. Type `yes` and press Return to upload. To upload only some weeks, add `-- --week 8-20`.

- Running it again is safe: only new or changed recordings are uploaded.
- If you redo a paragraph and re-assemble a week, run this again. Phones that already downloaded that week get the new version the next time Home opens on Wi‑Fi.
- The key is never shown or saved, and it's forgotten when you close Terminal.

## 7. Check it in the app

- **A free week:** set your due date so it's week 6, 21 or 36 (or open that week from the meditation list), then play it.
- **A Premium week in Expo Go:** in Settings, turn on simulated Premium, then play any uploaded Premium week. This works because of the preview code.
- **On a real iPhone build (TestFlight):** buy Premium with a sandbox account and play a Premium week. This is the real RevenueCat check.

## Before launch

- [ ] In Supabase → Edge Functions → Secrets, **delete `MEDITATION_PREVIEW_CODE`**. This turns off the testing shortcut everywhere, even if the code is still in an old build.
- [ ] Remove the `EXPO_PUBLIC_MEDITATION_PREVIEW_CODE` line from `.env` before making the App Store build.
- [ ] `REVENUECAT_SECRET_KEY` is set, and a TestFlight purchase plays a Premium week.
- [ ] All 74 meditations are uploaded: running `npm run meditations:upload` reports everything as *already uploaded*.

---

## How it works (technical)

- **Layout.** Files live at `maren/faith/week-07.m4a` (Faith-centered) and `maren/secular/week-07.m4a` (Grounded). Free weeks go in `meditations-free` (public) and every other week in `meditations` (private). Which weeks are free comes from `FREE_MEDITATION_WEEKS` in `src/config/premium.ts`. If that list changes, the next upload moves the affected files to the right bucket.
- **Manifest.** `meditations-free/manifest.json` lists every uploaded file with its path, a revision code, its length in seconds, its size, and whether it's free. The app only offers weeks that are listed. When a file's revision changes, phones re-download it.
- **Free download:** `…/storage/v1/object/public/meditations-free/<path>?v=<rev>`.
- **Premium download.** The app sends `POST /functions/v1/meditation-url` with `{ week, version, appUserId }`, where `appUserId` is RevenueCat's anonymous customer ID. The function:
  1. looks up that customer with RevenueCat's REST API (`GET /v1/subscribers/{id}`) and requires an active `premium` entitlement;
  2. builds the file path itself (it never accepts a path from the app);
  3. returns a signed link that's valid for 6 hours.

  After a refund, RevenueCat removes the entitlement, and new links are refused.
- **On the phone.** Downloads are saved in the app's documents folder, with a `week-07.rev` note recording which revision they are. Home downloads this week's meditation on Wi‑Fi (Settings › Meditations › Download on Wi‑Fi). The player uses the downloaded copy first, then streams. If neither works within about 10 seconds, it plays the placeholder.
- **Code.**
  - `src/lib/meditationHosting.ts`: addresses and manifest rules (tested).
  - `src/lib/meditations.ts`: downloading and playback sources.
  - `supabase/functions/meditation-url/index.ts`: the Premium check (tested).
  - `scripts/meditation-upload.mjs`: uploads.
  - `tests/hosting.test.ts`: the tests.
