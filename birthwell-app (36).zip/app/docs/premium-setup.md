# BirthWell Premium: App Store and RevenueCat setup

BirthWell Premium is a **non-consumable in-app purchase**: $11.99, paid once, never expires, restorable on any device signed in with the same Apple ID. The app code is ready. These steps connect it to Apple. Only you can do them, because they need your Apple and RevenueCat accounts.

**Status:** the purchase flow has been tested with the simulated store only. It is **not** confirmed working with real Apple purchases until step 7 (sandbox testing) passes.

---

## 1. Apple Developer Program

- Join at developer.apple.com/programs ($99 a year). It's required for in-app purchases, TestFlight and the App Store.
- **Bundle ID:** the app uses `com.birthwell.app` (in `app.json`). If that's taken, or you'd prefer your own (for example `com.yourname.birthwell`), change both `ios.bundleIdentifier` and `android.package` in `app.json` **before** the steps below. It can't change after release.

## 2. App Store Connect: create the app and agreements

1. appstoreconnect.apple.com → **Apps** → **+** → **New App**. Platform iOS, name **BirthWell**, your bundle ID, SKU `birthwell`.
2. **Business** (or Agreements, Tax, and Banking) → accept the **Paid Apps** agreement and fill in tax and bank details. In-app purchases don't work, even in testing, until this agreement is active.

## 3. Create the in-app purchase

In your app → **Monetization → In-App Purchases** → **+**:

| Field | Value |
|---|---|
| Type | **Non-Consumable** |
| Reference name | BirthWell Premium |
| Product ID | **`birthwell_premium`** (must match exactly) |
| Price | **$11.99** (choose the $11.99 USD price; Apple sets other countries automatically) |
| Display name | BirthWell Premium |
| Description | All five coaches, every soundscape and every guided meditation. One-time purchase. |
| Review screenshot | A screenshot of the BirthWell Premium screen |
| Review notes | One-time unlock. Free users keep the contraction timer, Maren's coaching, two soundscapes and three meditations. Restore Purchases is on the Premium screen and in Settings. |

**Family Sharing** (optional): turning it on lets up to five family members share Premium. Decide before launch, because it can't be turned off later.

## 4. RevenueCat

RevenueCat checks purchases with Apple on its server and tells the app whether Premium is owned. It's free until your app earns $2,500 a month in tracked revenue; check their current pricing.

1. Sign up at revenuecat.com → **Create project** "BirthWell".
2. **Add app → App Store** → enter your bundle ID.
3. **In-App Purchase Key:** in App Store Connect → **Users and Access → Integrations → In-App Purchase** → generate a key, download the `.p8` file, and upload it in RevenueCat with its Key ID and your Issuer ID.
4. **Products:** add product **`birthwell_premium`** (or import it from App Store Connect).
5. **Entitlements:** create entitlement **`premium`** and attach `birthwell_premium` to it. The ID must be exactly `premium`.
6. **API keys:** copy the **public Apple SDK key**. It starts with `appl_` and is safe to put in the app.

## 5. Add the key to the app

In your `birthwell` folder, create a file called `.env` (or add to it if it exists) with:

```
EXPO_PUBLIC_REVENUECAT_IOS_KEY=appl_your_key_here
```

`.env` is not shared or uploaded with the project.

## 6. Make a development build

Expo Go can't make real Apple purchases; in Expo Go, BirthWell uses the simulated store. You need a development build, which is your own installable copy of the app.

```bash
npx eas-cli@latest login
npx eas-cli@latest build:configure
npx eas-cli@latest build --profile development --platform ios
```

EAS builds in the cloud and gives you a link or QR code to install it on your iPhone. Your phone must be registered: EAS walks you through it. Then run `npx expo start` and open the development build instead of Expo Go.

## 7. Test in Apple's sandbox (required before launch)

1. App Store Connect → **Users and Access → Sandbox → Testers** → **+**. Create a test Apple Account using an email you haven't used with Apple.
2. On your iPhone: **Settings → Developer → Sandbox Apple Account**, and sign in with the test account. If "Developer" isn't listed, connect the phone to a Mac with Xcode once, or turn on Developer Mode in Settings → Privacy & Security.
3. Sandbox purchases are free. Check each of these:

| # | Test | Expected |
|---|---|---|
| P1 | Buy Premium | The Apple purchase sheet shows **$11.99**; after confirming, the thank-you screen appears and everything unlocks |
| P2 | Cancel on the Apple sheet | Back on the Premium screen, no message, still Free |
| P3 | Buy again after owning it | No second charge; the screen shows it's already yours |
| P4 | Delete the app, reinstall, tap **Restore Purchases** | Premium comes back |
| P5 | Airplane Mode, then reopen the app | Premium stays unlocked |
| P6 | Airplane Mode, then tap Unlock | A friendly "didn't go through, you haven't been charged" message |
| P7 | Start labor mode as a Free user | No purchase screens appear while timing; Premium coaches and sounds show a short note only |

"Waiting for approval" (Ask to Buy) can't easily be produced in the sandbox. It's covered by the simulated store, and RevenueCat handles it.

## 8. TestFlight, then App Review

- `npx eas-cli@latest build --profile production --platform ios`, then `npx eas-cli@latest submit --platform ios`.
- Submit the in-app purchase **together with** the app version. A first in-app purchase must be reviewed alongside an app version.
- Add your **privacy policy** and **terms** links in `src/config/links.ts` and in App Store Connect first.

## Where things are in the code

- `src/config/premium.ts`: product ID, entitlement ID, price fallback, and everything that's free
- `src/lib/purchases.ts`: RevenueCat store, the simulated store (development only), and the "unavailable" store (release builds without a key, which never unlock for free)
- `src/state/Premium.tsx`: Premium status, cached in the iOS Keychain so it works offline and is never removed just because the phone is offline
- `src/app/premium.tsx`: the Premium screen

## Testing without Apple

- **Expo Go and development builds** use a **simulated store**. Settings shows a "Testing · simulated store" panel to make the next purchase succeed, be cancelled, need approval, or fail, to go offline, and to simulate a reinstall.
- A test build can force the simulated store with `EXPO_PUBLIC_SIMULATED_STORE=1`. **Never** set this for an App Store build. If you make one locally after a test build, add `--clear` so the old setting isn't reused from the build cache. EAS cloud builds always start clean.
- A release build without the RevenueCat key never unlocks Premium: purchases report that the App Store isn't available.
