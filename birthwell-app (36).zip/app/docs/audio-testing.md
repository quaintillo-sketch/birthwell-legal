# Audio reliability: how it works, and how to test it

## What was verified, and how

These checks ran in the development environment (no iPhone available there):

| Check | How | Result |
|---|---|---|
| Two complete libraries per coach, Grounded (31) and Faith-Centered (33): 5 opening, 5 breathing, 4 small encouragements, 4 encouragement, acknowledgments (3 Grounded, shared, plus 2 Faith-Centered), 4 resting, 4 reassurance/prayer, 1 preview, 1 volume; filenames unique and correctly prefixed; 269 unique recordings for 320 phrases. The 25 acknowledgments match the approved wording exactly | Automated test (`npm test`) | Pass |
| Faith-Centered: 55–75% of phrases per coach explicitly spiritual (not all); mentions Jesus and the Holy Spirit; at least 3 short prayers; practical breathing lines kept; "God is with you" variants used at most 3 times; no outcome promises or faith-vs-medicine wording | Automated test | Pass |
| Grounded: no religious language | Automated test | Pass |
| Every quoted verse has a reference; Psalm 46:5 removed; at least 5 short prayers per coach; no assumed feelings ("hate", "fear", "I know. I know."), prescriptive breathing, or pressure to be strong or in control; "wave" used 1–4 times per coach per mode, never as a fixed rise-and-fall | Automated test | Pass |
| Two-hour labor simulation (3 different random labors × 5 coaches × 2 modes × 3 frequencies): exactly one resting phrase per rest, rests under 5% talk, never two phrases at once, no back-to-back repeats, openers never repeat in consecutive contractions; Balanced at most 2 phrases per contraction and 3 in any minute | Automated test, plus `npm run simulate` (report in `docs/rotation-simulation.md`) | Pass. The simulation caught a bug where, on busy settings, the same opener could play in two contractions in a row; fixed. |
| No stage, progress, "push" or battle wording in any phrase; no two coaches share a phrase | Automated test | Pass |
| Balanced gives 1 phrase in a 30s contraction and usually 2 in a one-minute one, plus 1 resting phrase. The second phrase lands anywhere from 30 to 42 s, and about 1 contraction in 6 gets only the opener | Automated test | Pass |
| Mid-contraction phrases are mostly breathing guidance, sprinkled with small encouragements, with some encouragement and reassurance/prayer | Automated test, plus simulation (Balanced: breathing 49%, small encouragements 27%, encouragement 17%, reassurance/prayer 7%) | Pass |
| Exactly one phrase when a contraction ends: about 3 in 4 times an acknowledgment, otherwise a resting phrase instead, never both. Nothing after a contraction under 12 s (mis-tap) | Automated test, plus simulation | Pass |
| Within a category, a phrase only returns after most of the others; openers are at least 4 contractions apart | Automated test, plus simulation | Pass. The plain shuffle could bring an opener back after 3 contractions at a bag boundary; fixed. |
| Contraction ends mid-phrase: within 3 s of finishing, the phrase finishes, and the resting phrase follows after a 1.2 s pause. Otherwise it stops, then the resting phrase. A resting phrase that can't start within 8 s is skipped, never played late, and a new contraction cancels it | Automated test, plus simulation (resting phrase at most 4.3 s after the tap; none skipped) | Pass |
| A phrase that comes due while the app is suspended is dropped, not played late; after a long suspension, prompts never pile up | Automated test | Pass |
| Every phrase in a category plays before any repeats; the same phrase never plays twice in a row (800-phrase simulated session per coach, switching mode halfway) | Automated test | Pass. An earlier run caught a bug where very small groups could repeat back-to-back; fixed. |
| Each mode only ever plays its own library; no back-to-back repeat even when switching mode mid-session | Automated test | Pass |
| iOS build includes background audio (`UIBackgroundModes: audio`) | `npx expo config` | Pass |
| M4A and MP3 recordings bundle; misnamed files are reported, not bundled | `npm run voices` + iOS export with sample files | Pass |
| Audio prep trims silence and levels loudness (−45.7 → −16.6 LUFS on a test file) | `scripts/prepare-audio.sh` | Pass |
| Start/end phrases appear on screen; the app runs without errors | Web build walkthrough | Pass |

**Not verified yet, because they need a real iPhone:** everything in the device checklist below. These results must come from you.

## How the system is designed

- **Timing uses timestamps.** A contraction is stored as start and end times. Every display and every coaching decision recalculates from the clock. Nothing counts timer ticks, so if iOS pauses the app, the timer is still right when it resumes.
- **One voice at a time.** A rotating phrase never starts while another is playing. It waits for the channel to clear, and is dropped if more than 6 seconds late. There's always at least a 4-second pause before a rotating phrase.
- **Start of a contraction.** The opening phrase replaces whatever is playing, because a resting phrase no longer fits.
- **End of a contraction.** The coach says one thing: usually a short acknowledgment (“You did wonderfully.”), sometimes a longer resting phrase instead, never both. If the phrase playing will finish within about 3 seconds, it finishes naturally; otherwise it fades out over 0.4 s. The end phrase follows after a 0.8-second pause, only if it can start within 8 seconds of the tap and no new contraction has begun; otherwise it's skipped. Nothing is said after a contraction under 12 seconds (a likely mis-tap). There's never a queue of delayed prompts.
- **Interruptions.** iOS pauses BirthWell's audio for calls, Siri and alarms:
  - Ambience resumes afterwards when iOS allows.
  - A coach phrase that was cut off is discarded, not resumed mid-sentence.
  - Unplugging headphones pauses ambience, as iOS apps normally do.
- **Silent switch.** Coaching and ambience play with the switch on silent. The in-app controls still apply: Coaching › Silent, Coach volume and Sound volume.
- **Background and locked screen.** Background audio is enabled for development and App Store builds; Expo Go ignores it. Labor mode keeps the screen awake while open, so the screen only locks if she presses the side button.

### What happens when the phone is locked during labor

iOS keeps an app running in the background only while it is **actually playing audio**:

- **Ambience on (default):** the soundscape keeps the app running, so scheduled coaching phrases keep playing while the phone is locked.
- **Ambience off, or My own music:** another app's music doesn't keep BirthWell running. After the last phrase finishes, iOS suspends the app within seconds, so mid-contraction phrases can't play while locked. When she unlocks, the timer shows the right time, and phrases she missed are skipped rather than played in a burst.

Some apps keep running by playing silent audio. BirthWell deliberately doesn't, because Apple's review guidelines only allow background audio for audible content, and doing so risks rejection. The practical guidance: in labor mode, keep the screen on (the app already prevents auto-lock) or keep an ambience playing.

Starting or ending a contraction always needs a tap, so it can't happen with the screen locked anyway.

## Device checklist

**Before you start:**
- Background tests (B1–B4) need a development build, not Expo Go. The rest work in Expo Go.
- To make a development build: install Xcode, plug in your iPhone, and run `npx expo run:ios --device` in the `birthwell` folder. A free Apple ID works; the build has to be reinstalled every 7 days.
- Use real recordings for at least one coach if possible, since the phone-voice fallback behaves slightly differently.

| # | Test | Steps | Expected | Result |
|---|---|---|---|---|
| S1 | Silent switch | Switch to silent, start a contraction | Coach speaks; ambience plays | |
| S2 | In-app silence | Coaching › Silent, start a contraction | No voice; ambience and haptics continue | |
| S3 | Volume | Move Coach volume and Sound volume | Volume-test phrase plays at the new level; ambience follows the slider | |
| O1 | Balanced count | Balanced; time a 20s, a 45s and a 75s contraction, then a few more of a minute or so | 1 phrase in the 20s one; usually 2 in the longer ones (occasionally just the opener, on purpose); 1 when each ends; quiet rests | |
| O2 | No overlap | Frequent; time a 90s contraction | Phrases never overlap; there's a pause between them | |
| O3 | Rapid taps | Tap started → ended → started quickly | Each tap cuts the previous phrase cleanly, without overlap or stutter | |
| O4 | Rotation | Time 10+ contractions on Balanced | No phrase twice in a row; an opener doesn't come back within 4 contractions; the second phrase comes at different moments | |
| O7 | Acknowledgment | Balanced; end 6+ contractions, plus one tapped start-and-end within a few seconds | Each real one: one short acknowledgment (sometimes a resting phrase instead), then quiet or ambience. Never two phrases. The mis-tap: nothing said | |
| O6 | End mid-phrase | More guidance; end a contraction just as a phrase starts, then again just as one is finishing | Long remaining: the phrase fades out quickly, a short pause, then the end phrase. Nearly finished: it finishes, a short pause, then the end phrase. Never two at once | |
| O5 | Two libraries | Time several contractions in Faith-centered, then switch Settings › Daily encouragement to Grounded | Faith library only in Faith-centered; no religious lines in Grounded; shared lines in both | |
| I1 | Phone call | During a phrase, call the phone from another phone, then hang up | Audio pauses for the call; afterwards ambience resumes; the interrupted phrase doesn't resume; next phrases play normally | |
| I2 | Siri | Activate Siri mid-phrase, then dismiss | As I1 | |
| I3 | Other music | Play music in another app, then open labor mode | Both play together; the coach is audible over the music; the music never pauses | |
| U1 | My own music: ducking | Voice & sound › My own music, “Lower music” on. Start a Spotify playlist, open labor mode, time a contraction | Music keeps playing; it dips while the coach speaks and returns to full volume within a second or so after each phrase | |
| U2 | My own music: no ducking | Same, with “Lower music” off | Music stays at full volume; the coach speaks over it | |
| U3 | Playlist link | Paste a Spotify playlist link, tap Open my playlist | Spotify opens on that playlist | |
| I4 | Headphones | Play through AirPods, then remove them | Audio pauses or switches to the speaker, as iOS normally does; coaching continues on the next phrase | |
| B1 | Lock with ambience | Ambience on, More guidance; start a contraction, press the side button | Coach phrases continue while locked; ambience continues | |
| B2 | Lock without ambience | Ambience Off; repeat B1 | Opening phrase finishes; later phrases may not play while locked; on unlock the timer is correct and no burst of phrases | |
| B3 | Background app | Start a contraction, swipe to the Home screen for 60s, return | Timer correct; no burst of phrases; coaching resumes at the next due phrase | |
| B4 | Long session | 30+ minutes of real use, mix of locked and unlocked | No stuck voice, no crashes, contraction history correct | |
| M1 | Meditation offline | (Once hosting is set up) download on Wi‑Fi, enable Airplane Mode, play | Plays fully offline | |
| M2 | Meditation storage | Settings › Meditations › Downloaded, Remove | File removed; size updates | |

Record anything unexpected with the test number. If B1 fails, the next step would be to look at Apple's audio session options. If U1's music stays lowered after the coach stops, turn off “Lower music while coach speaks” and report it; the restore step may need adjusting.
