# Script changes in this revision

New lines only, compared with the 44 Maren recordings you already have. Every one of those 44 lines and IDs is unchanged.

- **End-of-contraction acknowledgments** (`ack`): your approved wording, word for word. 3 Grounded acknowledgments per coach, shared by both modes (one recording each), plus 2 Faith-Centered ones. That makes 5 recordings per coach, 25 in all. When a contraction ends, the coach says one acknowledgment, or about 1 time in 4 a resting phrase instead. Never both.
- **Small encouragements** (`affirm`, 4 per mode): sprinkled through a contraction between breathing cues, unchanged from the last version.

The earlier “kind words” (`praise`) lines are gone. If you generated any `*-praise-*` files, delete them; the app ignores them either way.

That adds 10 recordings per coach (5 acknowledgments, 5 small encouragements): 269 in total, about 11,700 characters.

## Maren

| ID | Type | Modes | Line |
|---|---|---|---|
| `both-ack-01` | Acknowledgment | Both (one recording) | You did wonderfully. |
| `both-ack-02` | Acknowledgment | Both (one recording) | There you go. Beautifully done. |
| `both-ack-03` | Acknowledgment | Both (one recording) | You made it through that one. |
| `faith-ack-01` | Acknowledgment | Faith-Centered | There you go. God is with you. |
| `faith-ack-02` | Acknowledgment | Faith-Centered | You did beautifully. Thank You, Jesus. |
| `both-affirm-01` | Small encouragement | Both | You’re doing well. |
| `both-affirm-02` | Small encouragement | Both | That’s it. Just like that. |
| `both-affirm-03` | Small encouragement | Both | Good. Stay with it. |
| `grounded-affirm-01` | Small encouragement | Grounded | You’re doing exactly what you need to. |
| `faith-affirm-01` | Small encouragement | Faith-Centered | You’re doing well, and you’re not alone in this. |

## Jo

| ID | Type | Modes | Line |
|---|---|---|---|
| `both-ack-01` | Acknowledgment | Both (one recording) | You did it! |
| `both-ack-02` | Acknowledgment | Both (one recording) | There you go. That was wonderful. |
| `both-ack-03` | Acknowledgment | Both (one recording) | Another one behind you! |
| `faith-ack-01` | Acknowledgment | Faith-Centered | You did it! Praise God. |
| `faith-ack-02` | Acknowledgment | Faith-Centered | There you go. Jesus is with you. |
| `both-affirm-01` | Small encouragement | Both | You’re doing so good. |
| `both-affirm-02` | Small encouragement | Both | Yes. That’s it. |
| `both-affirm-03` | Small encouragement | Both | Look at you go. |
| `grounded-affirm-01` | Small encouragement | Grounded | You’ve so got this. |
| `faith-affirm-01` | Small encouragement | Faith-Centered | You’re doing amazing, friend. God’s got you. |

## Esme

| ID | Type | Modes | Line |
|---|---|---|---|
| `both-ack-01` | Acknowledgment | Both (one recording) | Beautifully done. |
| `both-ack-02` | Acknowledgment | Both (one recording) | There you go. Now rest. |
| `both-ack-03` | Acknowledgment | Both (one recording) | You made it through. |
| `faith-ack-01` | Acknowledgment | Faith-Centered | Beautifully done. Rest in Him. |
| `faith-ack-02` | Acknowledgment | Faith-Centered | There you go. Thank You, Lord. |
| `both-affirm-01` | Small encouragement | Both | Good. |
| `both-affirm-02` | Small encouragement | Both | Yes… like that. |
| `both-affirm-03` | Small encouragement | Both | Steady. You’re doing it. |
| `grounded-affirm-01` | Small encouragement | Grounded | Soft. Steady. Good. |
| `faith-affirm-01` | Small encouragement | Faith-Centered | Good. You are held. |

## Ines

| ID | Type | Modes | Line |
|---|---|---|---|
| `both-ack-01` | Acknowledgment | Both (one recording) | You did beautifully. |
| `both-ack-02` | Acknowledgment | Both (one recording) | There you go. The wave has passed. |
| `both-ack-03` | Acknowledgment | Both (one recording) | Beautiful. Now take your rest. |
| `faith-ack-01` | Acknowledgment | Faith-Centered | There you go. Rest in His love. |
| `faith-ack-02` | Acknowledgment | Faith-Centered | You did beautifully. God is near. |
| `both-affirm-01` | Small encouragement | Both | That’s it, gently. |
| `both-affirm-02` | Small encouragement | Both | You’re doing beautifully. |
| `both-affirm-03` | Small encouragement | Both | Just like that… easy. |
| `grounded-affirm-01` | Small encouragement | Grounded | You’re moving with it so well. |
| `faith-affirm-01` | Small encouragement | Faith-Centered | Gently now. You are held in love. |

## Della

| ID | Type | Modes | Line |
|---|---|---|---|
| `both-ack-01` | Acknowledgment | Both (one recording) | Yes! You did it! |
| `both-ack-02` | Acknowledgment | Both (one recording) | Look at you. Beautifully done! |
| `both-ack-03` | Acknowledgment | Both (one recording) | There you go! You did wonderfully. |
| `faith-ack-01` | Acknowledgment | Faith-Centered | You did it! Thank You, Jesus! |
| `faith-ack-02` | Acknowledgment | Faith-Centered | Yes! God’s right here with you! |
| `both-affirm-01` | Small encouragement | Both | You’re doing great. |
| `both-affirm-02` | Small encouragement | Both | That’s it. Nice and steady. |
| `both-affirm-03` | Small encouragement | Both | Look at you. You’re doing it. |
| `grounded-affirm-01` | Small encouragement | Grounded | You’ve got this. I believe in you. |
| `faith-affirm-01` | Small encouragement | Faith-Centered | You’re doing great. The Lord is your strength. |
