# BirthWell · Faith-centered meditations, recording scripts

**Weeks 7–42 · final, approved scripts, ready for recording.** No audio has been generated. Recording waits for Leah's approval of the setup in section 3.

## 1. What's in these scripts

**What each script contains:**

- Exactly what Maren says, in order, and nothing else.
- Tone directions, such as `[warm, unhurried]`, shown where they change. A direction carries on until the next one.
- Silences: `[music 6s]` at the start and end, and `[pause Ns]`.
- A new paragraph means a natural one-second breath.
- *Italic* lines are Scripture, word for word from the World English Bible.

**Approved changes now in the official scripts:**

- Weeks 24, 25, 33, 34, 39 and 41 are prayer-only. Week 13 keeps James 1:17.
- All editorial fixes from the final review are in.
- Week 25's prayer: "Help me receive this child with love and care."
- Week 41's closing: "Be gentle with yourself in these days. You are held in his care."
- Week 42's closing: "Your little one is already so loved."
- **Gratitude for the baby** is now in every closing prayer, in words tied to each week's theme and spoken about the present. There are no promises about outcomes, and no pressure to feel grateful.
- Week 21's prayer: "…find moments of peace in these days of carrying new life." Week 23's: "…help me recognize your goodness throughout this season." Week 37's: "…trust you through the days ahead."
- **Weeks 7–13** also say how precious this time with the baby is, whatever happens, and place the little one in God's care. Weeks 9, 11 and 13 add the wonder that this life began at all.
- **The same threads appear through weeks 14–42, about every few weeks** (15, 18, 20, 25, 30, 32 and 38). Each is in a sweet, wonder-filled voice.
- **Weeks 14, 16, 24 and 35:** the reflection on the body's own quiet work credits God's design, for example "God has woven a quiet wisdom into your body."
- The earlier Faith-centered versions are kept in `archive/faith-before-woven-weeks-07-42.md`.

**For recording only:** three verses that end mid-sentence are sent to ElevenLabs with a full stop, so Maren closes them naturally:

- week 26: "…My peace I give to you."
- week 31: "…I will be with you."
- week 37: "…under heaven."

The scripts themselves keep the original punctuation, and these recording scripts show what is actually sent.

**Pronunciation:**

- Zephaniah (week 16) is sent as a spoken spelling.
- To check by ear on the review sheets: Ebenezer (20), Lamentations (15), Ecclesiastes (37), Philippians (8), Galatia (17), Judah (18) and Isaiah.

## 2. Final checks

| Check | Result |
|---|---|
| Scripture, word for word against the World English Bible | ✓ every passage matches |
| Sent words match the approved scripts exactly (all 74, both recording modes) | ✓ |
| Prayer-only weeks marked in their headers | ✓ weeks 24, 25, 33, 34, 39 and 41 |
| Tone directions unchanged where paragraphs moved | ✓ |
| Repetition check | ✓ the only repeats left are deliberate: the blessing prayed line by line (14), the strength-and-soften pattern (23), and the repeated prayer for use in labor (38) |
| Gratitude for the baby | ✓ in all 37 Faith-centered closing prayers (weeks 6–42), worded differently each week |
| Sensitivity | ✓ no promised outcomes, no required joy or gratitude, prayer never replaces care, and the care-team lines in weeks 37–42 are intact |
| Automated tests | ✓ 48 of 48 |
| **Faith-centered runtimes** | **4:28–5:48**, all inside 4:15–6:00 |
| **Grounded runtimes** | **4:12–4:46**. Three weeks run just under 4:15: week 22 (4:14), week 26 (4:12) and week 30 (4:14). All three are within the 10-second small exception, so no script changes are needed. |

Runtimes are estimated at Maren's pace from the Week 6 pilot. The review sheets will show the real lengths.

### Runtimes, week by week

| Week | Title | Scripture | Faith-centered | Grounded |
|---|---|---|---|---|
| 7 | Come and rest | ✓ | 5:44 | 4:39 |
| 8 | Peace that guards | ✓ | 5:46 | 4:36 |
| 9 | Fearfully, wonderfully made | ✓ | 5:37 | 4:33 |
| 10 | Bread for today | ✓ | 5:39 | 4:42 |
| 11 | Be still and know | ✓ | 5:17 | 4:43 |
| 12 | Pour out your heart | ✓ | 5:30 | 4:40 |
| 13 | Every good gift | ✓ | 4:36 | 4:30 |
| 14 | A blessing for the little one | ✓ | 5:34 | 4:42 |
| 15 | New every morning | ✓ | 5:01 | 4:31 |
| 16 | Sleep for the beloved | ✓ | 5:04 | 4:43 |
| 17 | Never left alone | ✓ | 4:48 | 4:33 |
| 18 | A greeting of joy | ✓ | 4:42 | 4:22 |
| 19 | The one thing | ✓ | 4:57 | 4:27 |
| 20 | Helped until now | ✓ | 5:08 | 4:41 |
| 21 | Quietness and confidence | ✓ | 5:39 | 4:39 |
| 22 | Life and loving kindness | ✓ | 4:46 | 4:14 |
| 23 | Strength that renews | ✓ | 5:27 | 4:28 |
| 24 | The breath of life | prayer only | 4:43 | 4:30 |
| 25 | A gift from the Lord | prayer only | 4:47 | 4:32 |
| 26 | My peace I give you | ✓ | 4:55 | 4:12 |
| 27 | In wisdom you made them | ✓ | 4:51 | 4:35 |
| 28 | A place prepared with love | ✓ | 5:09 | 4:21 |
| 29 | In the shadow of your wings | ✓ | 4:39 | 4:24 |
| 30 | As a mother comforts | ✓ | 4:28 | 4:14 |
| 31 | Through the waters | ✓ | 5:48 | 4:43 |
| 32 | A quiet soul | ✓ | 5:30 | 4:46 |
| 33 | Fullness of joy | prayer only | 4:39 | 4:33 |
| 34 | Held up by love | prayer only | 4:38 | 4:28 |
| 35 | Grace that is enough | ✓ | 5:06 | 4:44 |
| 36 | My help comes from the Lord | ✓ | 5:21 | 4:32 |
| 37 | A time for everything | ✓ | 5:02 | 4:43 |
| 38 | My times are in your hand | ✓ | 5:09 | 4:40 |
| 39 | God of all comfort | prayer only | 4:40 | 4:41 |
| 40 | I wait for the Lord | ✓ | 4:48 | 4:30 |
| 41 | Rest, and wait | prayer only | 4:36 | 4:33 |
| 42 | This is the day | ✓ | 4:43 | 4:29 |
## 3. Recording setup, for Leah's approval

**What's left to record:** Grounded weeks 7–42 in full, plus the Faith-centered paragraphs that differ from Grounded. Paragraphs that are identical in both versions reuse the Grounded recording, as week 6 did.

| Batch | Grounded | Faith-centered (new paragraphs) | Characters | Credits at the rate charged so far (0.4) | At the listed rate (1.0) |
|---|---|---|---|---|---|
| 1 · weeks 7–20 | 29,512 | 17,747 | **47,259** | about 18,900 | 47,259 |
| 2 · weeks 21–42 | 41,663 | 18,926 | **60,589** | about 24,200 | 60,589 |
| **Total** | | | **107,848** | **about 43,100** | **107,848** |

**Plan and balance:**

- You have about 9,600 credits, which isn't enough for batch 1.
- One month of **Creator** (121,000 credits; currently $11 for the first month) covers both batches even at the listed rate, with room for redos.
- The best time to subscribe is just before batch 1, since the scripts are now final.

**How each batch runs:** on your Mac, in one Terminal window, with your key entered as before.

1. **Grounded first:**
   `npm run meditations -- --week 7-20 --version grounded --max-credits 32000`

2. **Then Faith-centered, reusing the identical Grounded paragraphs:**
   `npm run meditations -- --week 7-20 --version faith --reuse-grounded --max-credits 20000`

3. **Listen** with the review sheets, and send me notes by week and paragraph number. A redo records only that paragraph.
4. **Batch 2** runs the same way, for weeks 21–42. The limits would be 46,000 for Grounded and 21,000 for Faith-centered.

**Safety checks still in place:**

- The recorder shows the verified rate and the cost, and asks you to type "yes".
- It won't start if the cost would go over the limit or over your balance.
- It checks the real charge after the first paragraph, and stops if it's higher than expected.
- Finished paragraphs are never paid for twice.

**Before batch 1:**

- **A week 7 sample comes first.** Week 7 is recorded and assembled in both versions, using the final process. The recorder is unlocked for week 7 only.
- **Listening preview:** Leah listens to both versions on their own and with a soundscape underneath, to check the voice, pacing, pauses and music.
- **Then the batches:** once the sample is approved, weeks 8–20 unlock. Week 7 doesn't need recording again. Batch 2 unlocks after batch 1 has been approved.
- **Week 6:** both versions are already recorded and stay as they are.

# The recording scripts

## Week 7 · Come and rest.

*About 5:44 · 21 paragraphs (11 identical to Grounded) · 2,946 characters*

`[music 6s]`

`[warm, unhurried]` Hi. If you can, let yourself lie down for this one. On your side is lovely, with a pillow wherever you need it. If lying down isn't possible right now, simply lean back and let something hold you.

`[pause 5s]`

`[gentle, understanding]` You may be more tired than usual right now. The kind of tired that a good night's sleep doesn't quite reach. Pregnancy can ask so much of you, in body and in heart, even on days when it seems like nothing is happening.

`[pause 5s]`

That tiredness isn't laziness, and it isn't weakness. Your body is adapting to pregnancy in countless quiet ways, and it asks for energy and rest, sometimes more than you expected. There is something remarkable in that work, even if all you notice today is how tired you feel.

`[pause 5s]`

`[warm, reassuring]` So here's your permission. For the next few minutes, you don't need to be useful. You don't need to catch up.

`[pause 4s]`

`[reverent]` Listen to the words of Jesus:

*Come to me, all you who labor and are heavily burdened, and I will give you rest. Take my yoke upon you, and learn from me, for I am gentle and humble in heart; and you will find rest for your souls.*

`[pause 8s]`

`[warm, reassuring]` He doesn't say, come once you've finished everything. He doesn't say, come once you've earned it. He simply says, come.

`[pause 5s]`

`[gentle]` What are you carrying today? Tell him quietly. The tiredness. The worries. The things you haven't gotten to. You can set each one down in front of him.

`[pause 10s]`

`[prayerful, sincere]` Jesus, I'm tired, and you already know it. Thank you that I don't have to earn your rest, or prove that I deserve it. Thank you for the little one I'm carrying. Even on the tired days, this time with my baby is a treasure, and I rest this little one in your care. I'm setting these things down with you. Teach me to rest in you. Amen.

`[pause 6s]`

`[calm, soothing]` Let's let the heaviness come.

Start with your feet. Imagine them growing warm and heavy, sinking a little into whatever is beneath them.

`[pause 5s]`

That warmth moves into your calves… your knees… your thighs… your hips and lower back. Heavy. Easy. Held.

`[pause 5s]`

Your belly, soft, with nothing to hold in. Your arms, heavy all the way down to your fingertips.

`[pause 5s]`

And your face. The space between your eyebrows. Your jaw. The soft skin around your eyes.

`[pause 5s]`

`[reverent]` In Psalm 23, David says of the Lord, his shepherd:

*He makes me lie down in green pastures. He leads me beside still waters.*

`[pause 7s]`

`[calm, peaceful]` Let yourself be there. Notice the light. The quiet. How nobody needs anything from you.

`[pause 8s]`

`[gentle]` If your mind wanders to the dishes, the emails, the list, that's all right. Notice it, and let your next breath out carry you back to your resting place.

`[pause 6s]`

`[calm, soothing]` Rest here a while, beside still waters, in his care.

`[pause 10s]`

`[warm]` When you're ready, let your body begin to wake. Gently. There's no rush.

`[pause 4s]`

Be gentle with yourself, and may you find his rest in the ordinary moments of today.

`[music 6s]`

## Week 8 · Peace that guards.

*About 5:46 · 20 paragraphs (8 identical to Grounded) · 2,968 characters*

`[music 6s]`

`[warm, unhurried]` Hi. Before we begin, take a moment to check in with yourself. Not how you think you should be feeling. How you actually are.

`[pause 5s]`

`[calm]` Find a comfortable position, and let your breath settle into whatever rhythm feels natural.

`[pause 5s]`

`[warm, lightly smiling]` Pregnancy can bring so many feelings, sometimes all at once. Excitement. Worry. Tenderness. Doubt. Moments of wonder, and moments of what have I gotten myself into? And some days, not much feeling at all.

`[pause 5s]`

`[reassuring]` There's no right way to feel right now. God isn't asking you to sort your feelings out first. He invites you to bring them to him, just as they are.

`[pause 5s]`

`[reverent]` Listen to these words from Philippians:

*In nothing be anxious, but in everything, by prayer and petition with thanksgiving, let your requests be made known to God. And the peace of God, which surpasses all understanding, will guard your hearts and your thoughts in Christ Jesus.*

`[pause 8s]`

`[warm, reflective]` In everything. Not only the tidy things. Not only the brave ones.

`[pause 5s]`

`[calm]` Rest a hand over the center of your chest, if you'd like. Feel the warmth there. As you breathe out, imagine the space beneath your hand growing a little wider. A little more room.

`[pause 7s]`

`[gentle]` Let's bring it all to him now, slowly.

Is there a worry you've been carrying? Something you keep turning over? Tell God about it, in your own words. Be as honest as you like.

`[pause 12s]`

`[hopeful]` Now, is there a hope in your heart? Something you long for, for yourself, or for your baby? Tell him that too.

`[pause 10s]`

`[warm]` And is there anything, even something small, you're thankful for today? Offer him that as well.

`[pause 8s]`

`[gentle]` Notice how both can be true at once. The hope and the worry. The wonder and the tiredness. You're holding all of it, right now, and you're still here, still breathing.

`[pause 6s]`

`[gentle wonder]` Within you, a new life is developing as your body makes room for the work of pregnancy. That may stir wonder, affection, anxiety, or a mixture that changes by the hour. You can recognize how extraordinary it is without feeling cheerful about every moment.

`[pause 5s]`

`[tender]` Even an ordinary appointment or a quiet day can stir up feelings that are hard to explain. You don't need to resolve them here. Rest a hand on your belly if you'd like, and allow one small moment of connection without asking it to predict tomorrow.

`[pause 7s]`

`[reverent]` Peter wrote that we can come to God:

*casting all your worries on him, because he cares for you.*

`[pause 7s]`

`[prayerful, sincere]` Father, thank you for listening. Thank you for this child, and for loving us both. These days with my baby are precious to me. You know every hope and every fear I've named, and the ones I couldn't put into words. I'm leaving them, and this little one, with you. Guard my heart and my thoughts today, and keep me close to you. Amen.

`[pause 7s]`

`[warm]` When you're ready, let your hands rest, and let your eyes slowly open.

`[pause 3s]`

However today feels, you're not doing it wrong. Take this peace with you into the rest of your day.

`[music 6s]`

## Week 9 · Fearfully, wonderfully made.

*About 5:37 · 24 paragraphs (15 identical to Grounded) · 2,728 characters*

`[music 6s]`

`[warm, unhurried]` Hello. Let's start by letting your body move a little, before we settle.

If it feels good, roll your shoulders slowly, up, back, and down. Once or twice.

`[pause 5s]`

`[calm]` Let your head tip gently toward one shoulder… and then the other.

`[pause 5s]`

Now find a comfortable position and let yourself be still. If you're feeling queasy or unsettled today, sitting a little upright, with something behind your back, might feel better.

`[pause 5s]`

There's no need to change your breathing. Just notice it, quietly doing its work.

`[pause 5s]`

`[gentle wonder]` This body of yours is responding to pregnancy through changes you can see and changes that remain hidden. Even without your direction, it adjusts and makes space for an extraordinary process. Appreciation doesn't have to mean loving every symptom, every ache, or every new shape.

`[pause 5s]`

`[reverent]` The prophet Isaiah describes God as a shepherd caring for his flock:

*He will gather the lambs in his arm, and carry them in his bosom. He will gently lead those who have their young.*

`[pause 7s]`

`[tender]` Gently leading those who have their young. Held. Led gently. Not hurried.

`[pause 5s]`

`[warm]` Today, let's simply be kind to your body, wherever it is.

`[pause 4s]`

`[calm]` Bring your attention to your feet, and whatever is beneath them. They've carried you a long way.

`[pause 5s]`

Your legs. Notice if they feel heavy or tired, and let them rest.

`[pause 5s]`

`[tender]` Your belly, where a new life is growing. Rest your hand here, if you'd like.

`[pause 8s]`

`[calm]` Your chest, rising and falling. Your heart, keeping its steady rhythm.

`[pause 5s]`

Your shoulders, your arms, your hands. Let them grow heavy.

`[pause 5s]`

Your face. Let the small muscles around your eyes and mouth soften.

`[pause 6s]`

`[gentle, reassuring]` If there's a place that feels sore, heavy, or uneasy, you don't need to fix it, or feel grateful for it. You can simply bring it to God, and let it be held. Tell him what's hard.

`[pause 10s]`

`[reverent]` The psalmist prayed:

*I will give thanks to you, for I am fearfully and wonderfully made. Your works are wonderful. My soul knows that very well.*

`[pause 7s]`

`[gentle]` If thankfulness feels true today, offer it to him, in your own words. If it doesn't, simply rest in his care.

`[pause 8s]`

`[warm]` Whatever your body is asking for today, whether that's rest, water, a little food, or some fresh air, you're allowed to give it.

`[pause 5s]`

`[prayerful, sincere]` Creator God, you made me with care, and you're near to me in every change. Thank you for this little one. It's a miracle that this life began at all, and I'm grateful for every day I get to carry them. I entrust them to your gentle care. On the hard days, be my comfort. Lead me gently, the way you lead those with young. Amen.

`[pause 6s]`

`[warm]` When you're ready, let your eyes open, and come back slowly.

`[pause 3s]`

Go gently, knowing you are held.

`[music 6s]`

## Week 10 · Bread for today.

*About 5:39 · 24 paragraphs (14 identical to Grounded) · 2,746 characters*

`[music 6s]`

`[warm, unhurried]` Hi. Let's take this one day, and this one moment, at a time.

Get comfortable in whatever way your body likes today. Let your hands rest wherever they land.

`[pause 5s]`

`[calm]` Your breath can do whatever it wants. You're just here to keep it company.

`[pause 5s]`

`[gentle, understanding]` It's natural, in pregnancy, for the mind to race ahead. To the next appointment. The next test result. How you'll manage work, or sleep, or money, or everything else. Months of questions can fit into a single minute of worrying.

`[pause 5s]`

`[reverent]` Jesus knew how heavy that can be. In the Sermon on the Mount, he said:

*Therefore don't be anxious for tomorrow, for tomorrow will be anxious for itself.*

`[pause 7s]`

`[warm, reassuring]` He wasn't scolding anyone for worrying. He was inviting them to put tomorrow down, and let God hold it.

`[pause 5s]`

`[calm]` For now, let's notice where your mind has been travelling. You don't need to follow it. Just notice the direction.

`[pause 8s]`

`[warm]` Now imagine gently calling it home, the way you might call to someone who's wandered a little too far down the beach. Just: come back.

`[pause 6s]`

Here is today. Only today.

`[pause 4s]`

`[reverent]` In that same sermon, he taught his followers to pray, simply:

*Give us today our daily bread.*

`[pause 7s]`

`[warm, reflective]` Not bread for the whole year. Bread for today.

`[pause 5s]`

`[gentle wonder]` Today, your body is occupied with the remarkable, largely unseen work of pregnancy. You don't need to map every step of it to appreciate what's happening now. You can be curious about your baby and still feel unsettled by questions that haven't been answered.

`[pause 5s]`

`[calm]` Let's find three things that are steady, right now.

First, something supporting you. The chair, the bed, the floor. Notice it holding you without being asked.

`[pause 6s]`

Second, something you can hear. Maybe the music. Maybe a sound in the room, or outside.

`[pause 6s]`

Third, something about your own body that feels okay, even a little. Warm hands. Soft shoulders. A comfortable spot.

`[pause 7s]`

`[warm]` Three steady things. They were here all along, while your mind was busy elsewhere.

`[pause 5s]`

`[gentle]` What do you need for today? Rest? Patience? Strength for a hard conversation? A little more comfort in your body? Tell God, in your own words. Nothing is too small.

`[pause 10s]`

`[prayerful, sincere]` Lord, thank you that I don't have to hold every tomorrow today. Thank you for the little one here with me today. Each day with my baby is a blessing, and I give this little one into your keeping. Give me what I need for this day, and help me trust you with the rest. Amen.

`[pause 6s]`

`[tender]` If you'd like, rest a hand on your belly. Today, you're both simply here.

`[pause 8s]`

`[warm]` When you're ready, open your eyes, and notice one more steady thing around you.

`[pause 4s]`

Tomorrow can wait. Go into today with what you need for today.

`[music 6s]`

## Week 11 · Be still and know.

*About 5:17 · 24 paragraphs (13 identical to Grounded) · 2,230 characters*

`[music 6s]`

`[warm, unhurried]` Let's begin with a few seconds of just listening.

`[pause 5s]`

`[calm]` Not trying to relax. Not trying to do anything. Just letting sounds arrive.

`[pause 5s]`

`[warm]` There's a kind of calm that doesn't need a quiet house, or a free afternoon, or everything going well. It's small, and it's steady, and it can be found inside an ordinary moment.

`[pause 5s]`

Let's find one.

`[calm]` If you have a warm drink nearby, you can hold it. If not, simply imagine one. A mug of tea, or warm milk, or anything that comforts you.

`[pause 5s]`

Feel the warmth spreading into your palms.

`[pause 4s]`

Notice the weight of the cup. The texture of it under your fingers.

`[pause 5s]`

If there's steam, imagine it rising slowly, and fading.

`[pause 6s]`

`[warm]` This is all it takes. One ordinary thing, noticed fully.

`[pause 5s]`

Hold your cup a little longer, and listen.

`[pause 3s]`

`[reverent]` Psalm 46 was written for God's people in a time of upheaval. Nations in uproar, the earth itself shaking. And in the middle of it all, God says:

*Be still, and know that I am God.*

`[pause 8s]`

`[calm, reverent]` Let's say it again, a little shorter each time, and rest in the silence between.

Be still, and know that I am God.

`[pause 10s]`

Be still, and know.

`[pause 10s]`

Be still.

`[pause 12s]`

Be.

`[pause 16s]`

`[gentle]` Stillness isn't the same as having no thoughts. It's more like resting. Letting God be God, while you simply stay near.

`[pause 6s]`

`[calm]` Now let your attention widen, just a little. To your hands. Your arms. Your shoulders, softening as you breathe out.

`[pause 6s]`

`[tender]` To your belly.

`[pause 3s]`

`[gentle wonder]` While you're noticing this ordinary comfort, remember that pregnancy is happening within the ordinary hours too. The body you're resting in is continually adjusting to carry this baby. Nothing dramatic needs to happen in this room for this moment to be meaningful.

`[pause 5s]`

`[prayerful, sincere]` Lord, in all the busyness and change of this season, thank you for being God, so I don't have to be. Thank you for the quiet miracle that this little life began at all. I cherish this moment, and I rest this little one in your hands. Let me be still with you. Amen.

`[pause 8s]`

`[warm]` When you're ready, set down your cup, real or imagined, and let your eyes open.

`[pause 4s]`

Stay in that stillness as long as you'd like. It's yours to come back to.

`[music 6s]`

## Week 12 · Pour out your heart.

*About 5:30 · 25 paragraphs (16 identical to Grounded) · 2,626 characters*

`[music 6s]`

`[warm, unhurried]` Start by noticing your hands. Where are they resting? Are they open, or curled? Soft, or holding on?

`[pause 5s]`

`[gentle]` Many of us carry tension without realizing it. In our hands, our shoulders, our faces. Today, let's gently let some of it go.

Settle in comfortably first.

`[pause 4s]`

`[calm]` We'll start with your hands. If it feels good, make a soft fist. Not tight. Just enough to notice the effort.

`[pause 4s]`

And let it go. Let your fingers uncurl and fall open.

`[pause 5s]`

Notice the difference. The tingling, or the warmth, or the heaviness after letting go.

`[pause 4s]`

Now your shoulders. If it's comfortable, lift them gently toward your ears.

`[pause 4s]`

And let them drop.

`[pause 5s]`

Let them keep sinking, a little more with each breath out.

`[pause 5s]`

`[gentle wonder]` Your body has been adapting to a new life while you manage everything else that fills your days. Its work is remarkable; the tension you carry is understandable. Releasing your shoulders for a moment doesn't mean releasing your care for this baby.

`[pause 5s]`

`[calm]` Now your face. Scrunch it gently, if you like. Eyes, nose, mouth, all pulling toward the center.

`[pause 3s]`

And release. Let your forehead go smooth. Let your jaw hang loose.

`[pause 6s]`

`[warm]` Your body knows how to let go. It just sometimes needs reminding.

`[pause 4s]`

`[reverent]` The psalms are full of honest prayers. People telling God exactly how they felt, the fears, the frustrations, the hopes. In Psalm 62, David writes:

*Pour out your heart before him. God is a refuge for us.*

`[pause 7s]`

`[warm, reflective]` Not tidy up your heart first. Pour it out.

`[pause 4s]`

`[gentle]` Now tell him what's heavy. Whatever comes.

`[pause 12s]`

`[calm, soothing]` Let's go once through your whole body, without tensing this time. Just a soft wave of letting go, from the top of your head, down through your shoulders, your arms, your back, your legs, all the way to your feet.

`[pause 6s]`

`[reverent]` Another psalm says:

*Cast your burden on the Lord and he will sustain you.*

`[pause 7s]`

`[warm, reassuring]` That doesn't mean every burden disappears. It means you don't carry it alone. He holds you up while you carry it.

`[pause 5s]`

`[prayerful, sincere]` Lord, thank you for listening to all of it, the big things and the small. Thank you for this little one, even on the heavy days. However this season unfolds, this time with my baby is beautiful. I'm placing these, and this little one, in your hands. Hold me up today. Amen.

`[pause 6s]`

`[tender]` If you'd like, rest your open hand on your belly. No effort. Just warmth. Stay soft. There's nothing you need to hold right now.

`[pause 8s]`

`[warm]` When you're ready, let some gentle movement come back, and slowly open your eyes.

`[pause 4s]`

Walk a little lighter today, knowing he holds what you've given him.

`[music 6s]`

## Week 13 · Every good gift.

*About 4:36 · 18 paragraphs (7 identical to Grounded) · 2,092 characters*

`[music 6s]`

`[warm, unhurried]` Think of one small thing from the last day or so that was good. It doesn't need to be big. A warm shower. A kind text. The first sip of something cold.

`[pause 5s]`

`[calm]` Hold that thought, and let yourself get comfortable.

`[pause 5s]`

`[gentle, understanding]` This meditation is about noticing good things. Not because everything is good. Some days in pregnancy are hard, and that's real. But even hard days can hold small moments worth noticing.

`[pause 5s]`

`[reverent]` James, writing to the early church, said this:

*Every good gift and every perfect gift is from above, coming down from the Father of lights.*

`[pause 7s]`

`[warm, unhurried]` Every good gift. Not only the big ones. The small, everyday ones too.

`[pause 5s]`

`[warm]` Let's go back to that first good thing. Picture it clearly. Where were you? What did it feel like? Let yourself enjoy it again, just for a moment.

`[pause 8s]`

`[prayerful]` Now simply say, in your heart: Thank you.

`[pause 6s]`

`[warm]` Let a second one come to mind. Maybe something someone said. Maybe something you saw. Light through a window. A song. A laugh.

`[pause 8s]`

`[prayerful]` Thank you.

`[pause 6s]`

`[warm]` And a third. Maybe something your body did well. A good night's sleep, a meal that sat right, a walk that felt easy.

`[pause 8s]`

`[prayerful]` Thank you.

`[pause 6s]`

`[gentle wonder]` One small good thing may simply be the thought that you're carrying a baby, even if that thought comes with complicated feelings.

`[pause 5s]`

`[reassuring]` If thankfulness feels hard today, that's all right. God isn't asking you to pretend everything is easy. You can tell him that too. Gratitude and honesty can sit side by side.

`[pause 6s]`

`[prayerful, sincere]` Father of lights, every good thing in my life comes from you. Thank you for the small gifts I so often miss, and for the miracle of this little one. Every day I carry this little one is a good gift from you, and I trust this little life to your love. Open my eyes to your goodness today, even in ordinary moments. Amen.

`[pause 6s]`

`[tender]` If you'd like, rest a hand on your belly. Your baby is part of your days now, even the ordinary ones.

`[pause 8s]`

`[warm]` When you're ready, let your eyes open.

`[pause 4s]`

Watch for his good gifts today. They're often closer than we think.

`[music 6s]`

## Week 14 · A blessing for the little one.

*About 5:34 · 23 paragraphs (10 identical to Grounded) · 2,666 characters*

`[music 6s]`

`[warm, unhurried]` This meditation is a little different. Today, you're invited to talk to your baby.

`[reassuring]` If that feels natural, wonderful. If it feels strange, or awkward, or a bit too soon, that's completely okay. You can just listen along, and try it whenever you're ready.

`[pause 5s]`

`[calm]` Find a comfortable position. If you'd like, rest one or both hands on your belly.

`[pause 5s]`

Let your breath settle in its own time.

`[pause 5s]`

`[gentle wonder]` Your baby is developing within the shelter of your body, and that relationship is already part of your everyday life, even if you don't yet feel a clear bond. Your body has been making adjustments in the background while you've gone about ordinary routines. God has woven a quiet wisdom into your body, and it has been at work all along.

`[pause 5s]`

`[tender]` Imagine, for a moment, what this little one might want to know about you.

`[pause 6s]`

You might start simply. Silently, or in a whisper: Hello. It's me.

`[pause 7s]`

`[warm]` You could tell your baby something about your day. Where you are right now. What you can hear.

`[pause 7s]`

You could tell them something about yourself. Something you love. Something you're looking forward to.

`[pause 7s]`

Whatever you said, or didn't say, this is how relationships begin. A little at a time.

`[pause 6s]`

`[reverent]` Now, one of the oldest blessings in Scripture. In the book of Numbers, God gave Moses these words for Aaron and the priests to speak over his people. People have prayed them over children for thousands of years.

Listen to them once through:

*The Lord bless you, and keep you. The Lord make his face to shine on you, and be gracious to you. The Lord lift up his face toward you, and give you peace.*

`[pause 8s]`

`[warm, reassuring]` A blessing isn't a guarantee of an easy road. It's an asking. Placing someone you love into God's care.

`[pause 5s]`

`[reverent, tender]` Let's pray it slowly over your baby now, line by line. You can echo the words silently, or simply listen.

The Lord bless you, and keep you.

`[pause 7s]`

The Lord make his face to shine on you, and be gracious to you.

`[pause 7s]`

The Lord lift up his face toward you, and give you peace.

`[pause 9s]`

`[gentle]` Now take a moment to pray for your baby in your own words. Whatever hopes are in your heart. Perhaps that they'll know they're loved. That they'll have courage, and kindness, and people around them.

`[pause 10s]`

`[warm]` And this blessing is for you too. Let it rest on you, as a mother, in this season.

`[pause 5s]`

`[prayerful, sincere]` Lord, thank you for the blessing of this little one. Bless me and keep me. Let your face shine on me. Give me your peace. Amen.

`[pause 6s]`

`[warm]` When you're ready, let your hands rest, and slowly open your eyes.

`[pause 4s]`

Go in his peace, both of you.

`[music 6s]`

## Week 15 · New every morning.

*About 5:01 · 20 paragraphs (14 identical to Grounded) · 2,464 characters*

`[music 6s]`

`[warm, unhurried]` Picture yourself a year or so ago. Before this pregnancy. What did an ordinary day look like? What did you care about? What made you laugh?

`[pause 8s]`

`[calm]` Hold that picture gently as you settle into a comfortable position.

`[pause 5s]`

`[gentle, understanding]` Pregnancy changes so much. Your body. Your energy. Your plans. Sometimes, how other people see you. It's natural to wonder how much of you is changing too.

`[pause 5s]`

`[warm]` Let's take a moment with that.

Bring to mind something you've always loved. A place, a song, a food, a kind of weather.

`[pause 7s]`

That's still you.

`[pause 4s]`

Bring to mind something you're good at. Something people come to you for.

`[pause 7s]`

Still you.

`[pause 4s]`

Bring to mind a way you've grown in the last few months. Something you've learned, or carried, or handled, that you didn't know you could.

`[pause 7s]`

That's you too. Growing.

`[pause 6s]`

`[reverent]` In the book of Lamentations, written during a time of upheaval, there's a moment of surprising hope. The writer says of God:

*his compassion doesn't fail. They are new every morning. Great is your faithfulness.*

`[pause 8s]`

`[warm, reflective]` Everything around the writer had changed. But God's compassion hadn't. It met the writer again, new, each morning.

`[pause 6s]`

`[gentle wonder]` As your baby develops, your body is changing in visible and invisible ways. It can be astonishing to think of how much it does without your conscious instruction. It can also be strange to feel that your familiar self is changing alongside it.

`[pause 5s]`

`[tender, reassuring]` Some days you might miss parts of your old life. The freedom, the energy, the body you knew. That isn't ingratitude. It's a natural part of a big change, and those feelings deserve gentleness too.

`[pause 5s]`

`[warm, reassuring]` Some things about you won't change at all. You are still his. Still loved. Still known, through every season of this pregnancy, and every season after.

`[pause 7s]`

`[prayerful, sincere]` Lord, so much in me is changing. Thank you that your love doesn't change. Thank you for the little life growing within me, morning by morning. Every new morning with this little one is a wonder, and I rest them in your faithful love. Meet me with your compassion each morning, and help me trust you through every new thing. Amen.

`[pause 7s]`

`[tender]` If you'd like, rest a hand on your belly. Your baby will come to know the person you've always been, as well as who you're becoming.

`[pause 8s]`

`[warm]` When you're ready, let your eyes open slowly.

`[pause 4s]`

You're still you. His compassion will meet you new, every morning.

`[music 6s]`

## Week 16 · Sleep for the beloved.

*About 5:04 · 24 paragraphs (9 identical to Grounded) · 2,336 characters*

`[music 6s]`

`[calm, soothing]` If it's evening, you might dim the lights, or turn them off altogether. If it's daytime, that's okay too. Let this be a small evening, wherever you are.

`[pause 5s]`

Find the most comfortable position you can. On your side, with a pillow between your knees, is often lovely at this stage. Use whatever support you have.

`[pause 5s]`

Let your breath slow down by itself. There's nowhere to be.

`[pause 5s]`

`[reverent, calm]` There's a line at the end of Psalm 127 that says:

*for he gives sleep to his loved ones.*

`[pause 7s]`

`[warm, soothing]` Sleep, and rest, as a gift. Not something you have to earn by finishing everything first.

`[pause 5s]`

`[calm, soothing]` Let's begin with your body, one piece at a time.

First, let your eyes rest. Let them grow heavy behind your eyelids.

`[pause 4s]`

Let your ears soften, so sounds become just a gentle background.

`[pause 4s]`

Let your jaw loosen, and your tongue rest at the bottom of your mouth.

`[pause 4s]`

Let your hands lie heavy and open.

`[pause 6s]`

`[gentle wonder]` Even as the house grows quiet, pregnancy doesn't stop being present. Your body continues the remarkable work of supporting this developing baby through the night, just as God designed it to. You don't have to stay awake to supervise that work, and you don't need to make yourself feel grateful before you rest.

`[pause 5s]`

`[calm, soothing]` Now let's give the day to God, without judging any of it.

`[gentle]` What went well today? Thank him for it.

`[pause 8s]`

What was hard? Tell him about it, and leave it with him.

`[pause 8s]`

What's left undone? Let it wait. It's in his hands until morning.

`[pause 8s]`

`[reverent, calm]` Now listen to these words, spoken by the prophet Zephaniah to God's people:

*He will calm you in his love. He will rejoice over you with singing.*

`[pause 8s]`

`[tender, soothing]` Imagine being sung over. Calmed. The way you might one day sing over your own child.

`[pause 6s]`

`[tender]` If you'd like, rest a hand on your belly. Let yourself feel the warmth there as you both settle.

`[pause 6s]`

`[prayerful, soothing]` Lord, I give you this day. Thank you for the little one resting here with me. Calm me in your love, and give me the rest I need. Amen.

`[pause 8s]`

`[calm, soothing]` Stay here. Let your body grow heavier and softer.

`[pause 10s]`

If you're drifting toward sleep, let yourself go. If not, rest here in his care.

`[pause 5s]`

Rest well, beloved.

`[music 6s]`

## Week 17 · Never left alone.

*About 4:48 · 18 paragraphs (10 identical to Grounded) · 2,399 characters*

`[music 6s]`

`[warm, unhurried]` Let's begin by noticing what's holding you up, right now. Literally.

The surface beneath you. The pillow behind your head, or the chair at your back. Let yourself lean into it.

`[pause 6s]`

`[calm]` You don't have to hold yourself up. Something is already doing it for you.

`[pause 6s]`

`[reverent]` The letter to the Hebrews reminds its readers of something God has said:

*I will in no way leave you, neither will I in any way forsake you.*

`[pause 8s]`

`[warm, reassuring]` In no way. Not in the hard moments. Not in the uncertain ones. Not when you feel strong, and not when you feel weak.

`[pause 6s]`

Support comes in many shapes. Some people have a partner, a family, a close circle of friends. Some have one or two people. Some are doing a lot of this on their own. Wherever you are, this meditation is for you.

`[pause 5s]`

`[reverent]` God often shows his care through people. Paul wrote to the churches in Galatia:

*Bear one another's burdens, and so fulfill the law of Christ.*

`[pause 7s]`

`[warm]` Bring to mind a person who's been kind to you during this pregnancy. It might be someone close. It might be a nurse, a coworker, a neighbor, a stranger who held a door.

`[pause 9s]`

Picture their face, if you can. Notice how it feels to remember their kindness. Thank God for them.

`[pause 8s]`

`[gentle wonder]` Your body is offering this baby a place to develop, while you deserve care and support in your own right. Pregnancy isn't a project you should have to manage alone. The extraordinary work happening inside you doesn't make your ordinary needs less important.

`[pause 5s]`

`[tender, reassuring]` If your support system feels complicated, or you're not ready to share every feeling about this pregnancy, you can start smaller. A message, a meal, a quiet check-in: receiving any of those is part of caring for yourself.

`[pause 5s]`

`[warm]` And notice the ways you support yourself, too. Resting when you need to. Eating when you're hungry. Choosing to spend these minutes here. That's support as well.

`[pause 6s]`

`[prayerful, sincere]` Lord, thank you that you never leave me. Thank you for the people who carry my burdens with me, and for the little one I carry. Where I feel alone, draw near, and bring the help I need. Amen.

`[pause 7s]`

`[tender]` If you'd like, rest a hand on your belly. Your baby is being held too, every moment, by you.

`[pause 8s]`

`[warm]` When you're ready, let your eyes open slowly.

`[pause 4s]`

You don't have to do this all by yourself. He goes with you into the rest of today.

`[music 6s]`

## Week 18 · A greeting of joy.

*About 4:42 · 21 paragraphs (7 identical to Grounded) · 2,432 characters*

`[music 6s]`

`[warm, unhurried]` Let's get quiet enough to listen inward.

Find a comfortable position. Lying on your side, or sitting reclined, often makes it easier to notice what's happening inside.

`[pause 6s]`

`[calm]` Let the sounds of the room fade into the background, like distant waves.

`[pause 6s]`

`[warm, storytelling]` As you settle, here's a story. Long ago, two expectant mothers met in a house in the hill country of Judah.

Mary was young, and newly pregnant, carrying news she was still trying to understand. She hurried to visit her relative, Elizabeth, who was also expecting, after years of waiting.

`[pause 4s]`

Imagine Mary arriving at the door, tired from her journey. Imagine Elizabeth hearing her voice.

`[reverent]` Luke tells us:

*When Elizabeth heard Mary's greeting, the baby leaped in her womb.*

`[pause 6s]`

`[reverent, joyful]` And Elizabeth said to her:

*For behold, when the voice of your greeting came into my ears, the baby leaped in my womb for joy!*

`[pause 7s]`

`[warm]` Two women, both carrying new life. Sharing their joy, and their questions, and staying together for months.

`[pause 5s]`

`[warm, reassuring]` Somewhere in these weeks, some people begin to notice tiny movements. Flutters, taps, little bubbles. For others, it takes longer. Every pregnancy has its own timing, and there's no right moment for this.

`[pause 5s]`

`[tender]` Rest your hands on your belly, if you'd like. Let them be still and soft.

`[pause 6s]`

`[calm]` Notice the warmth beneath your hands, and the slow rise and fall of your breath.

`[pause 8s]`

`[gentle]` You don't need to look for any particular sensation right now.

`[pause 5s]`

`[tender]` Your baby lives surrounded by your rhythms. Your heartbeat. Your breathing. The movement of your body through the day. In their own way, they're getting to know you too.

`[pause 6s]`

`[warm]` Elizabeth's joy began with a greeting. Imagine greeting your baby now, in your heart. A simple hello, full of love.

`[pause 8s]`

`[gentle]` Who is an Elizabeth for you? Someone you can share this season with? Thank God for them. Or, if you're longing for someone like that, ask him for it.

`[pause 7s]`

`[prayerful, sincere]` Lord, thank you for the joy of new life, and for the people who share it with me. Help me treasure these sweet days of getting to know my baby, one tender hello at a time. Let joy find its way into my heart, even in the waiting. Amen.

`[pause 7s]`

`[warm]` When you're ready, let your attention widen again to the room around you, and slowly open your eyes.

`[pause 4s]`

May you find small joys to share today.

`[music 6s]`

## Week 19 · The one thing.

*About 4:57 · 20 paragraphs (10 identical to Grounded) · 2,424 characters*

`[music 6s]`

`[warm, lightly smiling]` Some days feel like one long list. Work, errands, appointments, meals, messages, and somewhere in there, growing a baby.

`[pause 5s]`

`[warm]` Today, let's practice a small pause you can take anywhere. Between meetings. In a parking lot. While the kettle boils. It takes about a minute.

Let yourself settle first.

`[pause 5s]`

`[calm, clear]` Here's how it goes. There are just three steps.

First: stop. Let your hands go still, wherever they are.

`[pause 5s]`

Second: feel your feet. Notice where they touch the floor, or the bed, or each other.

`[pause 6s]`

Third: let one breath out be a little longer and softer than the rest. Not forced. Just unhurried.

`[pause 6s]`

That's it. Stop. Feet. One soft breath out.

`[pause 6s]`

`[tender]` If you'd like, add a fourth step whenever you have a moment: a hand on your belly, as a small hello to your baby in the middle of your day.

`[pause 6s]`

`[gentle wonder]` Wherever you pause, in a hallway, beside the car, or between errands, your body is carrying this pregnancy with you. Remarkable work is unfolding even when the rest of life seems ordinary. You can appreciate it for a second without having to stop your entire day.

`[pause 5s]`

`[warm, storytelling]` In Luke's Gospel, Jesus visits the home of two sisters, Martha and Mary. Martha is busy getting everything ready. Mary sits at Jesus' feet, listening.

`[pause 5s]`

`[reverent, tender]` Martha, worn out, asks Jesus to tell her sister to help. And Jesus answers her, gently:

*Martha, Martha, you are anxious and troubled about many things, but one thing is needed.*

`[pause 8s]`

`[warm, reassuring]` Notice that he says her name twice. Kindly. He isn't scolding her for caring, or for working hard. He's inviting her to stop for a moment, and be with him.

`[pause 6s]`

`[tender]` Imagine Jesus saying your name the same way. Kindly. Twice.

`[pause 7s]`

`[gentle]` What are the many things you're anxious and troubled about right now? You can name them to him.

`[pause 8s]`

`[calm]` Now imagine setting them down, just for these few minutes, and sitting at his feet. There's nothing to prepare. Nothing to prove. Just be with him.

`[pause 10s]`

`[prayerful, sincere]` Jesus, my days are full, and my mind is busier still. Thank you for inviting me to sit with you, and for the little one who is with me in every busy hour. Help me find my way back to you, even in the middle of everything. Amen.

`[pause 7s]`

`[warm]` When you're ready, let your eyes open.

`[pause 4s]`

This pause is yours. Sit at his feet whenever you can, even for a moment in a busy day.

`[music 6s]`

## Week 20 · Helped until now.

*About 5:08 · 22 paragraphs (8 identical to Grounded) · 2,540 characters*

`[music 6s]`

`[warm, unhurried]` Wherever you are in your pregnancy, you've likely reached somewhere around the middle. A good place to pause, and look around.

Find a comfortable position, and let yourself settle.

`[pause 6s]`

`[warm, storytelling]` In the book of First Samuel, after a hard-won season, the prophet Samuel set up a large stone as a marker. He named it Ebenezer, which means stone of help, saying:

*the Lord helped us until now.*

`[pause 8s]`

`[warm]` Let's set up a small Ebenezer of your own today.

`[warm, reflective]` First, think of the day you found out you were pregnant. Where were you? What did you feel?

`[pause 8s]`

Whatever you felt then, joy, shock, fear, all of it, it was a real beginning.

`[pause 5s]`

`[gentle]` Now think of one thing that's been hard since then. Something you've carried, or handled, or simply gotten through.

`[pause 8s]`

`[warm, reassuring]` You got through it. Notice that.

`[pause 5s]`

`[gentle, reflective]` Where have you seen God's help? Maybe in a person. A kind word. Strength you didn't know you had.

`[pause 8s]`

`[prayerful]` Thank him for each one, in your own words.

`[pause 8s]`

`[warm]` Now imagine placing a stone, right here, in this moment. A marker that says: God has helped me until now.

`[pause 7s]`

`[gentle wonder]` You've reached a point where you can look back and notice how much has changed: appointments, expectations, sensations, and the quiet work your body has been doing all along. There may be milestones worth celebrating, and there may be memories or uncertainties that make celebrating complicated.

`[pause 5s]`

`[warm, hopeful]` Now let's turn, gently, toward what's ahead.

`[reverent]` Moses spoke these words to Joshua and the people of Israel, as they faced a new and uncertain land:

*The Lord himself is who goes before you. He will be with you. He will not fail you nor forsake you.*

`[pause 8s]`

`[warm, reassuring]` He doesn't promise that the road will be easy. He promises to be with you on it.

`[pause 5s]`

`[gentle]` What feels uncertain about the months ahead? Name it to him. And picture him already there, going before you into each of those places.

`[pause 9s]`

`[tender]` If you'd like, lay a hand on your belly, and think of the developing baby you are carrying today.

`[pause 6s]`

`[prayerful, sincere]` Lord, thank you for helping me until now, and for the little one I've carried with you this far. I trust you with what's ahead, and I place this precious little one, so wonderfully made, in your hands. Go before me, and stay with me, every step of the way. Amen.

`[pause 7s]`

`[warm]` When you're ready, let your eyes open slowly.

`[pause 4s]`

Wherever the road goes from here, the God who has helped you until now is with you still.

`[music 6s]`

## Week 21 · Quietness and confidence.

*About 5:39 · 23 paragraphs (17 identical to Grounded) · 2,732 characters*

`[music 6s]`

`[warm, unhurried]` Hi. This is a time for going a little deeper into rest than usual.

Find a position where your whole body feels supported. Lying on your side, or reclining with pillows behind you. Let every part of you be held.

`[pause 5s]`

`[calm]` Notice your next breath arrive, and let it go. Nothing to change. Just letting it be easy.

`[pause 5s]`

`[reverent]` Through the prophet Isaiah, God spoke to his people about where real strength is found. Among his words is this line:

*Your strength will be in quietness and in confidence.*

`[pause 8s]`

`[warm, reflective]` Quietness and confidence. Not hurry. Not effort. Not trying harder.

`[pause 5s]`

`[calm, soothing]` Imagine you're standing at the top of a gentle path. It winds softly downward through tall grass, toward a garden you can't quite see yet. The air is warm. The light is golden.

`[pause 5s]`

We'll walk down slowly together. With each step, you'll let go a little more.

`[pause 4s]`

The first step. Let your forehead smooth and your eyes grow heavy.

`[pause 5s]`

The next step. Your jaw loosens. Your tongue rests.

`[pause 5s]`

Another step. Your shoulders slide down, away from your ears.

`[pause 5s]`

Another. Your arms grow warm and heavy, all the way to your fingertips.

`[pause 5s]`

Another. Your back softens into whatever is holding you.

`[pause 5s]`

And another. Your hips, your legs, your feet. Heavy, and easy.

`[pause 6s]`

`[gentle wonder]` As you rest more deeply, your body carries on its remarkable work. Your heart is pumping more blood than ever before, warm and steady, nourishing the little one growing inside you. All of it happening, while you simply rest.

`[pause 5s]`

`[calm, peaceful]` Now the path opens into the garden. Notice what's here. Maybe flowers, or soft green leaves, or the sound of water somewhere nearby. Let it be exactly as you'd like it.

`[pause 8s]`

Find a place to settle in your garden. A patch of soft grass. A bench in the shade. Let yourself sink into it.

`[pause 7s]`

`[tender]` If you'd like, rest a hand on your belly, and imagine your baby resting here with you, warm and peaceful.

`[pause 8s]`

`[gentle]` Now, in your heart, simply rest before God. You don't need to say anything. Let your quietness be your prayer.

`[pause 12s]`

`[prayerful, sincere]` Lord, thank you that strength isn't only found in doing. Thank you for the little one resting quietly within me. Teach me to rest in you, to grow quietly confident in your care, and to find moments of peace in these days of carrying new life. Amen.

`[pause 7s]`

`[warm]` This garden is always here for you. You can find your way back down the path whenever you need it.

`[pause 5s]`

When you're ready, take a slightly deeper breath, and let your body gently begin to wake. Fingers. Toes. Eyes opening slowly.

`[pause 4s]`

May quietness and confidence go with you through this day.

`[music 6s]`

## Week 22 · Life and loving kindness.

*About 4:46 · 19 paragraphs (10 identical to Grounded) · 2,284 characters*

`[music 6s]`

`[warm, curious]` Let's take a little journey inward today. Not to anywhere far away. Just to the place where your baby is growing.

`[pause 4s]`

`[calm]` Settle in comfortably. Let your hands find your belly, if that feels natural.

`[pause 5s]`

Let your breath slow down by itself. Let your shoulders drop, and your jaw soften.

`[pause 5s]`

`[warm, reflective]` There's a moment in the book of Job where Job, speaking honestly to God, pauses to remember how he was made. He says:

*You have clothed me with skin and flesh, and knit me together with bones and sinews. You have granted me life and loving kindness.*

`[pause 8s]`

`[gentle wonder]` Skin and flesh. Bones and sinews. Even now, these are being formed in your baby. Tiny fingers and toes. A heartbeat. Eyes, ears, a face that's uniquely theirs.

`[pause 6s]`

Imagine, for a moment, the world your baby knows.

It's warm.

`[pause 5s]`

It's soft. Cushioned on every side, gently rocking whenever you move.

`[pause 5s]`

It's full of rhythm. The steady drum of your heartbeat. The whoosh of your breath. The gurgles and hums of a body at work.

`[pause 6s]`

And it's full of you. Your voice, muffled and warm. Your laugh. The way your body sways when you walk.

`[pause 6s]`

`[tender]` Your baby doesn't know the world outside yet. But they know the rhythm of you. That's their first experience of being held.

`[pause 6s]`

`[warm, reverent]` Notice the last line of Job's words. Life and loving kindness. God doesn't only make us. He gives us life wrapped in his kindness.

`[pause 6s]`

`[tender]` And one day, you'll show that same loving kindness to your child. In a thousand small ways. Feeding, holding, soothing, delighting in them. Love, learned first from the God who loves you.

`[pause 7s]`

If you'd like, say something to your baby, silently or out loud. Something simple. I'm here. We're resting together.

`[pause 9s]`

`[gentle]` Take a moment to thank God, in your own words, for the life he's forming, and for his kindness to you.

`[pause 10s]`

`[prayerful, sincere]` Creator God, thank you for knitting this little one together with such care. Thank you for my body, and for all it's doing. Surround us both with your loving kindness, today and every day. Amen.

`[pause 7s]`

`[warm]` When you're ready, let your attention widen to the room around you, and open your eyes.

`[pause 4s]`

Life and loving kindness, given to you, and to your little one.

`[music 6s]`

## Week 23 · Strength that renews.

*About 5:27 · 25 paragraphs (16 identical to Grounded) · 2,509 characters*

`[music 6s]`

`[warm, unhurried]` Let's start with something you might not stop to notice very often: how strong your body is.

Settle into a comfortable seat, or lie on your side. Let yourself be supported.

`[pause 5s]`

`[calm]` Notice your breath. Let it find its own easy rhythm.

`[pause 5s]`

`[gentle wonder]` Over these months, your body has been doing something extraordinary. It has made room. It has carried more weight, pumped more blood, and grown a whole new organ just to nourish your baby. That's real strength, even on the days you feel tired.

`[pause 6s]`

`[reverent]` Isaiah chapter 40 was written to encourage God's people when they felt worn out. It reminds them that the Creator of the whole earth never grows tired. And then it says:

*He gives power to the weak. He increases the strength of him who has no might.*

`[pause 7s]`

And a little later:

*those who wait for the Lord will renew their strength.*

`[pause 8s]`

`[warm, reflective]` Renew. Not invent from nothing. Renew. Like a well that fills again, or a field that grows green after rain.

`[pause 5s]`

`[calm]` Let's notice your body's strength, and pair it with softness.

Bring your attention to your legs. These legs carry you, and your baby, through every day. Notice their strength.

`[pause 5s]`

And now let them soften. Let them be heavy, and resting.

`[pause 5s]`

Your hips and lower back. They're working hard to support your growing belly. Notice their strength.

`[pause 5s]`

And now let them soften. Let the muscles there release, just a little.

`[pause 5s]`

Your arms and hands. Strong enough to carry so much, and soon, strong enough to hold your baby. Notice them.

`[pause 5s]`

And let them soften, open and easy.

`[pause 5s]`

Your shoulders and neck. They hold more than you realize. Notice them.

`[pause 5s]`

And let them drop. Let the tension melt away.

`[pause 5s]`

Your belly. Stretching, growing, holding your baby close.

`[pause 5s]`

`[tender]` Let it be soft too. There's nothing to hold in. Rest a hand there, if you'd like.

`[pause 8s]`

`[warm]` Let yourself rest in that for a moment. Strong. And soft.

`[pause 8s]`

`[gentle]` Waiting on the Lord can be as simple as this: being still, and receiving. Take a quiet moment to tell God what you need today. Energy, patience, rest, joy.

`[pause 10s]`

`[prayerful, sincere]` Lord, thank you for the strength you've given my body for this work, and for the little one it carries. When I feel tired, renew me. Fill me again, day by day, and help me recognize your goodness throughout this season. Amen.

`[pause 7s]`

`[warm]` When you're ready, let some gentle movement return, and slowly open your eyes.

`[pause 4s]`

May his strength meet you, fresh and new, as you go.

`[music 6s]`

## Week 24 · The breath of life.

*About 4:43 · 19 paragraphs (11 identical to Grounded) · 2,163 characters*

`[music 6s]`

`[warm, unhurried]` Today we'll spend a few minutes with something simple and powerful: the out-breath.

Find a comfortable position, sitting or lying on your side.

`[pause 5s]`

`[calm]` First, just notice your breathing as it is. No changes yet. Notice where you feel it. Your nose, your chest, your belly.

`[pause 7s]`

`[warm]` Each breath is given. Each one, a quiet reminder of the God who made you.

`[pause 5s]`

When we breathe out slowly, our bodies tend to relax. Muscles soften. The mind grows a little quieter. It's one of the gentlest tools you have, and it's always with you.

`[pause 5s]`

`[calm, clear]` Let's try it, only if it feels comfortable.

Breathe in naturally. And then let your breath out a little more slowly than usual. Like a sigh that takes its time.

`[pause 7s]`

Again. A natural breath in. And a long, unhurried breath out.

`[pause 7s]`

There's no number to reach, and no right length. Just a little longer and softer than before.

`[pause 7s]`

`[calm, soothing]` As you breathe out, you might imagine your shoulders melting down. Or your jaw going soft. Or your hands opening.

`[pause 7s]`

`[prayerful]` You might pair your breathing with a simple prayer. Breathing in: You give me life. Breathing out: I rest in you.

`[pause 12s]`

You give me life.

I rest in you.

`[pause 12s]`

`[gentle wonder]` Every breath is part of an extraordinary process. Oxygen moves from your lungs into your bloodstream, helping support both your body and your developing baby. Take a moment to appreciate how much happens naturally, without your having to think about it. What a wonder, the way God made you.

`[pause 6s]`

`[warm, reassuring]` This long, slow exhale is something you can return to anytime. Before sleep. In a waiting room. And later, when it's time to meet your baby. The more familiar it becomes, the more easily it will come to you.

`[pause 6s]`

`[tender]` If you'd like, rest a hand on your belly and thank God for this shared life.

`[pause 8s]`

`[prayerful, sincere]` Lord, thank you for every breath, and for the life growing in me. Let my breathing remind me of your nearness, today, and in the days to come. Amen.

`[pause 7s]`

`[warm]` Now let your breathing return to its natural rhythm, and slowly open your eyes.

`[pause 4s]`

Every breath today is a small gift from him.

`[music 6s]`

## Week 25 · A gift from the Lord.

*About 4:47 · 16 paragraphs (13 identical to Grounded) · 2,335 characters*

`[music 6s]`

`[warm, lightly smiling]` There's someone else who's been busy in there lately. Let's take a few minutes to say hello.

`[pause 4s]`

`[calm]` Find a comfortable position. Lying on your side, or reclining, can make it easier to notice what's happening inside.

`[pause 5s]`

Rest your hands on your belly, wherever feels natural.

`[pause 5s]`

Let your breath settle. Let your body grow still and quiet. Let your shoulders drop, and your face soften.

`[pause 6s]`

`[gentle wonder]` At this stage, you may be becoming more familiar with the sensation of your baby's movements. Perhaps you've noticed little rolls, nudges, or stretches. These moments can offer a lovely opportunity to pause and feel connected to the little life you're carrying.

`[pause 6s]`

`[warm]` For these next few moments, simply pay attention. If you feel a movement, notice where it is and what it feels like.

`[pause 10s]`

`[warm, lightly smiling]` If you'd like, you can answer. A gentle press of your hand. A soft pat. A few words: Hello in there. I feel you.

`[pause 8s]`

`[tender]` Some babies seem to respond to their mother's touch or voice. Whether or not yours moves right now, they're surrounded by your warmth and your rhythm. They know you in their own way.

`[pause 7s]`

`[warm]` Many parents find their baby has favorite times to be active. After a meal, maybe, or just as you lie down at night. You might start to notice your baby's own little rhythms, the first hints of their personality.

`[pause 6s]`

Let yourself enjoy this. The quiet company of the little one you're getting to know.

`[pause 8s]`

`[gentle wonder]` Think of how much is happening in there. Tiny muscles getting stronger. Lungs practicing. Hands opening and closing. Each day, a little more ready for the world.

`[pause 6s]`

Your baby is a gift, and every gift reflects the giver. Your baby's life is a reflection of God's own generosity and delight. Before you ever held them, he knew them.

`[pause 7s]`

`[prayerful, sincere]` Father, thank you for this child, a gift from your hand. Thank you for every movement, every stretch, every sign of life. Help me receive this child with love and care, and cherish every precious day I get to carry them. Amen.

`[pause 7s]`

`[tender]` Before we finish, you might tell your baby one thing you're looking forward to. I can't wait to see your face. Or anything that feels true for you.

`[pause 9s]`

`[warm]` When you're ready, let your hands rest, and open your eyes.

`[pause 4s]`

A gift from the Lord, growing close to your heart.

`[music 6s]`

## Week 26 · My peace I give you.

*About 4:55 · 18 paragraphs (11 identical to Grounded) · 2,342 characters*

`[music 6s]`

`[warm, unhurried]` Picture a clear, gentle stream on a warm afternoon. Sunlight sparkles on the water. The sound is soft and constant.

`[pause 6s]`

`[calm]` Let that sound help you settle. Find a comfortable position, and let your body be supported.

`[pause 5s]`

Let your breath slow down, like the water slowing in a quiet pool.

`[pause 6s]`

`[calm, soothing]` Now look into the stream, and notice a smooth stone resting on the bottom. The water moves over it and around it, all day long. And the stone stays steady.

`[pause 6s]`

Imagine you are that stone. Calm. Grounded. Resting on the riverbed.

`[pause 6s]`

Feel the weight of your body, heavy and settled, the way the stone rests in the sand. Nothing needs to move. Nothing needs to hold on.

`[pause 6s]`

`[warm, storytelling]` On the night before he died, Jesus sat with his closest friends and spoke to them tenderly about the days ahead. Among his words was this gift:

*Peace I leave with you. My peace I give to you.*

`[pause 8s]`

`[warm, reflective]` My peace. Not a peace that depends on everything going perfectly. Jesus' own peace. The kind he carried with him through every day of his life, through crowds and storms and quiet hillsides alike.

`[pause 6s]`

And notice that he gives it. You don't have to manufacture it, or earn it, or find it on your own. It's a gift, offered freely.

`[pause 6s]`

`[gentle]` Life flows around you. Plans, conversations, to-do lists, new things to learn. All of it can move past, like water, while you stay steady at your center.

`[pause 7s]`

`[gentle wonder]` And within you, your baby rests in their own gentle waters, rocked and cushioned, surrounded by warmth. Steady, and held, while life flows around them.

`[pause 6s]`

`[tender]` If you'd like, rest a hand on your belly. Two steady centers, resting together.

`[pause 8s]`

`[warm, reassuring]` This place of steadiness is something you can come back to. On busy days. When things feel like a lot. And later, when you're welcoming your baby. You can always find the stone beneath the water.

`[pause 7s]`

`[gentle]` Now take a moment to talk with Jesus. Thank him for his peace, and tell him anything that's on your heart.

`[pause 10s]`

`[prayerful, sincere]` Jesus, thank you for giving me your own peace. Let it fill my heart and my home, and rest on this little one too. Thank you for the blessing of this child. Amen.

`[pause 7s]`

`[warm]` When you're ready, let your body begin to stir, and open your eyes.

`[pause 4s]`

His peace is yours to keep.

`[music 6s]`

## Week 27 · In wisdom you made them.

*About 4:51 · 21 paragraphs (16 identical to Grounded) · 2,286 characters*

`[music 6s]`

`[warm, unhurried]` Hello. Today, you're going to write a little letter. Not on paper. Just in your heart, to your body.

Settle in comfortably, and let yourself be supported.

`[pause 5s]`

`[calm]` Let your breath slow. Let your eyes close, or rest your gaze gently. Let your shoulders soften as you breathe out.

`[pause 5s]`

`[warm, reflective]` Psalm 104 is one long song of wonder. It moves through mountains and springs, birds and trees, sunrise and moonlight. And then the psalmist breaks into praise:

*Lord, how many are your works! In wisdom, you have made them all.*

`[pause 8s]`

`[gentle wonder]` As your second trimester nears its end, it's worth pausing to notice how much your body has done. Growing a placenta. Making more blood. Shifting and stretching to make room. Sheltering your baby through every hour of every day.

`[pause 6s]`

`[warm]` Let's begin your letter. Dear body.

`[pause 4s]`

`[tender]` Thank you, heart, for beating stronger for two.

`[pause 5s]`

Thank you, lungs, for every breath we share.

`[pause 5s]`

Thank you, belly, for making room, and holding our baby close.

`[pause 5s]`

Thank you, back and hips, for carrying more than ever before.

`[pause 5s]`

Thank you, legs and feet, for taking us everywhere we need to go.

`[pause 5s]`

Thank you, skin, for stretching and growing with us.

`[pause 5s]`

Thank you, hands, for resting on our baby, and for all the holding still to come.

`[pause 6s]`

`[warm]` Now add your own lines. Is there something your body has done that you're especially grateful for? A day it carried you through. A moment it surprised you. Tell it, in your own words.

`[pause 10s]`

`[warm, reassuring]` Your body may not always feel comfortable. It's working very hard. Gratitude doesn't mean every moment feels good. It simply means noticing the remarkable things it's doing, right now.

`[pause 6s]`

`[calm]` Rest for a moment in the knowledge that you, and your baby, are part of God's good creation. Made with wisdom. Made with care.

`[pause 6s]`

`[tender]` If you'd like, rest a hand on your belly, and finish your letter. Thank you for this. Thank you for us.

`[pause 8s]`

`[prayerful, sincere]` Lord, how many are your works! Thank you for the wisdom woven into my body, and for the little one you're forming. Let me see your goodness everywhere I look today. Amen.

`[pause 7s]`

`[warm]` When you're ready, let your hands rest, and slowly open your eyes.

`[pause 4s]`

You are part of his wise and wonderful work.

`[music 6s]`

## Week 28 · A place prepared with love.

*About 5:09 · 18 paragraphs (12 identical to Grounded) · 2,507 characters*

`[music 6s]`

`[warm, lightly smiling]` Many people feel an urge, around this time, to prepare. To fold tiny clothes, arrange a corner of a room, make things ready. Today, let's prepare in a gentler way.

`[pause 4s]`

`[calm]` Find a comfortable position, well supported. Let your breath settle. Let your shoulders soften, and your hands rest.

`[pause 6s]`

`[reverent]` On the night before he died, Jesus comforted his friends by telling them about his Father's house, with room for all of them. And he said:

*I am going to prepare a place for you.*

`[pause 8s]`

`[warm, reflective]` There's something deeply loving about preparing a place for someone. It says: I've been thinking of you. I want you to feel at home. Jesus offers that kind of love to each of us.

`[pause 6s]`

`[calm, peaceful]` Imagine a space where your baby will rest when they arrive. It doesn't have to be fancy, or finished. Just picture it as you'd like it to be.

`[pause 6s]`

Notice the light in that space. Soft morning light, maybe. Or a warm lamp in the evening.

`[pause 6s]`

Notice what's there. A blanket, folded. Something soft to hold. Maybe a chair where you'll sit together.

`[pause 6s]`

Notice the sounds. Quiet, perhaps. Or a little music. Or the hum of a home going about its day.

`[pause 6s]`

`[tender]` Imagine the feeling of that space. Calm. Safe. Welcoming. A nest, made with love.

`[pause 7s]`

`[warm]` Now notice that you're preparing another kind of space too. A space inside you. In your heart, your days, your life. Room for a new person to belong.

`[pause 6s]`

`[gentle wonder]` Your body has been preparing all along, making room week by week, without being asked. Your heart is learning to do the same. Each time you think of your baby, talk to them, or rest a hand on your belly, that inner nest grows a little warmer.

`[pause 6s]`

`[tender]` If you'd like, rest a hand on your belly, and imagine welcoming your baby into both spaces. The nest in your home, and the nest in your heart.

`[pause 8s]`

`[warm, reassuring]` You don't have to have everything ready. Babies need warmth, and closeness, and love, and you're already preparing all of those.

`[pause 6s]`

`[gentle]` Now take a moment to pray over your home, and the place you're making. Ask God to fill it with peace, and love, and joy.

`[pause 10s]`

`[prayerful, sincere]` Lord, thank you for preparing a place for me in your love, and for the little one we're making room for. Bless the home I'm preparing for this little one. Let it be warm with your presence, and full of welcome. Amen.

`[pause 7s]`

`[warm]` When you're ready, let your hands rest, and slowly open your eyes.

`[pause 4s]`

A place made ready, with love, for someone dearly wanted.

`[music 6s]`

## Week 29 · In the shadow of your wings.

*About 4:39 · 18 paragraphs (12 identical to Grounded) · 2,270 characters*

`[music 6s]`

`[warm, understanding]` As your baby grows, your body is changing shape quickly. Some positions that used to feel comfortable might not anymore. Let's take a few minutes to find some ease.

`[pause 4s]`

`[calm]` Try lying on your side, with a pillow between your knees and another under your belly, if you have one. Or sit reclined, well propped up. Take your time getting comfortable.

`[pause 8s]`

`[gentle wonder]` Your baby is taking up more room these days, and your organs have been gently shifting to make space. It's an amazing bit of rearranging, happening quietly inside you.

`[pause 6s]`

`[calm]` Because of that, you might notice your breath feels a little higher in your chest. Let's give it some room.

Rest one hand on the side of your ribs.

`[pause 5s]`

As you breathe in, notice your ribs widening gently under your hand, like an umbrella opening.

`[pause 6s]`

As you breathe out, feel them settle.

`[pause 6s]`

Let a few breaths come this way. Wide and easy, without forcing anything.

`[pause 10s]`

`[reverent]` David wrote Psalm 63 while he was out in the wilderness. Even there, he remembered God through the night, and wrote:

*For you have been my help. I will rejoice in the shadow of your wings.*

`[pause 8s]`

`[warm, reflective]` The shadow of wings. Imagine a mother bird gathering her little ones close, sheltering them beneath her. Warm. Safe. Completely covered.

`[pause 6s]`

`[calm, soothing]` Now let your breathing return to its natural rhythm, and let the rest of your body soften. Your shoulders. Your jaw. Your hands.

`[pause 7s]`

Notice any place that feels tight or tired, perhaps your lower back, or your hips. Imagine breathing a little warmth there. Let the pillows and the bed take more of your weight.

`[pause 7s]`

`[tender]` If you'd like, move your hand to your belly. Your baby is growing and stretching, making the most of the space you've given them.

`[pause 6s]`

`[gentle wonder]` Notice the shelter you are providing too. Your baby rests within you, surrounded by warmth, cushioned and close. Just as God shelters you, you shelter your little one.

`[pause 7s]`

`[prayerful, sincere]` Lord, you have been my help. Thank you for sheltering me, and for letting me shelter this little one. Let me rest and rejoice in the shadow of your wings. Amen.

`[pause 7s]`

`[warm]` When you're ready, take your time coming back. Move slowly, and open your eyes.

`[pause 4s]`

Sheltered, and sheltering, in his care.

`[music 6s]`

## Week 30 · As a mother comforts.

*About 4:28 · 16 paragraphs (9 identical to Grounded) · 2,049 characters*

`[music 6s]`

`[warm, tender]` Today, let's spend a few minutes with something joyful: looking forward to welcoming your baby.

`[pause 4s]`

`[calm]` Find a comfortable position, and let yourself be supported. Let your breath slow down.

`[pause 6s]`

Let your body soften. Your shoulders. Your jaw. Your hands. Let your whole body feel warm and easy.

`[pause 6s]`

`[reverent]` Through the prophet Isaiah, God spoke these tender words to his people:

*As one whom his mother comforts, so I will comfort you.*

`[pause 8s]`

`[warm, reflective]` Of all the ways God could describe his love, here he chooses a mother's comfort. Close. Patient. Tender. Unhurried.

`[pause 6s]`

`[warm, reassuring]` If you'd like, imagine a moment of welcoming your baby. You don't need to picture every detail. Simply allow yourself to reflect on the love and tenderness you hope to share.

`[pause 8s]`

`[tender]` Perhaps you imagine the warmth of a tiny body held close. Perhaps a small hand, or a sleepy face you've wondered about for months. Or perhaps no picture comes at all, only a feeling. Whatever comes is enough.

`[pause 8s]`

`[warm]` Think of the small, everyday ways you hope to share that love. A gentle voice. A soft song. Warm arms, and a lap to rest in.

`[pause 8s]`

What would you like your baby to know about how loved they are? Let the words come in your own way, silently or out loud.

`[pause 10s]`

`[gentle wonder]` Your voice is one your baby already knows. They've been hearing it for months, from the inside. The love you're imagining has already begun.

`[pause 7s]`

`[calm, soothing]` Now let yourself be the one comforted. Imagine God's comfort wrapping around you, the way a mother wraps her arms around her child. Let your whole body rest.

`[pause 8s]`

`[tender]` If you'd like, rest a hand on your belly. You, comforted by God. Your baby, comforted by you.

`[pause 7s]`

`[prayerful, sincere]` Lord, thank you for comforting me the way a mother comforts her child. Thank you for the gift of my baby. Just as you hold me, I rest this little one in your loving arms. Teach me to comfort my baby with that same tender love. Amen.

`[pause 7s]`

`[warm]` When you're ready, let your eyes open slowly.

`[pause 4s]`

Comforted, and ready to comfort, in his love.

`[music 6s]`

## Week 31 · Through the waters.

*About 5:48 · 23 paragraphs (17 identical to Grounded) · 2,739 characters*

`[music 6s]`

`[warm, unhurried]` Imagine you're sitting on warm sand, at the edge of a calm sea. The sun is low and golden. The water is gentle.

`[pause 6s]`

`[calm]` Let that picture help you settle. Find a comfortable position, and let your body be supported.

`[pause 5s]`

Let your breath slow down by itself, as easy as the water.

`[pause 6s]`

`[reverent]` Long ago, through the prophet Isaiah, God spoke to his people about the journeys ahead of them. Among his words was this:

*When you pass through the waters, I will be with you.*

`[pause 8s]`

`[warm, reflective]` God didn't describe the waters. He didn't say how deep, or how long. He simply said: I will be with you. His presence is the heart of the promise.

`[pause 6s]`

`[calm, soothing]` Now watch the waves. Each one begins far out, small and quiet. It slowly rises. It reaches its fullest point. And then it eases, spreading softly across the sand, and drawing back into stillness.

`[pause 8s]`

Rise. Peak. Ease. And then a pause, before the next one begins.

`[pause 6s]`

`[warm]` Many people find this a helpful picture for the contractions of labor, sometimes called surges or waves. Each one has a beginning, a middle, and an end. And between them, a time of rest.

`[pause 5s]`

`[calm, clear]` Let's practice breathing with an imagined wave. Only if it feels comfortable.

As the wave begins to rise, breathe in naturally.

`[pause 5s]`

As it reaches its peak and begins to ease, let your breath out long and slow, like the water spreading over the sand.

`[pause 7s]`

And now, the stillness between. Let your whole body rest.

`[pause 8s]`

Let's ride one more. The wave rises… breathe in.

`[pause 5s]`

It peaks and eases… a long, slow breath out.

`[pause 7s]`

And rest.

`[pause 8s]`

`[tender]` The same God who has been with you through every week of this pregnancy is with you in the weeks ahead, and in the moment you meet your baby.

`[pause 6s]`

`[warm]` This picture is yours to keep, and to come back to whenever you like. You'll have other tools too, and there's no single right way to use any of them.

`[pause 5s]`

`[gentle wonder]` Your body is full of extraordinary rhythms. Your heart beats steadily, supporting the remarkable work of pregnancy. Your breath rises and falls without conscious effort, while your baby develops within you. Take a moment to appreciate the beautiful connection between your body and the little life you're carrying.

`[pause 6s]`

`[tender]` If you'd like, rest a hand on your belly, and imagine the gentle sea holding you both.

`[pause 7s]`

`[prayerful, sincere]` Lord, thank you that you are with me. Thank you for the little one traveling this path with me. In every wave, and in every rest between, let me know your nearness. Be with my baby, and be with me, every step of the way. Amen.

`[pause 7s]`

`[warm]` When you're ready, let the sea fade gently, and open your eyes.

`[pause 4s]`

Wherever your path leads, he goes with you.

`[music 6s]`

## Week 32 · A quiet soul.

*About 5:30 · 22 paragraphs (14 identical to Grounded) · 2,607 characters*

`[music 6s]`

`[warm, curious]` Let's begin with a small experiment. Clench your jaw, just slightly. Notice how your shoulders and hands want to tighten with it.

`[pause 5s]`

Now let your jaw go loose. Notice what happens in the rest of your body.

`[pause 6s]`

`[warm]` Our bodies are connected in surprising ways. When one place softens, others often follow. That's what we'll practice today.

`[pause 4s]`

`[calm]` Find a comfortable position, supported and easy.

`[pause 5s]`

`[reverent]` There's a short psalm, only three verses long, that paints one of the most tender pictures in Scripture. David writes:

*Surely I have stilled and quieted my soul, like a weaned child with his mother, like a weaned child is my soul within me.*

`[pause 8s]`

`[warm, reflective]` A little one resting against their mother. Not asking for anything. Not needing anything. Just content to be close.

`[pause 6s]`

`[warm]` That kind of quiet doesn't come from having everything figured out. It comes from trust. From knowing you're held.

`[pause 5s]`

`[calm]` Begin with your face. Let your forehead smooth. Let the space between your eyebrows widen.

`[pause 5s]`

Your jaw. Let your teeth part slightly, and your lips rest softly together.

`[pause 6s]`

Your hands. Let them open, palms up, fingers loose and curled like a sleeping baby's.

`[pause 5s]`

Ready to receive, rather than hold on.

`[pause 5s]`

Your shoulders. Let them drop away from your ears. Then let them drop a little more.

`[pause 6s]`

`[tender]` Your belly. Allow the muscles to soften, wherever that feels comfortable. There's no need to hold anything in. Take a moment to appreciate the remarkable ways your body has adapted to make room for your growing baby.

`[pause 7s]`

`[calm, soothing]` Now, with each slow breath out, imagine all of these places softening together. Face, jaw, hands, shoulders, belly. Soft and open.

`[pause 8s]`

`[warm]` Many people find that a soft face and loose hands help the whole body settle, during everyday moments, and during labor too. It's a simple thing you can come back to, anytime.

`[pause 5s]`

`[gentle wonder]` Your body has been opening for months. Making room. Stretching. Shifting. Growing around your baby with remarkable flexibility. Softening is something it already knows how to do.

`[pause 6s]`

`[calm]` Stay soft for a moment longer. Let your breath move freely through an easy, open body.

`[pause 8s]`

`[gentle]` Rest in God's presence for a moment. There's nothing you need to ask for. Simply be near him.

`[pause 10s]`

`[prayerful, sincere]` Lord, quiet my soul like a child resting with its mother. Thank you for holding me close, and for the gift of the little one I hold within me. What a miracle that I get to carry them. Amen.

`[pause 7s]`

`[warm]` When you're ready, let some movement return, and open your eyes.

`[pause 4s]`

A quiet soul, resting close to him.

`[music 6s]`

## Week 33 · Fullness of joy.

*About 4:39 · 19 paragraphs (15 identical to Grounded) · 2,092 characters*

`[music 6s]`

`[warm, unhurried]` Today, you'll create something you can take with you anywhere: a calm place, all your own.

Find a comfortable position, and let your breath slow down.

`[pause 6s]`

`[calm, peaceful]` Let a peaceful place come to mind. It might be somewhere you've been. A beach, a garden, a quiet room. Or somewhere completely imagined. Let the first gentle place that appears be enough.

`[pause 7s]`

`[calm]` Now step into it with your senses.

What do you see? The colors. The light. The shapes around you.

`[pause 6s]`

What do you hear? Maybe water, or wind, or birdsong. Or a lovely quiet.

`[pause 6s]`

What do you feel? Warm sun. A cool breeze. Soft ground beneath you.

`[pause 6s]`

Is there a scent? Salt air, fresh rain, flowers, warm bread?

`[pause 6s]`

`[warm]` Let yourself settle into this place. Notice how your body feels here. Easy. Safe. At home.

`[pause 6s]`

`[tender]` And notice that you aren't here alone. God is with you. Unhurried. Glad to be with you.

`[pause 9s]`

`[calm, clear]` Now let's give your calm place a small cue, a way to find it quickly. Gently touch your thumb to the tip of one finger. Keep it there, and keep breathing in your calm place.

`[pause 9s]`

Let the feeling of this place and the feeling of that touch belong together.

`[pause 6s]`

Now release your fingers.

`[pause 4s]`

`[warm]` Whenever you'd like to return, on a busy day, before sleep, or during labor, you can touch your thumb to your finger, breathe slowly, and remember: he is with you.

`[pause 6s]`

`[gentle wonder]` Within you, your baby is surrounded by a world of warmth, movement, and familiar rhythms. Your body has created an extraordinary environment for this little life to develop. Take a moment to appreciate that beautiful connection.

`[pause 6s]`

`[tender]` If you'd like, rest a hand on your belly, and imagine your baby with you in your calm place.

`[pause 8s]`

`[prayerful, sincere]` Lord, thank you that in your presence there is fullness of joy. Thank you for the little one with me in this quiet place. Show me the path of life, and let me walk it with you, one step at a time. Amen.

`[pause 7s]`

`[warm]` When you're ready, let your calm place fade gently, and open your eyes.

`[pause 4s]`

His presence is always just a breath away.

`[music 6s]`

## Week 34 · Held up by love.

*About 4:38 · 16 paragraphs (10 identical to Grounded) · 2,137 characters*

`[music 6s]`

`[warm, unhurried]` As your baby's birthday draws closer, let's take a few minutes to think about care. Not the plans or the paperwork. Just the feeling of being cared for.

`[pause 5s]`

`[calm]` Find a comfortable position, and let yourself be supported.

`[pause 5s]`

Let your breath slow down. Let your shoulders soften.

`[pause 6s]`

`[warm]` Support looks different for everyone. A partner, a friend, a family member, a doula, a midwife or doctor, a calm nurse. Some people will have many people beside them. Some, just one or two. Every kind of care counts.

`[pause 6s]`

Bring them to mind, one by one. Thank God for each of them.

`[pause 10s]`

`[calm, peaceful]` Now imagine the kind of care that would help you feel at ease. Not a specific scene. Just the feeling of it.

`[pause 6s]`

Perhaps it's a calm voice. Perhaps a hand on your shoulder, or someone who knows when to simply be quiet.

`[pause 7s]`

Perhaps it's a comfort from home. Your own pillow. A favorite song. A soft light.

`[pause 7s]`

`[warm]` Notice what matters most to you. These are worth sharing with the people who'll be with you. Some people like to write them down as part of their birth preferences, so everyone can see what helps.

`[pause 6s]`

`[warm, reassuring]` And remember the care you give yourself too. Resting. Asking for what you need. Being patient and kind with yourself. You're part of your own circle of care.

`[pause 6s]`

`[gentle wonder]` Your baby has been surrounded by care since the very beginning, by you. Your warmth. Your heartbeat. The nourishment your body gives them every moment. Soon, they'll be surrounded by your arms, too. And through it all, God holds you both.

`[pause 6s]`

`[tender]` If you'd like, rest a hand on your belly, and imagine that circle of care around you.

`[pause 7s]`

`[gentle]` Now take a moment to pray for those who will be with you. For their wisdom, their kindness, and their care.

`[pause 10s]`

`[prayerful, sincere]` Lord, thank you for the people who hold me up, and for the little one at the center of all this care. Give them wisdom, gentleness and strength. Surround my baby and me with your care, and with theirs. Amen.

`[pause 7s]`

`[warm]` When you're ready, let your hands rest, and open your eyes.

`[pause 4s]`

You deserve care and support, too. Held up by love, and by him.

`[music 6s]`

## Week 35 · Grace that is enough.

*About 5:06 · 21 paragraphs (10 identical to Grounded) · 2,346 characters*

`[music 6s]`

`[warm, unhurried]` Hello. In these final weeks, you've been growing in so many ways. Not only your body, but your heart, your confidence, your readiness. Let's take a few minutes to notice that.

`[pause 5s]`

`[calm]` Find a comfortable position, and let yourself be supported. Let your breath slow down by itself.

`[pause 6s]`

Let your forehead smooth. Your jaw soften. Your hands open.

`[pause 6s]`

`[reverent]` The apostle Paul once asked God, more than once, to take away something that was hard for him. And he received this answer:

*My grace is sufficient for you, for my power is made perfect in weakness.*

`[pause 8s]`

`[warm]` Sufficient. Enough. God's grace doesn't wait until you feel strong. It meets you right where you are, with exactly what you need for today.

`[pause 6s]`

`[gentle wonder]` Think about the extraordinary changes of these past months. From the earliest stages of development to the little one you're carrying today, so much has taken place within you. Your body has adapted in remarkable ways, with a wisdom God placed within it, and there's something beautiful about taking a moment to appreciate that work.

`[pause 6s]`

`[warm]` Today, let's gather a few gentle words you can carry with you. Words you can return to on any day, and when it's time to meet your baby.

`[pause 5s]`

`[calm, reassuring]` Listen to each one, and notice whether it feels right for you.

I can take this one moment at a time.

`[pause 6s]`

His grace is enough for this moment.

`[pause 6s]`

The Lord is with me.

`[pause 6s]`

I can rest in him.

`[pause 6s]`

My baby and I are in this together.

`[pause 7s]`

Choose one, or one from Scripture that you love. Repeat it slowly to yourself, with each breath out.

`[pause 12s]`

`[warm]` You might write your words down later, or put them somewhere you'll see them often. A note on the mirror. A message on your phone.

`[pause 5s]`

`[warm, reassuring]` These words aren't meant to make anything happen. They're simply companions. Something kind to hold on to.

`[pause 6s]`

`[tender]` If you'd like, rest a hand on your belly, and pray your words over your baby too.

`[pause 8s]`

`[prayerful, sincere]` Lord, thank you that your grace is enough for me. Thank you for this child, a gift of your grace. Give me what I need for each day, and for the day I meet my child. Let me lean on you, and rest in you. Amen.

`[pause 7s]`

`[warm]` When you're ready, let your eyes open slowly.

`[pause 4s]`

Enough grace, for today and for every day ahead.

`[music 6s]`

## Week 36 · My help comes from the Lord.

*About 5:21 · 21 paragraphs (15 identical to Grounded) · 2,458 characters*

`[music 6s]`

`[warm, unhurried]` There's a part of any rhythm that's easy to overlook: the rest in between. Today, that's what we'll practice.

`[pause 4s]`

`[calm]` Find a comfortable position, and let yourself be fully supported.

`[pause 5s]`

Let your breath slow down. Let your face soften.

`[pause 6s]`

`[reverent]` Psalm 121 is one of the songs God's people sang as they traveled up to Jerusalem. It begins:

*I will lift up my eyes to the hills. Where does my help come from? My help comes from the Lord, who made heaven and earth.*

`[pause 8s]`

`[warm]` My help comes from the Lord. The same God who made the mountains, the stars, and the little one within you is the one who helps you.

`[pause 6s]`

In labor, contractions come and go, like waves. And between them, there's time to rest. Many people find that learning to rest fully, even for a short while, makes a real difference.

`[pause 5s]`

`[calm, clear]` Let's practice. If it's comfortable, gently press your palms together in front of you. Not hard. Just enough to feel a little effort. Hold it, and keep breathing.

`[pause 6s]`

And release. Let your hands fall open. Let your shoulders drop.

`[pause 4s]`

`[calm, soothing]` Now rest completely. Let your body go heavy. Let your breath slow. Notice how good it feels to let go.

`[pause 10s]`

Once more. Press your palms gently together. A little effort. Keep breathing.

`[pause 6s]`

And release.

`[pause 4s]`

Rest. Every muscle softening. Your jaw, your hands, your belly. Sinking into whatever holds you.

`[pause 10s]`

You might notice how quickly your body learns. Each time you let go, it gets a little easier.

`[pause 5s]`

`[warm, reassuring]` You can practice this kind of rest anytime. After a busy morning. Before sleep. And whenever you notice yourself holding on, you can remember: I'm allowed to let go.

`[pause 6s]`

`[gentle wonder]` Your baby has rhythms of their own, growing and developing within the remarkable environment your body provides. As you rest here, take a moment to appreciate the life you're carrying and the connection you share.

`[pause 6s]`

`[tender]` If you'd like, rest a hand on your belly, and enjoy this quiet moment together.

`[pause 8s]`

`[gentle]` Take a quiet moment to lift your eyes to the Lord. Tell him what help you'd like in these final weeks.

`[pause 10s]`

`[prayerful, sincere]` Lord, my help comes from you. Thank you for carrying me this far, as I carry this little one. Teach me to rest in you between every effort, and stay near to me and my baby in the days ahead. Amen.

`[pause 7s]`

`[warm]` When you're ready, let your eyes open slowly.

`[pause 4s]`

Lift your eyes. Your help is near.

`[music 6s]`

## Week 37 · A time for everything.

*About 5:02 · 18 paragraphs (11 identical to Grounded) · 2,455 characters*

`[music 6s]`

`[warm, unhurried]` Let's begin with your hands. Wherever they're resting, turn them palms up, if that's comfortable.

`[pause 5s]`

`[calm]` Find a supported position, and let your breath slow down by itself. Let your shoulders soften.

`[pause 6s]`

`[reverent]` The book of Ecclesiastes has a beautiful passage about the rhythm of life. It begins:

*For everything there is a season, and a time for every purpose under heaven.*

`[pause 8s]`

`[warm, reflective]` A time for every purpose. A season for everything. Including this season, these final weeks of waiting and preparing, and the day you'll meet your baby.

`[pause 6s]`

`[warm]` As your baby's arrival draws near, you may have been thinking about plans. Who will be with you. What might help. The bag by the door. Plans are a lovely way to prepare, and they can be held gently.

`[pause 6s]`

`[calm, clear]` Try this. Gently close your hands, as if you were holding something tightly.

`[pause 5s]`

Notice how that feels. The effort in your fingers, your wrists, your arms.

`[pause 5s]`

Now let your hands open again, palms up and relaxed.

`[pause 6s]`

`[warm, reassuring]` Open hands can still hold things. They just hold them lightly. Your hopes and preferences are still there, resting in your open palms, ready to adapt as the day unfolds.

`[pause 6s]`

`[gentle]` Now offer your plans to God, one by one, in your own words. Place each one in your open hands, and lift it to him.

`[pause 10s]`

`[gentle wonder]` Your body has been adapting for months. Making room, shifting, changing, carrying your baby with remarkable flexibility. Take a moment to appreciate that work, and allow yourself to approach the coming days with gentleness and an open heart.

`[pause 6s]`

`[calm]` Now let your whole body follow your hands. Open, soft, and easy. Your face. Your jaw. Your shoulders. Your belly.

`[pause 8s]`

`[tender]` If you'd like, rest one open hand on your belly. Imagine holding your hopes for your baby the same way. Warmly. Gently. With love.

`[pause 8s]`

`[warm]` Whatever plans you've made, the most important preparation is already happening. You're learning your baby. You're making room in your heart. You're getting ready to meet someone you already love.

`[pause 7s]`

`[prayerful, sincere]` Lord, thank you for this season, and for the little one at the heart of it. I give you my plans and my hopes for this birth. Help me hold them with open hands, and trust you through the days ahead. Be near to me and my baby, today and every day. Amen.

`[pause 7s]`

`[warm]` When you're ready, let your hands rest, and open your eyes.

`[pause 4s]`

There is a time for everything, and this time is held by him.

`[music 6s]`

## Week 38 · My times are in your hand.

*About 5:09 · 18 paragraphs (10 identical to Grounded) · 2,373 characters*

`[music 6s]`

`[warm, unhurried]` Here's a gentle thought to rest with today: you only ever have to meet one moment at a time.

`[pause 5s]`

`[calm]` Find a comfortable position. Let your breath slow down. Let your body be supported.

`[pause 6s]`

`[reverent]` In Psalm 31, David prays honestly to God, and in the middle of his prayer, he says:

*But I trust in you, Lord. I said, You are my God. My times are in your hand.*

`[pause 8s]`

`[warm, reflective]` My times are in your hand. Not just the big moments, but each one. This breath. This hour. This day. And the day you'll meet your baby.

`[pause 6s]`

`[calm, clear]` Let's practice. Notice this breath. Only this one. The air coming in, and going out.

`[pause 6s]`

Now this moment. The feeling of whatever is beneath you. The sounds in the room.

`[pause 6s]`

If your mind jumps ahead, gently bring it back, and pray: My times are in your hand.

`[pause 9s]`

Notice one thing you can hear right now. One thing you can feel. One thing you can see, even behind closed eyes, like light or shadow. Each one is a small anchor to now.

`[pause 8s]`

`[warm, reassuring]` You won't always manage to stay in the present, and that's fine. Every time you notice your mind wandering and gently come back, that is the practice. It grows a little stronger each time.

`[pause 6s]`

`[warm]` Many people find this a steadying way to approach labor. Not thinking about how long it might be, or what comes next. Just meeting each contraction as it comes, and then the rest that follows. One moment, and then the next.

`[pause 6s]`

`[calm, soothing]` Between contractions, you can return to this simple prayer. My times are in your hand. Rest, and breathe, and let the next moment come in its own time.

`[pause 7s]`

`[gentle wonder]` Your baby lives entirely in the present. Each moment, they grow, and stretch, and rest, without a thought for tomorrow. There's something lovely about joining them there, even for a few minutes.

`[pause 6s]`

`[tender]` If you'd like, rest a hand on your belly. This moment, together.

`[pause 7s]`

`[gentle]` Now take a moment to entrust your times to God. Today. This week. The day your baby arrives. Tell him, in your own words.

`[pause 10s]`

`[prayerful, sincere]` Lord, I trust in you. You are my God. My times are in your hand, and so is this precious little life. Thank you for this little one, and for this moment together. Help me meet each moment with you, one breath at a time. Amen.

`[pause 7s]`

`[warm]` When you're ready, let your eyes open slowly.

`[pause 4s]`

Every moment ahead is already in his hand.

`[music 6s]`

## Week 39 · God of all comfort.

*About 4:40 · 18 paragraphs (11 identical to Grounded) · 2,156 characters*

`[music 6s]`

`[warm, unhurried]` Today, let's gather a little collection of comforts. Things you might reach for in the days ahead, and when it's time to meet your baby.

`[pause 5s]`

`[calm]` Find a comfortable position, and let your breath slow down.

`[pause 6s]`

`[warm, reflective]` God is the God of all comfort. Not some comfort. All of it. Every warm blanket, every kind hand, every quiet moment of relief comes from his heart for you.

`[pause 6s]`

`[warm]` Different things help different people, and what helps can change from hour to hour. So think of these as possibilities. Gentle options, not a checklist.

`[pause 5s]`

`[calm, peaceful]` Warmth. A warm shower or bath, a heat pack, a soft blanket. Imagine warmth spreading through your back and hips.

`[pause 7s]`

Movement. Swaying, rocking, walking, leaning on something steady. Imagine your hips swaying gently, side to side.

`[pause 7s]`

Sound. Worship music you love. A familiar voice. Or simple quiet.

`[pause 7s]`

Touch. A hand on your back. Firm pressure, or a light stroke. Or perhaps no touch at all. Notice what you'd prefer.

`[pause 7s]`

Scent. A familiar lotion, a soft fabric that smells of home, fresh air through an open window.

`[pause 6s]`

Prayer. A short phrase of Scripture, like the one you chose a few weeks ago.

`[pause 7s]`

Breath. A long, slow breath out, whenever it feels right.

`[pause 7s]`

Rest. Stillness between efforts, eyes closed, held in his care.

`[pause 6s]`

`[warm, reassuring]` You won't need all of these, and some may not help you at all. That's completely fine. You can try one thing, let it go, and try another. You get to discover what works for you.

`[pause 6s]`

`[gentle wonder]` Your body has been finding its own comforts all along, shifting to ease your back, seeking rest when it's tired. You know more about what you need than you might think.

`[pause 6s]`

`[tender]` If you'd like, rest a hand on your belly, close to your baby.

`[pause 7s]`

`[prayerful, sincere]` Father of mercies, God of all comfort, thank you for every comfort you give, and for this little one, so close to me now. In the days ahead, surround me with your comfort, and show me what helps. Amen.

`[pause 7s]`

`[warm]` When you're ready, let your eyes open slowly.

`[pause 4s]`

All comfort, from the God who loves you.

`[music 6s]`

## Week 40 · I wait for the Lord.

*About 4:48 · 16 paragraphs (10 identical to Grounded) · 2,282 characters*

`[music 6s]`

`[warm, lightly smiling]` You may be hearing a lot of the same question lately. Any news yet? Let's take a few minutes away from all of that.

`[pause 5s]`

`[calm]` Find your most comfortable position. Let your breath slow down by itself.

`[pause 6s]`

`[warm, reassuring]` A due date is an estimate, not an appointment your baby is expected to keep. As you approach this part of pregnancy, you may be following a plan with your care team for the days ahead. For these few minutes, you can set aside the calendar and simply rest.

`[pause 6s]`

`[reverent]` In Psalm 130, the psalmist describes what it's like to wait on God:

*I wait for the Lord. My soul waits. I hope in his word.*

`[pause 8s]`

`[warm, reflective]` Waiting is woven all through Scripture. Sarah, Hannah, Elizabeth, Mary. Each one waited, in her own way, for a child. Waiting is not empty time. It's time held in God's hands.

`[pause 6s]`

`[gentle wonder]` Some people find these last days bring a surprising burst of energy. Others feel slow and heavy. Both are simply your body, doing its work in its own way. Listen to what it asks for.

`[pause 6s]`

`[calm, soothing]` Let your forehead smooth. Your jaw soften. Your shoulders drop. Your hands open.

`[pause 8s]`

`[gentle wonder]` Waiting can feel long, but it's also full of quiet work. Your body is continuing its remarkable preparation, and your baby is continuing to grow. So much is happening, even in the stillness.

`[pause 6s]`

`[warm]` What would make these waiting days a little sweeter? A walk in fresh air. A favorite meal. An early night. Time with someone you love. A good book. Let one or two ideas come to mind.

`[pause 9s]`

`[tender]` If you'd like, rest a hand on your belly. These are some of the last days your baby will be this close to you, held entirely within. There's something precious in that.

`[pause 9s]`

`[warm]` Whatever the coming days hold, you can meet each one as it comes, with patience and a little kindness for yourself.

`[pause 6s]`

`[gentle]` Now bring your waiting to God. Your hopes, your impatience, your excitement. Tell him all of it, and let him hold it with you.

`[pause 10s]`

`[prayerful, sincere]` Lord, I wait with you. Thank you for the little life I carry and for the remarkable journey of this pregnancy. Give me patience, wisdom for the days ahead, and peace in your presence today. Amen.

`[pause 7s]`

`[warm]` When you're ready, let your eyes open slowly.

`[pause 4s]`

One day at a time. Waiting with hope, and not alone.

`[music 6s]`

## Week 41 · Rest, and wait.

*About 4:36 · 16 paragraphs (10 identical to Grounded) · 2,015 characters*

`[music 6s]`

`[warm, unhurried]` Hello. Today is a day for slowing down, and savoring.

Find a comfortable position, wherever your body feels most at ease. Let yourself be supported.

`[pause 6s]`

`[calm]` Let your breath slow down by itself. Let your face soften.

`[pause 6s]`

`[warm]` These days may feel long, and your body may be asking for more comfort and rest. Wherever you find yourself today, let's take a few minutes to appreciate this moment of pregnancy, without asking it to feel any particular way.

`[pause 6s]`

`[gentle wonder]` Think back over this journey with God. The first moment you knew. The first flutter you felt. The prayers you've prayed. The ways your body has grown and carried your baby, week after week. All of it, held by him.

`[pause 9s]`

Thank him for anything that comes to mind.

`[pause 9s]`

`[warm]` Maybe you'd like to remember these days. A photo of your belly. A note to your baby. A few words in a journal about how it feels right now. Small keepsakes from a once-in-a-lifetime season.

`[pause 7s]`

`[tender]` Now notice your baby, here with you. The roundness of your belly. The closeness. A whole person, so near, and almost ready to meet you.

`[pause 8s]`

`[warm]` Is there something small you'd like to savor today? A warm bath. A slow cup of tea. Sunlight through a window. A nap in the afternoon. Let one simple pleasure come to mind.

`[pause 8s]`

Imagine enjoying it fully. No rushing. Nowhere else to be.

`[pause 7s]`

`[gentle wonder]` Notice the warmth of your hands. The rise and fall of your breath. The quiet company of your baby. Simple things, and so precious.

`[pause 7s]`

`[calm, soothing]` Let your shoulders sink. Let your hands rest open. Rest in the Lord.

`[pause 8s]`

`[tender]` If you'd like, rest a hand on your belly, and pray a blessing over your baby, in your own words.

`[pause 10s]`

`[prayerful, sincere]` Lord, I rest in you, and I wait for you. Thank you for being with me in these final days, and for the little one now so near. Bless my baby, and be with us as we prepare to meet. Amen.

`[pause 7s]`

`[warm]` When you're ready, let your eyes open slowly.

`[pause 4s]`

Be gentle with yourself in these days. You are held in his care.

`[music 6s]`

## Week 42 · This is the day.

*About 4:43 · 16 paragraphs (8 identical to Grounded) · 2,298 characters*

`[music 6s]`

`[warm, tender]` Hello. Wherever you are in these final days, you've come such a long way. Let's take a few minutes to honor that, and to welcome your baby.

`[pause 5s]`

`[calm]` Find your most comfortable position, and let yourself be fully supported. Let your breath slow down.

`[pause 6s]`

`[reverent, joyful]` Psalm 118 is a song of thanksgiving, full of joy. In the middle of it, the psalmist says:

*This is the day that the Lord has made. We will rejoice and be glad in it!*

`[pause 8s]`

`[warm, reflective]` This is the day. Not only the day your baby arrives, but today. This ordinary, waiting, precious day, made by God, and full of his goodness.

`[pause 6s]`

`[gentle wonder]` Think of everything your body has done. From those very first weeks, when so much was happening out of sight, to now. Growing, adapting, sheltering, carrying. A truly extraordinary journey.

`[pause 7s]`

`[warm]` And think of everything you've done. The rest you've taken. The questions you've asked. The love you've already given to someone you haven't yet held.

`[pause 7s]`

`[tender]` And think of your baby's journey too. From the tiniest beginning to a whole little person, getting ready for the world. What a story you share.

`[pause 7s]`

Every day of this pregnancy was a day the Lord made. The tired days and the joyful ones. The quiet ones and the busy ones. He was present in every one.

`[pause 6s]`

`[gentle]` Take a moment to give thanks. For your body. For your baby. For the people who've walked with you.

`[pause 10s]`

`[warm, reassuring]` You've practiced so many gentle things along the way. Slowing down. Breathing out. Softening. Finding your calm place. Resting between efforts. They're all with you, ready whenever you need them.

`[pause 7s]`

There may be plans and decisions surrounding your baby's arrival, and each birth experience is different. For these few moments, simply make room for the love and tenderness you hope to share with your little one.

`[pause 6s]`

`[tender]` If you'd like, rest a hand on your belly, and offer your baby a welcome. Something like: Whenever you arrive, you are so welcome here.

`[pause 10s]`

`[prayerful, sincere]` Lord, this is the day you have made. Thank you for every day of this journey, and for the gift of this child. I trust you with the day we meet. Let us rejoice together in your goodness. Amen.

`[pause 7s]`

`[warm]` When you're ready, let your eyes open slowly.

`[pause 4s]`

Your little one is already so loved.

`[music 6s]`

