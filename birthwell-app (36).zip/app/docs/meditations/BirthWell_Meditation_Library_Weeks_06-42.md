# BirthWell Meditation Library · Weeks 6–42

**Editorially approved by Leah** · narrated by Maren · no audio recorded yet; recordings are approved separately

## At a glance

- **74 meditations:** weeks 6–42, each in a Grounded and a Faith-centered version.
- **Length:** 4:50–5:30 each, about 6.5 hours of finished audio in total. This assumes a slow, natural pace of about 120 spoken words a minute, plus every pause and music-only section.
- **Spoken characters:** about 133,563, averaging 1,804 per meditation. With tone tags and a 20% allowance for re-recording, that's about 175,000 ElevenLabs credits.
- **Narrator:** Maren, for every meditation. The scripts don't depend on a particular voice, so other narrators can be added later.
- **Scripture:** 48 quoted passages across the 37 Faith-centered meditations, each checked word for word against the World English Bible, with God's name shown as "the Lord".
- **Checked across the whole library:** no repeated titles, openings or endings; no references to pregnancy loss; and no religious language in the Grounded versions.
- **Care team:** these meditations complement, never replace, the individual guidance of each mother's care team.

## How to read the scripts

- `[music 8s]` is music only: the soundscape plays before Maren starts or after she finishes.
- `[pause 5s]` is a silence between thoughts, with the soundscape underneath.
- A blank line between paragraphs is a short natural breath (about 1 second).
- **Tone tags** such as `[warm, unhurried]` or `[prayerful, sincere]` direct Maren's delivery in ElevenLabs v4. They aren't spoken. A tag carries on until the next one.
- *Italic lines* in the Faith-centered scripts are Scripture, word for word. Each **Scripture** line says whether it's verbatim, a verbatim excerpt, or a story retold in Maren's own words.
- The title has three parts. The middle part shows in italic clay in the app.

## Editorial history

- **Weeks 6–20:** approved after four rounds of Leah's revisions. See change-log-weeks-06-20.md.
- **Weeks 21–30:** approved with Leah's edits. See change-log-weeks-21-30.md.
- **Weeks 31–36:** approved with Leah's refinements. See change-log-weeks-31-36.md.
- **Weeks 37–42:** approved with Leah's edits. See change-log-weeks-37-42.md.
- Each of Leah's own revisions is kept word for word in `archive/`.

## Overview

| Week | Stage | Grounded | Length | Faith-centered | Scripture | Length |
|---|---|---|---|---|---|---|
| 6 | Early pregnancy and connection | Simply to arrive. | 5:29 | Known before the beginning. | Isaiah 43:1 | 5:29 |
| 7 | Early pregnancy and connection | Rest is enough. | 5:30 | Come and rest. | Matthew 11:28–29 | 5:29 |
| 8 | Early pregnancy and connection | Room for every feeling. | 5:27 | Peace that guards. | Philippians 4:6–7 | 5:28 |
| 9 | Early pregnancy and connection | Kind to your body. | 5:19 | Fearfully, wonderfully made. | Isaiah 40:11 | 5:28 |
| 10 | Early pregnancy and connection | One day at a time. | 5:30 | Bread for today. | Matthew 6:34 | 5:29 |
| 11 | Early pregnancy and connection | Small and steady. | 5:29 | Be still and know. | Psalm 46:10 | 5:22 |
| 12 | Early pregnancy and connection | Letting it go. | 5:29 | Pour out your heart. | Psalm 62:8 | 5:26 |
| 13 | Early pregnancy and connection | Small good things. | 5:15 | Every good gift. | James 1:17 | 5:26 |
| 14 | Early pregnancy and connection | A few words for you. | 5:26 | A blessing for the little one. | Numbers 6:24–26 | 5:30 |
| 15 | Early pregnancy and connection | Still you and growing. | 5:14 | New every morning. | Lamentations 3:22–23 | 5:29 |
| 16 | Early pregnancy and connection | Into a softer evening. | 5:30 | Sleep for the beloved. | Psalm 127:2 | 5:30 |
| 17 | Early pregnancy and connection | Held by many hands. | 5:21 | Never left alone. | Hebrews 13:5 | 5:25 |
| 18 | Early pregnancy and connection | Listening for you. | 5:03 | A greeting of joy. | Luke 1:39–45 | 5:29 |
| 19 | Early pregnancy and connection | The pause between things. | 5:10 | The one thing. | Luke 10:38–42 | 5:30 |
| 20 | Early pregnancy and connection | Halfway, and here. | 5:25 | Helped until now. | 1 Samuel 7:12 | 5:27 |
| 21 | Growing connection and preparation | Sinking into softness. | 5:23 | Quietness and confidence. | Isaiah 30:15 | 5:07 |
| 22 | Growing connection and preparation | The world within you. | 4:52 | Life and loving kindness. | Job 10:11–12 | 4:54 |
| 23 | Growing connection and preparation | Strong and soft. | 5:10 | Strength that renews. | Isaiah 40:29 | 5:03 |
| 24 | Growing connection and preparation | The long, slow exhale. | 5:12 | The breath of life. | Job 33:4 | 4:54 |
| 25 | Growing connection and preparation | Hello in there. | 5:14 | A gift from the Lord. | Psalm 127:3 | 5:03 |
| 26 | Growing connection and preparation | Steady as a stone. | 4:50 | My peace I give you. | John 14:27 | 5:04 |
| 27 | Growing connection and preparation | Thank you, body, for this. | 5:17 | In wisdom you made them. | Psalm 104:24 | 5:04 |
| 28 | Growing connection and preparation | A nest of your own. | 5:02 | A place prepared with love. | John 14:2 | 4:51 |
| 29 | Growing connection and preparation | Room to breathe. | 5:05 | In the shadow of your wings. | Psalm 63:7 | 4:54 |
| 30 | Growing connection and preparation | The first hello. | 4:53 | As a mother comforts. | Isaiah 66:13 | 4:58 |
| 31 | Preparing for labor | Like a wave. | 5:25 | Through the waters. | Isaiah 43:2 | 5:07 |
| 32 | Preparing for labor | Soft and open. | 5:28 | A quiet soul. | Psalm 131:2 | 5:20 |
| 33 | Preparing for labor | Your calm place. | 5:14 | Fullness of joy. | Psalm 16:11 | 5:09 |
| 34 | Preparing for labor | Surrounded by care. | 5:11 | Held up by love. | Exodus 17:12 | 5:10 |
| 35 | Preparing for labor | Growing ready. | 5:23 | Grace that is enough. | 2 Corinthians 12:9 | 5:14 |
| 36 | Preparing for labor | Rest between the waves. | 5:12 | My help comes from the Lord. | Psalm 121:1–2 | 5:17 |
| 37 | Approaching birth | Open hands. | 5:29 | A time for everything. | Ecclesiastes 3:1 | 5:10 |
| 38 | Approaching birth | Just this moment. | 5:21 | My times are in your hand. | Psalm 31:14–15 | 5:30 |
| 39 | Approaching birth | Many kinds of comfort. | 5:22 | God of all comfort. | 2 Corinthians 1:3 | 5:06 |
| 40 | Approaching birth | The waiting days. | 5:14 | I wait for the Lord. | Psalm 130:5 | 5:18 |
| 41 | Approaching birth | Slow and sweet. | 5:14 | Rest, and wait. | Psalm 37:7 | 5:26 |
| 42 | Approaching birth | Whenever you arrive. | 5:13 | This is the day. | Psalm 118:24 | 5:23 |

---

## Week 6 · Grounded

**Title:** Simply / *to* / arrive.
**Description:** Five quiet minutes to land in your body, just as it is today, with nothing to figure out.
**Approach:** arriving through the senses, an optional hand on the belly, and stillness.

[music 8s]

[warm, unhurried] Hello. Before anything else, just notice that you've stopped. Whatever came before this moment, and whatever comes after, can wait a few minutes.

Settle into a position that feels easy. Sitting, lying down, leaning back against something soft. There's nothing to get right here.

[pause 4s]

[calm] You might let your eyes close, or let your gaze rest somewhere gentle.

[pause 4s]

There's no need to change anything about your breathing. Just notice your next breath as it comes… and as it goes.

[pause 6s]

Now let's arrive, one sense at a time.

Notice the sounds around you. Some near, some farther away. You don't need to name them. Just let them be part of the room.

[pause 7s]

Notice where your body is being held. The weight of your legs. Your back. Your head. Let whatever is beneath you take a little more of you.

[pause 7s]

Notice the air on your skin. Warm or cool. Still, or gently moving.

[pause 4s]

You're here.

[pause 4s]

[gentle wonder] There's something extraordinary about these earliest weeks. Cells are multiplying and beginning to take on different roles, while your body adapts in ways you may not even notice. You don't need to direct any of that work. You may be astonished by it, or still be taking in the news. Either response belongs here.

[pause 6s]

[warm, gentle wonder] Every pregnancy begins with its own mix of feelings. Whatever yours may be today, give yourself permission to simply be present. Take a moment to appreciate the remarkable changes taking place within you, and the little life at the heart of it all.

[pause 6s]

[warm] If it feels right, rest one hand low on your belly, and the other over your heart.

[pause 5s]

You don't have to feel anything in particular. Just notice the warmth of your own hands, and the small movement beneath them as you breathe.

[pause 5s]

You don't need to have this figured out. Not the plans, not the feelings, not the months ahead. Right now there is only this breath, and the one after it.

[pause 7s]

[calm] Let your shoulders soften as you breathe out. Let your jaw loosen.

[pause 5s]

Let your hands simply rest. For these last moments, there's nothing to do at all. Just be here, as you are.

[pause 12s]

[warm] When you're ready, let a little movement come back. Your fingers. Your toes. Notice the light around you.

[pause 4s]

You arrived, and that was enough. You can return to this quiet whenever you need it.

[music 8s]

---

## Week 6 · Faith-centered

**Title:** Known / *before* / the beginning.
**Description:** Five quiet minutes to rest in being known and loved by God, right where you are.
**Approach:** God's call by name, the hidden work he sees, and a moment of personal prayer in the middle.
**Scripture:** Isaiah 43:1 (verbatim excerpt: the words God speaks to Israel, from the second half of the verse); Psalm 139:13 (verbatim).

[music 8s]

[warm, unhurried] Welcome. Let these few minutes be set apart, for you and for God.

Find a position that feels restful. There's nothing you need to prepare, and nothing you need to say yet.

[pause 4s]

[calm] Let your breath find a comfortable rhythm. Notice it moving in… and out… without changing a thing.

[pause 5s]

[reverent] Through the prophet Isaiah, God spoke these words to his people Israel, reminding them that they belonged to him:

*Don't be afraid, for I have redeemed you. I have called you by your name. You are mine.*

[pause 8s]

[warm, reflective] Those words were first spoken to a whole people, long ago. But they show us the heart of a God who knows his own by name. Not by their to-do lists, or by how well they're coping. By name.

[pause 6s]

Let your own name settle quietly in your mind. Whatever today holds, you are not a stranger to God.

[pause 7s]

[tender] Something new has begun in you. Whatever you're feeling about it today, you are already known by God, and you are loved.

[pause 5s]

[gentle wonder] Even at this early beginning, pregnancy is full of intricate, unseen changes. Your body is participating in the work of carrying a new life, and you can bring your awe at that mystery to God. You need not feel strong or certain to give thanks for this moment.

[pause 6s]

[prayerful, grateful] Lord, thank you for the wonder of this new beginning. For the intricate ways you've designed the human body, and for the precious life I carry today. Help me slow down, recognize your goodness, and receive this moment with gratitude and peace.

[pause 5s]

[reverent] If it feels right, rest one hand low on your belly as you listen. The psalmist prayed:

*For you formed my inmost being. You knit me together in my mother's womb.*

[pause 8s]

[warm, reassuring] The God who saw you before anyone else did sees this little one now. You don't have to understand what's ahead. You don't have to hold all of it by yourself.

[pause 6s]

[gentle] Take a quiet moment to talk with God about this new beginning, in words or simply in stillness. He already knows what you're feeling.

[pause 12s]

[prayerful, sincere] Lord, thank you that you know me by name. Thank you for seeing this little life, hidden from everyone but you. I don't know everything that's ahead, but I know I'm not alone in it. Help me rest in your love today. Amen.

[pause 8s]

[warm] When you're ready, gently open your eyes.

[pause 3s]

Go into your day knowing you are known, and you are loved.

[music 8s]

---

## Week 7 · Grounded

**Title:** Rest / *is* / enough.
**Description:** Five minutes of permission to slow down, because growing a new life is real work.
**Approach:** permission to rest, progressive heaviness, and a peaceful resting place.

[music 8s]

[warm, unhurried] Hi. If you can, let yourself lie down for this one. On your side is lovely, with a pillow wherever you need it. If lying down isn't possible right now, simply lean back and let something hold you.

[pause 5s]

[gentle, understanding] You may be more tired than usual right now. The kind of tired that a good night's sleep doesn't quite reach. Pregnancy can ask so much of you, in body and in heart, even on days when it seems like nothing is happening.

[pause 5s]

That tiredness isn't laziness, and it isn't weakness. Your body is adapting to pregnancy in countless quiet ways, and it asks for energy and rest, sometimes more than you expected. There is something remarkable in that work, even if all you notice today is how tired you feel.

[pause 6s]

[tender] You can appreciate the life you're carrying and still wish this part felt easier. Pregnancy asks a great deal of your body, and rest is one way to care for yourself through it. Take a moment to acknowledge how much your body is doing, even when you're doing nothing at all.

[pause 6s]

[warm, reassuring] So here's your permission. For the next few minutes, you don't need to be useful. You don't need to catch up. Rest doesn't need to be earned.

[pause 5s]

[calm, soothing] Let's let the heaviness come.

Start with your feet. Imagine them growing warm and heavy, sinking a little into whatever is beneath them.

[pause 6s]

That warmth moves into your calves… your knees… your thighs… your hips and lower back. Heavy. Easy. Held.

[pause 6s]

Your belly, soft, with nothing to hold in. Your arms, heavy all the way down to your fingertips.

[pause 6s]

And your face. The space between your eyebrows. Your jaw. The soft skin around your eyes.

[pause 6s]

[calm, peaceful] Now picture a place where you could rest completely. Maybe a sunlit room on a slow afternoon, with nowhere to be. A hammock in the shade. Or somewhere only you know.

[pause 7s]

Let yourself be there. Notice the light. The quiet. How nobody needs anything from you.

[pause 8s]

[gentle] If your mind wanders to the dishes, the emails, the list, that's all right. Notice it, and let your next breath out carry you back to your resting place.

[pause 7s]

You're allowed to stay a little longer.

[pause 10s]

[warm] When you're ready, let your body begin to wake. Gently. There's no rush.

[pause 4s]

Be gentle with yourself today, and rest whenever you can. It counts.

[music 8s]

---

## Week 7 · Faith-centered

**Title:** Come / *and* / rest.
**Description:** Five minutes to lay down what feels heavy and receive the rest Jesus offers.
**Approach:** coming to Jesus as you are, setting burdens down in prayer, then resting in his care.
**Scripture:** Matthew 11:28–29 (verbatim); Psalm 23:2 (verbatim).

[music 8s]

[warm, unhurried] Welcome. Let yourself get comfortable. Lie down if you can, perhaps on your side with a pillow. Or simply lean back and let yourself be supported.

[pause 5s]

[gentle, understanding] You may be more tired than usual right now. Pregnancy can ask so much of you, in body and in heart. And it can be hard to slow down when there's so much to carry.

[pause 4s]

[reverent] Listen to the words of Jesus:

*Come to me, all you who labor and are heavily burdened, and I will give you rest. Take my yoke upon you, and learn from me, for I am gentle and humble in heart; and you will find rest for your souls.*

[pause 10s]

[warm, reassuring] He doesn't say, come once you've finished everything. He doesn't say, come once you've earned it. He simply says, come.

[pause 5s]

[calm] Picture yourself coming to him now, just as you are. Tired, perhaps. Unfinished. A little worn. And imagine him making room for you. Gentle. Unhurried. Glad you came.

[pause 9s]

[tender] Your body is doing quiet, demanding work as this pregnancy continues. The little life within you is precious, and so are you, the mother carrying it. You don't have to turn your exhaustion into a lesson or hide it from Jesus.

[pause 6s]

[warm, reassuring] Whatever this season feels like for you, Jesus invites you to come as you are. You can bring him your gratitude, your exhaustion, and everything else on your heart. Let these few minutes be an opportunity to rest in his love while your body continues the remarkable work of carrying new life.

[pause 5s]

[gentle] What are you carrying today? Tell him quietly. The tiredness. The worries. The things you haven't gotten to. You can set each one down in front of him.

[pause 12s]

[prayerful, sincere] Jesus, I'm tired, and you already know it. Thank you that I don't have to earn your rest, or prove that I deserve it. I'm setting these things down with you. Teach me to rest in you. Amen.

[pause 8s]

[calm, soothing] Now let your body follow your heart. Let your shoulders sink, and your hands open.

[pause 6s]

[reverent] In Psalm 23, David says of the Lord, his shepherd:

*He makes me lie down in green pastures. He leads me beside still waters.*

[pause 8s]

[calm, soothing] Rest here a while, beside still waters, in his care.

[pause 11s]

[warm] When you're ready, let some movement return, slowly.

[pause 3s]

May you find his rest in the ordinary moments of today.

[music 8s]

---

## Week 8 · Grounded

**Title:** Room for / *every* / feeling.
**Description:** Five minutes to let joy, worry, and everything in between sit side by side.
**Approach:** an honest check-in, making room in the chest, and welcoming mixed feelings.

[music 8s]

[warm, unhurried] Hi. Before we begin, take a moment to check in with yourself. Not how you think you should be feeling. How you actually are.

[pause 6s]

[calm] Find a comfortable position, and let your breath settle into whatever rhythm feels natural.

[pause 6s]

[warm, lightly smiling] Pregnancy can bring so many feelings, sometimes all at once. Excitement. Worry. Tenderness. Doubt. Moments of wonder, and moments of "what have I gotten myself into?" And some days, not much feeling at all.

[pause 6s]

[reassuring] There's no right way to feel right now. Whatever you're feeling is welcome here.

[pause 6s]

[calm] Rest a hand over the center of your chest, if you'd like. Feel the warmth there. As you breathe out, imagine the space beneath your hand growing a little wider. A little more room.

[pause 8s]

[gentle] Now gently ask yourself: *What's here today?*

You don't need words. Just notice. Is there lightness? Heaviness? A flutter? A knot?

[pause 10s]

[reassuring] Whatever you find, you don't need to fix it or explain it. You can simply say to it: *There's room for this feeling, too.*

[pause 6s]

[calm] If worry is here, let it sit beside you, like someone on a park bench. It doesn't have to leave for you to feel some peace. You can keep breathing with it there.

[pause 8s]

[warm, hopeful] And if there's joy, even a small spark of it, let yourself feel that too. Joy doesn't need to wait until everything is certain. It's allowed to be here now.

[pause 8s]

[gentle] Notice how both can be true at once. The hope and the worry. The wonder and the tiredness. You're holding all of it, right now, and you're still here, still breathing.

[pause 8s]

[gentle wonder] Within you, a new life is developing as your body makes room for the work of pregnancy. That may stir wonder, affection, anxiety, or a mixture that changes by the hour. You can recognize how extraordinary it is without feeling cheerful about every moment.

[pause 6s]

[tender] Even an ordinary appointment or a quiet day can stir up feelings that are hard to explain. You don't need to resolve them here. Rest a hand on your belly if you'd like, and allow one small moment of connection without asking it to predict tomorrow.

[pause 10s]

[warm] When you're ready, let your hands rest, and let your eyes slowly open.

[pause 3s]

However today feels, you're not doing it wrong. There's room for all of you.

[music 10s]

---

## Week 8 · Faith-centered

**Title:** Peace / *that* / guards.
**Description:** Five minutes to bring your real worries and hopes to God, and rest in his care.
**Approach:** guided personal prayer, with silence to bring a worry, a hope, and a thanks to God in your own words.
**Scripture:** Philippians 4:6–7 (verbatim); 1 Peter 5:7 (verbatim).

[music 8s]

[warm, unhurried] Welcome. Let this be a quiet place to be honest with God.

Settle in, and let your breath find its own comfortable pace.

[pause 6s]

[gentle] Pregnancy can stir up so many feelings. Hope and fear. Gratitude and questions.

[pause 5s]

[reassuring] God isn't asking you to sort them out first. He invites you to bring them to him, just as they are.

[pause 5s]

[reverent] Listen to these words from Philippians:

*In nothing be anxious, but in everything, by prayer and petition with thanksgiving, let your requests be made known to God. And the peace of God, which surpasses all understanding, will guard your hearts and your thoughts in Christ Jesus.*

[pause 8s]

[warm, reflective] In everything. Not only the tidy things. Not only the brave ones.

[pause 5s]

[tender] There is an extraordinary tenderness in carrying a baby while carrying questions too. Your body is engaged in the work of pregnancy, and your heart may be doing its own difficult work of hoping. God welcomes the whole of you, not only the thankful or peaceful parts.

[pause 6s]

If relaxing feels difficult today, you can tell God that plainly. You are allowed to marvel at this life and ask for courage at the same time. Neither feeling cancels the other.

[pause 6s]

[gentle] Let's bring it all to him now, slowly.

Is there a worry you've been carrying? Something you keep turning over? Tell God about it, in your own words. Be as honest as you like.

[pause 13s]

[hopeful] Now, is there a hope in your heart? Something you long for, for yourself, or for your baby? Tell him that too.

[pause 10s]

[warm] And is there anything, even something small, you're thankful for today? Offer him that as well.

[pause 8s]

[reverent] Peter wrote that we can come to God:

*casting all your worries on him, because he cares for you.*

[pause 8s]

[gentle, reassuring] Peace doesn't always arrive all at once. Sometimes it comes quietly, like someone sitting down beside you. Whatever you still feel, you're not carrying it alone.

[pause 6s]

[prayerful, sincere] Father, thank you for listening. You know every hope and every fear I've named, and the ones I couldn't put into words. I'm leaving them with you. Guard my heart and my thoughts today, and keep me close to you. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open gently.

[pause 3s]

Take this peace with you into the rest of your day.

[music 8s]

---

## Week 9 · Grounded

**Title:** Kind / *to your* / body.
**Description:** Five minutes of gentle attention for a body that's changing every day.
**Approach:** gentle movement first, then a kind body scan with no pressure to feel grateful.

[music 8s]

[warm, unhurried] Hello. Let's start by letting your body move a little, before we settle.

If it feels good, roll your shoulders slowly, up, back, and down. Once or twice.

[pause 6s]

[calm] Let your head tip gently toward one shoulder… and then the other.

[pause 6s]

Now find a comfortable position and let yourself be still. If you're feeling queasy or unsettled today, sitting a little upright, with something behind your back, might feel better.

[pause 6s]

There's no need to change your breathing. Just notice it, quietly doing its work.

[pause 6s]

[gentle wonder] This body of yours is responding to pregnancy through changes you can see and changes that remain hidden. Even without your direction, it adjusts and makes space for an extraordinary process. Appreciation doesn't have to mean loving every symptom, every ache, or every new shape.

[pause 6s]

[tender] Perhaps today gratitude is simply noticing that your body deserves care. Perhaps it's feeling a quiet connection to the baby you're carrying. And perhaps today all you can manage is rest. Each of those can be enough.

[pause 6s]

[warm] Today, let's simply be kind to your body, wherever it is.

[pause 4s]

[calm] Bring your attention to your feet, and whatever is beneath them. They've carried you a long way.

[pause 7s]

Your legs. Notice if they feel heavy or tired, and let them rest.

[pause 7s]

[tender] Your belly, where a new life is growing. Rest your hand here, if you'd like.

[pause 10s]

[calm] Your chest, rising and falling. Your heart, keeping its steady rhythm.

[pause 7s]

Your shoulders, your arms, your hands. Let them grow heavy.

[pause 7s]

Your face. Let the small muscles around your eyes and mouth soften.

[pause 8s]

[gentle, reassuring] If there's a place that feels sore, heavy, or uneasy, you don't need to fix it, or feel grateful for it. Just notice it with kindness, the way you might rest a warm hand on someone you love.

[pause 12s]

[warm] Whatever your body is asking for today, whether that's rest, water, a little food, or some fresh air, you're allowed to give it.

[pause 6s]

When you're ready, let your eyes open, and come back slowly.

[pause 3s]

Carry a little of this kindness with you today.

[music 10s]

---

## Week 9 · Faith-centered

**Title:** Fearfully, / *wonderfully* / made.
**Description:** Five minutes to bring your changing body to God, with honesty and gratitude.
**Approach:** opens with prayer, God as the gentle shepherd, an honest body prayer, and gratitude offered freely.
**Scripture:** Isaiah 40:11 (verbatim excerpt: the second and third sentences); Psalm 139:14 (verbatim).

[music 8s]

[warm, unhurried] Welcome. Let's begin this time with a short prayer.

[prayerful, sincere] Lord, thank you for this moment to slow down. Be near to me as I rest. Amen.

[pause 5s]

[calm] Find a comfortable position. If you're feeling unsettled or queasy today, sitting a little upright, with support behind your back, may help. Let your breath be easy. There's nothing you need to change.

[pause 6s]

[reverent] The prophet Isaiah describes God as a shepherd caring for his flock:

*He will gather the lambs in his arm, and carry them in his bosom. He will gently lead those who have their young.*

[pause 8s]

[tender] Gently leading those who have their young. Held. Led gently. Not hurried.

[pause 6s]

[gentle wonder] Your body's changes may leave you amazed one day and uncomfortable the next. Pregnancy asks a great deal of you, and God's care does not depend on how gracefully you bear it. You can thank him for the wonder of this growing life while still asking for relief and strength.

[pause 6s]

[prayerful, sincere] Lord, teach me to treat this body with tenderness. When trust feels difficult, help me bring my questions to you without shame. Let gratitude be an invitation, never a demand.

[pause 6s]

[calm] Let's bring your body before God, one part at a time.

Your feet and legs, carrying you through each day.

[pause 6s]

[tender] Your belly, where a new life is growing. Rest your hand here, if you'd like.

[pause 8s]

[calm] Your heart, beating steadily. Your breath, coming and going. Your shoulders, your hands, your face. Let them soften.

[pause 8s]

[gentle] If there's a place that aches or feels uneasy, you can simply bring it to him, and let it be held. Tell him what's hard.

[pause 10s]

[reverent] The psalmist prayed:

*I will give thanks to you, for I am fearfully and wonderfully made. Your works are wonderful. My soul knows that very well.*

[pause 8s]

[gentle] If thankfulness feels true today, offer it to him, in your own words. If it doesn't, simply rest in his care.

[pause 10s]

[prayerful, sincere] Creator God, you made me with care, and you're near to me in every change. Thank you for this little one. On the hard days, be my comfort. Lead me gently, the way you lead those with young. Amen.

[pause 8s]

[warm] When you're ready, open your eyes and come back slowly.

[pause 3s]

Go gently, knowing you are held.

[music 8s]

---

## Week 10 · Grounded

**Title:** One / *day* / at a time.
**Description:** Five minutes to set down tomorrow's questions and come back to today.
**Approach:** noticing how far ahead the mind runs, gently returning to today, and finding three things that are steady right now.

[music 8s]

[warm, unhurried] Hi. Let's take this one day, and this one moment, at a time.

Get comfortable in whatever way your body likes today. Let your hands rest wherever they land.

[pause 5s]

[calm] Your breath can do whatever it wants. You're just here to keep it company.

[pause 6s]

[gentle, understanding] It's natural, in pregnancy, for the mind to race ahead. To the next appointment. The next test result. How you'll manage work, or sleep, or money, or everything else. Months of questions can fit into a single minute of worrying.

[pause 6s]

[calm] For now, let's notice where your mind has been travelling. You don't need to follow it. Just notice the direction.

[pause 10s]

[warm] Now imagine gently calling it home, the way you might call to someone who's wandered a little too far down the beach. No scolding. Just: *come back.*

[pause 8s]

Here is today. Only today.

[pause 5s]

[gentle wonder] Today, your body is occupied with the remarkable, largely unseen work of pregnancy. You don't need to map every step of it to appreciate what's happening now. You can be curious about your baby and still feel unsettled by questions that haven't been answered.

[pause 6s]

[warm, tender] There's something lovely about returning to the present. This breath. The warmth of your hands. The quiet awareness of the little life you're carrying. You don't need to have every detail of the coming months figured out to appreciate what is happening within you today.

[pause 6s]

[calm] Let's find three things that are steady, right now.

First, something supporting you. The chair, the bed, the floor. Notice it holding you without being asked.

[pause 8s]

Second, something you can hear. Maybe the music. Maybe a sound in the room, or outside.

[pause 8s]

Third, something about your own body that feels okay, even a little. Warm hands. Soft shoulders. A comfortable spot.

[pause 10s]

[warm] Three steady things. They were here all along, while your mind was busy elsewhere.

[pause 6s]

[tender] If you'd like, rest a hand on your belly. Today, you're both simply here.

[pause 10s]

Let yourself stay with today a little longer.

[pause 10s]

[warm] When you're ready, open your eyes, and notice one more steady thing around you.

[pause 4s]

Tomorrow can wait. For now, this day is enough.

[music 10s]

---

## Week 10 · Faith-centered

**Title:** Bread / *for* / today.
**Description:** Five minutes to trust God with tomorrow, and ask him for what you need today.
**Approach:** Jesus' teaching on tomorrow, honest prayer for today's needs, and quiet trust.
**Scripture:** Matthew 6:34 (verbatim excerpt: the first sentence); Matthew 6:11 (verbatim).

[music 8s]

[warm, unhurried] Welcome. For the next few minutes, today is the only day you need to think about.

Settle in comfortably, and let your breath find its own easy pace.

[pause 6s]

[gentle, understanding] It's natural, in pregnancy, for the mind to race ahead. The next appointment. Results you're waiting for. How everything will work out. It can feel like trying to carry months of tomorrows all at once.

[pause 6s]

[reverent] Jesus knew how heavy that can be. In the Sermon on the Mount, he said:

*Therefore don't be anxious for tomorrow, for tomorrow will be anxious for itself.*

[pause 8s]

[warm, reassuring] He wasn't scolding anyone for worrying. He was inviting them to put tomorrow down, and let God hold it.

[pause 5s]

[reverent] In that same sermon, he taught his followers to pray, simply:

*Give us today our daily bread.*

[pause 8s]

[warm, reflective] Not bread for the whole year. Bread for today.

Long before, in the wilderness, God gave his people manna each morning. Just enough for each day. They couldn't store it up for the week ahead. They had to trust that tomorrow's would come with tomorrow.

[pause 7s]

[gentle wonder] So much of pregnancy unfolds beyond your conscious effort. Your body is adapting in countless intricate ways as a little life develops within you. What a remarkable part of God's creation. You can pause here, appreciate this quiet work, and thank him for the gift of carrying new life today.

[pause 6s]

[prayerful, sincere] Father, when unanswered questions make tomorrow seem heavy, give me the grace to live this one day. Help me cherish what is here without pretending I know what comes next.

[pause 6s]

[gentle] What do you need for today? Rest? Patience? Strength for a hard conversation? A little more comfort in your body? Tell God, in your own words. Nothing is too small.

[pause 13s]

[tender, reassuring] And if there's a tomorrow you've been carrying, an appointment, a decision, a fear, picture yourself placing it into his hands. It will still be there when its day comes. And so will he.

[pause 10s]

[prayerful, sincere] Lord, thank you that I don't have to hold every tomorrow today. Give me what I need for this day, and help me trust you with the rest. Amen.

[pause 7s]

[tender] If you'd like, rest a hand on your belly, and simply be here, with God, today.

[pause 10s]

[warm] When you're ready, let your eyes open slowly.

[pause 3s]

Go into today with what you need for today.

[music 8s]

---

## Week 11 · Grounded

**Title:** Small / *and* / steady.
**Description:** Five minutes to find calm in an ordinary moment, the kind that's always within reach.
**Approach:** mindful listening, then noticing one ordinary comfort in close detail, like a warm drink in your hands.

[music 8s]

[warm, unhurried] Let's begin with a few seconds of just listening.

[pause 6s]

[calm] Not trying to relax. Not trying to do anything. Just letting sounds arrive.

[pause 6s]

[warm] There's a kind of calm that doesn't need a quiet house, or a free afternoon, or everything going well. It's small, and it's steady, and it can be found inside an ordinary moment.

[pause 6s]

Let's find one.

[calm] If you have a warm drink nearby, you can hold it. If not, simply imagine one. A mug of tea, or warm milk, or anything that comforts you.

[pause 6s]

Feel the warmth spreading into your palms.

[pause 5s]

Notice the weight of the cup. The texture of it under your fingers.

[pause 6s]

If there's steam, imagine it rising slowly, and fading.

[pause 7s]

[warm] This is all it takes. One ordinary thing, noticed fully.

[pause 5s]

[calm] Notice the smell, if there is one. Notice the first small taste, if you take a sip. Let it be the only thing happening, just for a moment.

[pause 10s]

Now let your attention widen, just a little. To your hands. Your arms. Your shoulders, softening as you breathe out.

[pause 8s]

[tender] To your belly.

[pause 3s]

[gentle wonder] While you're noticing this ordinary comfort, remember that pregnancy is happening within the ordinary hours too. The body you're resting in is continually adjusting to carry this baby. Nothing dramatic needs to happen in this room for this moment to be meaningful.

[pause 6s]

[warm, gentle wonder] Perhaps you notice a little warmth in your hands, a softening in your shoulders, or simply the pleasure of being still. These ordinary moments are worth appreciating. And through them all, your body continues its extraordinary work, carrying a new life through even the simplest parts of your day.

[pause 6s]

[warm] Most days aren't made of big peaceful hours. They're made of minutes. Waiting for the kettle. Sitting in the car before you go inside. Lying down for the first moment at night.

[pause 6s]

Any one of those minutes can become a small, steady place, if you let yourself notice it.

[pause 7s]

[calm] Stay here with your ordinary moment a little longer.

[pause 9s]

[warm] When you're ready, set down your cup, real or imagined, and let your eyes open.

[pause 4s]

Small, steady moments like this are always within reach. You know where to find one now.

[music 8s]

---

## Week 11 · Faith-centered

**Title:** Be / *still* / and know.
**Description:** Five minutes of quiet with one short verse, letting it slowly settle into stillness.
**Approach:** a slow, contemplative reading where the verse grows shorter with each repeat, with silence between.
**Scripture:** Psalm 46:10 (verbatim excerpt: the first sentence). The shorter repeats that follow are adapted from it and are not shown in italics.

[music 8s]

[warm, unhurried] Welcome.

[pause 5s]

This meditation uses very few words, and a lot of quiet.

[calm] We'll stay with one short line from Psalm 46, and let it slowly settle, the way snow settles in a snow globe once you stop shaking it.

[pause 6s]

Find a comfortable way to sit or lie down. Let your hands rest open.

[pause 6s]

[reverent] Psalm 46 was written for God's people in a time of upheaval. Nations in uproar, the earth itself shaking. And in the middle of it all, God says:

*Be still, and know that I am God.*

[pause 10s]

[gentle wonder] As you settle into stillness, your body continues its remarkable work of carrying new life. You don't have to keep watch over every unseen change. Let the quiet remind you that this baby matters, and that you matter to God too.

[pause 6s]

[warm, reverent] There's no special feeling you need to achieve in these moments with God. You can simply rest in his presence, grateful for the beautiful complexity of the life he's created and the remarkable work taking place within your body. Let the words of the psalm gently draw your attention back to him.

[pause 6s]

[calm, reverent] Let's say it again, a little shorter each time, and rest in the silence between.

Be still, and know that I am God.

[pause 12s]

Be still, and know.

[pause 12s]

Be still.

[pause 14s]

Be.

[pause 20s]

[gentle] Stillness isn't the same as having no thoughts. It's more like resting. Letting God be God, while you simply stay near.

[pause 8s]

If your mind wanders, that's all right. Come back to whichever word feels like home.

[pause 14s]

[prayerful, sincere] Lord, in all the busyness and change of this season, thank you for being God, so I don't have to be. Let me be still with you. Amen.

[pause 10s]

[warm] When you're ready, let your eyes open gently.

[pause 3s]

Stay in that stillness as long as you'd like. It's yours to come back to.

[music 10s]

---

## Week 12 · Grounded

**Title:** Letting / *it* / go.
**Description:** Five minutes to release the tension your body has been quietly holding.
**Approach:** gentle, optional tense-and-release through the hands, shoulders, and face, then letting the mind loosen too.

[music 8s]

[warm, unhurried] Start by noticing your hands. Where are they resting? Are they open, or curled? Soft, or holding on?

[pause 6s]

[gentle] Many of us carry tension without realizing it. In our hands, our shoulders, our faces. Today, let's gently let some of it go.

Settle in comfortably first.

[pause 4s]

[calm] We'll start with your hands. If it feels good, make a soft fist. Not tight. Just enough to notice the effort.

[pause 4s]

And let it go. Let your fingers uncurl and fall open.

[pause 6s]

Notice the difference. The tingling, or the warmth, or the heaviness after letting go.

[pause 4s]

Now your shoulders. If it's comfortable, lift them gently toward your ears.

[pause 4s]

And let them drop.

[pause 6s]

Let them keep sinking, a little more with each breath out.

[pause 6s]

[gentle wonder] Your body has been adapting to a new life while you manage everything else that fills your days. Its work is remarkable; the tension you carry is understandable. Releasing your shoulders for a moment doesn't mean releasing your care for this baby.

[pause 6s]

[calm] Now your face. Scrunch it gently, if you like. Eyes, nose, mouth, all pulling toward the center.

[pause 3s]

And release. Let your forehead go smooth. Let your jaw hang loose.

[pause 7s]

[warm] Your body knows how to let go. It just sometimes needs reminding.

[pause 4s]

[calm, soothing] Let's go once through your whole body, without tensing this time. Just a soft wave of letting go, from the top of your head, down through your shoulders, your arms, your back, your legs, all the way to your feet.

[pause 7s]

[gentle] Now let your mind follow. Is there something you've been holding tightly, a worry, a plan, an expectation? You don't need to solve it. Just imagine your grip on it softening, the way your hands did.

[pause 7s]

[calm, tender] Notice what it feels like to offer your body a little gentleness. Your muscles can soften, your breathing can settle, and for these few minutes, you can simply rest. Your body is carrying out so many intricate processes without needing your conscious attention. You deserve this moment of ease.

[pause 5s]

[tender] If you'd like, rest your open hand on your belly. No effort. Just warmth. Stay soft. There's nothing you need to hold right now.

[pause 9s]

[warm] When you're ready, let some gentle movement come back, and slowly open your eyes.

[pause 4s]

Whatever you let go of, let it stay down for a while.

[music 8s]

---

## Week 12 · Faith-centered

**Title:** Pour out / *your* / heart.
**Description:** Five minutes to tell God what's heavy, and release your grip as you hand it to him.
**Approach:** honest prayer paired with gently letting go in the hands and shoulders.
**Scripture:** Psalm 62:8 (verbatim excerpt: the second and third sentences); Psalm 55:22 (verbatim excerpt: the first sentence).

[music 8s]

[warm, unhurried] What feels heavy today?

[pause 6s]

[gentle] You don't have to answer right away. Just let the question rest with you as you settle in. Find a comfortable position, and let your breath come and go in its own time.

[pause 6s]

[reverent] The psalms are full of honest prayers. People telling God exactly how they felt, the fears, the frustrations, the hopes. In Psalm 62, David writes:

*Pour out your heart before him. God is a refuge for us.*

[pause 8s]

[warm, reflective] Not "tidy up your heart first." Pour it out.

[pause 5s]

A refuge is a safe place to run to when things feel like too much. Not a place you have to be strong to enter. A place you go because you need it.

[pause 6s]

[calm] So let's do that. Notice your hands. If they're curled or tense, let them open slowly, palms up, as if you were holding something out to God.

[pause 6s]

[gentle wonder] As this little life develops, your body is doing work you cannot oversee, and your heart may wish it could oversee every part. God welcomes your wonder at creation, your gratitude for the little life you're carrying, and everything else resting on your heart today.

[pause 6s]

[warm, tender] You don't need to find perfect words for this moment with God. You can simply open your heart to him. Bring your gratitude for the little life you're carrying, your appreciation for the body he's given you, and anything else that rests on your heart today.

[pause 6s]

[gentle] Now tell him what's heavy. Whatever comes.

[pause 15s]

[calm] As you finish, let your shoulders drop. Let your jaw soften. Let your body follow your heart in letting go.

[pause 6s]

[reverent] Another psalm says:

*Cast your burden on the Lord and he will sustain you.*

[pause 8s]

[warm, reassuring] That doesn't mean every burden disappears. It means you don't carry it alone. He holds you up while you carry it.

[pause 6s]

[prayerful, sincere] Lord, thank you for listening to all of it, the big things and the small. I'm placing these in your hands. Hold me up today. Amen.

[pause 8s]

[tender] If you'd like, rest your open hand on your belly, and let your hands stay soft.

[pause 10s]

[warm] When you're ready, let your eyes open.

[pause 3s]

Walk a little lighter today, knowing he holds what you've given him.

[music 8s]

---

## Week 13 · Grounded

**Title:** Small / *good* / things.
**Description:** Five minutes to notice what's been quietly good, even on an ordinary or difficult day.
**Approach:** three small moments recalled in detail, then letting them warm the body, without any pressure to feel positive.

[music 8s]

[warm, unhurried] Think of one small thing from the last day or so that was good. It doesn't need to be big. A warm shower. A kind text. The first sip of something cold.

[pause 6s]

[calm] Hold that thought, and let yourself get comfortable.

[pause 6s]

[gentle, understanding] This meditation is about noticing good things. Not because everything is good. Some days in pregnancy are hard, and that's real. But even hard days can hold small moments worth noticing.

[pause 6s]

[warm] Let's go back to that first good thing. Picture it clearly. Where were you? What did it feel like? Let yourself enjoy it again, just for a moment.

[pause 10s]

Now let a second one come to mind. Maybe something someone said. Maybe something you saw. Light through a window. A song. A laugh.

[pause 10s]

And a third. Maybe something your body did well. A good night's sleep, a meal that sat right, a walk that felt easy.

[pause 10s]

[gentle wonder] One small good thing may simply be the thought that you're carrying a baby, even if that thought comes with complicated feelings. Your body is involved in an extraordinary process, and it's reasonable to feel both thankful for its work and tired of its demands.

[pause 6s]

[reassuring] You don't have to turn gratitude into another task. A moment of comfort is worth noticing simply because it feels good, right here and now.

[pause 6s]

If it's hard to find three today, that's all right. One is enough. Even making space for these few minutes is a small good thing.

[pause 8s]

[calm] Three small good things. Notice where you feel them in your body. Maybe a softening in your chest. A little warmth. Or maybe nothing much, and that's fine too.

[pause 10s]

[tender] If you'd like, rest a hand on your belly. Your baby is part of your days now, even the ordinary ones.

[pause 10s]

[warm] Small good things are easy to miss. They don't announce themselves. But they add up, quietly, the way the days of this pregnancy are adding up.

[pause 10s]

When you're ready, let your eyes open.

[pause 4s]

May you notice a few more small good things before the day is done.

[music 8s]

---

## Week 13 · Faith-centered

**Title:** Every / *good* / gift.
**Description:** Five minutes to recognize God's goodness in the small gifts of your days.
**Approach:** recalling small gifts one by one, thanking God for each, and making room for days when thankfulness is hard.
**Scripture:** James 1:17 (verbatim excerpt: the first part of the verse).

[music 8s]

[reverent] James, writing to the early church, said this:

*Every good gift and every perfect gift is from above, coming down from the Father of lights.*

[pause 8s]

[warm, unhurried] Let those words settle as you find a comfortable position.

[pause 6s]

Every good gift. Not only the big ones. The small, everyday ones too.

[pause 6s]

[gentle wonder] James calls God the Father of lights. The one who made the sun and the stars, and who still notices the smallest good thing in your day.

[pause 8s]

[warm] Let's look for some. Think back over the last day or so. What was one good thing, however small? A warm meal. A kind word. A quiet moment. Picture it clearly.

[pause 10s]

[prayerful] Now simply say, in your heart: Thank you.

[pause 8s]

[warm] Let a second gift come to mind. Maybe a person. Someone who helped, or listened, or made you laugh.

[pause 10s]

[prayerful] Thank you.

[pause 8s]

[warm] And a third. Perhaps something about this pregnancy. Or perhaps just that you're here, breathing, right now.

[pause 10s]

[prayerful] Thank you.

[pause 8s]

[gentle wonder] Among the gifts you may notice is the wonder of a body carrying new life. Even as you rest, so many intricate changes are taking place beyond your awareness. You can appreciate this remarkable work in your own way, without needing to feel any particular emotion.

[pause 6s]

[reassuring] If thankfulness feels hard today, that's all right. God isn't asking you to pretend everything is easy. You can tell him that too. Gratitude and honesty can sit side by side.

[pause 8s]

[gentle] Your prayer can be simple and sincere: 'Thank you for this moment, Lord. Help me be present to the gift of today.' Whatever is on your heart, you can bring it to him.

[pause 12s]

[prayerful, sincere] Father of lights, every good thing in my life comes from you. Thank you for the small gifts I so often miss, and for the gift of this little one. Open my eyes to your goodness today, even in ordinary moments. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open slowly.

[pause 3s]

Watch for his good gifts today. They're often closer than we think.

[music 8s]

---

## Week 14 · Grounded

**Title:** A few / *words* / for you.
**Description:** Five minutes to speak to your baby, silently or out loud, in whatever way feels natural.
**Approach:** a guided first conversation with the baby, with no pressure on how it feels.

[music 8s]

[warm, unhurried] This meditation is a little different. Today, you're invited to talk to your baby.

[reassuring] If that feels natural, wonderful. If it feels strange, or awkward, or a bit too soon, that's completely okay. You can just listen along, and try it whenever you're ready.

[pause 6s]

[calm] Find a comfortable position. If you'd like, rest one or both hands on your belly.

[pause 6s]

Let your breath settle in its own time.

[pause 6s]

[gentle wonder] Your baby is developing within the shelter of your body, and that relationship is already part of your everyday life, even if you don't yet feel a clear bond. Your body has been making adjustments in the background while you've gone about ordinary routines.

[pause 6s]

[warm] Some people find it meaningful to start talking to their baby early, long before they meet. A voice, a few words, a habit that can grow over the months ahead.

[pause 6s]

[tender] Imagine, for a moment, what this little one might want to know about you.

[pause 8s]

You might start simply. Silently, or in a whisper: *Hello. It's me.*

[pause 9s]

[reassuring] You may feel excited to speak, or a little unsure what to say. There's no test to pass and no particular feeling you need to find. Even a quiet hello, or a hand resting on your belly, can be enough for today.

[pause 6s]

[warm] You could tell your baby something about your day. Where you are right now. What you can hear.

[pause 9s]

You could tell them something about yourself. Something you love. Something you're looking forward to.

[pause 9s]

Maybe a place you'd like to show them one day. A song you might sing. Something you hope you'll do together.

[pause 10s]

[tender] And if there's something you're feeling, hope, or nervousness, or wonder, you can say that too. There's no wrong thing to say.

[pause 9s]

Or you can say nothing at all, and simply be together in the quiet.

[pause 10s]

[warm] Whatever you said, or didn't say, this is how relationships begin. A little at a time.

[pause 10s]

When you're ready, let your hands rest, and slowly open your eyes.

[pause 4s]

You can pick up this conversation any time. There's no rush to it.

[music 8s]

---

## Week 14 · Faith-centered

**Title:** A blessing / *for* / the little one.
**Description:** Five minutes to pray an ancient blessing over your baby, and receive it for yourself too.
**Approach:** praying the priestly blessing slowly, line by line, over the baby, then personally.
**Scripture:** Numbers 6:24–26 (verbatim).

[music 8s]

[warm, unhurried] Welcome. Today we'll pray a blessing over your baby. One of the oldest blessings in Scripture.

Settle in, and if you'd like, rest your hands on your belly.

[pause 6s]

[calm] Let your breath slow in its own time.

[pause 5s]

[reverent] In the book of Numbers, God gave Moses these words for Aaron and the priests to speak over his people. People have prayed them over children for thousands of years.

Listen to them once through:

*The Lord bless you, and keep you. The Lord make his face to shine on you, and be gracious to you. The Lord lift up his face toward you, and give you peace.*

[pause 10s]

[warm, reassuring] A blessing isn't a guarantee of an easy road. It's an asking. Placing someone you love into God's care.

[pause 6s]

[tender] Notice the shape of it. Blessing. Keeping. His face shining toward you, the way a parent's face lights up when their child walks into the room. Grace. Peace.

[pause 6s]

[gentle wonder] The life you're carrying is part of the remarkable work unfolding within your body. You might feel joy, tenderness, or uncertainty as you pray. Each is welcome in this moment.

[pause 6s]

[prayerful, sincere] God, thank you for the ways this body is carrying new life today. Teach me to care for myself with the same tenderness I hope to give my child, and receive whatever feelings rise as I speak these words.

[pause 6s]

[reverent, tender] Let's pray it slowly over your baby now, line by line. You can echo the words silently, or simply listen.

The Lord bless you, and keep you.

[pause 9s]

The Lord make his face to shine on you, and be gracious to you.

[pause 9s]

The Lord lift up his face toward you, and give you peace.

[pause 12s]

[gentle] Now take a moment to pray for your baby in your own words. Whatever hopes are in your heart. Perhaps that they'll know they're loved. That they'll have courage, and kindness, and people around them.

[pause 13s]

[warm] And this blessing is for you too. Let it rest on you, as a mother, in this season.

[pause 6s]

[prayerful, sincere] Lord, bless me and keep me. Let your face shine on me. Give me your peace. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open slowly.

[pause 3s]

Go in his peace, both of you.

[music 8s]

---

## Week 15 · Grounded

**Title:** Still / *you* / and growing.
**Description:** Five minutes to honor how you're changing, and everything about you that remains.
**Approach:** a gentle visualization of who you were before, who you are now, and the self that carries through.

[music 8s]

[warm, unhurried] Picture yourself a year or so ago. Before this pregnancy. What did an ordinary day look like? What did you care about? What made you laugh?

[pause 10s]

[calm] Hold that picture gently as you settle into a comfortable position.

[pause 6s]

[gentle, understanding] Pregnancy changes so much. Your body. Your energy. Your plans. Sometimes, how other people see you. It's natural to wonder how much of you is changing too.

[pause 6s]

[warm] Let's take a moment with that.

Bring to mind something you've always loved. A place, a song, a food, a kind of weather.

[pause 9s]

That's still you.

[pause 5s]

Bring to mind something you're good at. Something people come to you for.

[pause 9s]

Still you.

[pause 5s]

Bring to mind a way you've grown in the last few months. Something you've learned, or carried, or handled, that you didn't know you could.

[pause 9s]

That's you too. Growing.

[pause 8s]

[gentle wonder] As your baby develops, your body is changing in visible and invisible ways. It can be astonishing to think of how much it does without your conscious instruction. It can also be strange to feel that your familiar self is changing alongside it.

[pause 6s]

[calm] Think of a tree. Each year it adds a new ring, and grows a little wider and taller. But the heart of it doesn't disappear. Every year is still inside it.

[pause 8s]

[tender, reassuring] Some days you might miss parts of your old life. The freedom, the energy, the body you knew. That isn't ingratitude. It's a natural part of a big change, and those feelings deserve gentleness too.

[pause 6s]

You can admire this process without needing to admire every physical sensation or new limitation. The person you have been and the mother you are becoming don't have to compete. There is room for both.

[pause 8s]

[tender] If you'd like, rest a hand on your belly. Your baby will come to know the person you've always been, as well as who you're becoming.

[pause 10s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

You're still you. And you're growing too.

[music 8s]

---

## Week 15 · Faith-centered

**Title:** New / *every* / morning.
**Description:** Five minutes to rest in God's unchanging faithfulness while so much in you is changing.
**Approach:** reflecting on change and constancy, with God's mercies as the steady center, and a quiet prayer of trust.
**Scripture:** Lamentations 3:22–23 (verbatim excerpt: from "his compassion" to the end of verse 23).

[music 8s]

[warm, unhurried] Imagine the early light of morning. The first gray glow at the window. The world quiet, before the day begins.

[pause 6s]

[calm] Let that quiet be with you as you settle in.

[pause 5s]

[gentle, understanding] So much is changing right now. Your body. Your energy. Your plans, maybe even how you see yourself. Some changes might feel exciting. Others might feel unsettling. Probably both.

[pause 5s]

[reverent] In the book of Lamentations, written during a time of upheaval, there's a moment of surprising hope. The writer says of God:

*his compassion doesn't fail. They are new every morning. Great is your faithfulness.*

[pause 10s]

[warm, reflective] Everything around the writer had changed. But God's compassion hadn't. It met the writer again, new, each morning.

[pause 8s]

[tender] New every morning. Not leftover from yesterday. Not rationed out. On the mornings when you wake up tired, or queasy, or anxious, his compassion is already there.

[pause 8s]

[gentle wonder] The life growing within you is a quiet reminder of how intricate creation can be. Your body is meeting this pregnancy with changes you did not have to plan, and you can offer God thanks for that work without insisting every change feels good.

[pause 6s]

[warm, reassuring] Sometimes God's mercies are found in the simplest moments: a little more patience, a moment of rest, or a quiet reminder of his love woven into an ordinary day. Ask for those small mercies as freely as you ask for peace.

[pause 6s]

[gentle] What feels most changed in your life right now? Bring it to God, honestly.

[pause 9s]

Now, what do you need to stay steady? Patience? Comfort? A reminder of who you are in him? Ask him for it.

[pause 9s]

[warm, reassuring] Some things about you won't change at all. You are still his. Still loved. Still known, through every season of this pregnancy, and every season after.

[pause 9s]

[tender] If you'd like, rest a hand on your belly. You and your baby are both changing every day, and both held by the same faithful God.

[pause 10s]

[prayerful, sincere] Lord, so much in me is changing. Thank you that your love doesn't change. Meet me with your compassion each morning, and help me trust you through every new thing. Amen.

[pause 10s]

[warm] When you're ready, let your eyes open.

[pause 3s]

His compassion will meet you new, every morning.

[music 8s]

---

## Week 16 · Grounded

**Title:** Into / *a softer* / evening.
**Description:** Five minutes to wind down your body and mind, for the end of the day or whenever you need rest.
**Approach:** an evening wind-down that dims the senses one by one and lets the day go, with a longer quiet ending.

[music 8s]

[calm, soothing] If it's evening, you might dim the lights, or turn them off altogether. If it's daytime, that's okay too. Let this be a small evening, wherever you are.

[pause 6s]

Find the most comfortable position you can. On your side, with a pillow between your knees, is often lovely at this stage. Use whatever support you have.

[pause 6s]

Let your breath slow down by itself. There's nowhere to be.

[pause 6s]

Let's let the day go, one piece at a time.

First, let your eyes rest. Let them grow heavy behind your eyelids.

[pause 5s]

Let your ears soften, so sounds become just a gentle background.

[pause 5s]

Let your jaw loosen, and your tongue rest at the bottom of your mouth.

[pause 5s]

Let your hands lie heavy and open.

[pause 8s]

[gentle wonder] Even as the house grows quiet, pregnancy doesn't stop being present. Your body continues the remarkable work of supporting this developing baby through the night. You don't have to stay awake to supervise that work, and you don't need to make yourself feel grateful before you rest.

[pause 6s]

[tender, reassuring] Whatever the day brought, tenderness toward your baby, worry, discomfort, or simple exhaustion, can come into this softer evening with you. Let tonight be a place to set down the expectation that you must feel one certain way.

[pause 6s]

[calm, soothing] Now think back over today, without judging any of it. The things that went well. The things that didn't. The things left undone.

[pause 8s]

Imagine each one as a lamp in a long hallway. One by one, you walk past them, turning each lamp down.

[pause 10s]

Notice the hallway growing softer and dimmer. Quieter. Your footsteps slowing. At the end of it, there's a warm, dark room, with a bed made up just for you.

[pause 10s]

The day is finished, or nearly. Whatever is left can wait until morning.

[pause 6s]

[tender] If you'd like, rest a hand on your belly. Let yourself feel the warmth there as you both settle.

[pause 7s]

[calm, soothing] Stay here. Let your body grow heavier and softer.

[pause 14s]

If you're drifting toward sleep, let yourself go. If not, simply enjoy the quiet.

[pause 6s]

Goodnight, or good rest, whichever you need.

[music 10s]

---

## Week 16 · Faith-centered

**Title:** Sleep / *for* / the beloved.
**Description:** Five minutes to lay down the day and rest in God's love, for evenings or any time you're weary.
**Approach:** handing the day over to God, piece by piece, then resting in his love, with a long quiet ending.
**Scripture:** Psalm 127:2 (verbatim excerpt: the end of the verse); Zephaniah 3:17 (verbatim excerpt: the third and fourth sentences).

[music 8s]

[reverent, calm] There's a line at the end of Psalm 127 that says:

*for he gives sleep to his loved ones.*

[pause 8s]

[warm, soothing] Sleep, and rest, as a gift. Not something you have to earn by finishing everything first.

[pause 6s]

[calm, soothing] If it's evening, you might dim the lights. If it's daytime, let this be a small evening wherever you are. Find the most comfortable position you can, with whatever pillows or support you need. Let your breath slow down by itself.

[pause 8s]

[gentle] Let's give the day to God, one piece at a time.

What went well today? Thank him for it.

[pause 10s]

What was hard? Tell him about it, and leave it with him.

[pause 10s]

What's left undone? Let it wait. It's in his hands until morning.

[pause 10s]

[gentle wonder] As you settle, remember the quiet wonder of carrying a developing child. Your body is adjusting in ways you may never see directly, and you can thank God for this mystery without needing to understand every part of it.

[pause 6s]

[calm, soothing] If your mind wanders back to the busyness of the day or the things waiting for your attention, bring that into your prayer too. God is present whether sleep comes easily or not. Rest can begin with simply being here with him.

[pause 6s]

[reverent, calm] Now listen to these words, spoken by the prophet Zephaniah to God's people:

*He will calm you in his love. He will rejoice over you with singing.*

[pause 10s]

[tender, soothing] Imagine being sung over. Calmed. The way you might one day sing over your own child.

[pause 7s]

Not because you've earned it, or finished your list, or handled today perfectly. Simply because you are his, and he delights in you.

[pause 8s]

[calm, soothing] If you'd like, rest a hand on your belly. You are both held in his love tonight. Let your shoulders sink into the pillow. Let your hands rest open, like a child asleep.

[pause 10s]

[prayerful, soothing] Lord, I give you this day. Calm me in your love, and give me the rest I need. Amen.

[pause 12s]

[calm, soothing] If you're drifting toward sleep, let yourself go. If not, rest here in his care.

[pause 6s]

Rest well, beloved.

[music 10s]

---

## Week 17 · Grounded

**Title:** Held / *by* / many hands.
**Description:** Five minutes to notice the support around you, whatever shape it takes.
**Approach:** noticing physical support first, then the people and places that help, with room for those who feel short on support.

[music 8s]

[warm, unhurried] Let's begin by noticing what's holding you up, right now. Literally.

The surface beneath you. The pillow behind your head, or the chair at your back. Let yourself lean into it.

[pause 8s]

[calm] You don't have to hold yourself up. Something is already doing it for you.

[pause 8s]

[warm, reassuring] Support comes in many shapes. Some people have a partner, a family, a close circle of friends. Some have one or two people. Some are doing a lot of this on their own. Wherever you are, this meditation is for you.

[pause 6s]

[warm] Let's notice the support that's there, even in small ways.

Bring to mind a person who's been kind to you during this pregnancy. It might be someone close. It might be a nurse, a coworker, a neighbor, a stranger who held a door.

[pause 12s]

Picture their face, if you can. Notice how it feels to remember their kindness.

[pause 10s]

[gentle wonder] Your body is offering this baby a place to develop, while you deserve care and support in your own right. Pregnancy isn't a project you should have to manage alone. The extraordinary work happening inside you doesn't make your ordinary needs less important.

[pause 6s]

[tender, reassuring] If your support system feels complicated, or you're not ready to share every feeling about this pregnancy, you can start smaller. A message, a meal, a quiet check-in: receiving any of those is part of caring for yourself.

[pause 6s]

[warm] Now think of a place that helps you feel supported. A favorite room. A walk you love. A spot where you can breathe more easily.

[pause 12s]

And think of something that supports you that isn't a person or a place. A routine. A song. A favorite blanket. Even this quiet moment.

[pause 12s]

And notice the ways you support yourself, too. Resting when you need to. Eating when you're hungry. Choosing to spend these minutes here. That's support as well.

[pause 8s]

[tender] If you'd like, rest a hand on your belly. Your baby is being held too, every moment, by you.

[pause 10s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

You don't have to do this all by yourself. Let yourself be held, in whatever ways you can.

[music 10s]

---

## Week 17 · Faith-centered

**Title:** Never / *left* / alone.
**Description:** Five minutes to rest in God's promise never to leave you, and see his care through others.
**Approach:** God's presence first, then the people he places around us, with room for those who feel alone.
**Scripture:** Hebrews 13:5 (verbatim excerpt: the words quoted as God's, at the end of the verse); Galatians 6:2 (verbatim).

[music 8s]

[warm, unhurried] Welcome. Wherever you're listening from, and whoever is or isn't beside you right now, you're not alone in this moment.

Find a comfortable position, and let yourself lean into whatever is supporting you.

[pause 8s]

[reverent] The letter to the Hebrews reminds its readers of something God has said:

*I will in no way leave you, neither will I in any way forsake you.*

[pause 10s]

[warm, reassuring] In no way. Not in the hard moments. Not in the uncertain ones. Not when you feel strong, and not when you feel weak.

[pause 8s]

[warm, reflective] This letter was written to people who were struggling. Some had lost their possessions. Some felt forgotten. And God's answer to them wasn't a list of instructions. It was his presence.

[pause 8s]

[calm] Take a moment to rest in his presence. You don't need to feel anything particular. Just know he's here.

[pause 10s]

[reverent] God often shows his care through people. Paul wrote to the churches in Galatia:

*Bear one another's burdens, and so fulfill the law of Christ.*

[pause 8s]

[gentle wonder] As a new life develops within your body, you are giving and carrying so much. God's care for you isn't an instruction to handle everything without help; you are worthy of comfort and practical support too.

[pause 6s]

[warm] Sometimes God answers our prayers for help through other people's hands and voices. A meal dropped off. A message at just the right moment. Someone who simply sits with us.

[pause 8s]

[gentle] Bring to mind someone who has helped carry your burdens lately. A partner, a friend, a family member, a nurse, someone at church, someone unexpected. Thank God for them.

[pause 10s]

[tender, reassuring] Some women share joyful news openly. Others prefer to keep it close for a while. God knows what you're carrying in your heart. You can ask him for trustworthy people and the courage to accept help in whatever measure feels right.

[pause 8s]

[tender] If you'd like, rest a hand on your belly.

[pause 6s]

[prayerful, sincere] Lord, thank you that you never leave me. Thank you for the people who carry my burdens with me. Where I feel alone, draw near, and bring the help I need. Amen.

[pause 10s]

[warm] When you're ready, let your eyes open slowly.

[pause 3s]

He goes with you into the rest of today.

[music 10s]

---

## Week 18 · Grounded

**Title:** Listening / *for* / you.
**Description:** Five minutes of quiet attention inward, wherever you are in getting to know your baby.
**Approach:** turning attention inward like listening to the sea, with no expectation of feeling movement.

[music 8s]

[warm, unhurried] Let's get quiet enough to listen inward.

Find a comfortable position. Lying on your side, or sitting reclined, often makes it easier to notice what's happening inside.

[pause 8s]

[calm] Let the sounds of the room fade into the background, like distant waves.

[pause 8s]

[warm, reassuring] Somewhere in these weeks, some people begin to notice tiny movements. Flutters, taps, little bubbles. For others, it takes longer. Every pregnancy has its own timing, and there's no right moment for this.

[pause 6s]

[tender] Rest your hands on your belly, if you'd like. Let them be still and soft.

[pause 8s]

[calm] Now bring your attention down to where your hands are resting. Notice warmth. Notice the slow rise and fall of your breath.

[pause 12s]

[gentle] You don't need to look for any particular sensation right now. Let this be a moment to notice your own breath, the warmth of your hands, and the quiet connection of being here with your baby.

[pause 6s]

[gentle wonder] Instead, simply recognize the remarkable changes taking place as your body carries this baby. You can feel curious, amazed, or uncertain. A gentle hand on your belly can be a gesture of connection without expecting anything in return.

[pause 6s]

[calm] Notice the stillness, too. Stillness is part of listening.

[pause 10s]

[tender] Your baby lives surrounded by your rhythms. Your heartbeat. Your breathing. The movement of your body through the day. In their own way, they're getting to know you too.

[pause 10s]

[warm] If you feel something, a flutter, a nudge, a little rolling sensation, you can greet it, silently. *Hi. I'm here.*

[pause 8s]

[calm] Whether you notice a gentle sensation or only the warmth of your hands, you can let this be a moment of quiet attention, without needing to achieve anything.

[pause 14s]

[warm] Over the coming weeks, quiet moments like this may become some of your favorite times together.

[pause 6s]

When you're ready, let your attention widen again to the room around you, and slowly open your eyes.

[pause 4s]

You can return to this gentle moment of connection whenever you'd like.

[music 8s]

---

## Week 18 · Faith-centered

**Title:** A greeting / *of* / joy.
**Description:** Five minutes with Mary and Elizabeth, two expectant mothers who shared their joy and their waiting.
**Approach:** imaginative reflection on the visitation, then praying for companionship and joy, with no expectation of feeling movement.
**Scripture:** Luke 1:39–45 (the story retold in Maren's own words); Luke 1:41 (verbatim excerpt: the first part of the verse); Luke 1:44 (verbatim).

[music 8s]

[warm, storytelling] Long ago, two expectant mothers met in a house in the hill country of Judah. Find a comfortable position as we step into their story.

[pause 5s]

Mary was young, and newly pregnant, carrying news she was still trying to understand. She hurried to visit her relative, Elizabeth, who was also expecting, after years of waiting.

[pause 5s]

Imagine Mary arriving at the door, tired from her journey. Imagine Elizabeth hearing her voice.

[reverent] Luke tells us:

*When Elizabeth heard Mary's greeting, the baby leaped in her womb.*

[pause 7s]

[reverent, joyful] And Elizabeth said to her:

*For behold, when the voice of your greeting came into my ears, the baby leaped in my womb for joy!*

[pause 9s]

[warm] Two women, both carrying new life. Sharing their joy, and their questions, and staying together for months.

[pause 5s]

[warm, smiling] Imagine the conversations they might have had. Talking about what their bodies were going through. Wondering together about the children they would hold. Laughing, maybe. Praising God, as Mary did.

[pause 7s]

[gentle, reassuring] Some people begin to feel small movements around this time, and others not for a while yet. This story isn't about a timeline. It's about joy shared, and about not waiting alone.

[pause 5s]

[tender] In the meeting of Mary and Elizabeth, joy rises through an encounter with the child each woman is carrying. Your own relationship with your baby may feel quieter or more complicated. There is no single right way for it to begin.

[pause 6s]

[gentle wonder] You can bring God your wonder at the life developing within you, along with any other feelings today holds. Let Mary and Elizabeth's story be an invitation to notice this moment with gratitude, not a standard for how you ought to feel.

[pause 6s]

[tender] If you'd like, rest your hands on your belly. Simply be with your baby, whatever you feel or don't feel.

[pause 10s]

[warm] Elizabeth's joy began with a greeting. Imagine greeting your baby now, in your heart. A simple hello, full of love.

[pause 9s]

[gentle] Who is an Elizabeth for you? Someone you can share this season with? Thank God for them. Or, if you're longing for someone like that, ask him for it.

[pause 8s]

[prayerful, sincere] Lord, thank you for the joy of new life, and for the people who share it with me. Let joy find its way into my heart, even in the waiting. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open slowly.

[pause 3s]

May you find small joys to share today.

[music 8s]

---

## Week 19 · Grounded

**Title:** The pause / *between* / things.
**Description:** Five minutes to learn a one-minute pause you can carry into any busy day.
**Approach:** a short, practical practice, rehearsed twice, for using between tasks.

[music 8s]

[warm, lightly smiling] Some days feel like one long list. Work, errands, appointments, meals, messages, and somewhere in there, growing a baby.

[pause 5s]

[warm] Today, let's practice a small pause you can take anywhere. Between meetings. In a parking lot. While the kettle boils. It takes about a minute.

Let yourself settle first.

[pause 6s]

[calm, clear] Here's how it goes. There are just three steps.

First: stop. Let your hands go still, wherever they are.

[pause 5s]

Second: feel your feet. Notice where they touch the floor, or the bed, or each other.

[pause 7s]

Third: let one breath out be a little longer and softer than the rest. Not forced. Just unhurried.

[pause 7s]

That's it. Stop. Feet. One soft breath out.

[pause 8s]

[warm] It's small on purpose. Small enough to remember on a hard day. Small enough to do with a phone in your hand, or a toddler on your hip, or in a waiting room before an appointment.

[pause 6s]

[gentle wonder] Wherever you pause, in a hallway, beside the car, or between errands, your body is carrying this pregnancy with you. Remarkable work is unfolding even when the rest of life seems ordinary. You can appreciate it for a second without having to stop your entire day.

[pause 6s]

[calm] Let's practice it once more, slowly.

Stop. Let everything go still.

[pause 5s]

Feet. Feel them, heavy and grounded.

[pause 7s]

One soft breath out.

[pause 8s]

[warm] Notice how you feel now. Maybe a little more here. Maybe just the same. Either is fine.

[pause 6s]

[tender] If you'd like, add a fourth step whenever you have a moment: a hand on your belly, as a small hello to your baby in the middle of your day.

One gentle breath can hold both gratitude for this developing life and whatever thoughts happen to be on your mind. You don't have to push either away.

[pause 10s]

[warm, reassuring] These pauses won't make a busy day less busy. But they can give you small places to land, in between all the things.

[pause 8s]

When you're ready, let your eyes open.

[pause 4s]

This pause is yours. It fits into any part of your day.

[music 8s]

---

## Week 19 · Faith-centered

**Title:** The / *one* / thing.
**Description:** Five minutes to sit at Jesus' feet in the middle of a busy season.
**Approach:** imaginative reflection on Mary and Martha, with gentle permission to stop, and quiet time with Jesus.
**Scripture:** Luke 10:38–42 (the story retold in Maren's own words); Luke 10:41–42 (verbatim excerpt: Jesus' words, from "you are anxious" to "one thing is needed").

[music 8s]

[warm, unhurried] Before we begin, notice how full your mind feels right now. Crowded? Quiet? Somewhere in between?

[pause 6s]

[calm] Whatever is there, let it wait a few minutes. Settle in, and let your body rest.

[pause 6s]

[warm, storytelling] In Luke's Gospel, Jesus visits the home of two sisters, Martha and Mary. Martha is busy getting everything ready. Mary sits at Jesus' feet, listening.

[pause 6s]

[reverent, tender] Martha, worn out, asks Jesus to tell her sister to help. And Jesus answers her, gently:

*Martha, Martha, you are anxious and troubled about many things, but one thing is needed.*

[pause 10s]

[warm, reassuring] Notice that he says her name twice. Kindly. He isn't scolding her for caring, or for working hard. He's inviting her to stop for a moment, and be with him.

[pause 8s]

[warm, reflective] Martha's work mattered. Someone had to make the meal. But in that moment, Jesus himself was sitting in her home, and she was missing time with him.

[pause 8s]

[gentle wonder] Pregnancy can bring a thousand little demands, yet within the rush your body is carrying a new life. That is worthy of wonder, and you don't need a long stretch of silence to bring that wonder to God.

[pause 6s]

[warm, gentle] If your thoughts wander during this moment, gently return your attention to God, knowing you can bring your whole heart to him. A brief prayer isn't less real because your feelings are mixed. You can meet God in this ordinary pause, as you are.

[pause 5s]

[tender] Imagine Jesus saying your name the same way. Kindly. Twice.

[pause 9s]

[gentle] What are the many things you're anxious and troubled about right now? You can name them to him.

[pause 9s]

[calm] Now imagine setting them down, just for these few minutes, and sitting at his feet. There's nothing to prepare. Nothing to prove. Just be with him.

[pause 13s]

[tender] If you'd like, rest a hand on your belly. Your baby is here with you, in this quiet place.

[pause 10s]

[prayerful, sincere] Jesus, my days are full, and my mind is busier still. Thank you for inviting me to sit with you. Help me find my way back to you, even in the middle of everything. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open slowly.

[pause 3s]

Sit at his feet whenever you can, even for a moment in a busy day.

[music 8s]

---

## Week 20 · Grounded

**Title:** Halfway, / *and* / here.
**Description:** Five minutes to look back on how far you've come, and ahead with openness.
**Approach:** a reflective look back over the weeks so far, then looking ahead with curiosity rather than pressure.

[music 8s]

[warm, unhurried] Wherever you are in your pregnancy, you've likely reached somewhere around the middle. A good place to pause, and look around.

Find a comfortable position, and let yourself settle.

[pause 8s]

[warm, reflective] Let's look back first.

Think of the day you found out you were pregnant. Where were you? What did you feel?

[pause 10s]

Whatever you felt then, joy, shock, fear, all of it, it was a real beginning.

[pause 6s]

[gentle] Now think of one thing that's been hard since then. Something you've carried, or handled, or simply gotten through.

[pause 10s]

[warm, reassuring] You got through it. Notice that.

[pause 6s]

[warm] And think of one moment you'd like to remember from these weeks. A small one is fine.

[pause 10s]

That's part of your story now.

[pause 6s]

Think of someone, or something, that helped you get here. A person who listened. A routine that steadied you. Even your own quiet determination to keep going.

[pause 10s]

[gentle wonder] You've reached a point where you can look back and notice how much has changed: appointments, expectations, sensations, and the quiet work your body has been doing all along. There may be milestones worth celebrating, and there may be memories or uncertainties that make celebrating complicated.

[pause 6s]

[tender] If you'd like, lay a hand on your belly. Think of the developing baby you are carrying today, rather than trying to picture every step ahead. Let appreciation for this remarkable process be possible without asking your feelings to become simple.

[pause 8s]

[warm, hopeful] Now let's turn, gently, toward what's ahead.

You don't need to plan it all, or know how it will go. Just notice what you feel when you think about the months to come. Curiosity? Nerves? Hope? A mix?

[pause 10s]

[reassuring] Whatever's there, you'll meet the coming weeks the same way you've met these ones. One day at a time, learning as you go.

[pause 6s]

There will be new things to learn. New changes in your body, new decisions, new feelings. You don't have to be ready for all of them today. Only for the next small step.

[pause 10s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

Wherever the road goes from here, you can meet it as you are.

[music 8s]

---

## Week 20 · Faith-centered

**Title:** Helped / *until* / now.
**Description:** Five minutes to remember God's faithfulness so far, and trust him with the road ahead.
**Approach:** setting up a "stone of help" in remembrance, giving thanks for the past, and entrusting the future to God.
**Scripture:** 1 Samuel 7:12 (verbatim excerpt: Samuel's words at the end of the verse); Deuteronomy 31:8 (verbatim excerpt: the first three sentences).

[music 8s]

[warm, storytelling] In the book of First Samuel, after a hard-won season, the prophet Samuel set up a large stone as a marker. He named it Ebenezer, which means "stone of help," saying:

*the Lord helped us until now.*

[pause 10s]

[warm] Let's set up a small Ebenezer of your own today.

Find a comfortable position, and let yourself settle.

[pause 8s]

[gentle, reflective] Look back over these weeks of pregnancy. Where have you seen God's help? Maybe in a person. A kind word. A hard day you made it through. Strength you didn't know you had.

[pause 10s]

[prayerful] Thank him for each one, in your own words.

[pause 10s]

[warm] Now imagine placing a stone, right here, in this moment. A marker that says: God has helped me until now.

[pause 10s]

[gentle wonder] Looking back on these weeks, you may see moments of gratitude, stretches of uncertainty, and the intricate work of a body carrying new life. You can thank God for what this day holds without needing to explain every part of the journey.

[pause 6s]

[tender, reassuring] If reaching this milestone stirs up tender feelings, bring them into your reflection. The faithfulness you remember is not a guarantee about tomorrow; it is an invitation to meet this moment with God, as you are.

[pause 6s]

[warm, hopeful] Now look ahead. The coming months may hold joy, and challenge, and things you can't yet imagine.

[reverent] Moses spoke these words to Joshua and the people of Israel, as they faced a new and uncertain land:

*The Lord himself is who goes before you. He will be with you. He will not fail you nor forsake you.*

[pause 10s]

[warm, reassuring] He doesn't promise that the road will be easy. He promises to be with you on it.

[pause 8s]

[gentle] What feels uncertain about the months ahead? Name it to him. And picture him already there, going before you into each of those places.

[pause 12s]

[tender] If you'd like, rest a hand on your belly.

[pause 6s]

[prayerful, sincere] Lord, thank you for helping me until now. I trust you with what's ahead. Go before me, and stay with me, every step of the way. Amen.

[pause 10s]

[warm] When you're ready, let your eyes open slowly.

[pause 3s]

The God who has helped you until now is with you still.

[music 10s]

---

## Week 21 · Grounded

**Title:** Sinking / *into* / softness.
**Description:** Five minutes of deep relaxation, following a gentle path down into a quiet garden.
**Approach:** a slow descending visualization that deepens relaxation step by step, ending in a peaceful garden.

[music 8s]

[warm, unhurried] Hi. This is a time for going a little deeper into rest than usual.

Find a position where your whole body feels supported. Lying on your side, or reclining with pillows behind you. Let every part of you be held.

[pause 6s]

[calm] Notice your next breath arrive, and let it go. Nothing to change. Just letting it be easy.

[pause 6s]

[calm, soothing] Imagine you're standing at the top of a gentle path. It winds softly downward through tall grass, toward a garden you can't quite see yet. The air is warm. The light is golden.

[pause 6s]

We'll walk down slowly together. With each step, you'll let go a little more.

[pause 4s]

The first step. Let your forehead smooth and your eyes grow heavy.

[pause 6s]

The next step. Your jaw loosens. Your tongue rests.

[pause 6s]

Another step. Your shoulders slide down, away from your ears.

[pause 6s]

Another. Your arms grow warm and heavy, all the way to your fingertips.

[pause 6s]

Another. Your back softens into whatever is holding you.

[pause 6s]

And another. Your hips, your legs, your feet. Heavy, and easy.

[pause 8s]

[gentle wonder] As you rest more deeply, your body carries on its remarkable work. Your heart is pumping more blood than ever before, warm and steady, nourishing the little one growing inside you. All of it happening, while you simply rest.

[pause 6s]

[calm, peaceful] Now the path opens into the garden. Notice what's here. Maybe flowers, or soft green leaves, or the sound of water somewhere nearby. Let it be exactly as you'd like it.

[pause 10s]

Find a place to settle in your garden. A patch of soft grass. A bench in the shade. Let yourself sink into it.

[pause 10s]

[tender] If you'd like, rest a hand on your belly, and imagine your baby resting here with you, warm and peaceful.

[pause 14s]

[warm] This garden is always here for you. You can find your way back down the path whenever you need it.

[pause 6s]

When you're ready, take a slightly deeper breath, and let your body gently begin to wake. Fingers. Toes. Eyes opening slowly.

[pause 4s]

Rested, and a little softer than before.

[music 8s]

---

## Week 21 · Faith-centered

**Title:** Quietness / *and* / confidence.
**Description:** Five minutes to rest in God's strength, discovered in quiet rather than effort.
**Approach:** a gentle settling into quiet, reflection on Isaiah's words about rest, and silent trust before God.
**Scripture:** Isaiah 30:15 (verbatim excerpt: the second sentence of God's words).

[music 8s]

[warm, unhurried] Let's begin by simply getting quiet.

Find a position that feels restful and well supported. Let your hands lie open.

[pause 6s]

[calm] Notice your breath, coming and going on its own. No need to manage it. Notice the sounds around you, near and far, and let them fade into the background.

[pause 8s]

[reverent] Through the prophet Isaiah, God spoke to his people about where real strength is found. Among his words is this line:

*Your strength will be in quietness and in confidence.*

[pause 10s]

[warm, reflective] Quietness and confidence. Not hurry. Not effort. Not trying harder.

[pause 6s]

There's a lot of doing in pregnancy. Appointments to keep, things to prepare, plans to make. And there's a lot that's good about that. But this verse invites you to remember that strength can also grow in stillness.

[pause 6s]

[gentle wonder] Even now, as you rest, your body is doing extraordinary work. Your heart is working in remarkable ways to support this pregnancy, while your baby's own heart beats within. So much intricate activity unfolds quietly, without your conscious direction.

[pause 8s]

[warm] Confidence, too, can grow quietly. Not the loud kind that has every answer. The settled kind that comes from knowing who holds you. Week by week, as you rest in God's care, that confidence can take root.

[pause 8s]

[calm] Let's practice that quiet now. Let your shoulders soften. Let your jaw loosen. Let your whole body rest against what's holding you.

[pause 10s]

[tender] If you'd like, rest a hand on your belly. Let this be a quiet moment shared by the two of you, held in God's care.

[pause 12s]

[gentle] Now, in your heart, simply rest before God. You don't need to say anything. Let your quietness be your prayer.

[pause 18s]

[prayerful, sincere] Lord, thank you that strength isn't only found in doing. Teach me to rest in you, to grow quietly confident in your care, and to enjoy these days of carrying new life. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open, and come back gently.

[pause 3s]

May quietness and confidence go with you through this day.

[music 8s]

---

## Week 22 · Grounded

**Title:** The world / *within* / you.
**Description:** Five minutes imagining the warm, rhythmic world your baby knows, and the part you play in it.
**Approach:** a sensory visualization of the baby's surroundings, then quiet connection.

[music 8s]

[warm, curious] Let's take a little journey inward today. Not to anywhere far away. Just to the place where your baby is growing.

[pause 4s]

[calm] Settle in comfortably. Let your hands find your belly, if that feels natural.

[pause 6s]

Let your breath slow down by itself. Let your shoulders drop, and your jaw soften.

[pause 6s]

[gentle wonder] Imagine, for a moment, the world your baby knows.

Imagine the warmth of the world surrounding your baby.

[pause 6s]

It's soft. Cushioned on every side, gently rocking whenever you move.

[pause 6s]

It's full of rhythm. The steady drum of your heartbeat. The whoosh of your breath. The gurgles and hums of a body at work.

[pause 8s]

And it's full of you. Your voice, muffled and warm. Your laugh. The way your body sways when you walk.

[pause 8s]

[tender] Your baby doesn't know the world outside yet. But they know the rhythm of you. That's their first experience of being held.

[pause 8s]

[gentle wonder] Think about the extraordinary ways your body adapts throughout pregnancy, providing a place for your baby to develop. Warmth, nourishment, movement, and familiar rhythms. So much of this remarkable process happens without your conscious direction.

[pause 8s]

[warm] Now imagine what your baby might notice right now, as you rest. Your heartbeat slowing a little. Your body growing still. The gentle rise and fall of your breath around them.

[pause 10s]

You're sharing this moment of calm together, in the most intimate way two people ever can.

[pause 10s]

[tender] If you'd like, say something to your baby, silently or out loud. Something simple. *I'm here. We're resting together.*

[pause 14s]

[calm] Stay a little longer in this shared quiet.

[pause 12s]

[warm] When you're ready, let your attention widen to the room around you, and open your eyes.

[pause 4s]

Wherever you go today, you're carrying their whole world with you.

[music 8s]

---

## Week 22 · Faith-centered

**Title:** Life / *and loving* / kindness.
**Description:** Five minutes to marvel at how God forms and cares for life, in you and in your baby.
**Approach:** reflecting on Job's wonder at being formed by God, then gratitude for the life within you.
**Scripture:** Job 10:11–12 (verbatim excerpt: the first two sentences).

[music 8s]

[warm, reflective] There's a moment in the book of Job where Job, speaking honestly to God, pauses to remember how he was made. He says:

*You have clothed me with skin and flesh, and knit me together with bones and sinews. You have granted me life and loving kindness.*

[pause 10s]

[warm, unhurried] Let his words settle as you find a comfortable position. Let your breath slow down on its own, and your shoulders soften.

[pause 6s]

[gentle wonder] Skin and flesh. Bones and sinews. Even now, these are being formed in your baby. Tiny fingers and toes. A heartbeat. Eyes, ears, a face that's uniquely theirs.

[pause 8s]

And your own body is part of that work. Supplying, sheltering, adapting, every moment of every day. What a remarkable thing to be part of.

[pause 8s]

[tender] If you'd like, rest your hands on your belly, and simply marvel for a moment at the life God is forming there.

[pause 12s]

[warm, reverent] Notice the last line of Job's words. Life and loving kindness. God doesn't only make us. He gives us life wrapped in his kindness.

[pause 8s]

[warm] That kindness surrounds you too. In the rest you can take today. In the people who care for you. In a good meal, a warm bed, a quiet moment like this one. In the small, good gifts of this season.

[pause 8s]

[tender] And one day, you'll show that same loving kindness to your child. In a thousand small ways. Feeding, holding, soothing, delighting in them. Love, learned first from the God who loves you.

[pause 10s]

[gentle] Take a moment to thank God, in your own words, for the life he's forming, and for his kindness to you.

[pause 15s]

[prayerful, sincere] Creator God, thank you for knitting this little one together with such care. Thank you for my body, and for all it's doing. Surround us both with your loving kindness, today and every day. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open slowly.

[pause 3s]

Life and loving kindness, given to you, and to your little one.

[music 8s]

---

## Week 23 · Grounded

**Title:** Strong / *and* / soft.
**Description:** Five minutes to appreciate the strength your body already has, and the softness that goes with it.
**Approach:** a body-awareness practice moving between strength and softness, with gentle encouragement.

[music 8s]

[warm, unhurried] Let's start with something you might not stop to notice very often: how strong your body is.

Settle into a comfortable seat, or lie on your side. Let yourself be supported.

[pause 6s]

[calm] Notice your breath. Let it find its own easy rhythm.

[pause 6s]

[gentle wonder] Over these months, your body has been doing something extraordinary. It has made room. It has carried more weight, pumped more blood, and grown a whole new organ just to nourish your baby. That's real strength, even on the days you feel tired.

[pause 8s]

[calm] Let's notice that strength, and pair it with softness.

Bring your attention to your legs. These legs carry you, and your baby, through every day. Notice their strength.

[pause 6s]

And now let them soften. Let them be heavy, and resting.

[pause 6s]

Your hips and lower back. They're working hard to support your growing belly. Notice their strength.

[pause 6s]

And now let them soften. Let the muscles there release, just a little.

[pause 6s]

Your arms and hands. Strong enough to carry so much, and soon, strong enough to hold your baby. Notice them.

[pause 6s]

And let them soften, open and easy.

[pause 6s]

Your shoulders and neck. They hold more than you realize. Notice them.

[pause 5s]

And let them drop. Let the tension melt away.

[pause 6s]

Your belly. Stretching, growing, holding your baby close.

[pause 5s]

[tender] Let it be soft too. There's nothing to hold in. Rest a hand there, if you'd like.

[pause 10s]

[warm, reassuring] Strength and softness belong together. Think of a tree in the wind, rooted deep but bending with ease. The strongest things in nature often bend and give. There's beauty in both strength and softness. You can appreciate what your body is capable of while allowing it the gentleness and rest it needs.

[pause 8s]

[warm] Let yourself rest in that for a moment. Strong. And soft.

[pause 12s]

When you're ready, let some gentle movement return, and slowly open your eyes.

[pause 4s]

You are stronger than you know, and you're allowed to be gentle too.

[music 8s]

---

## Week 23 · Faith-centered

**Title:** Strength / *that* / renews.
**Description:** Five minutes to receive God's strength for this season, with gratitude for all your body is doing.
**Approach:** reflection on Isaiah 40, gratitude for the body's strength, and prayer for renewed energy.
**Scripture:** Isaiah 40:29 (verbatim); Isaiah 40:31 (verbatim excerpt: the first part of the verse).

[music 8s]

[warm, unhurried] Pregnancy asks a lot of your body, and your body has been rising to meet it, week after week.

Let's take a few minutes to rest, and to receive.

[pause 4s]

[calm] Find a comfortable position. Let your breath come and go easily. Let your shoulders settle, and your hands rest.

[pause 6s]

[reverent] Isaiah chapter 40 was written to encourage God's people when they felt worn out. It reminds them that the Creator of the whole earth never grows tired. And then it says:

*He gives power to the weak. He increases the strength of him who has no might.*

[pause 8s]

And a little later:

*those who wait for the Lord will renew their strength.*

[pause 10s]

[warm, reflective] Renew. Not invent from nothing. Renew. Like a well that fills again, or a field that grows green after rain.

[pause 6s]

[gentle wonder] Think of all your body has done these past months. Growing your baby from the very first cells. Adapting, stretching, carrying more each week. That's a remarkable kind of strength, and it comes from the God who designed you.

[pause 8s]

[warm] And strength isn't only physical. Think of the patience you've found. The kindness you've shown yourself on tired days. The love already growing for someone you haven't met yet. Those are gifts of strength too.

[pause 8s]

[calm] Let's rest in that now. Let your shoulders soften. Let your arms and legs grow heavy. Let your body be carried for a while, instead of carrying.

[pause 10s]

[tender] If you'd like, rest a hand on your belly. Your baby is growing in strength too, held within yours.

[pause 10s]

[gentle] Waiting on the Lord can be as simple as this: being still, and receiving. Take a quiet moment to tell God what you need today. Energy, patience, rest, joy.

[pause 15s]

[prayerful, sincere] Lord, thank you for the strength you've given my body for this work. When I feel tired, renew me. Fill me again, day by day, and let me enjoy this season with you. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open.

[pause 3s]

May his strength meet you, fresh and new, as you go.

[music 8s]

---

## Week 24 · Grounded

**Title:** The long, / *slow* / exhale.
**Description:** Five minutes to explore a gentle breathing pattern you can return to throughout pregnancy and birth.
**Approach:** a relaxed introduction to lengthening the out-breath, with no counting and no right or wrong.

[music 8s]

[warm, unhurried] Today we'll spend a few minutes with something simple and powerful: the out-breath.

Find a comfortable position, sitting or lying on your side.

[pause 6s]

[calm] First, just notice your breathing as it is. No changes yet. Notice where you feel it. Your nose, your chest, your belly.

[pause 10s]

[warm] When we breathe out slowly, our bodies tend to relax. Muscles soften. The mind grows a little quieter. It's one of the gentlest tools you have, and it's always with you.

[pause 6s]

[calm, clear] Let's try it, only if it feels comfortable.

Breathe in naturally. And then let your breath out a little more slowly than usual. Like a sigh that takes its time.

[pause 8s]

Again. A natural breath in. And a long, unhurried breath out.

[pause 8s]

There's no number to reach, and no right length. Just a little longer and softer than before.

[pause 10s]

[calm, soothing] As you breathe out, you might imagine your shoulders melting down. Or your jaw going soft. Or your hands opening.

[pause 10s]

Some people like to picture the breath as a soft wave rolling out to sea. Others imagine blowing gently across a cup of tea. Choose whatever image feels natural to you, or none at all.

[pause 8s]

Let a few more breaths come this way, at your own pace.

[pause 15s]

[gentle wonder] Every breath is part of an extraordinary process. Oxygen moves from your lungs into your bloodstream, helping support both your body and your developing baby. Take a moment to appreciate how much happens naturally, without your having to think about it.

[pause 8s]

[tender] If you'd like, rest a hand on your belly as you breathe out.

[pause 10s]

[warm, reassuring] This long, slow exhale is something you can return to anytime. Before sleep. In a waiting room. And later, when it's time to meet your baby. The more familiar it becomes, the more easily it will come to you.

[pause 8s]

[warm] Now let your breathing return to its natural rhythm, and slowly open your eyes.

[pause 4s]

One long, slow breath out is always within your reach.

[music 8s]

---

## Week 24 · Faith-centered

**Title:** The breath / *of* / life.
**Description:** Five minutes to rest in the God who gives every breath, with a gentle, prayerful practice of slowing down.
**Approach:** breath as God's gift, a slow and easy breathing prayer, and gratitude for shared life.
**Scripture:** Job 33:4 (verbatim).

[music 8s]

[warm, reflective] Every breath you've ever taken has been a gift. Today, let's slow down enough to notice that.

Find a comfortable position, and let yourself be supported.

[pause 6s]

[reverent] In the book of Job, a young man named Elihu says:

*The Spirit of God has made me, and the breath of the Almighty gives me life.*

[pause 10s]

[warm] The breath of the Almighty. Each breath, given. Each one, a quiet reminder of the God who made you.

[pause 6s]

[calm] Notice your breathing now, just as it is. Feel it moving in, and out. You don't need to change anything yet.

[pause 8s]

[calm, clear] If it's comfortable, let your next breath out be a little slower. Unhurried. Like a long sigh.

[pause 8s]

And again. A natural breath in, and a long, easy breath out.

[pause 8s]

[warm] Slow breathing like this helps the body soften and settle. It's a gentle gift you can return to anytime: in a waiting room, before sleep, and one day, when you're welcoming your baby.

[pause 8s]

[prayerful] You might pair your breathing with a simple prayer. Breathing in: You give me life. Breathing out: I rest in you.

[pause 15s]

You give me life.

I rest in you.

[pause 15s]

[gentle wonder] Each breath you take is shared with your baby. Through your body, life and nourishment flow to them, moment by moment. God's gift of breath, passed along in love.

[pause 8s]

[tender] If you'd like, rest a hand on your belly and thank God for this shared life.

[pause 10s]

[prayerful, sincere] Lord, thank you for every breath, and for the life growing in me. Let my breathing remind me of your nearness, today, and in the days to come. Amen.

[pause 8s]

[warm] Let your breathing return to its own rhythm, and when you're ready, open your eyes.

[pause 3s]

Every breath today is a small gift from him.

[music 8s]

---

## Week 25 · Grounded

**Title:** Hello / *in* / there.
**Description:** Five minutes to notice and enjoy your baby's movements, and answer them with love.
**Approach:** quiet attention to the baby's movements, with a playful moment of response and connection.

[music 8s]

[warm, lightly smiling] There's someone else who's been busy in there lately. Let's take a few minutes to say hello.

[pause 4s]

[calm] Find a comfortable position. Lying on your side, or reclining, can make it easier to notice what's happening inside.

[pause 6s]

Rest your hands on your belly, wherever feels natural.

[pause 6s]

[calm] Let your breath settle. Let your body grow still and quiet. Let your shoulders drop, and your face soften.

[pause 8s]

[gentle wonder] At this stage, you may be becoming more familiar with the sensation of your baby's movements. Perhaps you've noticed little rolls, nudges, or stretches. These moments can offer a lovely opportunity to pause and feel connected to the little life you're carrying.

[pause 8s]

[warm] For these next few moments, simply pay attention. If you feel a movement, notice where it is and what it feels like.

[pause 14s]

[warm, lightly smiling] If you'd like, you can answer. A gentle press of your hand. A soft pat. A few words: *Hello in there. I feel you.*

[pause 12s]

[tender] Some babies seem to respond to their mother's touch or voice. Whether or not yours moves right now, they're surrounded by your warmth and your rhythm. They know you in their own way.

[pause 10s]

[gentle wonder] Think of how much is happening in there. Tiny muscles getting stronger. Lungs practicing. Hands opening and closing. Each day, a little more ready for the world.

[pause 8s]

[warm] Many parents find their baby has favorite times to be active. After a meal, maybe, or just as you lie down at night. You might start to notice your baby's own little rhythms, the first hints of their personality.

[pause 8s]

Let yourself enjoy this. The quiet company of the little one you're getting to know.

[pause 15s]

[tender] Before we finish, you might tell your baby one thing you're looking forward to. *I can't wait to see your face.* Or anything that feels true for you.

[pause 12s]

[warm] When you're ready, let your hands rest, and open your eyes.

[pause 4s]

You're getting to know each other, one little hello at a time.

[music 8s]

---

## Week 25 · Faith-centered

**Title:** A gift / *from* / the Lord.
**Description:** Five minutes to receive your baby as God's good gift, and thank him for this growing life.
**Approach:** reflection on Psalm 127, attention to the baby's movements, and a prayer of thankfulness.
**Scripture:** Psalm 127:3 (verbatim).

[music 8s]

[warm, unhurried] Let's begin by simply resting your hands on your belly, if you'd like, and noticing the life within.

Settle into a comfortable position, lying on your side or reclining, well supported.

[pause 6s]

[calm] Let your breath slow down. Let your shoulders soften. Let your face relax.

[pause 6s]

[reverent] In Psalm 127, the psalmist says:

*Behold, children are a heritage of the Lord. The fruit of the womb is his reward.*

[pause 10s]

[warm, reflective] A heritage. A gift handed down with love. Not something earned, but something given, by a generous God.

[pause 6s]

In Bible times, a heritage was something precious passed down through a family. Land, a home, a name. The psalmist uses that word for children. A treasure, entrusted with love.

[pause 8s]

[gentle wonder] Your baby is that kind of gift. Growing now, moving, stretching, becoming more themselves every day. Knit together in the quiet, with a care only God could give.

[pause 8s]

[warm] Take a few moments to notice your baby. If you feel a movement, a roll, a nudge, let it be a reminder of the gift you're carrying.

[pause 14s]

[tender] You might greet your baby in your heart. Or simply rest your hand where you feel them, and enjoy their company.

[pause 12s]

[gentle wonder] Every gift reflects the giver. Your baby's life is a reflection of God's own generosity and delight. Before you ever held them, he knew them, and he chose to give them to you.

[pause 8s]

[gentle] Now think of the things you're grateful for in this pregnancy. Maybe a first flutter you'll never forget. The way your body has adapted. People who've celebrated with you. Thank God for each one, in your own words.

[pause 15s]

[prayerful, sincere] Father, thank you for this child, a gift from your hand. Thank you for every movement, every stretch, every sign of life. Help me receive this gift with joy, and care for it with love. Amen.

[pause 8s]

[warm] Let your hands rest, and when you're ready, open your eyes.

[pause 3s]

A gift from the Lord, growing close to your heart.

[music 8s]

---

## Week 26 · Grounded

**Title:** Steady / *as* / a stone.
**Description:** Five minutes to find a calm, steady center, like a smooth stone in a gentle stream.
**Approach:** a flowing-water visualization for steadiness, preparing an inner calm you can return to later.

[music 8s]

[warm, unhurried] Picture a clear, gentle stream on a warm afternoon. Sunlight sparkles on the water. The sound is soft and constant.

[pause 8s]

[calm] Let that sound help you settle. Find a comfortable position, and let your body be supported.

[pause 6s]

Let your breath slow down, like the water slowing in a quiet pool.

[pause 8s]

[calm, soothing] Now look into the stream, and notice a smooth stone resting on the bottom. The water moves over it and around it, all day long. And the stone stays steady.

[pause 8s]

Imagine you are that stone. Calm. Grounded. Resting on the riverbed.

[pause 8s]

Feel the weight of your body, heavy and settled, the way the stone rests in the sand. Nothing needs to move. Nothing needs to hold on.

[pause 8s]

[gentle] Life flows around you. Plans, conversations, to-do lists, new things to learn. All of it can move past, like water, while you stay steady at your center.

[pause 10s]

Notice how the water has smoothed the stone over time. Not by force. Just gently, constantly. Calm is like that too. It grows with practice.

[pause 8s]

[gentle wonder] And within you, your baby rests in their own gentle waters, rocked and cushioned, surrounded by warmth. Steady, and held, while life flows around them.

[pause 8s]

[tender] If you'd like, rest a hand on your belly. Two steady centers, resting together.

[pause 12s]

[warm, reassuring] This place of steadiness is something you can come back to. On busy days. When things feel like a lot. And later, when you're welcoming your baby. You can always find the stone beneath the water.

[pause 10s]

[calm] Stay here a little longer, steady and calm, with the stream flowing gently around you.

[pause 12s]

[warm] When you're ready, let your body begin to stir, and open your eyes.

[pause 4s]

Steady at your center, whatever flows by.

[music 8s]

---

## Week 26 · Faith-centered

**Title:** My peace / *I* / give you.
**Description:** Five minutes to receive the peace Jesus offers, a peace that's his own gift to you.
**Approach:** reflection on Jesus' promise of peace, a guided receiving of that peace, and personal prayer.
**Scripture:** John 14:27 (verbatim excerpt: the first two sentences).

[music 8s]

[warm, storytelling] On the night before he died, Jesus sat with his closest friends and spoke to them tenderly about the days ahead. Among his words was this gift:

*Peace I leave with you. My peace I give to you;*

[pause 10s]

[warm, unhurried] Let his words rest with you as you settle in. Let your breath slow down, and your hands rest open.

[pause 6s]

[warm, reflective] My peace. Not a peace that depends on everything going perfectly. Jesus' own peace. The kind he carried with him through every day of his life, through crowds and storms and quiet hillsides alike.

[pause 8s]

And notice that he gives it. You don't have to manufacture it, or earn it, or find it on your own. It's a gift, offered freely.

[pause 6s]

His peace goes with you into every room and every day. Into quiet mornings and busy afternoons, and into the days ahead when you'll welcome your baby.

[pause 8s]

[calm] Let's receive it slowly. Imagine that peace as a gentle warmth, beginning at the top of your head.

[pause 6s]

Let it flow down over your face, softening your forehead, your eyes, your jaw.

[pause 6s]

Down through your shoulders and arms, all the way to your fingertips.

[pause 6s]

Through your chest, with each breath you take.

[pause 6s]

[tender] And into your belly, surrounding your baby with warmth and calm.

[pause 8s]

Down through your legs, and into your feet.

[pause 8s]

[gentle wonder] Your body is doing remarkable work, and your baby is growing in the shelter of it. Let this peace rest over both of you, gentle and steady.

[pause 10s]

[gentle] Now take a moment to talk with Jesus. Thank him for his peace, and tell him anything that's on your heart.

[pause 15s]

[prayerful, sincere] Jesus, thank you for giving me your own peace. Let it fill my heart and my home, and rest on this little one too. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open slowly.

[pause 3s]

His peace is yours to keep.

[music 8s]

---

## Week 27 · Grounded

**Title:** Thank you, / *body,* / for this.
**Description:** Five minutes to offer your body a heartfelt thank-you as your second trimester draws to a close.
**Approach:** a gratitude practice, written like a gentle letter to your body, part by part.

[music 8s]

[warm, unhurried] Hello. Today, you're going to write a little letter. Not on paper. Just in your heart, to your body.

Settle in comfortably, and let yourself be supported.

[pause 6s]

[calm] Let your breath slow. Let your eyes close, or rest your gaze gently. Let your shoulders soften as you breathe out.

[pause 6s]

[gentle wonder] As your second trimester nears its end, it's worth pausing to notice how much your body has done. Growing a placenta. Making more blood. Shifting and stretching to make room. Sheltering your baby through every hour of every day.

[pause 8s]

[warm] Let's begin your letter. Dear body.

[pause 4s]

[tender] Thank you, heart, for beating stronger for two.

[pause 6s]

Thank you, lungs, for every breath we share.

[pause 6s]

Thank you, belly, for making room, and holding our baby close.

[pause 6s]

Thank you, back and hips, for carrying more than ever before.

[pause 6s]

Thank you, legs and feet, for taking us everywhere we need to go.

[pause 6s]

Thank you, skin, for stretching and growing with us.

[pause 6s]

Thank you, hands, for resting on our baby, and for all the holding still to come.

[pause 8s]

[warm] Now add your own lines. Is there something your body has done that you're especially grateful for? A day it carried you through. A moment it surprised you. Tell it, in your own words.

[pause 15s]

[warm, reassuring] Your body may not always feel comfortable. It's working very hard. Gratitude doesn't mean every moment feels good. It simply means noticing the remarkable things it's doing, right now.

[pause 8s]

[gentle wonder] And notice that your body has been working for you all along, long before this pregnancy. Healing small cuts. Carrying you through busy days. Keeping your heart beating through every night. This is just its newest, most remarkable chapter.

[pause 8s]

[tender] If you'd like, rest a hand on your belly, and finish your letter. Thank you for this. Thank you for us.

[pause 14s]

[warm] When you're ready, let your hands rest, and slowly open your eyes.

[pause 4s]

Your body heard every word.

[music 8s]

---

## Week 27 · Faith-centered

**Title:** In wisdom / *you* / made them.
**Description:** Five minutes to praise God for the wisdom and beauty of his creation, including the life within you.
**Approach:** a psalm of wonder, gratitude for the wisdom woven into the body, and a prayer of praise.
**Scripture:** Psalm 104:24 (verbatim excerpt: the first two sentences).

[music 8s]

[warm, reflective] Psalm 104 is one long song of wonder. It moves through mountains and springs, birds and trees, sunrise and moonlight. And then the psalmist breaks into praise:

*Lord, how many are your works! In wisdom, you have made them all.*

[pause 10s]

[warm, unhurried] Let those words of praise settle as you find a comfortable position. Let your breath slow down, and your shoulders soften.

[pause 6s]

[warm, reflective] Imagine the psalmist looking out at the world. Rivers running through valleys. Birds nesting in the trees. Lions in the night, and people heading out to work in the morning. Everywhere he looks, he sees God's wisdom.

[pause 8s]

[gentle wonder] In wisdom, you have made them all. That includes the wisdom built into your own body. The way it knows how to grow a placenta. How it makes more blood, and shifts and stretches to make room. How it shelters your baby through every hour of every day.

[pause 10s]

And it includes your baby. Tiny lungs practicing. Eyes beginning to open. A heartbeat steady and strong. All of it unfolding according to God's careful design.

[pause 10s]

[tender] If you'd like, rest your hands on your belly, and simply marvel at the wisdom at work there.

[pause 12s]

[warm] Now, like the psalmist, let your wonder turn into praise. Thank God for anything you've noticed about his work in you. Your body. Your baby. The beauty of this season.

[pause 15s]

[calm] Rest for a moment in the knowledge that you, and your baby, are part of God's good creation. Made with wisdom. Made with care.

[pause 8s]

[tender] One day, your baby will look out at the world with wonder of their own. The first sunrise. The first snowfall. The first time they see your face. You'll get to share that wonder with them.

[pause 8s]

[prayerful, sincere] Lord, how many are your works! Thank you for the wisdom woven into my body, and for the little one you're forming. Let me see your goodness everywhere I look today. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open.

[pause 3s]

You are part of his wise and wonderful work.

[music 8s]

---

## Week 28 · Grounded

**Title:** A nest / *of* / your own.
**Description:** Five minutes to imagine the warm, welcoming space you're preparing, in your home and in your heart.
**Approach:** a nesting visualization, from a physical space to an inner space of welcome.

[music 8s]

[warm, lightly smiling] Many people feel an urge, around this time, to prepare. To fold tiny clothes, arrange a corner of a room, make things ready. Today, let's prepare in a gentler way.

[pause 4s]

[calm] Find a comfortable position, well supported. Let your breath settle. Let your shoulders soften, and your hands rest.

[pause 8s]

[calm, peaceful] Imagine a space where your baby will rest when they arrive. It doesn't have to be fancy, or finished. Just picture it as you'd like it to be.

[pause 8s]

Notice the light in that space. Soft morning light, maybe. Or a warm lamp in the evening.

[pause 8s]

Notice what's there. A blanket, folded. Something soft to hold. Maybe a chair where you'll sit together.

[pause 8s]

Notice the sounds. Quiet, perhaps. Or a little music. Or the hum of a home going about its day.

[pause 8s]

[tender] Imagine the feeling of that space. Calm. Safe. Welcoming. A nest, made with love.

[pause 10s]

[warm] Now notice that you're preparing another kind of space too. A space inside you. In your heart, your days, your life. Room for a new person to belong.

[pause 8s]

[gentle wonder] Your body has been preparing all along, making room week by week, without being asked. Your heart is learning to do the same. Each time you think of your baby, talk to them, or rest a hand on your belly, that inner nest grows a little warmer.

[pause 8s]

[tender] If you'd like, rest a hand on your belly, and imagine welcoming your baby into both spaces. The nest in your home, and the nest in your heart.

[pause 14s]

[warm, reassuring] You don't have to have everything ready. Babies need warmth, and closeness, and love, and you're already preparing all of those.

[pause 10s]

[calm] Let yourself rest here a moment longer, in the calm of the nest you're making.

[pause 10s]

[warm] When you're ready, let your hands rest, and slowly open your eyes.

[pause 4s]

The most important nest you'll give your baby is you.

[music 8s]

---

## Week 28 · Faith-centered

**Title:** A place / *prepared* / with love.
**Description:** Five minutes to reflect on preparing for your baby, and on the God who prepares a place for us.
**Approach:** Jesus' words about preparing a place, a nesting visualization, and prayer over the home you're making.
**Scripture:** John 14:2 (verbatim excerpt: the last sentence).

[music 8s]

[warm, lightly smiling] Around this time, many people feel the urge to get ready. Washing tiny clothes. Setting up a corner of a room. Making a nest.

[pause 4s]

[calm] Find a comfortable position, and let your breath settle. Let your shoulders soften as you breathe out.

[pause 8s]

[reverent] On the night before he died, Jesus comforted his friends by telling them about his Father's house, with room for all of them. And he said:

*I am going to prepare a place for you.*

[pause 10s]

[warm, reflective] There's something deeply loving about preparing a place for someone. It says: I've been thinking of you. I want you to feel at home. Jesus offers that kind of love to each of us.

[pause 8s]

[calm, peaceful] Now imagine the place you're preparing for your baby. It doesn't need to be finished. Just picture the light, the softness, a blanket folded and waiting.

[pause 10s]

Imagine bringing your baby into that space for the first time. The warmth. The quiet. The feeling of welcome.

[pause 10s]

[gentle wonder] Your body has been preparing too, making room, week by week, sheltering your baby until it's time to meet. What a beautiful, God-given kind of preparation.

[pause 8s]

[warm] And your heart is preparing. Every prayer you pray for your baby, every moment you spend imagining them, is part of the place you're making. A home is more than a room. It's a place where someone is known and loved.

[pause 8s]

[tender] If you'd like, rest a hand on your belly.

[pause 6s]

[gentle] Now take a moment to pray over your home, and the place you're making. Ask God to fill it with peace, and love, and joy.

[pause 15s]

[prayerful, sincere] Lord, thank you for preparing a place for me in your love. Bless the home I'm preparing for this little one. Let it be warm with your presence, and full of welcome. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open.

[pause 3s]

A place made ready, with love, for someone dearly wanted.

[music 8s]

---

## Week 29 · Grounded

**Title:** Room / *to* / breathe.
**Description:** Five minutes of comfort for a growing body, finding ease, space, and support.
**Approach:** finding a comfortable position, gentle rib-breathing awareness, and comfort for the third trimester.

[music 8s]

[warm, understanding] As your baby grows, your body is changing shape quickly. Some positions that used to feel comfortable might not anymore. Let's take a few minutes to find some ease.

[pause 4s]

[calm] Try lying on your side, with a pillow between your knees and another under your belly, if you have one. Or sit reclined, well propped up. Take your time getting comfortable.

[pause 10s]

[gentle wonder] Your baby is taking up more room these days, and your organs have been gently shifting to make space. It's an amazing bit of rearranging, happening quietly inside you.

[pause 8s]

[calm] Because of that, you might notice your breath feels a little higher in your chest. Let's give it some room.

Rest one hand on the side of your ribs.

[pause 6s]

As you breathe in, notice your ribs widening gently under your hand, like an umbrella opening.

[pause 8s]

As you breathe out, feel them settle.

[pause 8s]

Let a few breaths come this way. Wide and easy, without forcing anything.

[pause 14s]

[calm, soothing] Now let your breathing return to its natural rhythm, and let the rest of your body soften. Your shoulders. Your jaw. Your hands.

[pause 10s]

Notice any place that feels tight or tired, perhaps your lower back, or your hips. Imagine breathing a little warmth there. Let the pillows and the bed take more of your weight.

[pause 10s]

[tender] If you'd like, move your hand to your belly. Your baby is growing and stretching, making the most of the space you've given them.

[pause 12s]

[warm, reassuring] Your body is adapting beautifully to carry your baby. Being kind to it, with rest, and pillows, and gentle movement, is part of that care.

[pause 8s]

[gentle wonder] Every bit of space your body makes is a gift to your baby. Room to grow. Room to stretch. Room to get ready for the world.

[pause 8s]

[warm] When you're ready, take your time coming back. Move slowly, and open your eyes.

[pause 4s]

Wherever you rest today, may you find a little more room to breathe.

[music 8s]

---

## Week 29 · Faith-centered

**Title:** In the shadow / *of* / your wings.
**Description:** Five minutes of comfort and rest under God's care, imagined as the shelter of wings.
**Approach:** finding comfort in the body, reflecting on the psalmist's image of shelter, and resting there in prayer.
**Scripture:** Psalm 63:7 (verbatim).

[music 8s]

[warm, understanding] As your baby grows, finding a comfortable position can take a little more effort. Let's begin by taking our time with that.

[pause 4s]

[calm] Lie on your side if you can, with a pillow between your knees and another under your belly. Or recline, well supported. Adjust until you feel held.

[pause 10s]

[calm] Let your breath settle. Let your shoulders soften. Let the pillows take your weight.

[pause 6s]

[reverent] David wrote Psalm 63 while he was out in the wilderness. Even there, he remembered God through the night, and wrote:

*For you have been my help. I will rejoice in the shadow of your wings.*

[pause 10s]

[warm, reflective] The shadow of wings. Imagine a mother bird gathering her little ones close, sheltering them beneath her. Warm. Safe. Completely covered.

[pause 8s]

[calm, peaceful] Let yourself rest beneath that shelter now. Let your whole body soften, as if you were tucked in close and warm.

[pause 12s]

[gentle wonder] Notice the shelter you are providing too. Your baby rests within you, surrounded by warmth, cushioned and close. Just as God shelters you, you shelter your little one.

[pause 10s]

[warm] And notice David's words: I will rejoice. Not just rest, but rejoice. There's joy in being sheltered. Joy in being cared for. Let yourself feel a little of that joy now, in this quiet, covered place.

[pause 10s]

[tender] If you'd like, rest a hand on your belly, and enjoy that layered shelter. Your baby, held in you. You, held in God.

[pause 12s]

[gentle] Take a quiet moment to thank God for being your help, and to rest in his care.

[pause 15s]

[prayerful, sincere] Lord, you have been my help. Thank you for sheltering me, and for letting me shelter this little one. Let me rest and rejoice in the shadow of your wings. Amen.

[pause 8s]

[warm] When you're ready, move slowly, and open your eyes.

[pause 3s]

Sheltered, and sheltering, in his care.

[music 8s]

---

## Week 30 · Grounded

**Title:** The / *first* / hello.
**Description:** Five minutes to look forward to welcoming your baby, with warmth and joy.
**Approach:** an open, optional invitation to reflect on welcoming your baby, focusing on love and tenderness rather than any particular scene.

[music 8s]

[warm, tender] Today, let's spend a few minutes with something joyful: looking forward to welcoming your baby.

[pause 4s]

[calm] Find a comfortable position, and let yourself be supported. Let your breath slow down.

[pause 8s]

[calm] Let your body soften. Your shoulders. Your jaw. Your hands. Let your whole body feel warm and easy.

[pause 8s]

[warm, reassuring] If you'd like, imagine a moment of welcoming your baby. You don't need to picture every detail. Simply allow yourself to reflect on the love and tenderness you hope to share.

[pause 10s]

[tender] Perhaps you imagine the warmth of a tiny body held close. Perhaps a small hand, or a sleepy face you've wondered about for months. Or perhaps no picture comes at all, only a feeling. Whatever comes is enough.

[pause 10s]

Let yourself notice the tenderness that rises when you think of your baby. The wish to hold them. To know them. To help them feel at home in the world.

[pause 10s]

[warm] Think of the small, everyday ways you hope to share that love. A gentle voice. A soft song. Warm arms, and a lap to rest in.

[pause 10s]

What would you like your baby to know about how loved they are? Let the words come in your own way, silently or out loud.

[pause 14s]

[gentle wonder] Your voice is one your baby already knows. They've been hearing it for months, from the inside. The love you're imagining has already begun.

[pause 10s]

[tender] Now come back gently to today. If you'd like, rest a hand on your belly. Your baby is right here, growing toward the day you meet, and you're growing toward it too.

[pause 12s]

[warm] Every week brings you a little closer. You can return to this feeling whenever you'd like to feel that joy again.

[pause 6s]

When you're ready, let your eyes open slowly.

[pause 4s]

Hold on to that feeling. You're already on your way to meeting.

[music 8s]

---

## Week 30 · Faith-centered

**Title:** As / *a mother* / comforts.
**Description:** Five minutes to rest in the comfort of God, pictured as a mother's tender love.
**Approach:** reflection on God's motherly comfort in Isaiah, the comfort you hope to give your baby, and receiving comfort yourself.
**Scripture:** Isaiah 66:13 (verbatim excerpt: the first sentence).

[music 8s]

[warm, tender] Picture, for a moment, a mother holding her child close. Rocking gently. Humming softly. Everything about her saying: You're safe. I'm here.

[pause 8s]

[calm] Hold that picture as you find a comfortable position. Let your breath slow down. Let your shoulders soften.

[pause 6s]

[reverent] Through the prophet Isaiah, God spoke these tender words to his people:

*As one whom his mother comforts, so I will comfort you.*

[pause 10s]

[warm, reflective] Of all the ways God could describe his love, here he chooses a mother's comfort. Close. Patient. Tender. Unhurried.

[pause 8s]

Think of what that kind of comfort looks like. A warm embrace. A quiet voice. A hand smoothing hair from a forehead. Staying close until the little one settles. God says: that is how I comfort you.

[pause 10s]

[tender] Soon, you'll be offering that kind of comfort too. If you'd like, imagine a moment of comforting your baby. You don't need to picture every detail. Simply reflect on the love and tenderness you hope to share.

[pause 12s]

[gentle wonder] Your body has been preparing for that all along. Your heart, your arms, your voice. Even now, your baby is learning the sound of you, and the rhythm of your heartbeat.

[pause 8s]

[calm, soothing] Now let yourself be the one comforted. Imagine God's comfort wrapping around you, the way a mother wraps her arms around her child. Let your shoulders soften. Let your whole body rest.

[pause 12s]

[tender] If you'd like, rest a hand on your belly. You, comforted by God. Your baby, comforted by you.

[pause 10s]

[gentle] Take a quiet moment to receive God's comfort, and to thank him for it.

[pause 14s]

[prayerful, sincere] Lord, thank you for comforting me the way a mother comforts her child. Teach me to comfort my baby with that same tender love. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open slowly.

[pause 3s]

Comforted, and ready to comfort, in his love.

[music 8s]

---

## Week 31 · Grounded

**Title:** Like / *a* / wave.
**Description:** Five minutes of breathing with the gentle rise and fall of a wave, a picture many people carry with them into labor.
**Approach:** an ocean visualization paired with the long, slow exhale, introduced as one helpful image among many.

[music 8s]

[warm, unhurried] Imagine you're sitting on warm sand, at the edge of a calm sea. The sun is low and golden. The water is gentle.

[pause 8s]

[calm] Let that picture help you settle. Find a comfortable position, and let your body be supported.

[pause 6s]

Let your breath slow down by itself, as easy as the water.

[pause 8s]

[calm, soothing] Now watch the waves. Each one begins far out, small and quiet. It slowly rises. It reaches its fullest point. And then it eases, spreading softly across the sand, and drawing back into stillness.

[pause 10s]

Rise. Peak. Ease. And then a pause, before the next one begins.

[pause 8s]

[warm] Many people find this a helpful picture for the contractions of labor, sometimes called surges or waves. Each one has a beginning, a middle, and an end. And between them, a time of rest.

[pause 6s]

[calm, clear] Let's practice breathing with an imagined wave. Only if it feels comfortable.

As the wave begins to rise, breathe in naturally.

[pause 5s]

As it reaches its peak and begins to ease, let your breath out long and slow, like the water spreading over the sand.

[pause 8s]

And now, the stillness between. Let your whole body rest.

[pause 10s]

Let's ride one more. The wave rises… breathe in.

[pause 5s]

It peaks and eases… a long, slow breath out.

[pause 8s]

And rest.

[pause 10s]

[gentle wonder] Your body is full of extraordinary rhythms. Your heart beats steadily, supporting the remarkable work of pregnancy. Your breath rises and falls without conscious effort, while your baby develops within you. Take a moment to appreciate the beautiful connection between your body and the little life you're carrying.

[pause 8s]

[tender] If you'd like, rest a hand on your belly, and imagine the gentle sea holding you both.

[pause 12s]

[warm] This picture is yours to keep, and to come back to whenever you like. You'll have other tools too, and there's no single right way to use any of them.

[pause 6s]

When you're ready, let the sea fade gently, and open your eyes.

[pause 4s]

Rising, easing, resting, like the tide.

[music 8s]

---

## Week 31 · Faith-centered

**Title:** Through / *the* / waters.
**Description:** Five minutes to rest in God's presence, with a gentle wave breathing practice for the weeks ahead.
**Approach:** Isaiah's promise of presence, an ocean visualization with slow breathing, and prayer.
**Scripture:** Isaiah 43:2 (verbatim excerpt: the first words of the verse).

[music 8s]

[reverent] Long ago, through the prophet Isaiah, God spoke to his people about the journeys ahead of them. Among his words was this:

*When you pass through the waters, I will be with you,*

[pause 10s]

[warm, unhurried] Let those words settle as you find a comfortable position. Let your breath slow down, and your shoulders soften.

[pause 6s]

[warm, reflective] God didn't describe the waters. He didn't say how deep, or how long. He simply said: I will be with you. His presence is the heart of the promise.

[pause 8s]

[tender] The same God who has been with you through every week of this pregnancy is with you in the weeks ahead, and in the moment you meet your baby.

[pause 6s]

[calm, soothing] Picture a calm sea at sunset. Watch the waves. Each one begins small, rises to its fullest, and then eases back into stillness. Rise. Peak. Ease. And rest.

[pause 10s]

[warm] Many people find waves a helpful picture for the contractions of labor. Each one with a beginning, a middle, and an end, and a time of rest between.

[pause 6s]

[calm, clear] Let's breathe with an imagined wave, only if it feels comfortable. As it rises, breathe in naturally.

[pause 5s]

As it peaks and eases, let your breath out long and slow.

[pause 8s]

And rest. Let your whole body soften in the stillness.

[pause 10s]

One more. The wave rises… breathe in.

[pause 5s]

It eases… a long, slow breath out. And rest.

[pause 10s]

[gentle wonder] Your body has been carrying your baby with such quiet strength. The rhythm of your heart, your breath, your baby's movements, all held within God's care.

[pause 8s]

[tender] If you'd like, rest a hand on your belly.

[pause 6s]

[prayerful, sincere] Lord, thank you that you are with me. In every wave, and in every rest between, let me know your nearness. Be with my baby, and be with me, every step of the way. Amen.

[pause 8s]

[warm] When you're ready, let the sea fade gently, and open your eyes.

[pause 3s]

Wherever your path leads, he goes with you.

[music 8s]

---

## Week 32 · Grounded

**Title:** Soft / *and* / open.
**Description:** Five minutes to practice softening the places that hold tension, and enjoy the ease that follows.
**Approach:** a release practice for the jaw, hands, shoulders and belly, with gratitude for a body that knows how to open.

[music 8s]

[warm, curious] Let's begin with a small experiment. Clench your jaw, just slightly. Notice how your shoulders and hands want to tighten with it.

[pause 5s]

Now let your jaw go loose. Notice what happens in the rest of your body.

[pause 8s]

[warm] Our bodies are connected in surprising ways. When one place softens, others often follow. That's what we'll practice today.

[pause 4s]

[calm] Find a comfortable position, supported and easy.

[pause 6s]

Begin with your face. Let your forehead smooth. Let the space between your eyebrows widen.

[pause 6s]

Your jaw. Let your teeth part slightly, and your lips rest softly together.

[pause 8s]

Your hands. Let them open, palms up, fingers loose and curled like a sleeping baby's.

[pause 8s]

Your shoulders. Let them drop away from your ears. Then let them drop a little more.

[pause 8s]

[tender] Your belly. Allow the muscles to soften, wherever that feels comfortable. There's no need to hold anything in. Take a moment to appreciate the remarkable ways your body has adapted to make room for your growing baby.

[pause 10s]

[calm, soothing] Now, with each slow breath out, imagine all of these places softening together. Face, jaw, hands, shoulders, belly. Soft and open.

[pause 12s]

[warm] You might notice your breath moving more freely now, with a little more room in your belly and chest. Let it come and go, easy and unforced.

[pause 8s]

[warm] Many people find that a soft face and loose hands help the whole body settle, during everyday moments, and during labor too. It's a simple thing you can come back to, anytime.

[pause 6s]

[gentle wonder] Your body has been opening for months. Making room. Stretching. Shifting. Growing around your baby with remarkable flexibility. Softening is something it already knows how to do.

[pause 8s]

[tender] If you'd like, rest a hand on your belly, and thank your body for its gentle strength.

[pause 12s]

[calm] Stay soft for a moment longer. Let your breath move freely through an easy, open body.

[pause 12s]

[warm] When you're ready, let some movement return, and open your eyes.

[pause 4s]

Soft jaw, open hands, easy heart.

[music 8s]

---

## Week 32 · Faith-centered

**Title:** A / *quiet* / soul.
**Description:** Five minutes to quiet your heart before God, like a child resting with its mother.
**Approach:** reflection on Psalm 131, a gentle softening of the body, and resting in God's care.
**Scripture:** Psalm 131:2 (verbatim).

[music 8s]

[reverent] There's a short psalm, only three verses long, that paints one of the most tender pictures in Scripture. David writes:

*Surely I have stilled and quieted my soul, like a weaned child with his mother, like a weaned child is my soul within me.*

[pause 10s]

[warm, unhurried] Let that picture settle as you find a comfortable position.

[pause 6s]

[warm, reflective] A little one resting against their mother. Not asking for anything. Not needing anything. Just content to be close.

[pause 8s]

[warm] That kind of quiet doesn't come from having everything figured out. It comes from trust. From knowing you're held.

[pause 6s]

[calm] Let's quiet the body first, so the soul can follow.

Let your forehead smooth. Let your jaw loosen, and your teeth part slightly.

[pause 6s]

Let your hands open and rest, palms up.

[pause 6s]

Open hands, like a child's, ready to receive rather than hold on.

[pause 5s]

Let your shoulders drop, and then drop a little more.

[pause 6s]

[tender] Allow your belly to soften comfortably. Even in these quiet moments, your body continues its remarkable work. You can appreciate that gift as you rest in God's presence.

[pause 8s]

[calm, soothing] Now let your thoughts grow quiet too. If they wander, gently bring them back, the way a mother gathers a little one back into her arms.

[pause 12s]

[warm] Many people find that a soft face and open hands help the whole body settle, both in everyday moments and in labor. It's a small, gentle practice you can return to, anytime.

[pause 6s]

[gentle wonder] Your body has been opening and making room for months, with a flexibility and strength God built into it. Soon, you'll hold your own little one close. And even now, God holds you close like that.

[pause 10s]

[gentle] Rest in his presence for a moment. There's nothing you need to ask for. Simply be near him.

[pause 15s]

[prayerful, sincere] Lord, quiet my soul like a child resting with its mother. Thank you for holding me close, as I hold this little one within me. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open slowly.

[pause 3s]

A quiet soul, resting close to him.

[music 8s]

---

## Week 33 · Grounded

**Title:** Your / *calm* / place.
**Description:** Five minutes to create a calm place in your mind, and a simple cue to help you find it again.
**Approach:** building a detailed, peaceful place through the senses, then linking it to a small touch you can use anytime.

[music 8s]

[warm, unhurried] Today, you'll create something you can take with you anywhere: a calm place, all your own.

Find a comfortable position, and let your breath slow down.

[pause 8s]

[calm, peaceful] Let a peaceful place come to mind. It might be somewhere you've been. A beach, a garden, a quiet room. Or somewhere completely imagined. Let the first gentle place that appears be enough.

[pause 10s]

[calm] Now step into it with your senses.

What do you see? The colors. The light. The shapes around you.

[pause 8s]

What do you hear? Maybe water, or wind, or birdsong. Or a lovely quiet.

[pause 8s]

What do you feel? Warm sun. A cool breeze. Soft ground beneath you.

[pause 8s]

Is there a scent? Salt air, fresh rain, flowers, warm bread?

[pause 8s]

[warm] Let yourself settle into this place. Notice how your body feels here. Easy. Safe. At home.

[pause 10s]

[calm, clear] Now let's give your calm place a small cue, a way to find it quickly. Gently touch your thumb to the tip of one finger. Keep it there, and keep breathing in your calm place.

[pause 12s]

Let the feeling of this place and the feeling of that touch belong together.

[pause 8s]

Now release your fingers.

[pause 4s]

[warm] Whenever you'd like to return, on a busy day, before sleep, or during labor, you can touch your thumb to your finger, take a slow breath, and let your calm place come back to you. It grows stronger each time you visit.

[pause 8s]

[gentle wonder] Within you, your baby is surrounded by a world of warmth, movement, and familiar rhythms. Your body has created an extraordinary environment for this little life to develop. Take a moment to appreciate that beautiful connection.

[pause 8s]

[tender] If you'd like, rest a hand on your belly, and imagine your baby with you in your calm place.

[pause 12s]

[warm] When you're ready, let your calm place fade gently, and open your eyes.

[pause 4s]

A small reminder of a peaceful place you can return to, whenever you'd like.

[music 8s]

---

## Week 33 · Faith-centered

**Title:** Fullness / *of* / joy.
**Description:** Five minutes walking in God's presence, a place of peace you can return to in any season.
**Approach:** reflection on Psalm 16, a visualization of walking with God, and a simple cue for returning to his presence.
**Scripture:** Psalm 16:11 (verbatim excerpt: the first two sentences).

[music 8s]

[reverent] In Psalm 16, David speaks of the security he finds in God. Near the end, he writes:

*You will show me the path of life. In your presence is fullness of joy.*

[pause 10s]

[warm, unhurried] Let those words settle as you find a comfortable position. Let your breath slow down.

[pause 6s]

[warm] In your presence is fullness of joy. Not a distant place. Not somewhere you have to earn your way into. Simply being near God.

[pause 8s]

[calm, peaceful] Let's imagine that nearness. Picture a peaceful path. Maybe through a meadow, along a shoreline, or beneath tall trees. The light is warm and soft.

[pause 10s]

Imagine walking slowly along that path, and becoming aware that you aren't walking alone. God is with you. Unhurried. Glad to be with you.

[pause 12s]

[tender] Perhaps you share what's on your heart as you walk. Or perhaps you simply walk together in comfortable quiet, the way old friends do.

[pause 10s]

What do you notice here? The light, the air, the sounds around you. Let this be a place of peace.

[pause 10s]

[calm, clear] Now, gently touch your thumb to the tip of one finger, and let that touch remind you of this nearness. Keep breathing, and resting, in his presence.

[pause 12s]

[warm] Whenever you'd like to return, on a busy day, before sleep, or during labor, you can touch your thumb to your finger, breathe slowly, and remember: he is with you.

[pause 8s]

Release your fingers now.

[pause 4s]

[gentle wonder] Your baby, too, is growing in a place of peace, warm and held within you. God's care surrounds you both, in every season.

[pause 8s]

[tender] If you'd like, rest a hand on your belly.

[pause 6s]

[prayerful, sincere] Lord, thank you that in your presence there is fullness of joy. Show me the path of life, and let me walk it with you, one step at a time. Amen.

[pause 8s]

[warm] When you're ready, let the path fade gently, and open your eyes.

[pause 3s]

His presence is always just a breath away.

[music 8s]

---

## Week 34 · Grounded

**Title:** Surrounded / *by* / care.
**Description:** Five minutes to imagine the care and support you'd like around you as you welcome your baby.
**Approach:** a reflective visualization of supportive people, places and comforts, with room for every kind of support.

[music 8s]

[warm, unhurried] As your baby's birthday draws closer, let's take a few minutes to think about care. Not the plans or the paperwork. Just the feeling of being cared for.

[pause 6s]

[calm] Find a comfortable position, and let yourself be supported.

[pause 6s]

Let your breath slow down. Let your shoulders soften.

[pause 8s]

[warm] Support looks different for everyone. A partner, a friend, a family member, a doula, a midwife or doctor, a calm nurse. Some people will have many people beside them. Some, just one or two. Every kind of care counts.

[pause 8s]

And care isn't only for the day itself. It's the friend who brings a meal afterward, the person who lets you sleep, the one who holds your baby while you shower. All of it is part of your circle.

[pause 8s]

[calm, peaceful] Now imagine the kind of care that would help you feel at ease. Not a specific scene. Just the feeling of it.

[pause 8s]

Perhaps it's a calm voice. Perhaps a hand on your shoulder, or someone who knows when to simply be quiet.

[pause 10s]

Perhaps it's a comfort from home. Your own pillow. A favorite song. A soft light.

[pause 10s]

[warm] Notice what matters most to you. These are worth sharing with the people who'll be with you. Some people like to write them down as part of their birth preferences, so everyone can see what helps.

[pause 8s]

[warm, reassuring] And remember the care you give yourself too. Resting. Asking for what you need. Being patient and kind with yourself. You're part of your own circle of care.

[pause 10s]

[gentle wonder] Your baby has been surrounded by care since the very beginning, by you. Your warmth. Your heartbeat. The nourishment your body gives them every moment. Soon, they'll be surrounded by your arms, too.

[pause 8s]

[tender] If you'd like, rest a hand on your belly, and imagine that circle of care around you both.

[pause 14s]

[warm] When you're ready, let your hands rest, and open your eyes.

[pause 4s]

You deserve care and support, too. Let yourself welcome it wherever you find it.

[music 8s]

---

## Week 34 · Faith-centered

**Title:** Held / *up* / by love.
**Description:** Five minutes to thank God for the people who support you, and pray for those who'll be with you.
**Approach:** the story of Aaron and Hur holding up Moses' hands, gratitude for support, and prayer for your birth team.
**Scripture:** Exodus 17:12 (the story retold in Maren's own words, with a verbatim excerpt from the middle of the verse).

[music 8s]

[reverent] There's a story in the book of Exodus about a long, tiring day. Moses needed to keep his hands raised, and as the hours went on, his arms grew heavy. So his friends found him a stone to sit on. And then:

*Aaron and Hur held up his hands, the one on the one side, and the other on the other side.*

[pause 10s]

[warm, unhurried] Let that picture settle as you find a comfortable position. Let your breath slow down.

[pause 6s]

[warm, reflective] Moses didn't have to do it alone. Someone stood on each side, holding him up. That's what good support looks like. Steady. Present. Close.

[pause 8s]

[warm] As your baby's birth draws closer, think of the people who hold you up. A partner, a friend, family, a doula, a midwife or doctor, a nurse, people from your church. Some may be close by, and some may be praying from far away.

[pause 10s]

Bring them to mind, one by one. Thank God for each of them.

[pause 15s]

[warm] Support continues after the birth too. Meals, a helping hand, someone who lets you rest. Thank God for those helpers as well.

[pause 8s]

[calm, peaceful] Now think about the kind of care that helps you feel at ease. A calm voice. A hand to hold. A quiet presence. Prayer. A favorite song. These are worth sharing with the people who'll be with you.

[pause 10s]

[gentle wonder] Your baby has been held up by you since the very beginning. Sheltered, nourished, carried every moment. Soon, you'll hold them in your arms. And through it all, God holds you both.

[pause 8s]

[tender] If you'd like, rest a hand on your belly.

[pause 6s]

[gentle] Now take a moment to pray for those who will be with you. For their wisdom, their kindness, and their care.

[pause 14s]

[prayerful, sincere] Lord, thank you for the people who hold me up. Give them wisdom, gentleness and strength. Surround my baby and me with your care, and with theirs. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open.

[pause 3s]

Held up by love, and by him.

[music 8s]

---

## Week 35 · Grounded

**Title:** Growing / *ready.*
**Description:** Five minutes to gather a few gentle words of encouragement you can carry into the weeks ahead.
**Approach:** relaxation followed by choosing and repeating simple, personal phrases of encouragement.

[music 8s]

[warm, unhurried] Hello. In these final weeks, you've been growing in so many ways. Not only your body, but your heart, your confidence, your readiness. Let's take a few minutes to notice that.

[pause 6s]

[calm] Find a comfortable position, and let yourself be supported. Let your breath slow down by itself.

[pause 8s]

Let your forehead smooth. Your jaw soften. Your hands open.

[pause 8s]

[gentle wonder] Think about the extraordinary changes of these past months. From the earliest stages of development to the little one you're carrying today, so much has taken place within you. Your body has adapted in remarkable ways, and there's something beautiful about taking a moment to appreciate that work.

[pause 8s]

[warm] Today, let's gather a few gentle words you can carry with you. Words you can return to on any day, and when it's time to meet your baby.

[pause 6s]

[calm, reassuring] Listen to each one, and notice whether it feels right for you.

I can take this one moment at a time.

[pause 8s]

I can rest when rest comes.

[pause 8s]

My breath is always with me.

[pause 8s]

I am cared for, and I am not alone.

[pause 8s]

My baby and I are in this together.

[pause 10s]

[warm] Choose one that feels true, or make your own. Something simple. Something that sounds like you.

[pause 12s]

Now say it to yourself, slowly, a few times. Let it settle in with each breath out.

[pause 15s]

[warm] You might write your words down later, or put them somewhere you'll see them often. A note on the mirror. A message on your phone.

[pause 6s]

[warm, reassuring] These words aren't meant to make anything happen. They're simply companions. Something kind to hold on to.

[pause 8s]

[tender] If you'd like, rest a hand on your belly, and share your words with your baby.

[pause 12s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

You are growing ready, one gentle day at a time.

[music 8s]

---

## Week 35 · Faith-centered

**Title:** Grace / *that is* / enough.
**Description:** Five minutes to rest in God's grace, which meets you day by day, and to carry a few words of Scripture with you.
**Approach:** reflection on God's words to Paul, relaxation, and choosing a short phrase of faith to carry into labor.
**Scripture:** 2 Corinthians 12:9 (verbatim excerpt: the words Paul heard from the Lord).

[music 8s]

[reverent] The apostle Paul once asked God, more than once, to take away something that was hard for him. And he received this answer:

*My grace is sufficient for you, for my power is made perfect in weakness.*

[pause 10s]

[warm, unhurried] Let those words settle as you find a comfortable position. Let your breath slow down, and your hands rest open.

[pause 6s]

[warm] Sufficient. Enough. God's grace doesn't wait until you feel strong. It meets you right where you are, with exactly what you need for today.

[pause 8s]

[gentle wonder] Think of all your body has done these past months, the little life it has nurtured, the changes it has carried with grace. And think of how God has met you, day after day. Not all at once, but always enough.

[pause 10s]

[calm] Let your forehead smooth. Your jaw soften. Your shoulders drop.

[pause 8s]

[warm] Let's gather a few words of faith you can carry with you. Short phrases you can return to anytime, and when it's time to meet your baby.

[pause 6s]

[calm, reassuring] Listen to each one, and notice which feels right for you.

His grace is enough for this moment.

[pause 8s]

The Lord is with me.

[pause 8s]

I can rest in him.

[pause 8s]

One breath, one moment, one prayer at a time.

[pause 10s]

Choose one, or one from Scripture that you love. Repeat it slowly to yourself, with each breath out.

[pause 15s]

[warm] You might write your phrase on a card, or save it somewhere you'll see it often.

[pause 6s]

[tender] If you'd like, rest a hand on your belly, and pray your phrase over your baby too.

[pause 10s]

[prayerful, sincere] Lord, thank you that your grace is enough for me. Give me what I need for each day, and for the day I meet my child. Let me lean on you, and rest in you. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open.

[pause 3s]

Enough grace, for today and for every day ahead.

[music 8s]

---

## Week 36 · Grounded

**Title:** Rest / *between* / the waves.
**Description:** Five minutes to practice resting fully after effort, a skill that's just as valuable as the effort itself.
**Approach:** a gentle press-and-release practice that focuses on how completely you can rest afterward.

[music 8s]

[warm, unhurried] There's a part of any rhythm that's easy to overlook: the rest in between. Today, that's what we'll practice.

[pause 4s]

[calm] Find a comfortable position, and let yourself be fully supported.

[pause 6s]

Let your breath slow down. Let your face soften.

[pause 8s]

[warm] In labor, contractions come and go, like waves. And between them, there's time to rest. Many people find that learning to rest fully, even for a short while, makes a real difference.

[pause 6s]

[calm, clear] Let's practice. If it's comfortable, gently press your palms together in front of you. Not hard. Just enough to feel a little effort. Hold it, and keep breathing.

[pause 6s]

And release. Let your hands fall open. Let your shoulders drop.

[pause 4s]

[calm, soothing] Now rest completely. Let your body go heavy. Let your breath slow. Notice how good it feels to let go.

[pause 12s]

Once more. Press your palms gently together. A little effort. Keep breathing.

[pause 6s]

And release.

[pause 4s]

Rest. Every muscle softening. Your jaw, your hands, your belly. Sinking into whatever holds you.

[pause 14s]

You might notice how quickly your body learns. Each time you let go, it gets a little easier.

[pause 6s]

[warm] Notice that the rest can be just as important as the effort. You don't need to think about what comes next. Only this moment of ease.

[pause 8s]

[gentle wonder] Your baby has rhythms of their own, growing and developing within the remarkable environment your body provides. As you rest here, take a moment to appreciate the life you're carrying and the connection you share.

[pause 8s]

[tender] If you'd like, rest a hand on your belly, and enjoy this quiet moment together.

[pause 14s]

[warm, reassuring] You can practice this kind of rest anytime. After a busy morning. Before sleep. And whenever you notice yourself holding on, you can remember: I'm allowed to let go.

[pause 8s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

After every effort, a time to rest.

[music 8s]

---

## Week 36 · Faith-centered

**Title:** My help / *comes* / from the Lord.
**Description:** Five minutes to lift your eyes to God, practice resting between efforts, and receive his help.
**Approach:** Psalm 121, a gentle effort-and-rest practice, and a prayer for help in the days ahead.
**Scripture:** Psalm 121:1–2 (verbatim).

[music 8s]

[reverent] Psalm 121 is one of the songs God's people sang as they traveled up to Jerusalem. It begins:

*I will lift up my eyes to the hills. Where does my help come from? My help comes from the Lord, who made heaven and earth.*

[pause 10s]

[warm, unhurried] Let those words settle as you find a comfortable position, fully supported. Let your breath slow down.

[pause 6s]

[warm] My help comes from the Lord. The same God who made the mountains, the stars, and the little one within you is the one who helps you.

[pause 8s]

And notice that the psalmist doesn't stop at the hills. He looks past them, to the God who made them.

[pause 6s]

[warm] In labor, contractions come and go, like waves, with time to rest between them. Learning to rest fully in those moments can be a real gift. Let's practice.

[pause 6s]

[calm, clear] If it's comfortable, gently press your palms together. A little effort. Keep breathing.

[pause 6s]

And release. Let your hands fall open. Let your shoulders drop.

[pause 4s]

[calm, soothing] Now rest completely. Let your body grow heavy. Breathe slowly. Let God's help be the ground beneath you.

[pause 12s]

Once more. Press gently. Keep breathing.

[pause 6s]

And release. Rest. Every muscle softening.

[pause 14s]

[gentle wonder] Within you, your baby has rhythms of their own. So much of their development takes place beyond what you can see or feel. Take a quiet moment to marvel at this little life, and thank God for the extraordinary work of creation.

[pause 8s]

[tender] If you'd like, rest a hand on your belly.

[pause 6s]

[gentle] Take a quiet moment to lift your eyes to the Lord. Tell him what help you'd like in these final weeks.

[pause 14s]

[prayerful, sincere] Lord, my help comes from you. Thank you for carrying me this far. Teach me to rest in you between every effort, and stay near to me and my baby in the days ahead. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open.

[pause 3s]

Lift your eyes. Your help is near.

[music 8s]

---

## Week 37 · Grounded

**Title:** Open / *hands.*
**Description:** Five minutes to hold your plans gently, with open hands and an open heart.
**Approach:** a hands-open practice for flexibility, gratitude for the journey so far, and gentle readiness.

[music 8s]

[warm, unhurried] Let's begin with your hands. Wherever they're resting, turn them palms up, if that's comfortable.

[pause 6s]

[calm] Find a supported position, and let your breath slow down by itself. Let your shoulders soften.

[pause 8s]

[warm] As your baby's arrival draws near, you may have been thinking about plans. Who will be with you. What might help. The bag by the door. Plans are a lovely way to prepare, and they can be held gently.

[pause 8s]

[calm, clear] Try this. Gently close your hands, as if you were holding something tightly.

[pause 5s]

Notice how that feels. The effort in your fingers, your wrists, your arms.

[pause 5s]

Now let your hands open again, palms up and relaxed.

[pause 8s]

[warm, reassuring] Open hands can still hold things. They just hold them lightly. Your hopes and preferences are still there, resting in your open palms, ready to adapt as the day unfolds.

[pause 8s]

[warm] Think of one hope you have for your baby's birth. Imagine resting it in your open hand. Notice that you can care about it deeply, and still hold it lightly.

[pause 10s]

[gentle wonder] Your body has been adapting for months. Making room, shifting, changing, carrying your baby with remarkable flexibility. There's something remarkable about the ways your body has adapted throughout pregnancy. Take a moment to appreciate that work, and allow yourself to approach the coming days with gentleness and an open heart.

[pause 8s]

[calm] Now let your whole body follow your hands. Open, soft, and easy. Your face. Your jaw. Your shoulders. Your belly.

[pause 11s]

[tender] If you'd like, rest one open hand on your belly. Imagine holding your hopes for your baby the same way. Warmly. Gently. With love.

[pause 12s]

[gentle] You might also think of something you'd like to set down. A pressure to get everything right. An expectation that feels heavy. Imagine it lifting gently off your open palm, like a leaf on a breeze.

[pause 8s]

[warm] Whatever plans you've made, the most important preparation is already happening. You're learning your baby. You're making room in your heart. You're getting ready to meet someone you already love.

[pause 10s]

When you're ready, let your hands rest, and open your eyes.

[pause 4s]

Hold your plans gently, and your baby close.

[music 8s]

---

## Week 37 · Faith-centered

**Title:** A time / *for* / everything.
**Description:** Five minutes to rest in God's timing, holding your plans with open hands.
**Approach:** reflection on Ecclesiastes 3, an open-hands prayer posture, and trusting God with the days ahead.
**Scripture:** Ecclesiastes 3:1 (verbatim).

[music 8s]

[reverent] The book of Ecclesiastes has a beautiful passage about the rhythm of life. It begins:

*For everything there is a season, and a time for every purpose under heaven:*

[pause 10s]

[warm, unhurried] Let those words settle as you find a comfortable position. Let your breath slow down, and your shoulders soften.

[pause 6s]

[warm, reflective] A time for every purpose. A season for everything. Including this season, these final weeks of waiting and preparing, and the day you'll meet your baby.

[pause 8s]

[warm] You may have been making plans. Who will be with you. What might help. The bag by the door. Planning is a lovely way to prepare. And it can be held with open hands, trusting God with the timing and the details.

[pause 8s]

[calm, clear] If it's comfortable, turn your hands palms up, resting open. A posture of trust. Ready to receive, rather than holding on tightly.

[pause 10s]

[gentle] Now offer your plans to God, one by one, in your own words. Your hopes. Your preferences. Your questions. Place each one in your open hands, and lift it to him.

[pause 15s]

[warm, reflective] Ecclesiastes goes on to name many seasons. A time to plant. A time to laugh. A time to embrace. Every one of them is held in God's hands, and so is this one.

[pause 8s]

[calm] Notice how your hands feel, resting open. Light. Unclenched. Ready to receive.

[pause 6s]

[gentle wonder] Your body has been adapting for months, with a flexibility God designed. Making room. Carrying your baby. Growing ready, in its own time.

[pause 8s]

[tender] If you'd like, rest an open hand on your belly. Your baby, too, has a season, and a time to be born, known fully by God.

[pause 12s]

[prayerful, sincere] Lord, thank you for this season. I give you my plans and my hopes for this birth. Help me hold them with open hands, and trust you with the timing. Be near to me and my baby, today and every day. Amen.

[pause 8s]

[warm] When you're ready, let your hands rest, and open your eyes.

[pause 3s]

There is a time for everything, and this time is held by him.

[music 8s]

---

## Week 38 · Grounded

**Title:** Just / *this* / moment.
**Description:** Five minutes to practice meeting each moment as it comes, a gentle way to approach the days ahead.
**Approach:** a present-moment practice that returns, again and again, to this breath and this moment.

[music 8s]

[warm, unhurried] Here's a gentle thought to rest with today: you only ever have to meet one moment at a time.

[pause 6s]

[calm] Find a comfortable position. Let your breath slow down. Let your body be supported.

[pause 8s]

[calm, clear] Let's practice. Notice this breath. Only this one. The air coming in, and going out.

[pause 8s]

Now this moment. The feeling of whatever is beneath you. The sounds in the room.

[pause 8s]

If your mind jumps ahead, to tomorrow, to next week, to the day you meet your baby, that's natural. Gently bring it back. Just this breath. Just this moment.

[pause 12s]

Notice one thing you can hear right now. One thing you can feel. One thing you can see, even behind closed eyes, like light or shadow. Each one is a small anchor to now.

[pause 10s]

[warm] Many people find this a steadying way to approach labor. Not thinking about how long it might be, or what comes next. Just meeting each contraction as it comes, and then the rest that follows. One moment, and then the next.

[pause 8s]

[calm, soothing] Between contractions, this same practice can help you rest. The moment that just passed is over. The next has not yet come. This moment is for resting.

[pause 8s]

[calm] Let's practice once more. This breath.

[pause 6s]

This moment.

[pause 6s]

This feeling of being held by the ground beneath you.

[pause 10s]

[gentle wonder] Your baby lives entirely in the present. Each moment, they grow, and stretch, and rest, without a thought for tomorrow. There's something lovely about joining them there, even for a few minutes.

[pause 8s]

[tender] If you'd like, rest a hand on your belly. This moment, together.

[pause 14s]

[warm, reassuring] You won't always manage to stay in the present, and that's fine. Every time you notice your mind wandering and gently come back, that is the practice. It grows a little stronger each time.

[pause 8s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

One breath, one moment, and then the next.

[music 8s]

---

## Week 38 · Faith-centered

**Title:** My times / *are in* / your hand.
**Description:** Five minutes to entrust each moment, and every moment ahead, to God.
**Approach:** reflection on Psalm 31, a present-moment practice of trust, and prayer.
**Scripture:** Psalm 31:14–15 (verbatim excerpt: from "But I trust in you" to "My times are in your hand").

[music 8s]

[reverent] In Psalm 31, David prays honestly to God, and in the middle of his prayer, he says:

*But I trust in you, Lord. I said, "You are my God." My times are in your hand.*

[pause 10s]

[warm, unhurried] Let those words settle as you find a comfortable position. Let your breath slow down.

[pause 6s]

[warm, reflective] My times are in your hand. Not just the big moments, but each one. This breath. This hour. This day. And the day you'll meet your baby.

[pause 8s]

[warm, reassuring] David wrote these words in a difficult season of his life. And still he could say: my times are in your hand. Trust doesn't need every answer. It simply chooses where to rest.

[pause 8s]

[calm, clear] Let's practice resting in that trust, one moment at a time. Notice this breath. Only this one.

[pause 8s]

Now this moment. Whatever is supporting you. The sounds around you. God's presence, here, now.

[pause 10s]

If your mind jumps ahead, gently bring it back, and pray: My times are in your hand.

[pause 12s]

[warm] Many people find this a steadying way to approach labor. Not looking far ahead, but meeting each contraction as it comes, and then the rest that follows. One moment at a time, held in God's hand.

[pause 8s]

[calm, soothing] Between contractions, you can return to this simple prayer. My times are in your hand. Rest, and breathe, and let the next moment come in its own time.

[pause 8s]

[gentle wonder] Within you, your baby has been developing in remarkable ways, moment by moment. Take a moment to appreciate the little life you're carrying, and the extraordinary work of creation that has brought you to today.

[pause 8s]

[tender] If you'd like, rest a hand on your belly.

[pause 6s]

[gentle] Now take a moment to entrust your times to God. Today. This week. The day your baby arrives. Tell him, in your own words.

[pause 15s]

[prayerful, sincere] Lord, I trust in you. You are my God. My times are in your hand. Help me meet each moment with you, one breath at a time. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open.

[pause 3s]

Every moment ahead is already in his hand.

[music 8s]

---

## Week 39 · Grounded

**Title:** Many / *kinds of* / comfort.
**Description:** Five minutes exploring the many comforts you might reach for, and the freedom to choose what helps.
**Approach:** a gentle tour of comforts (warmth, water, movement, sound, touch, words), held lightly and without promises.

[music 8s]

[warm, unhurried] Today, let's gather a little collection of comforts. Things you might reach for in the days ahead, and when it's time to meet your baby.

[pause 6s]

[calm] Find a comfortable position, and let your breath slow down.

[pause 8s]

[warm] Different things help different people, and what helps can change from hour to hour. So think of these as possibilities. Gentle options, not a checklist.

[pause 6s]

[calm, peaceful] Warmth. A warm shower or bath, a heat pack, a soft blanket. Imagine warmth spreading through your back and hips.

[pause 10s]

Movement. Swaying, rocking, walking, leaning on something steady. Imagine your hips swaying gently, side to side.

[pause 10s]

Sound. Music you love. A soundscape. A familiar voice. Or simple quiet. Notice what feels soothing.

[pause 10s]

Touch. A hand on your back. Firm pressure, or a light stroke. Or perhaps no touch at all. Notice what you'd prefer.

[pause 10s]

Scent. A familiar lotion, a soft fabric that smells of home, fresh air through an open window.

[pause 8s]

Words. A few kind words, like the ones you chose a few weeks ago. Something to come back to.

[pause 10s]

Breath. A long, slow breath out, whenever it feels right.

[pause 10s]

Rest. Stillness between efforts. Lying on your side, eyes closed, letting everything go soft.

[pause 8s]

[warm, reassuring] You won't need all of these, and some may not help you at all. That's completely fine. You can try one thing, let it go, and try another. You get to discover what works for you.

[pause 8s]

[gentle wonder] Your body has been finding its own comforts all along, shifting to ease your back, seeking rest when it's tired. You know more about what you need than you might think.

[pause 8s]

[tender] If you'd like, rest a hand on your belly. Comfort for you, and closeness with your baby.

[pause 12s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

Comfort comes in many forms. You're free to find yours.

[music 8s]

---

## Week 39 · Faith-centered

**Title:** God / *of all* / comfort.
**Description:** Five minutes to rest in the God of all comfort, and gather comforts for the days ahead.
**Approach:** reflection on 2 Corinthians 1, a gentle tour of comforts held lightly, and prayer.
**Scripture:** 2 Corinthians 1:3 (verbatim excerpt: the end of the verse).

[music 8s]

[reverent] At the beginning of his second letter to the Corinthians, Paul praises God with a beautiful name. He calls him:

*the Father of mercies and God of all comfort;*

[pause 10s]

[warm, unhurried] Let those words settle as you find a comfortable position. Let your breath slow down.

[pause 6s]

[warm, reflective] God of all comfort. Not some comfort. All of it. Every warm blanket, every kind hand, every quiet moment of relief comes from his heart for you.

[pause 8s]

[warm] Let's gather a little collection of comforts you might reach for in the days ahead, and when it's time to meet your baby. Different things help different people, and what helps can change. Hold these lightly, as possibilities.

[pause 6s]

[calm, peaceful] Warmth. A warm shower, a heat pack, a soft blanket.

[pause 8s]

Movement. Swaying, rocking, walking, leaning on something steady.

[pause 8s]

Sound. Worship music you love. A familiar voice. Or simple quiet.

[pause 8s]

Touch. A hand on your back, or no touch at all, whichever you prefer.

[pause 8s]

Prayer. A short phrase of Scripture, like the one you chose a few weeks ago.

[pause 8s]

Breath. A long, slow breath out, whenever it feels right.

[pause 8s]

Rest. Stillness between efforts, eyes closed, held in his care.

[pause 8s]

[warm, reassuring] You won't need all of these, and some may not help you at all. That's fine. You're free to try, and let go, and try again.

[pause 8s]

[gentle wonder] Your body has been seeking its own comforts all along, shifting to ease, resting when it's tired. God made it wonderfully responsive.

[pause 8s]

[tender] If you'd like, rest a hand on your belly.

[pause 6s]

[prayerful, sincere] Father of mercies, God of all comfort, thank you for every comfort you give. In the days ahead, surround me with your comfort, and show me what helps. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open.

[pause 3s]

All comfort, from the God who loves you.

[music 8s]

---

## Week 40 · Grounded

**Title:** The / *waiting* / days.
**Description:** Five minutes of patience and ease for the days around your due date, whenever your baby arrives.
**Approach:** reframing the due date as a gentle estimate, settling into patience, and enjoying the present.

[music 8s]

[warm, lightly smiling] You may be hearing a lot of the same question lately. Any news yet? Let's take a few minutes away from all of that.

[pause 6s]

[calm] Find your most comfortable position. Let your breath slow down by itself.

[pause 8s]

[warm, reassuring] A due date is an estimate, not an appointment your baby is expected to keep. As you approach this part of pregnancy, you may be following a plan with your care team for the days ahead. For these few minutes, you can set aside the calendar and simply rest.

[pause 8s]

[calm] Let's set the waiting down for a moment. Imagine placing it on a shelf beside you. It will still be there later. For now, you can rest.

[pause 10s]

[gentle wonder] Some people find these last days bring a surprising burst of energy. Others feel slow and heavy. Both are simply your body, doing its work in its own way. Listen to what it asks for.

[pause 8s]

[calm, soothing] Let your forehead smooth. Your jaw soften. Your shoulders drop. Your hands open.

[pause 10s]

[gentle wonder] Waiting can feel long, but it's also full of quiet work. Your body is continuing its remarkable preparation, and your baby is continuing to grow. So much is happening, even in the stillness.

[pause 8s]

[warm] What would make these waiting days a little sweeter? A walk in fresh air. A favorite meal. An early night. Time with someone you love. A good book. Let one or two ideas come to mind.

[pause 12s]

[calm, peaceful] Imagine a quiet, golden afternoon with nothing on the calendar. Just you, your baby, and time. Every nap, every early night, every slow afternoon is a gift to yourself.

[pause 10s]

[tender] If you'd like, rest a hand on your belly. These are some of the last days your baby will be this close to you, held entirely within. There's something precious in that.

[pause 14s]

[warm] Whatever the coming days hold, you can meet each one as it comes, with patience and a little kindness for yourself.

[pause 8s]

When you're ready, let your eyes open slowly.

[pause 4s]

One day at a time. There's still room for peace in the waiting.

[music 8s]

---

## Week 40 · Faith-centered

**Title:** I wait / *for* / the Lord.
**Description:** Five minutes of patient hope around your due date, waiting with God rather than alone.
**Approach:** reflection on Psalm 130, setting down impatience, and hopeful prayer.
**Scripture:** Psalm 130:5 (verbatim).

[music 8s]

[warm, lightly smiling] You may be hearing the same question often these days. Any news yet? Let's step away from all of that for a few minutes, and rest with God.

[pause 6s]

[calm] Find your most comfortable position. Let your breath slow down by itself.

[pause 6s]

[reverent] In Psalm 130, the psalmist describes what it's like to wait on God:

*I wait for the Lord. My soul waits. I hope in his word.*

[pause 10s]

[warm, reflective] Waiting is woven all through Scripture. Sarah, Hannah, Elizabeth, Mary. Each one waited, in her own way, for a child. Waiting is not empty time. It's time held in God's hands.

[pause 8s]

Think of Hannah, praying year after year at the temple. Or Elizabeth, rejoicing when her son was finally born. Their stories remind us that waiting and joy often belong together.

[pause 8s]

[warm, reassuring] A due date is an estimate, and the days around it may bring plans, appointments, and decisions. You can approach those responsibilities thoughtfully while also giving yourself permission to rest. For these few moments, bring your attention back to God's presence today.

[pause 8s]

[calm, soothing] Let your forehead smooth. Your jaw soften. Your shoulders drop. Let your hands rest open.

[pause 10s]

[warm] Rest these days, if you can. An afternoon nap. An early night. A slow walk in the fresh air. Let each one be a small act of trust.

[pause 8s]

[gentle wonder] Even in the waiting, so much is happening. Your body continues its remarkable preparation. Your baby continues to grow, held within you, in God's care.

[pause 8s]

[tender] If you'd like, rest a hand on your belly, and enjoy these last days of carrying your baby so close.

[pause 12s]

[gentle] Now bring your waiting to God. Your hopes, your impatience, your excitement. Tell him all of it, and let him hold it with you.

[pause 15s]

[prayerful, sincere] Lord, I wait with you. Thank you for the little life I carry and for the remarkable journey of this pregnancy. Give me patience, wisdom for the days ahead, and peace in your presence today. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open.

[pause 3s]

Waiting with hope, and not alone.

[music 8s]

---

## Week 41 · Grounded

**Title:** Slow / *and* / sweet.
**Description:** Five minutes to savor these final days of pregnancy, and the closeness you share with your baby.
**Approach:** a savoring practice of gentle pleasures, gratitude for the journey, and quiet connection.

[music 8s]

[warm, unhurried] Hello. Today is a day for slowing down, and savoring.

Find a comfortable position, wherever your body feels most at ease. Let yourself be supported.

[pause 8s]

[calm] Let your breath slow down by itself. Let your face soften.

[pause 8s]

[warm] These days may feel long, and your body may be asking for more comfort and rest. Wherever you find yourself today, let's take a few minutes to appreciate this moment of pregnancy, without asking it to feel any particular way.

[pause 8s]

[gentle wonder] Think back over the journey. The first moment you knew. The first flutter you felt. The way your body has grown and changed and carried your baby, week after week. All of it, remarkable.

[pause 12s]

[warm] Maybe you'd like to remember these days. A photo of your belly. A note to your baby. A few words in a journal about how it feels right now. Small keepsakes from a once-in-a-lifetime season.

[pause 10s]

[tender] Now notice your baby, here with you. The roundness of your belly. The closeness. A whole person, so near, and almost ready to meet you.

[pause 12s]

[warm] Is there something small you'd like to savor today? A warm bath. A slow cup of tea. Sunlight through a window. A nap in the afternoon. Let one simple pleasure come to mind.

[pause 12s]

Imagine enjoying it fully. No rushing. Nowhere else to be.

[pause 10s]

[gentle wonder] Notice the warmth of your hands. The rise and fall of your breath. The quiet company of your baby. Simple things, and so precious.

[pause 10s]

[calm, soothing] Let your shoulders sink. Let your hands rest. Let this moment be slow, and sweet.

[pause 12s]

[tender] If you'd like, rest a hand on your belly, and say something to your baby. Perhaps thank you for this time together. Or simply, I can't wait to meet you.

[pause 14s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

Savor these days. They're yours, and your baby's.

[music 8s]

---

## Week 41 · Faith-centered

**Title:** Rest, / *and* / wait.
**Description:** Five minutes to rest in God and savor these final days with your baby.
**Approach:** reflection on Psalm 37, gratitude for the journey, and resting patiently in God's care.
**Scripture:** Psalm 37:7 (verbatim excerpt: the first sentence).

[music 8s]

[reverent] In Psalm 37, David offers a simple invitation:

*Rest in the Lord, and wait patiently for him.*

[pause 10s]

[warm, unhurried] Let those words settle as you find a comfortable position, wherever your body feels most at ease. Let your breath slow down.

[pause 6s]

[warm, reflective] Rest, and wait. Not restless watching, but peaceful waiting. Settled in God's care, the way a child rests in a parent's arms.

[pause 8s]

[gentle wonder] Think back over this journey with God. The first moment you knew. The first flutter you felt. The prayers you've prayed. The ways your body has grown and carried your baby, week after week. All of it, held by him.

[pause 12s]

Thank him for anything that comes to mind.

[pause 12s]

[warm] Maybe you'd like to remember these days. A photo of your belly. A prayer written down for your baby to read one day. Small keepsakes from a once-in-a-lifetime season.

[pause 10s]

[tender] Now notice your baby, here with you. The roundness of your belly. The closeness. A whole person, knit together by God, and almost ready to meet you.

[pause 12s]

[warm] Even in these final days, there can be small moments worth appreciating. The warmth of your hand resting on your belly. The quiet connection you share with your little one. Whatever today feels like, you can simply pause and thank God for the remarkable life you're carrying.

[pause 8s]

[gentle wonder] Notice the warmth of your hands. The rise and fall of your breath. The quiet company of your baby. Simple gifts, each one from God.

[pause 10s]

[calm, soothing] Let your shoulders sink. Let your hands rest open. Rest in the Lord.

[pause 12s]

[tender] If you'd like, rest a hand on your belly, and pray a blessing over your baby, in your own words.

[pause 14s]

[prayerful, sincere] Lord, I rest in you, and I wait for you. Thank you for every day of this journey. Bless my baby, and be with us as we prepare to meet. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open.

[pause 3s]

Rest in him. Your waiting is in good hands.

[music 8s]

---

## Week 42 · Grounded

**Title:** Whenever / *you* / arrive.
**Description:** Five minutes to welcome your baby, whenever and however they arrive, with gratitude for the whole journey.
**Approach:** a closing reflection on the journey, an open welcome for the baby, and a gentle blessing.

[music 8s]

[warm, tender] Hello. Wherever you are in these final days, you've come such a long way. Let's take a few minutes to honor that, and to welcome your baby.

[pause 6s]

[calm] Find your most comfortable position, and let yourself be fully supported. Let your breath slow down.

[pause 8s]

[gentle wonder] Think of everything your body has done. From those very first weeks, when so much was happening out of sight, to now. Growing, adapting, sheltering, carrying. A truly extraordinary journey.

[pause 10s]

[warm] And think of everything you've done. The rest you've taken. The questions you've asked. The love you've already given to someone you haven't yet held.

[pause 10s]

[tender] And think of your baby's journey too. From the tiniest beginning to a whole little person, getting ready for the world. What a story you share.

[pause 10s]

[warm, reassuring] There may be plans and decisions surrounding your baby's arrival, and each birth experience is different. For these few moments, simply make room for the love and tenderness you hope to share with your little one.

[pause 8s]

[warm] You may imagine the small moments of getting to know your baby. A familiar voice. A gentle touch. A quiet moment of closeness. You don't need to picture exactly how those moments will unfold.

[pause 8s]

[tender] If you'd like, rest a hand on your belly, and imagine a moment of welcome. You don't need to picture any details. Just the love you hope to share.

[pause 14s]

[warm] If you'd like, offer your baby a simple welcome, silently or out loud. Something like: Whenever you arrive, you are so welcome here.

[pause 14s]

[calm, soothing] Let your shoulders sink. Let your hands rest. Let your whole body be soft and supported.

[pause 12s]

[warm, reassuring] You've practiced so many gentle things along the way. Slowing down. Breathing out. Softening. Finding your calm place. Resting between efforts. They're all with you, ready whenever you need them.

[pause 10s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

Whenever you arrive, little one, you are already so loved.

[music 10s]

---

## Week 42 · Faith-centered

**Title:** This is / *the* / day.
**Description:** Five minutes to rejoice in today, give thanks for the whole journey, and welcome your baby in God's time.
**Approach:** reflection on Psalm 118, thanksgiving for the pregnancy, and a blessing of welcome.
**Scripture:** Psalm 118:24 (verbatim).

[music 8s]

[reverent, joyful] Psalm 118 is a song of thanksgiving, full of joy. In the middle of it, the psalmist says:

*This is the day that the Lord has made. We will rejoice and be glad in it!*

[pause 10s]

[warm, unhurried] Let those words settle as you find your most comfortable position. Let your breath slow down.

[pause 6s]

[warm, reflective] This is the day. Not only the day your baby arrives, but today. This ordinary, waiting, precious day, made by God, and full of his goodness.

[pause 8s]

[gentle wonder] Think of everything God has done through this pregnancy. From the very first weeks, when so much was hidden, to now. Your body growing, adapting, sheltering, carrying. A little life, knit together with care.

[pause 10s]

[tender] Every day of this pregnancy was a day the Lord made. The tired days and the joyful ones. The quiet ones and the busy ones. He was present in every one.

[pause 8s]

[gentle] Take a moment to give thanks. For your body. For your baby. For the people who've walked with you. For every day of this journey.

[pause 15s]

[warm, reassuring] As you prepare to welcome your baby, bring your hopes and the plans ahead into God's presence. Take a moment to appreciate the love you've been growing for this little one, and ask God to guide and care for you both.

[pause 8s]

[warm] Perhaps you imagine a quiet moment of closeness with your baby. A familiar voice, a gentle touch, or simply the tenderness of beginning to know one another. You can bring those hopes to God without needing to picture every detail.

[pause 8s]

[tender] If you'd like, rest a hand on your belly, and offer your baby a welcome. Something like: Whenever you arrive, you are so welcome here.

[pause 14s]

[calm, soothing] Let your shoulders sink. Let your hands rest open. Rest in his care.

[pause 10s]

[prayerful, sincere] Lord, this is the day you have made. Thank you for every day of this journey, and for the gift of this child. I trust you with the day we meet. Let us rejoice together in your goodness. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open.

[pause 3s]

Rejoice in today. Your little one is already so loved.

[music 10s]
