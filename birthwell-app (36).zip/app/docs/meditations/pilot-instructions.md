# Week 6 pilot · Instructions for your Mac

**What this records:** Week 6 Grounded and Week 6 Faith-centered only, in Maren's voice. It costs 4,689 characters, which is 4,689 credits if v4 charges 1 credit per character. The cap is **5,000 credits**.

**Built-in safety:**

- The recorder won't start if your account's listed v4 rate would push the pilot over 5,000 credits. It also won't start if your balance is too low.
- After the first paragraph, it checks what your account was actually charged. If the full pilot would go over 5,000 at that rate, it stops at once.
- Weeks 7–42 are locked. They can't be recorded until you approve the pilot and I unlock them.
- Every finished paragraph is saved. Running a command again never pays for the same paragraph twice.
- Your API key is never shown on screen, printed or saved to a file.

---

## Step 1 · Your ElevenLabs account (in the browser)

1. **Plan:** using the recordings in the app commercially needs a paid plan. The plan recommended for the whole library is **Creator**. If you're not on a paid plan yet, subscribe to Creator before the pilot, so the pilot recordings are covered too.

2. **A new API key just for the meditations.** This keeps it separate from your coaching key, and lets it read your plan and credit rate.
   - In ElevenLabs, open **Developers → API Keys** (it may be under your profile or Settings) and choose **Create API key**.
   - Name it `BirthWell meditations`.
   - If it asks for permissions, allow these four and leave everything else off:
     - **Text to Speech:** access
     - **User:** read (lets the recorder see your plan and credits left)
     - **Models:** read (lets it see v4's credit rate)
     - **Voices:** read (lets it confirm it's using Maren)
   - If it offers a **credit limit** for the key, set it to **5,000**. That's an extra safety net on ElevenLabs' side.
   - Copy the key. Don't paste it anywhere except the Terminal step below: not into chat, email or a file.

---

## Step 2 · Update the app files (Terminal)

Unzip the new `birthwell-app.zip` in Downloads, which gives `~/Downloads/app`. Then:

```
rsync -a --exclude node_modules --exclude src/data/voiceFiles.ts ~/Downloads/app/ ~/birthwell/
cd ~/birthwell
npm install
ffmpeg -version | head -1
```

The last line should print an ffmpeg version, the tool you used to prepare the coaching audio. If it says "command not found", stop and tell me.

You don't need to change your settings file. The recorder uses Maren's voice from your existing `scripts/elevenlabs.config.json`.

---

## Step 3 · Enter your key (hidden)

```
read -rs ELEVENLABS_API_KEY && export ELEVENLABS_API_KEY
```

Paste your new key and press **Return**. Nothing appears on screen; that's expected. The key lasts only while this Terminal window is open.

Never type the key directly into a command such as `export ELEVENLABS_API_KEY=sk_…`. That would save it in your Terminal history.

---

## Step 4 · Free account check (spends nothing)

```
npm run meditations -- --week 6 --check --max-credits 5000
```

It shows:
- your plan and credits left;
- v4's credit rate;
- that the voice is Maren;
- the pilot's cost at that rate, and whether it fits the 5,000 cap.

**Please send me this output before going on.** It doesn't contain your key.

**Stop here and tell me** if any of these happen:
- it says **OVER your cap**;
- your balance is not enough;
- the voice isn't Maren;
- it can't read the model list or your plan. That means the key is missing a permission, and we fix that first.

---

## Step 5 · Dry run (free)

```
npm run meditations -- --week 6 --dry-run
```

It should show **35 requests and 4,689 characters**, and end with "Every request matches the approved scripts word for word."

---

## Step 6 · Record the pilot

Only go on once the check in step 4 says the pilot is within the cap.

```
npm run meditations -- --week 6 --max-credits 5000
```

1. It shows the verified rate and the cost, then asks you to type **yes**.
2. It records 35 paragraphs, one per line, which takes about 5–10 minutes. After the first one, you'll see a **Credit check** line confirming the real charge.
3. When each meditation is finished, it is joined into one file.
4. The last lines show the characters sent and the **credits used, read from your account**. Please send me these lines.

**If it stops partway** (a dropped connection, or the credit check), nothing is lost. Send me the message. Running the same command again picks up where it left off, without paying again for finished paragraphs.

---

## Step 7 · Listen

```
open audio-out/meditations/maren
```

| File | What it is |
|---|---|
| `secular/week-06.m4a` | Week 6 Grounded |
| `faith/week-06.m4a` | Week 6 Faith-centered |
| `….review.md` | The review sheet: every paragraph's start time, tone and pace, with flags. Opens in TextEdit. |

**Please listen for:**

- **Voice:** does Maren sound warm, clear and like herself all the way through, without drifting toward a whisper?
- **Pacing:** slow and natural, never rushed or stretched? The sheet shows each file's length against 4:45–5:30.
- **Pronunciation:** especially "Isaiah" in the Faith-centered one.
- **Continuity:** where one paragraph follows another after a short breath, does it sound like one continuous reading, or like a new take? Note the paragraph numbers.
- **Overall quality:** volume, clarity, and no clicks or artifacts.

Send me your notes by paragraph number. A single paragraph can be redone on its own, at the cost of just its characters.

---

## Step 8 · When you're done

Close the Terminal window, or run:

```
unset ELEVENLABS_API_KEY
```

Batch 1 stays locked until you've approved Maren's voice, pacing, pronunciation, paragraph continuity and overall quality.
