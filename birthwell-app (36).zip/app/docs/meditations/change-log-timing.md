# Timing changes after the Week 6 pilot

**Opening and closing music, all 74 scripts.** At Leah's request, every `[music 8s]` and `[music 10s]` at the start and end of a script is now `[music 6s]`. The spoken words are unchanged. Recordings are unaffected, because silences are built when the files are joined; the Week 6 Grounded pilot can be rebuilt with the new timing at no cost (`npm run meditations -- --week 6 --version grounded --assemble`).

**Length targets.** After hearing the pilot, Leah kept Maren's natural pace and set new targets: Grounded **4:15–5:30**, Faith-centered **4:15–6:00**, each with small exceptions of up to 10 seconds. Faith-centered runs longer because it now follows the Grounded meditation with faith woven in. The recorder and its tests use these targets, estimating length at Maren's measured pace from the pilot.

**Week 6 Faith-centered** was rewritten on the Grounded script with faith woven in, and approved by Leah. The earlier approved version is in `archive/week-06-faith-before-woven.md`, and `drafts/week-06-faith-woven.md` shows where every line comes from. Its pauses were shortened: 6 s → 5 s, the 7 s arrival pauses → 5 s, and 8 s → 6 s after the closing prayer.

## Opening music shortened to 4 seconds (Leah, 24 October 2026)

Every meditation (all 74) now opens with `[music 4s]` instead of `[music 6s]`, so Maren begins sooner. The ending stays at `[music 6s]`. No words changed and nothing needs re-recording: the opening is soundscape only, so finished files are simply re-assembled (`npm run meditations -- --assemble --week 6-20`).
