# Weekly meditations · Weeks 31–36 (approved)

**Status:** editorial direction approved by Leah, with her refinements. Audio not yet recorded; recordings are approved separately. **Faith-centered, weeks 7–42:** rewritten on each week's Grounded script with faith woven in, and approved by Leah after editorial polish and final review; earlier versions are in `archive/faith-before-woven-weeks-07-42.md`. Weeks 24, 25, 33, 34, 39 and 41 are prayer-only (no Scripture passage). Every Faith-centered closing prayer thanks God for the baby, in words tied to that week's theme.

**Narrator at launch:** Maren, for both Grounded and Faith-centered.

**Themes for weeks 31–36** (preparing for labor). Each week gently introduces one supportive practice, while wonder, gratitude and connection with the baby stay at the center:

| Week | Grounded | Faith-centered | Practice introduced |
|---|---|---|---|
| 31 | Like a wave | Through the waters | Breathing with a rising and easing wave |
| 32 | Soft and open | A quiet soul | Softening the jaw, hands and shoulders |
| 33 | Your calm place | Fullness of joy | A calm place to return to, with a simple touch cue |
| 34 | Surrounded by care | Held up by love | Imagining the support you'd like around you |
| 35 | Growing ready | Grace that is enough | Gentle words to carry with you |
| 36 | Rest between the waves | My help comes from the Lord | Resting fully after effort |

Same format as weeks 6–30: `[music]` and `[pause]` markers, tone tags at the start of paragraphs, and Scripture from the World English Bible in italics, with God's name shown as "the Lord", as in most English Bibles. Each **Scripture** line says whether a passage is verbatim or a verbatim excerpt. Only exact Scripture is in italics.

---

## Week 31 · Grounded

**Title:** Like / *a* / wave.
**Description:** Five minutes of breathing with the gentle rise and fall of a wave, a picture many people carry with them into labor.
**Approach:** an ocean visualization paired with the long, slow exhale, introduced as one helpful image among many.

[music 4s]

[warm, unhurried] Imagine you're sitting on warm sand, at the edge of a calm sea. The sun is low and golden. The water is gentle.

[pause 8s]

[calm] Let that picture help you settle. Find a comfortable position, and let your body be supported.

[pause 6s]

Let your breath slow down by itself, as easy as the water.

[pause 8s]

[calm, soothing] Now watch the waves. Each one begins far out, small and quiet. It slowly rises. It reaches its fullest point. And then it eases, spreading softly across the sand, and drawing back into stillness.

[pause 10s]

Rise. Peak. Ease. And then a pause, before the next one begins.

[pause 8s]

[warm] Many people find this a helpful picture for the contractions of labor, sometimes called surges or waves. Each one has a beginning, a middle, and an end. And between them, a time of rest.

[pause 6s]

[calm, clear] Let's practice breathing with an imagined wave. Only if it feels comfortable.

As the wave begins to rise, breathe in naturally.

[pause 5s]

As it reaches its peak and begins to ease, let your breath out long and slow, like the water spreading over the sand.

[pause 8s]

And now, the stillness between. Let your whole body rest.

[pause 10s]

Let's ride one more. The wave rises… breathe in.

[pause 5s]

It peaks and eases… a long, slow breath out.

[pause 8s]

And rest.

[pause 10s]

[gentle wonder] Your body is full of extraordinary rhythms. Your heart beats steadily, supporting the remarkable work of pregnancy. Your breath rises and falls without conscious effort, while your baby develops within you. Take a moment to appreciate the beautiful connection between your body and the little life you're carrying.

[pause 8s]

[tender] If you'd like, rest a hand on your belly, and imagine the gentle sea holding you both.

[pause 12s]

[warm] This picture is yours to keep, and to come back to whenever you like. You'll have other tools too, and there's no single right way to use any of them.

[pause 6s]

When you're ready, let the sea fade gently, and open your eyes.

[pause 4s]

Rising, easing, resting, like the tide.

[music 6s]

---

## Week 31 · Faith-centered

**Title:** Through / *the* / waters.
**Description:** Five minutes to breathe with the rhythm of waves, and remember God's promise to be with you.
**Approach:** the Grounded sea at sunset and breathing with an imagined wave, with God's promise to be with you through the waters.
**Scripture:** Isaiah 43:2 (verbatim excerpt: the first words of the verse).

[music 4s]

[warm, unhurried] Imagine you're sitting on warm sand, at the edge of a calm sea. The sun is low and golden. The water is gentle.

[pause 6s]

[calm] Let that picture help you settle. Find a comfortable position, and let your body be supported.

[pause 5s]

Let your breath slow down by itself, as easy as the water.

[pause 6s]

[reverent] Long ago, through the prophet Isaiah, God spoke to his people about the journeys ahead of them. Among his words was this:

*When you pass through the waters, I will be with you,*

[pause 8s]

[warm, reflective] God didn't describe the waters. He didn't say how deep, or how long. He simply said: I will be with you. His presence is the heart of the promise.

[pause 6s]

[calm, soothing] Now watch the waves. Each one begins far out, small and quiet. It slowly rises. It reaches its fullest point. And then it eases, spreading softly across the sand, and drawing back into stillness.

[pause 8s]

Rise. Peak. Ease. And then a pause, before the next one begins.

[pause 6s]

[warm] Many people find this a helpful picture for the contractions of labor, sometimes called surges or waves. Each one has a beginning, a middle, and an end. And between them, a time of rest.

[pause 5s]

[calm, clear] Let's practice breathing with an imagined wave. Only if it feels comfortable.

As the wave begins to rise, breathe in naturally.

[pause 5s]

As it reaches its peak and begins to ease, let your breath out long and slow, like the water spreading over the sand.

[pause 7s]

And now, the stillness between. Let your whole body rest.

[pause 8s]

Let's ride one more. The wave rises… breathe in.

[pause 5s]

It peaks and eases… a long, slow breath out.

[pause 7s]

And rest.

[pause 8s]

[tender] The same God who has been with you through every week of this pregnancy is with you in the weeks ahead, and in the moment you meet your baby.

[pause 6s]

[warm] This picture is yours to keep, and to come back to whenever you like. You'll have other tools too, and there's no single right way to use any of them.

[pause 5s]

[gentle wonder] Your body is full of extraordinary rhythms. Your heart beats steadily, supporting the remarkable work of pregnancy. Your breath rises and falls without conscious effort, while your baby develops within you. Take a moment to appreciate the beautiful connection between your body and the little life you're carrying.

[pause 6s]

[tender] If you'd like, rest a hand on your belly, and imagine the gentle sea holding you both.

[pause 7s]

[prayerful, sincere] Lord, thank you that you are with me. Thank you for the little one traveling this path with me. In every wave, and in every rest between, let me know your nearness. Be with my baby, and be with me, every step of the way. Amen.

[pause 7s]

[warm] When you're ready, let the sea fade gently, and open your eyes.

[pause 4s]

Wherever your path leads, he goes with you.

[music 6s]

---

## Week 32 · Grounded

**Title:** Soft / *and* / open.
**Description:** Five minutes to practice softening the places that hold tension, and enjoy the ease that follows.
**Approach:** a release practice for the jaw, hands, shoulders and belly, with gratitude for a body that knows how to open.

[music 4s]

[warm, curious] Let's begin with a small experiment. Clench your jaw, just slightly. Notice how your shoulders and hands want to tighten with it.

[pause 5s]

Now let your jaw go loose. Notice what happens in the rest of your body.

[pause 8s]

[warm] Our bodies are connected in surprising ways. When one place softens, others often follow. That's what we'll practice today.

[pause 4s]

[calm] Find a comfortable position, supported and easy.

[pause 6s]

Begin with your face. Let your forehead smooth. Let the space between your eyebrows widen.

[pause 6s]

Your jaw. Let your teeth part slightly, and your lips rest softly together.

[pause 8s]

Your hands. Let them open, palms up, fingers loose and curled like a sleeping baby's.

[pause 8s]

Your shoulders. Let them drop away from your ears. Then let them drop a little more.

[pause 8s]

[tender] Your belly. Allow the muscles to soften, wherever that feels comfortable. There's no need to hold anything in. Take a moment to appreciate the remarkable ways your body has adapted to make room for your growing baby.

[pause 10s]

[calm, soothing] Now, with each slow breath out, imagine all of these places softening together. Face, jaw, hands, shoulders, belly. Soft and open.

[pause 12s]

[warm] You might notice your breath moving more freely now, with a little more room in your belly and chest. Let it come and go, easy and unforced.

[pause 8s]

[warm] Many people find that a soft face and loose hands help the whole body settle, during everyday moments, and during labor too. It's a simple thing you can come back to, anytime.

[pause 6s]

[gentle wonder] Your body has been opening for months. Making room. Stretching. Shifting. Growing around your baby with remarkable flexibility. Softening is something it already knows how to do.

[pause 8s]

[tender] If you'd like, rest a hand on your belly, and thank your body for its gentle strength.

[pause 12s]

[calm] Stay soft for a moment longer. Let your breath move freely through an easy, open body.

[pause 12s]

[warm] When you're ready, let some movement return, and open your eyes.

[pause 4s]

Soft jaw, open hands, easy heart.

[music 6s]

---

## Week 32 · Faith-centered

**Title:** A / *quiet* / soul.
**Description:** Five minutes to soften your body and quiet your soul, like a child resting close.
**Approach:** the Grounded softening of face, jaw, hands, shoulders and belly, with David's picture of a soul quieted like a child resting with its mother.
**Scripture:** Psalm 131:2 (verbatim).

[music 4s]

[warm, curious] Let's begin with a small experiment. Clench your jaw, just slightly. Notice how your shoulders and hands want to tighten with it.

[pause 5s]

Now let your jaw go loose. Notice what happens in the rest of your body.

[pause 6s]

[warm] Our bodies are connected in surprising ways. When one place softens, others often follow. That's what we'll practice today.

[pause 4s]

[calm] Find a comfortable position, supported and easy.

[pause 5s]

[reverent] There's a short psalm, only three verses long, that paints one of the most tender pictures in Scripture. David writes:

*Surely I have stilled and quieted my soul, like a weaned child with his mother, like a weaned child is my soul within me.*

[pause 8s]

[warm, reflective] A little one resting against their mother. Not asking for anything. Not needing anything. Just content to be close.

[pause 6s]

[warm] That kind of quiet doesn't come from having everything figured out. It comes from trust. From knowing you're held.

[pause 5s]

[calm] Begin with your face. Let your forehead smooth. Let the space between your eyebrows widen.

[pause 5s]

Your jaw. Let your teeth part slightly, and your lips rest softly together.

[pause 6s]

Your hands. Let them open, palms up, fingers loose and curled like a sleeping baby's.

[pause 5s]

Ready to receive, rather than hold on.

[pause 5s]

Your shoulders. Let them drop away from your ears. Then let them drop a little more.

[pause 6s]

[tender] Your belly. Allow the muscles to soften, wherever that feels comfortable. There's no need to hold anything in. Take a moment to appreciate the remarkable ways your body has adapted to make room for your growing baby.

[pause 7s]

[calm, soothing] Now, with each slow breath out, imagine all of these places softening together. Face, jaw, hands, shoulders, belly. Soft and open.

[pause 8s]

[warm] Many people find that a soft face and loose hands help the whole body settle, during everyday moments, and during labor too. It's a simple thing you can come back to, anytime.

[pause 5s]

[gentle wonder] Your body has been opening for months. Making room. Stretching. Shifting. Growing around your baby with remarkable flexibility. Softening is something it already knows how to do.

[pause 6s]

[calm] Stay soft for a moment longer. Let your breath move freely through an easy, open body.

[pause 8s]

[gentle] Rest in God's presence for a moment. There's nothing you need to ask for. Simply be near him.

[pause 10s]

[prayerful, sincere] Lord, quiet my soul like a child resting with its mother. Thank you for holding me close, and for the gift of the little one I hold within me. What a miracle that I get to carry them. Amen.

[pause 7s]

[warm] When you're ready, let some movement return, and open your eyes.

[pause 4s]

A quiet soul, resting close to him.

[music 6s]

---

## Week 33 · Grounded

**Title:** Your / *calm* / place.
**Description:** Five minutes to create a calm place in your mind, and a simple cue to help you find it again.
**Approach:** building a detailed, peaceful place through the senses, then linking it to a small touch you can use anytime.

[music 4s]

[warm, unhurried] Today, you'll create something you can take with you anywhere: a calm place, all your own.

Find a comfortable position, and let your breath slow down.

[pause 8s]

[calm, peaceful] Let a peaceful place come to mind. It might be somewhere you've been. A beach, a garden, a quiet room. Or somewhere completely imagined. Let the first gentle place that appears be enough.

[pause 10s]

[calm] Now step into it with your senses.

What do you see? The colors. The light. The shapes around you.

[pause 8s]

What do you hear? Maybe water, or wind, or birdsong. Or a lovely quiet.

[pause 8s]

What do you feel? Warm sun. A cool breeze. Soft ground beneath you.

[pause 8s]

Is there a scent? Salt air, fresh rain, flowers, warm bread?

[pause 8s]

[warm] Let yourself settle into this place. Notice how your body feels here. Easy. Safe. At home.

[pause 10s]

[calm, clear] Now let's give your calm place a small cue, a way to find it quickly. Gently touch your thumb to the tip of one finger. Keep it there, and keep breathing in your calm place.

[pause 12s]

Let the feeling of this place and the feeling of that touch belong together.

[pause 8s]

Now release your fingers.

[pause 4s]

[warm] Whenever you'd like to return, on a busy day, before sleep, or during labor, you can touch your thumb to your finger, take a slow breath, and let your calm place come back to you. It grows stronger each time you visit.

[pause 8s]

[gentle wonder] Within you, your baby is surrounded by a world of warmth, movement, and familiar rhythms. Your body has created an extraordinary environment for this little life to develop. Take a moment to appreciate that beautiful connection.

[pause 8s]

[tender] If you'd like, rest a hand on your belly, and imagine your baby with you in your calm place.

[pause 12s]

[warm] When you're ready, let your calm place fade gently, and open your eyes.

[pause 4s]

A small reminder of a peaceful place you can return to, whenever you'd like.

[music 6s]

---

## Week 33 · Faith-centered

**Title:** Fullness / *of* / joy.
**Description:** Five minutes to create a calm place, and know God's presence there.
**Approach:** the Grounded calm place explored through the senses, with God present there with you, and a simple touch cue to return to it.
**Scripture:** none; prayer only.

[music 4s]

[warm, unhurried] Today, you'll create something you can take with you anywhere: a calm place, all your own.

Find a comfortable position, and let your breath slow down.

[pause 6s]

[calm, peaceful] Let a peaceful place come to mind. It might be somewhere you've been. A beach, a garden, a quiet room. Or somewhere completely imagined. Let the first gentle place that appears be enough.

[pause 7s]

[calm] Now step into it with your senses.

What do you see? The colors. The light. The shapes around you.

[pause 6s]

What do you hear? Maybe water, or wind, or birdsong. Or a lovely quiet.

[pause 6s]

What do you feel? Warm sun. A cool breeze. Soft ground beneath you.

[pause 6s]

Is there a scent? Salt air, fresh rain, flowers, warm bread?

[pause 6s]

[warm] Let yourself settle into this place. Notice how your body feels here. Easy. Safe. At home.

[pause 6s]

[tender] And notice that you aren't here alone. God is with you. Unhurried. Glad to be with you.

[pause 9s]

[calm, clear] Now let's give your calm place a small cue, a way to find it quickly. Gently touch your thumb to the tip of one finger. Keep it there, and keep breathing in your calm place.

[pause 9s]

Let the feeling of this place and the feeling of that touch belong together.

[pause 6s]

Now release your fingers.

[pause 4s]

[warm] Whenever you'd like to return, on a busy day, before sleep, or during labor, you can touch your thumb to your finger, breathe slowly, and remember: he is with you.

[pause 6s]

[gentle wonder] Within you, your baby is surrounded by a world of warmth, movement, and familiar rhythms. Your body has created an extraordinary environment for this little life to develop. Take a moment to appreciate that beautiful connection.

[pause 6s]

[tender] If you'd like, rest a hand on your belly, and imagine your baby with you in your calm place.

[pause 8s]

[prayerful, sincere] Lord, thank you that in your presence there is fullness of joy. Thank you for the little one with me in this quiet place. Show me the path of life, and let me walk it with you, one step at a time. Amen.

[pause 7s]

[warm] When you're ready, let your calm place fade gently, and open your eyes.

[pause 4s]

His presence is always just a breath away.

[music 6s]

---

## Week 34 · Grounded

**Title:** Surrounded / *by* / care.
**Description:** Five minutes to imagine the care and support you'd like around you as you welcome your baby.
**Approach:** a reflective visualization of supportive people, places and comforts, with room for every kind of support.

[music 4s]

[warm, unhurried] As your baby's birthday draws closer, let's take a few minutes to think about care. Not the plans or the paperwork. Just the feeling of being cared for.

[pause 6s]

[calm] Find a comfortable position, and let yourself be supported.

[pause 6s]

Let your breath slow down. Let your shoulders soften.

[pause 8s]

[warm] Support looks different for everyone. A partner, a friend, a family member, a doula, a midwife or doctor, a calm nurse. Some people will have many people beside them. Some, just one or two. Every kind of care counts.

[pause 8s]

And care isn't only for the day itself. It's the friend who brings a meal afterward, the person who lets you sleep, the one who holds your baby while you shower. All of it is part of your circle.

[pause 8s]

[calm, peaceful] Now imagine the kind of care that would help you feel at ease. Not a specific scene. Just the feeling of it.

[pause 8s]

Perhaps it's a calm voice. Perhaps a hand on your shoulder, or someone who knows when to simply be quiet.

[pause 10s]

Perhaps it's a comfort from home. Your own pillow. A favorite song. A soft light.

[pause 10s]

[warm] Notice what matters most to you. These are worth sharing with the people who'll be with you. Some people like to write them down as part of their birth preferences, so everyone can see what helps.

[pause 8s]

[warm, reassuring] And remember the care you give yourself too. Resting. Asking for what you need. Being patient and kind with yourself. You're part of your own circle of care.

[pause 10s]

[gentle wonder] Your baby has been surrounded by care since the very beginning, by you. Your warmth. Your heartbeat. The nourishment your body gives them every moment. Soon, they'll be surrounded by your arms, too.

[pause 8s]

[tender] If you'd like, rest a hand on your belly, and imagine that circle of care around you both.

[pause 14s]

[warm] When you're ready, let your hands rest, and open your eyes.

[pause 4s]

You deserve care and support, too. Let yourself welcome it wherever you find it.

[music 6s]

---

## Week 34 · Faith-centered

**Title:** Held / *up* / by love.
**Description:** Five minutes to notice the people who hold you up, and pray for them.
**Approach:** the Grounded circle of care around you and your baby, with thanks to God for your helpers, and prayer for those who'll be with you.
**Scripture:** none; prayer only.

[music 4s]

[warm, unhurried] As your baby's birthday draws closer, let's take a few minutes to think about care. Not the plans or the paperwork. Just the feeling of being cared for.

[pause 5s]

[calm] Find a comfortable position, and let yourself be supported.

[pause 5s]

Let your breath slow down. Let your shoulders soften.

[pause 6s]

[warm] Support looks different for everyone. A partner, a friend, a family member, a doula, a midwife or doctor, a calm nurse. Some people will have many people beside them. Some, just one or two. Every kind of care counts.

[pause 6s]

Bring them to mind, one by one. Thank God for each of them.

[pause 10s]

[calm, peaceful] Now imagine the kind of care that would help you feel at ease. Not a specific scene. Just the feeling of it.

[pause 6s]

Perhaps it's a calm voice. Perhaps a hand on your shoulder, or someone who knows when to simply be quiet.

[pause 7s]

Perhaps it's a comfort from home. Your own pillow. A favorite song. A soft light.

[pause 7s]

[warm] Notice what matters most to you. These are worth sharing with the people who'll be with you. Some people like to write them down as part of their birth preferences, so everyone can see what helps.

[pause 6s]

[warm, reassuring] And remember the care you give yourself too. Resting. Asking for what you need. Being patient and kind with yourself. You're part of your own circle of care.

[pause 6s]

[gentle wonder] Your baby has been surrounded by care since the very beginning, by you. Your warmth. Your heartbeat. The nourishment your body gives them every moment. Soon, they'll be surrounded by your arms, too. And through it all, God holds you both.

[pause 6s]

[tender] If you'd like, rest a hand on your belly, and imagine that circle of care around you.

[pause 7s]

[gentle] Now take a moment to pray for those who will be with you. For their wisdom, their kindness, and their care.

[pause 10s]

[prayerful, sincere] Lord, thank you for the people who hold me up, and for the little one at the center of all this care. Give them wisdom, gentleness and strength. Surround my baby and me with your care, and with theirs. Amen.

[pause 7s]

[warm] When you're ready, let your hands rest, and open your eyes.

[pause 4s]

You deserve care and support, too. Held up by love, and by him.

[music 6s]

---

## Week 35 · Grounded

**Title:** Growing / *ready.*
**Description:** Five minutes to gather a few gentle words of encouragement you can carry into the weeks ahead.
**Approach:** relaxation followed by choosing and repeating simple, personal phrases of encouragement.

[music 4s]

[warm, unhurried] Hello. In these final weeks, you've been growing in so many ways. Not only your body, but your heart, your confidence, your readiness. Let's take a few minutes to notice that.

[pause 6s]

[calm] Find a comfortable position, and let yourself be supported. Let your breath slow down by itself.

[pause 8s]

Let your forehead smooth. Your jaw soften. Your hands open.

[pause 8s]

[gentle wonder] Think about the extraordinary changes of these past months. From the earliest stages of development to the little one you're carrying today, so much has taken place within you. Your body has adapted in remarkable ways, and there's something beautiful about taking a moment to appreciate that work.

[pause 8s]

[warm] Today, let's gather a few gentle words you can carry with you. Words you can return to on any day, and when it's time to meet your baby.

[pause 6s]

[calm, reassuring] Listen to each one, and notice whether it feels right for you.

I can take this one moment at a time.

[pause 8s]

I can rest when rest comes.

[pause 8s]

My breath is always with me.

[pause 8s]

I am cared for, and I am not alone.

[pause 8s]

My baby and I are in this together.

[pause 10s]

[warm] Choose one that feels true, or make your own. Something simple. Something that sounds like you.

[pause 12s]

Now say it to yourself, slowly, a few times. Let it settle in with each breath out.

[pause 15s]

[warm] You might write your words down later, or put them somewhere you'll see them often. A note on the mirror. A message on your phone.

[pause 6s]

[warm, reassuring] These words aren't meant to make anything happen. They're simply companions. Something kind to hold on to.

[pause 8s]

[tender] If you'd like, rest a hand on your belly, and share your words with your baby.

[pause 12s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

You are growing ready, one gentle day at a time.

[music 6s]

---

## Week 35 · Faith-centered

**Title:** Grace / *that is* / enough.
**Description:** Five minutes to gather a few words of faith to carry with you.
**Approach:** the Grounded gathering of gentle words to return to, with God's answer to Paul, "My grace is sufficient for you," and short phrases of faith to pray over yourself and your baby.
**Scripture:** 2 Corinthians 12:9 (verbatim excerpt: the words Paul heard from the Lord).

[music 4s]

[warm, unhurried] Hello. In these final weeks, you've been growing in so many ways. Not only your body, but your heart, your confidence, your readiness. Let's take a few minutes to notice that.

[pause 5s]

[calm] Find a comfortable position, and let yourself be supported. Let your breath slow down by itself.

[pause 6s]

Let your forehead smooth. Your jaw soften. Your hands open.

[pause 6s]

[reverent] The apostle Paul once asked God, more than once, to take away something that was hard for him. And he received this answer:

*My grace is sufficient for you, for my power is made perfect in weakness.*

[pause 8s]

[warm] Sufficient. Enough. God's grace doesn't wait until you feel strong. It meets you right where you are, with exactly what you need for today.

[pause 6s]

[gentle wonder] Think about the extraordinary changes of these past months. From the earliest stages of development to the little one you're carrying today, so much has taken place within you. Your body has adapted in remarkable ways, with a wisdom God placed within it, and there's something beautiful about taking a moment to appreciate that work.

[pause 6s]

[warm] Today, let's gather a few gentle words you can carry with you. Words you can return to on any day, and when it's time to meet your baby.

[pause 5s]

[calm, reassuring] Listen to each one, and notice whether it feels right for you.

I can take this one moment at a time.

[pause 6s]

His grace is enough for this moment.

[pause 6s]

The Lord is with me.

[pause 6s]

I can rest in him.

[pause 6s]

My baby and I are in this together.

[pause 7s]

Choose one, or one from Scripture that you love. Repeat it slowly to yourself, with each breath out.

[pause 12s]

[warm] You might write your words down later, or put them somewhere you'll see them often. A note on the mirror. A message on your phone.

[pause 5s]

[warm, reassuring] These words aren't meant to make anything happen. They're simply companions. Something kind to hold on to.

[pause 6s]

[tender] If you'd like, rest a hand on your belly, and pray your words over your baby too.

[pause 8s]

[prayerful, sincere] Lord, thank you that your grace is enough for me. Thank you for this child, a gift of your grace. Give me what I need for each day, and for the day I meet my child. Let me lean on you, and rest in you. Amen.

[pause 7s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

Enough grace, for today and for every day ahead.

[music 6s]

---

## Week 36 · Grounded

**Title:** Rest / *between* / the waves.
**Description:** Five minutes to practice resting fully after effort, a skill that's just as valuable as the effort itself.
**Approach:** a gentle press-and-release practice that focuses on how completely you can rest afterward.

[music 4s]

[warm, unhurried] There's a part of any rhythm that's easy to overlook: the rest in between. Today, that's what we'll practice.

[pause 4s]

[calm] Find a comfortable position, and let yourself be fully supported.

[pause 6s]

Let your breath slow down. Let your face soften.

[pause 8s]

[warm] In labor, contractions come and go, like waves. And between them, there's time to rest. Many people find that learning to rest fully, even for a short while, makes a real difference.

[pause 6s]

[calm, clear] Let's practice. If it's comfortable, gently press your palms together in front of you. Not hard. Just enough to feel a little effort. Hold it, and keep breathing.

[pause 6s]

And release. Let your hands fall open. Let your shoulders drop.

[pause 4s]

[calm, soothing] Now rest completely. Let your body go heavy. Let your breath slow. Notice how good it feels to let go.

[pause 12s]

Once more. Press your palms gently together. A little effort. Keep breathing.

[pause 6s]

And release.

[pause 4s]

Rest. Every muscle softening. Your jaw, your hands, your belly. Sinking into whatever holds you.

[pause 14s]

You might notice how quickly your body learns. Each time you let go, it gets a little easier.

[pause 6s]

[warm] Notice that the rest can be just as important as the effort. You don't need to think about what comes next. Only this moment of ease.

[pause 8s]

[gentle wonder] Your baby has rhythms of their own, growing and developing within the remarkable environment your body provides. As you rest here, take a moment to appreciate the life you're carrying and the connection you share.

[pause 8s]

[tender] If you'd like, rest a hand on your belly, and enjoy this quiet moment together.

[pause 14s]

[warm, reassuring] You can practice this kind of rest anytime. After a busy morning. Before sleep. And whenever you notice yourself holding on, you can remember: I'm allowed to let go.

[pause 8s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

After every effort, a time to rest.

[music 6s]

---

## Week 36 · Faith-centered

**Title:** My help / *comes* / from the Lord.
**Description:** Five minutes to practice resting between efforts, with your eyes lifted to the Lord.
**Approach:** the Grounded practice of gentle effort and full release, with Psalm 121's reminder that our help comes from the Lord, and a prayer for help in the final weeks.
**Scripture:** Psalm 121:1–2 (verbatim).

[music 4s]

[warm, unhurried] There's a part of any rhythm that's easy to overlook: the rest in between. Today, that's what we'll practice.

[pause 4s]

[calm] Find a comfortable position, and let yourself be fully supported.

[pause 5s]

Let your breath slow down. Let your face soften.

[pause 6s]

[reverent] Psalm 121 is one of the songs God's people sang as they traveled up to Jerusalem. It begins:

*I will lift up my eyes to the hills. Where does my help come from? My help comes from the Lord, who made heaven and earth.*

[pause 8s]

[warm] My help comes from the Lord. The same God who made the mountains, the stars, and the little one within you is the one who helps you.

[pause 6s]

In labor, contractions come and go, like waves. And between them, there's time to rest. Many people find that learning to rest fully, even for a short while, makes a real difference.

[pause 5s]

[calm, clear] Let's practice. If it's comfortable, gently press your palms together in front of you. Not hard. Just enough to feel a little effort. Hold it, and keep breathing.

[pause 6s]

And release. Let your hands fall open. Let your shoulders drop.

[pause 4s]

[calm, soothing] Now rest completely. Let your body go heavy. Let your breath slow. Notice how good it feels to let go.

[pause 10s]

Once more. Press your palms gently together. A little effort. Keep breathing.

[pause 6s]

And release.

[pause 4s]

Rest. Every muscle softening. Your jaw, your hands, your belly. Sinking into whatever holds you.

[pause 10s]

You might notice how quickly your body learns. Each time you let go, it gets a little easier.

[pause 5s]

[warm, reassuring] You can practice this kind of rest anytime. After a busy morning. Before sleep. And whenever you notice yourself holding on, you can remember: I'm allowed to let go.

[pause 6s]

[gentle wonder] Your baby has rhythms of their own, growing and developing within the remarkable environment your body provides. As you rest here, take a moment to appreciate the life you're carrying and the connection you share.

[pause 6s]

[tender] If you'd like, rest a hand on your belly, and enjoy this quiet moment together.

[pause 8s]

[gentle] Take a quiet moment to lift your eyes to the Lord. Tell him what help you'd like in these final weeks.

[pause 10s]

[prayerful, sincere] Lord, my help comes from you. Thank you for carrying me this far, as I carry this little one. Teach me to rest in you between every effort, and stay near to me and my baby in the days ahead. Amen.

[pause 7s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

Lift your eyes. Your help is near.

[music 6s]
