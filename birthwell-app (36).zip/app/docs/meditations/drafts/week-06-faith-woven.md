# Week 6 · Faith-centered, woven from Grounded (draft for Leah)

**Status:** approved by Leah and moved into `weeks-06-09.md`. The earlier approved version is kept in `archive/week-06-faith-before-woven.md`. Pauses were later shortened (6 s → 5 s, and 8 s → 6 s after the closing prayer), and the opening and closing music to 6 s.

**The idea:** the Faith-centered meditation follows the Grounded one: the same opening, the same arrival through the senses, the same hand on the belly and the same close. Faith is woven in at natural moments rather than being a separate meditation.

**How to read it:**
- Every line is either from the approved **Grounded** script or the approved **Faith-centered** script. Only three short joining phrases are new, listed at the end.
- The Scripture is unchanged: Isaiah 43:1 (verbatim excerpt) and Psalm 139:13 (verbatim), both World English Bible.

---

## Week 6 · Faith-centered

**Title:** Known / *before* / the beginning.
**Description:** Five quiet minutes to rest in being known and loved by God, right where you are.
**Approach:** the Grounded arrival through the senses, with God's call by name, the psalmist's words over the hand on the belly, and a moment of personal prayer before the close.
**Scripture:** Isaiah 43:1 (verbatim excerpt: the words God speaks to Israel, from the second half of the verse); Psalm 139:13 (verbatim).

[music 6s]

[warm, unhurried] Hello. Before anything else, just notice that you've stopped. Whatever came before this moment, and whatever comes after, can wait a few minutes.

Settle into a position that feels easy. Sitting, lying down, leaning back against something soft. There's nothing to get right here.

[pause 4s]

[calm] You might let your eyes close, or let your gaze rest somewhere gentle.

[pause 4s]

There's no need to change anything about your breathing. Just notice your next breath as it comes… and as it goes.

[pause 5s]

Now let's arrive, one sense at a time.

Notice the sounds around you. Some near, some farther away. You don't need to name them. Just let them be part of the room.

[pause 5s]

Notice where your body is being held. The weight of your legs. Your back. Your head. Let whatever is beneath you take a little more of you.

[pause 5s]

Notice the air on your skin. Warm or cool. Still, or gently moving.

[pause 4s]

You're here. And God is here with you.

[pause 5s]

[reverent] Through the prophet Isaiah, God spoke these words to his people Israel, reminding them that they belonged to him:

*Don't be afraid, for I have redeemed you. I have called you by your name. You are mine.*

[pause 7s]

[warm, reflective] Whatever today holds, you are not a stranger to God.

[pause 5s]

[gentle wonder] There's something extraordinary about these earliest weeks. Cells are multiplying and beginning to take on different roles, while your body adapts in ways you may not even notice. You don't need to direct any of that work. You may be astonished by it, or still be taking in the news. Either response belongs here, and you can bring it to God just as it is.

[pause 5s]

[warm, gentle wonder] Every pregnancy begins with its own mix of feelings. Whatever yours may be today, give yourself permission to simply be present. Take a moment to appreciate the remarkable changes taking place within you, and the little life at the heart of it all.

[pause 5s]

[warm] If it feels right, rest one hand low on your belly, and the other over your heart.

[pause 4s]

[reverent] The psalmist prayed:

*For you formed my inmost being. You knit me together in my mother's womb.*

[pause 7s]

[warm] Just notice the warmth of your own hands as you breathe.

[pause 5s]

You don't need to have this figured out. Not the plans, not the feelings, not the months ahead. You don't have to hold all of it by yourself.

[pause 5s]

[calm] Let your shoulders soften as you breathe out. Let your jaw loosen.

[pause 5s]

[gentle] Take a quiet moment to talk with God about this new beginning, in words or simply in stillness. He already knows what you're feeling.

[pause 10s]

[prayerful, sincere] Lord, thank you that you know me by name. Thank you for this blessing I get to hold within me, and for all the tiny miracles that had to happen for this little life to begin. Every moment I carry this little one is precious, and I place this little life in your hands. I don't know everything that's ahead, but I know I'm not alone in it. Help me rest in your love today. Amen.

[pause 6s]

[warm] When you're ready, let a little movement come back. Your fingers. Your toes. Notice the light around you.

[pause 4s]

You arrived, and that was enough. Go into your day knowing you are known, and you are loved.

[music 6s]

---

## Where each part comes from

| Part | Source |
|---|---|
| Opening through "You're here." | Grounded, word for word |
| "And God is here with you." | **New** |
| Isaiah 43:1 and its introduction | Faith-centered, word for word |
| "Whatever today holds, you are not a stranger to God." | Faith-centered, word for word |
| "There's something extraordinary… Either response belongs here," | Grounded, word for word |
| "…and you can bring it to God just as it is." | **New** |
| "Every pregnancy begins with its own mix of feelings…" | Grounded, word for word (kept at Leah's request) |
| Hand on belly | Grounded, word for word |
| "The psalmist prayed:" and Psalm 139:13 | Faith-centered, word for word |
| "Just notice the warmth of your own hands as you breathe." | Grounded, shortened: "You don't have to feel anything in particular." and "and the small movement beneath them" are left out; no words added |
| "You don't need to have this figured out… the months ahead." | Grounded, word for word |
| "You don't have to hold all of it by yourself." | Faith-centered, word for word (replaces Grounded's "Right now there is only this breath, and the one after it.") |
| Shoulders and jaw | Grounded, word for word |
| "Take a quiet moment to talk with God…" and the closing prayer | Faith-centered, word for word |
| "When you're ready… Notice the light around you." | Grounded, word for word |
| "You arrived, and that was enough." | Grounded, word for word |
| "Go into your day knowing you are known, and you are loved." | Faith-centered, word for word (replaces Grounded's "You can return to this quiet whenever you need it.") |

**Left out from the approved Grounded script:**
- "Let your hands simply rest… Just be here, as you are." (the stillness is now the moment of personal prayer)

**Left out from the approved Faith-centered script:**
- the "set apart" welcome
- "Those words were first spoken to a whole people… By name." and "Let your own name settle quietly in your mind." (left out to stay near 5 minutes)
- the mid-meditation gratitude prayer ("Lord, thank you for the wonder of this new beginning…")
- "The God who saw you before anyone else did…"
- the closing "gently open your eyes"

**The three new phrases:**
1. "And God is here with you."
2. "…and you can bring it to God just as it is."
3. "Go into your day knowing you are known, and you are loved." This one isn't actually new: it's the approved Faith-centered closing line, joined onto Grounded's "You arrived, and that was enough."
