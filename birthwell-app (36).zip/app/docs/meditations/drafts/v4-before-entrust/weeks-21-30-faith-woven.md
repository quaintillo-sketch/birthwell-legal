# Weeks 21–30 · Faith-centered, woven from Grounded (draft for Leah)

**Status:** draft for Leah's review. The approved scripts are unchanged and nothing is recorded.

**How these are built:** like Week 6, each Faith-centered meditation follows its Grounded partner: its opening, its body or imagery work, and its close. Faith is woven in with the approved Faith-centered Scripture, reflections and prayers. Titles, descriptions and Scripture are unchanged.

---

## Week 21 · Faith-centered

**Title:** Quietness / *and* / confidence.
**Description:** Five minutes to rest deeply and let strength grow in quietness.
**Approach:** the Grounded path down into a peaceful garden, with God's words through Isaiah about quietness and confidence, and a silent prayer of rest.
**Scripture:** Isaiah 30:15 (verbatim excerpt: the second sentence of God's words).

[music 6s]

[warm, unhurried] Hi. This is a time for going a little deeper into rest than usual.

Find a position where your whole body feels supported. Lying on your side, or reclining with pillows behind you. Let every part of you be held.

[pause 5s]

[calm] Notice your next breath arrive, and let it go. Nothing to change. Just letting it be easy.

[pause 5s]

[reverent] Through the prophet Isaiah, God spoke to his people about where real strength is found. Among his words is this line:

*Your strength will be in quietness and in confidence.*

[pause 8s]

[warm, reflective] Quietness and confidence. Not hurry. Not effort. Not trying harder.

[pause 5s]

[calm, soothing] Imagine you're standing at the top of a gentle path. It winds softly downward through tall grass, toward a garden you can't quite see yet. The air is warm. The light is golden.

[pause 5s]

We'll walk down slowly together. With each step, you'll let go a little more.

[pause 4s]

The first step. Let your forehead smooth and your eyes grow heavy.

[pause 5s]

The next step. Your jaw loosens. Your tongue rests.

[pause 5s]

Another step. Your shoulders slide down, away from your ears.

[pause 5s]

Another. Your arms grow warm and heavy, all the way to your fingertips.

[pause 5s]

Another. Your back softens into whatever is holding you.

[pause 5s]

And another. Your hips, your legs, your feet. Heavy, and easy.

[pause 6s]

[gentle wonder] As you rest more deeply, your body carries on its remarkable work. Your heart is pumping more blood than ever before, warm and steady, nourishing the little one growing inside you. All of it happening, while you simply rest.

[pause 5s]

[calm, peaceful] Now the path opens into the garden. Notice what's here. Maybe flowers, or soft green leaves, or the sound of water somewhere nearby. Let it be exactly as you'd like it.

[pause 8s]

Find a place to settle in your garden. A patch of soft grass. A bench in the shade. Let yourself sink into it.

[pause 7s]

[tender] If you'd like, rest a hand on your belly, and imagine your baby resting here with you, warm and peaceful.

[pause 8s]

[gentle] Now, in your heart, simply rest before God. You don't need to say anything. Let your quietness be your prayer.

[pause 12s]

[prayerful, sincere] Lord, thank you that strength isn't only found in doing. Thank you for the little one resting quietly within me. Teach me to rest in you, to grow quietly confident in your care, and to find moments of peace in these days of carrying new life. Amen.

[pause 7s]

[warm] This garden is always here for you. You can find your way back down the path whenever you need it.

[pause 5s]

When you're ready, take a slightly deeper breath, and let your body gently begin to wake. Fingers. Toes. Eyes opening slowly.

[pause 4s]

May quietness and confidence go with you through this day.

[music 6s]

---

## Week 22 · Faith-centered

**Title:** Life / *and loving* / kindness.
**Description:** Five minutes to imagine your baby's world, and thank God for the life he's forming.
**Approach:** the Grounded journey inward to the world your baby knows, with Job's words about being knit together and God's life and loving kindness.
**Scripture:** Job 10:11–12 (verbatim excerpt: the first two sentences).

[music 6s]

[warm, curious] Let's take a little journey inward today. Not to anywhere far away. Just to the place where your baby is growing.

[pause 4s]

[calm] Settle in comfortably. Let your hands find your belly, if that feels natural.

[pause 5s]

Let your breath slow down by itself. Let your shoulders drop, and your jaw soften.

[pause 5s]

[warm, reflective] There's a moment in the book of Job where Job, speaking honestly to God, pauses to remember how he was made. He says:

*You have clothed me with skin and flesh, and knit me together with bones and sinews. You have granted me life and loving kindness.*

[pause 8s]

[gentle wonder] Skin and flesh. Bones and sinews. Even now, these are being formed in your baby. Tiny fingers and toes. A heartbeat. Eyes, ears, a face that's uniquely theirs.

[pause 6s]

Imagine, for a moment, the world your baby knows.

It's warm.

[pause 5s]

It's soft. Cushioned on every side, gently rocking whenever you move.

[pause 5s]

It's full of rhythm. The steady drum of your heartbeat. The whoosh of your breath. The gurgles and hums of a body at work.

[pause 6s]

And it's full of you. Your voice, muffled and warm. Your laugh. The way your body sways when you walk.

[pause 6s]

[tender] Your baby doesn't know the world outside yet. But they know the rhythm of you. That's their first experience of being held.

[pause 6s]

[warm, reverent] Notice the last line of Job's words. Life and loving kindness. God doesn't only make us. He gives us life wrapped in his kindness.

[pause 6s]

[tender] And one day, you'll show that same loving kindness to your child. In a thousand small ways. Feeding, holding, soothing, delighting in them. Love, learned first from the God who loves you.

[pause 7s]

[tender] If you'd like, say something to your baby, silently or out loud. Something simple. *I'm here. We're resting together.*

[pause 9s]

[gentle] Take a moment to thank God, in your own words, for the life he's forming, and for his kindness to you.

[pause 10s]

[prayerful, sincere] Creator God, thank you for knitting this little one together with such care. Thank you for my body, and for all it's doing. Surround us both with your loving kindness, today and every day. Amen.

[pause 7s]

[warm] When you're ready, let your attention widen to the room around you, and open your eyes.

[pause 4s]

Life and loving kindness, given to you, and to your little one.

[music 6s]

---

## Week 23 · Faith-centered

**Title:** Strength / *that* / renews.
**Description:** Five minutes to notice your body's strength, soften, and receive strength from God.
**Approach:** the Grounded pairing of strength and softness through the body, with Isaiah's promise that those who wait for the Lord renew their strength.
**Scripture:** Isaiah 40:29 (verbatim); Isaiah 40:31 (verbatim excerpt: the first part of the verse).

[music 6s]

[warm, unhurried] Let's start with something you might not stop to notice very often: how strong your body is.

Settle into a comfortable seat, or lie on your side. Let yourself be supported.

[pause 5s]

[calm] Notice your breath. Let it find its own easy rhythm.

[pause 5s]

[gentle wonder] Over these months, your body has been doing something extraordinary. It has made room. It has carried more weight, pumped more blood, and grown a whole new organ just to nourish your baby. That's real strength, even on the days you feel tired.

[pause 6s]

[reverent] Isaiah chapter 40 was written to encourage God's people when they felt worn out. It reminds them that the Creator of the whole earth never grows tired. And then it says:

*He gives power to the weak. He increases the strength of him who has no might.*

[pause 7s]

And a little later:

*those who wait for the Lord will renew their strength.*

[pause 8s]

[warm, reflective] Renew. Not invent from nothing. Renew. Like a well that fills again, or a field that grows green after rain.

[pause 5s]

[calm] Let's notice your body's strength, and pair it with softness.

Bring your attention to your legs. These legs carry you, and your baby, through every day. Notice their strength.

[pause 5s]

And now let them soften. Let them be heavy, and resting.

[pause 5s]

Your hips and lower back. They're working hard to support your growing belly. Notice their strength.

[pause 5s]

And now let them soften. Let the muscles there release, just a little.

[pause 5s]

Your arms and hands. Strong enough to carry so much, and soon, strong enough to hold your baby. Notice them.

[pause 5s]

And let them soften, open and easy.

[pause 5s]

Your shoulders and neck. They hold more than you realize. Notice them.

[pause 5s]

And let them drop. Let the tension melt away.

[pause 5s]

Your belly. Stretching, growing, holding your baby close.

[pause 5s]

[tender] Let it be soft too. There's nothing to hold in. Rest a hand there, if you'd like.

[pause 8s]

[warm] Let yourself rest in that for a moment. Strong. And soft.

[pause 8s]

[gentle] Waiting on the Lord can be as simple as this: being still, and receiving. Take a quiet moment to tell God what you need today. Energy, patience, rest, joy.

[pause 10s]

[prayerful, sincere] Lord, thank you for the strength you've given my body for this work, and for the little one it carries. When I feel tired, renew me. Fill me again, day by day, and help me recognize your goodness throughout this season. Amen.

[pause 7s]

[warm] When you're ready, let some gentle movement return, and slowly open your eyes.

[pause 4s]

May his strength meet you, fresh and new, as you go.

[music 6s]

---

## Week 24 · Faith-centered

**Title:** The breath / *of* / life.
**Description:** Five minutes of slow breathing, and a simple prayer for each breath.
**Approach:** the Grounded long, slow exhale, with each breath received as a gift from God and a breath prayer: "You give me life. I rest in you."
**Scripture:** none; prayer only.

[music 6s]

[warm, unhurried] Today we'll spend a few minutes with something simple and powerful: the out-breath.

Find a comfortable position, sitting or lying on your side.

[pause 5s]

[calm] First, just notice your breathing as it is. No changes yet. Notice where you feel it. Your nose, your chest, your belly.

[pause 7s]

[warm] Each breath is given. Each one, a quiet reminder of the God who made you.

[pause 5s]

When we breathe out slowly, our bodies tend to relax. Muscles soften. The mind grows a little quieter. It's one of the gentlest tools you have, and it's always with you.

[pause 5s]

[calm, clear] Let's try it, only if it feels comfortable.

Breathe in naturally. And then let your breath out a little more slowly than usual. Like a sigh that takes its time.

[pause 7s]

Again. A natural breath in. And a long, unhurried breath out.

[pause 7s]

There's no number to reach, and no right length. Just a little longer and softer than before.

[pause 7s]

[calm, soothing] As you breathe out, you might imagine your shoulders melting down. Or your jaw going soft. Or your hands opening.

[pause 7s]

[prayerful] You might pair your breathing with a simple prayer. Breathing in: You give me life. Breathing out: I rest in you.

[pause 12s]

You give me life.

I rest in you.

[pause 12s]

[gentle wonder] Every breath is part of an extraordinary process. Oxygen moves from your lungs into your bloodstream, helping support both your body and your developing baby. Take a moment to appreciate how much happens naturally, without your having to think about it.

[pause 6s]

[warm, reassuring] This long, slow exhale is something you can return to anytime. Before sleep. In a waiting room. And later, when it's time to meet your baby. The more familiar it becomes, the more easily it will come to you.

[pause 6s]

[tender] If you'd like, rest a hand on your belly and thank God for this shared life.

[pause 8s]

[prayerful, sincere] Lord, thank you for every breath, and for the life growing in me. Let my breathing remind me of your nearness, today, and in the days to come. Amen.

[pause 7s]

[warm] Now let your breathing return to its natural rhythm, and slowly open your eyes.

[pause 4s]

Every breath today is a small gift from him.

[music 6s]

---

## Week 25 · Faith-centered

**Title:** A gift / *from* / the Lord.
**Description:** Five minutes to say hello to your baby, and thank God for the gift you're carrying.
**Approach:** the Grounded hello to your baby through movement and touch, with thanks to God for the gift of this child.
**Scripture:** none; prayer only.

[music 6s]

[warm, lightly smiling] There's someone else who's been busy in there lately. Let's take a few minutes to say hello.

[pause 4s]

[calm] Find a comfortable position. Lying on your side, or reclining, can make it easier to notice what's happening inside.

[pause 5s]

Rest your hands on your belly, wherever feels natural.

[pause 5s]

[calm] Let your breath settle. Let your body grow still and quiet. Let your shoulders drop, and your face soften.

[pause 6s]

[gentle wonder] At this stage, you may be becoming more familiar with the sensation of your baby's movements. Perhaps you've noticed little rolls, nudges, or stretches. These moments can offer a lovely opportunity to pause and feel connected to the little life you're carrying.

[pause 6s]

[warm] For these next few moments, simply pay attention. If you feel a movement, notice where it is and what it feels like.

[pause 10s]

[warm, lightly smiling] If you'd like, you can answer. A gentle press of your hand. A soft pat. A few words: *Hello in there. I feel you.*

[pause 8s]

[tender] Some babies seem to respond to their mother's touch or voice. Whether or not yours moves right now, they're surrounded by your warmth and your rhythm. They know you in their own way.

[pause 7s]

[warm] Many parents find their baby has favorite times to be active. After a meal, maybe, or just as you lie down at night. You might start to notice your baby's own little rhythms, the first hints of their personality.

[pause 6s]

Let yourself enjoy this. The quiet company of the little one you're getting to know.

[pause 8s]

[gentle wonder] Think of how much is happening in there. Tiny muscles getting stronger. Lungs practicing. Hands opening and closing. Each day, a little more ready for the world.

[pause 6s]

Your baby is a gift, and every gift reflects the giver. Your baby's life is a reflection of God's own generosity and delight. Before you ever held them, he knew them.

[pause 7s]

[prayerful, sincere] Father, thank you for this child, a gift from your hand. Thank you for every movement, every stretch, every sign of life. Help me receive this child with love and care. Amen.

[pause 7s]

[tender] Before we finish, you might tell your baby one thing you're looking forward to. *I can't wait to see your face.* Or anything that feels true for you.

[pause 9s]

[warm] When you're ready, let your hands rest, and open your eyes.

[pause 4s]

A gift from the Lord, growing close to your heart.

[music 6s]

---

## Week 26 · Faith-centered

**Title:** My peace / *I* / give you.
**Description:** Five minutes to rest steady at your center and receive the peace Jesus gives.
**Approach:** the Grounded steady stone in a gentle stream, with Jesus' gift of his own peace, received slowly, and a moment to talk with him.
**Scripture:** John 14:27 (verbatim excerpt: the first two sentences).

[music 6s]

[warm, unhurried] Picture a clear, gentle stream on a warm afternoon. Sunlight sparkles on the water. The sound is soft and constant.

[pause 6s]

[calm] Let that sound help you settle. Find a comfortable position, and let your body be supported.

[pause 5s]

Let your breath slow down, like the water slowing in a quiet pool.

[pause 6s]

[calm, soothing] Now look into the stream, and notice a smooth stone resting on the bottom. The water moves over it and around it, all day long. And the stone stays steady.

[pause 6s]

Imagine you are that stone. Calm. Grounded. Resting on the riverbed.

[pause 6s]

Feel the weight of your body, heavy and settled, the way the stone rests in the sand. Nothing needs to move. Nothing needs to hold on.

[pause 6s]

[warm, storytelling] On the night before he died, Jesus sat with his closest friends and spoke to them tenderly about the days ahead. Among his words was this gift:

*Peace I leave with you. My peace I give to you;*

[pause 8s]

[warm, reflective] My peace. Not a peace that depends on everything going perfectly. Jesus' own peace. The kind he carried with him through every day of his life, through crowds and storms and quiet hillsides alike.

[pause 6s]

And notice that he gives it. You don't have to manufacture it, or earn it, or find it on your own. It's a gift, offered freely.

[pause 6s]

[gentle] Life flows around you. Plans, conversations, to-do lists, new things to learn. All of it can move past, like water, while you stay steady at your center.

[pause 7s]

[gentle wonder] And within you, your baby rests in their own gentle waters, rocked and cushioned, surrounded by warmth. Steady, and held, while life flows around them.

[pause 6s]

[tender] If you'd like, rest a hand on your belly. Two steady centers, resting together.

[pause 8s]

[warm, reassuring] This place of steadiness is something you can come back to. On busy days. When things feel like a lot. And later, when you're welcoming your baby. You can always find the stone beneath the water.

[pause 7s]

[gentle] Now take a moment to talk with Jesus. Thank him for his peace, and tell him anything that's on your heart.

[pause 10s]

[prayerful, sincere] Jesus, thank you for giving me your own peace. Let it fill my heart and my home, and rest on this little one too. Thank you for the blessing of this child. Amen.

[pause 7s]

[warm] When you're ready, let your body begin to stir, and open your eyes.

[pause 4s]

His peace is yours to keep.

[music 6s]

---

## Week 27 · Faith-centered

**Title:** In wisdom / *you* / made them.
**Description:** Five minutes to thank your body, and praise the God who made it with wisdom.
**Approach:** the Grounded letter of thanks to your body, with the psalmist's praise for God's wise works, and wonder turned into prayer.
**Scripture:** Psalm 104:24 (verbatim excerpt: the first two sentences).

[music 6s]

[warm, unhurried] Hello. Today, you're going to write a little letter. Not on paper. Just in your heart, to your body.

Settle in comfortably, and let yourself be supported.

[pause 5s]

[calm] Let your breath slow. Let your eyes close, or rest your gaze gently. Let your shoulders soften as you breathe out.

[pause 5s]

[warm, reflective] Psalm 104 is one long song of wonder. It moves through mountains and springs, birds and trees, sunrise and moonlight. And then the psalmist breaks into praise:

*Lord, how many are your works! In wisdom, you have made them all.*

[pause 8s]

[gentle wonder] As your second trimester nears its end, it's worth pausing to notice how much your body has done. Growing a placenta. Making more blood. Shifting and stretching to make room. Sheltering your baby through every hour of every day.

[pause 6s]

[warm] Let's begin your letter. Dear body.

[pause 4s]

[tender] Thank you, heart, for beating stronger for two.

[pause 5s]

Thank you, lungs, for every breath we share.

[pause 5s]

Thank you, belly, for making room, and holding our baby close.

[pause 5s]

Thank you, back and hips, for carrying more than ever before.

[pause 5s]

Thank you, legs and feet, for taking us everywhere we need to go.

[pause 5s]

Thank you, skin, for stretching and growing with us.

[pause 5s]

Thank you, hands, for resting on our baby, and for all the holding still to come.

[pause 6s]

[warm] Now add your own lines. Is there something your body has done that you're especially grateful for? A day it carried you through. A moment it surprised you. Tell it, in your own words.

[pause 10s]

[warm, reassuring] Your body may not always feel comfortable. It's working very hard. Gratitude doesn't mean every moment feels good. It simply means noticing the remarkable things it's doing, right now.

[pause 6s]

[calm] Rest for a moment in the knowledge that you, and your baby, are part of God's good creation. Made with wisdom. Made with care.

[pause 6s]

[tender] If you'd like, rest a hand on your belly, and finish your letter. Thank you for this. Thank you for us.

[pause 8s]

[prayerful, sincere] Lord, how many are your works! Thank you for the wisdom woven into my body, and for the little one you're forming. Let me see your goodness everywhere I look today. Amen.

[pause 7s]

[warm] When you're ready, let your hands rest, and slowly open your eyes.

[pause 4s]

You are part of his wise and wonderful work.

[music 6s]

---

## Week 28 · Faith-centered

**Title:** A place / *prepared* / with love.
**Description:** Five minutes to picture the place you're preparing for your baby, and pray over your home.
**Approach:** the Grounded nest imagined in your home and in your heart, with Jesus' promise to prepare a place for us, and a prayer over your home.
**Scripture:** John 14:2 (verbatim excerpt: the last sentence).

[music 6s]

[warm, lightly smiling] Many people feel an urge, around this time, to prepare. To fold tiny clothes, arrange a corner of a room, make things ready. Today, let's prepare in a gentler way.

[pause 4s]

[calm] Find a comfortable position, well supported. Let your breath settle. Let your shoulders soften, and your hands rest.

[pause 6s]

[reverent] On the night before he died, Jesus comforted his friends by telling them about his Father's house, with room for all of them. And he said:

*I am going to prepare a place for you.*

[pause 8s]

[warm, reflective] There's something deeply loving about preparing a place for someone. It says: I've been thinking of you. I want you to feel at home. Jesus offers that kind of love to each of us.

[pause 6s]

[calm, peaceful] Imagine a space where your baby will rest when they arrive. It doesn't have to be fancy, or finished. Just picture it as you'd like it to be.

[pause 6s]

Notice the light in that space. Soft morning light, maybe. Or a warm lamp in the evening.

[pause 6s]

Notice what's there. A blanket, folded. Something soft to hold. Maybe a chair where you'll sit together.

[pause 6s]

Notice the sounds. Quiet, perhaps. Or a little music. Or the hum of a home going about its day.

[pause 6s]

[tender] Imagine the feeling of that space. Calm. Safe. Welcoming. A nest, made with love.

[pause 7s]

[warm] Now notice that you're preparing another kind of space too. A space inside you. In your heart, your days, your life. Room for a new person to belong.

[pause 6s]

[gentle wonder] Your body has been preparing all along, making room week by week, without being asked. Your heart is learning to do the same. Each time you think of your baby, talk to them, or rest a hand on your belly, that inner nest grows a little warmer.

[pause 6s]

[tender] If you'd like, rest a hand on your belly, and imagine welcoming your baby into both spaces. The nest in your home, and the nest in your heart.

[pause 8s]

[warm, reassuring] You don't have to have everything ready. Babies need warmth, and closeness, and love, and you're already preparing all of those.

[pause 6s]

[gentle] Now take a moment to pray over your home, and the place you're making. Ask God to fill it with peace, and love, and joy.

[pause 10s]

[prayerful, sincere] Lord, thank you for preparing a place for me in your love, and for the little one we're making room for. Bless the home I'm preparing for this little one. Let it be warm with your presence, and full of welcome. Amen.

[pause 7s]

[warm] When you're ready, let your hands rest, and slowly open your eyes.

[pause 4s]

A place made ready, with love, for someone dearly wanted.

[music 6s]

---

## Week 29 · Faith-centered

**Title:** In the shadow / *of* / your wings.
**Description:** Five minutes to find ease in a changing body, sheltered in God's care.
**Approach:** the Grounded comfortable position and wide, easy breathing, with David's song of rejoicing in the shadow of God's wings, and the shelter you give your baby.
**Scripture:** Psalm 63:7 (verbatim).

[music 6s]

[warm, understanding] As your baby grows, your body is changing shape quickly. Some positions that used to feel comfortable might not anymore. Let's take a few minutes to find some ease.

[pause 4s]

[calm] Try lying on your side, with a pillow between your knees and another under your belly, if you have one. Or sit reclined, well propped up. Take your time getting comfortable.

[pause 8s]

[gentle wonder] Your baby is taking up more room these days, and your organs have been gently shifting to make space. It's an amazing bit of rearranging, happening quietly inside you.

[pause 6s]

[calm] Because of that, you might notice your breath feels a little higher in your chest. Let's give it some room.

Rest one hand on the side of your ribs.

[pause 5s]

As you breathe in, notice your ribs widening gently under your hand, like an umbrella opening.

[pause 6s]

As you breathe out, feel them settle.

[pause 6s]

Let a few breaths come this way. Wide and easy, without forcing anything.

[pause 10s]

[reverent] David wrote Psalm 63 while he was out in the wilderness. Even there, he remembered God through the night, and wrote:

*For you have been my help. I will rejoice in the shadow of your wings.*

[pause 8s]

[warm, reflective] The shadow of wings. Imagine a mother bird gathering her little ones close, sheltering them beneath her. Warm. Safe. Completely covered.

[pause 6s]

[calm, soothing] Now let your breathing return to its natural rhythm, and let the rest of your body soften. Your shoulders. Your jaw. Your hands.

[pause 7s]

Notice any place that feels tight or tired, perhaps your lower back, or your hips. Imagine breathing a little warmth there. Let the pillows and the bed take more of your weight.

[pause 7s]

[tender] If you'd like, move your hand to your belly. Your baby is growing and stretching, making the most of the space you've given them.

[pause 6s]

[gentle wonder] Notice the shelter you are providing too. Your baby rests within you, surrounded by warmth, cushioned and close. Just as God shelters you, you shelter your little one.

[pause 7s]

[prayerful, sincere] Lord, you have been my help. Thank you for sheltering me, and for letting me shelter this little one. Let me rest and rejoice in the shadow of your wings. Amen.

[pause 7s]

[warm] When you're ready, take your time coming back. Move slowly, and open your eyes.

[pause 4s]

Sheltered, and sheltering, in his care.

[music 6s]

---

## Week 30 · Faith-centered

**Title:** As / *a mother* / comforts.
**Description:** Five minutes to imagine welcoming your baby, and rest in God's motherly comfort.
**Approach:** the Grounded looking forward to welcoming your baby, with God's promise to comfort us as a mother comforts her child.
**Scripture:** Isaiah 66:13 (verbatim excerpt: the first sentence).

[music 6s]

[warm, tender] Today, let's spend a few minutes with something joyful: looking forward to welcoming your baby.

[pause 4s]

[calm] Find a comfortable position, and let yourself be supported. Let your breath slow down.

[pause 6s]

[calm] Let your body soften. Your shoulders. Your jaw. Your hands. Let your whole body feel warm and easy.

[pause 6s]

[reverent] Through the prophet Isaiah, God spoke these tender words to his people:

*As one whom his mother comforts, so I will comfort you.*

[pause 8s]

[warm, reflective] Of all the ways God could describe his love, here he chooses a mother's comfort. Close. Patient. Tender. Unhurried.

[pause 6s]

[warm, reassuring] If you'd like, imagine a moment of welcoming your baby. You don't need to picture every detail. Simply allow yourself to reflect on the love and tenderness you hope to share.

[pause 8s]

[tender] Perhaps you imagine the warmth of a tiny body held close. Perhaps a small hand, or a sleepy face you've wondered about for months. Or perhaps no picture comes at all, only a feeling. Whatever comes is enough.

[pause 8s]

[warm] Think of the small, everyday ways you hope to share that love. A gentle voice. A soft song. Warm arms, and a lap to rest in.

[pause 8s]

What would you like your baby to know about how loved they are? Let the words come in your own way, silently or out loud.

[pause 10s]

[gentle wonder] Your voice is one your baby already knows. They've been hearing it for months, from the inside. The love you're imagining has already begun.

[pause 7s]

[calm, soothing] Now let yourself be the one comforted. Imagine God's comfort wrapping around you, the way a mother wraps her arms around her child. Let your whole body rest.

[pause 8s]

[tender] If you'd like, rest a hand on your belly. You, comforted by God. Your baby, comforted by you.

[pause 7s]

[prayerful, sincere] Lord, thank you for comforting me the way a mother comforts her child. Thank you for the gift of my baby. Teach me to comfort my baby with that same tender love. Amen.

[pause 7s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

Comforted, and ready to comfort, in his love.

[music 6s]
