# BirthWell · Faith-centered meditations, final review

**Weeks 7–42 · recommendations for Leah's approval.** Nothing has been changed. Every proposed change below was tested on a separate copy, to check lengths and Scripture. The drafts, the approved scripts and the audio are untouched.

## 1. Recommended Scripture-free weeks

Seven weeks, ranked strongest first. In each one, the faith stays:

- God is still named and spoken to.
- The closing prayer stays word for word.
- Nothing is replaced with a long explanation.

After this, 29 of the 36 weeks still include Scripture, and the seven are spread across the pregnancy.

| Week | Why the Scripture could go | Length after |
|---|---|---|
| **41** · Rest, and wait | *"Wait patiently for him"* in week 41 can be heard as "just keep waiting", which runs against our care rule for weeks 40–42. "Rest in the Lord," the blessing and the prayer stay. | 4:31 |
| **25** · A gift from the Lord | *"The fruit of the womb is his reward"* can sting for women who have lost a pregnancy or struggled to conceive. The gift theme and prayer stay. | 4:45 |
| **24** · The breath of life | The breath prayer ("You give me life. I rest in you.") already carries the faith. Removing Elihu, a figure few will know, also removes a hard name to pronounce. | 4:39 |
| **34** · Held up by love | The Moses, Aaron and Hur story is the longest story in the set, and it slows the care-circle practice. Removing it also drops the hard-to-say "Hur". Thanking God for each helper, and the prayer, stay. | 4:33 |
| **33** · Fullness of joy | The calm place can now flow without a break, straight into "And notice that you aren't here alone. God is with you." This also ends the triple repeat of "fullness of joy". | 4:34 |
| **39** · God of all comfort | The list of comforts flows better uninterrupted. The prayer still names the "Father of mercies, God of all comfort". | 4:37 |
| **13** · Every good gift | The three "Thank you" prayers already make this distinctly Christian, and the "Father of lights" prayer stays. | 4:27 |

### Exact changes for these weeks

**All seven:**
- **Removed:** the Scripture introduction and verse.
- **Also removed, where it simply repeats the verse:** the line straight after it.
  - Week 41: "Rest, and wait. Not restless watching…"
  - Week 25: "A heritage…"
  - Week 33: "In your presence is fullness of joy. Not a distant place…"
  - Week 34: "Moses didn't have to do it alone…"

**Week 13:**
- "Every good gift. Not only the big ones." → "Every good gift **comes from God**. Not only the big ones."
- **Put back:** the approved Grounded line "Small good things are easy to miss… the way the days of this pregnancy are adding up." This keeps it above 4:15 without padding.

**Week 24:**
- "The breath of the Almighty. Each breath, given." → "Each breath is given."

**Week 25:**
- "Every gift reflects the giver." → "Your baby is a gift, and every gift reflects the giver."
- **Put back:** two approved Grounded lines, "Many parents find their baby has favorite times to be active…" and "Let yourself enjoy this…". Without them it would run 4:04.

**Week 39:**
- "God of all comfort. Not some comfort." → "God is the God of all comfort. Not some comfort."

**Week 41:**
- **Put back:** the approved Grounded line "Notice the warmth of your hands… Simple things, and so precious." Without it it would run 4:12.

## 2. Remaining editorial issues and proposed fixes

**Week 13**
- Two side-by-side lines both said "it's okay if gratitude is mixed with other feelings".
- **Fix:** remove "Your body is involved in an extraordinary process, and it's reasonable to feel both thankful for its work and tired of its demands." The next line ("If thankfulness feels hard today…") says it more warmly.

**Week 16**
- "Let's let the day go, one piece at a time" comes just before "Now let's give the day to God", so the day is handed over twice.
- **Fix:** "Let's begin with your body, one piece at a time."

**Week 18**
- The story starts abruptly.
  - **Fix:** "As you settle, here's a story. Long ago, two expectant mothers…"
- Two lines in a row both ask you to notice your hands and breath.
  - **Fix:** merge them into "Notice the warmth beneath your hands, and the slow rise and fall of your breath."

**Week 35**
- **Fix:** "pray your phrase" → "pray your words", matching "your words" everywhere else in the meditation.

**Week 25 (sensitivity)**
- **Fix:** "Before you ever held them, he knew them, and he chose to give them to you." → "…he knew them." For someone who has lost a baby, "he chose to give" can imply God chose not to give before.

**Checked and kept on purpose:**
- the blessing prayed line by line in week 14;
- the strength-and-soften pattern in week 23;
- the repeated prayer "My times are in your hand" in week 38, which is meant for use during labor;
- the "Be still… Be." sequence in week 11.

**Optional, for you to decide:**
- Week 42 ends "Rejoice in today."
- Near the due date, some mothers may hear that as pressure to feel joyful.
- A gentler close would be simply "Your little one is already so loved."

**Emotional sensitivity check (all 36):**
- Nothing promises a healthy pregnancy or a particular birth.
- Nothing requires joy or gratitude.
- Prayer never replaces medical care.
- The care-team, due-date and feelings safeguards in weeks 37–42 are intact.
- The word "Safe" appears only to describe imagined places: a nest, a calm place, sheltering wings.

## 3. Runtimes after all proposed changes

All 36 weeks run **4:19–5:43** at Maren's pace, inside the 4:15–6:00 Faith-centered target. No pauses were lengthened. Every Scripture passage that remains is unchanged, and no tone directions change.

## 4. Recording concerns

**1. Names to listen for**
- Zephaniah (week 16) already has a spoken spelling.
- To check by ear:
  - Ebenezer (20)
  - Lamentations (15)
  - Ecclesiastes (37)
  - Philippians (8)
  - Galatia (17)
  - Judah (18)
  - Isaiah
- The Scripture-free weeks also remove Elihu, Hur and Corinthians.

**2. Verses that end mid-sentence**
- Week 26 ends in ";", week 31 in ",", and week 37 in ":". Maren may sound as if she's about to keep going.
- **Proposal:** the recorder sends a full stop there. Only the text sent to ElevenLabs changes; the approved scripts don't.

**3. Very short lines**
- "Be." (week 11), "Thank you." (week 13), and "You give me life. / I rest in you." (week 24) can come out clipped.
- If one does, it can be re-recorded on its own cheaply.

**4. Shortest week**
- Week 30, at 4:19, is the shortest.
- If Maren reads a little faster on the day, it could dip just under 4:15. That would still fall within the 10-second small exception.

**5. Cost**
- About 104,000 characters are left to record: Grounded weeks 7–42 (71,000) and the new Faith-centered material (33,000).
- The rest of the Faith-centered text can reuse Grounded recordings.
- That's about 42,000 credits at the rate you've been charged so far (0.4 per character), or 104,000 at the listed rate. Either fits one month of Creator.

## 5. What I need from you

1. **Which Scripture-free weeks you approve:** all seven, or a selection.
2. **Yes or no to the editorial fixes in section 2,** and to the optional week 42 closing.
3. **Yes or no to the full stop at the end of the three verses** in recording only (weeks 26, 31 and 37).

After approval, I'll apply the changes and move the Faith-centered weeks 7–42 into the official scripts. Then I'll prepare clean, recording-ready scripts: spoken words, tone directions and pauses only. A final check runs before anything is recorded.

# Appendix · Proposed spoken text of the changed weeks

These read as Maren would speak them, with no strikethrough. **Bold** marks wording that's new to this week compared with the current draft: a joining phrase, a trimmed line, or an approved Grounded line put back. Remaining Scripture is in *italics*. Pauses and tone directions aren't shown.

### Week 13 · Every good gift (about 4:27)

Think of one small thing from the last day or so that was good. It doesn't need to be big. A warm shower. A kind text. The first sip of something cold. Hold that thought, and let yourself get comfortable. This meditation is about noticing good things. Not because everything is good. Some days in pregnancy are hard, and that's real. But even hard days can hold small moments worth noticing. **Every good gift comes from God.** Not only the big ones. The small, everyday ones too. Let's go back to that first good thing. Picture it clearly. Where were you? What did it feel like? Let yourself enjoy it again, just for a moment. Now simply say, in your heart: Thank you. Let a second one come to mind. Maybe something someone said. Maybe something you saw. Light through a window. A song. A laugh. Thank you. And a third. Maybe something your body did well. A good night's sleep, a meal that sat right, a walk that felt easy. Thank you. One small good thing may simply be the thought that you're carrying a baby, even if that thought comes with complicated feelings. If thankfulness feels hard today, that's all right. God isn't asking you to pretend everything is easy. You can tell him that too. Gratitude and honesty can sit side by side. **Small good things are easy to miss. They don't announce themselves. But they add up, quietly, the way the days of this pregnancy are adding up.** Father of lights, every good thing in my life comes from you. Thank you for the small gifts I so often miss, and for the gift of this little one. Open my eyes to your goodness today, even in ordinary moments. Amen. If you'd like, rest a hand on your belly. Your baby is part of your days now, even the ordinary ones. When you're ready, let your eyes open. Watch for his good gifts today. They're often closer than we think.

### Week 16 · Sleep for the beloved (about 4:58)

If it's evening, you might dim the lights, or turn them off altogether. If it's daytime, that's okay too. Let this be a small evening, wherever you are. Find the most comfortable position you can. On your side, with a pillow between your knees, is often lovely at this stage. Use whatever support you have. Let your breath slow down by itself. There's nowhere to be. There's a line at the end of Psalm 127 that says: *for he gives sleep to his loved ones.* Sleep, and rest, as a gift. Not something you have to earn by finishing everything first. **Let's begin with your body, one piece at a time.** First, let your eyes rest. Let them grow heavy behind your eyelids. Let your ears soften, so sounds become just a gentle background. Let your jaw loosen, and your tongue rest at the bottom of your mouth. Let your hands lie heavy and open. Even as the house grows quiet, pregnancy doesn't stop being present. Your body continues the remarkable work of supporting this developing baby through the night. You don't have to stay awake to supervise that work, and you don't need to make yourself feel grateful before you rest. Now let's give the day to God, without judging any of it. What went well today? Thank him for it. What was hard? Tell him about it, and leave it with him. What's left undone? Let it wait. It's in his hands until morning. Now listen to these words, spoken by the prophet Zephaniah to God's people: *He will calm you in his love.* *He will rejoice over you with singing.* Imagine being sung over. Calmed. The way you might one day sing over your own child. If you'd like, rest a hand on your belly. Let yourself feel the warmth there as you both settle. Lord, I give you this day. Calm me in your love, and give me the rest I need. Amen. Stay here. Let your body grow heavier and softer. If you're drifting toward sleep, let yourself go. If not, rest here in his care. Rest well, beloved.

### Week 18 · A greeting of joy (about 4:34)

Let's get quiet enough to listen inward. Find a comfortable position. Lying on your side, or sitting reclined, often makes it easier to notice what's happening inside. Let the sounds of the room fade into the background, like distant waves. **As you settle, here's a story.** Long ago, two expectant mothers met in a house in the hill country of Judah. Mary was young, and newly pregnant, carrying news she was still trying to understand. She hurried to visit her relative, Elizabeth, who was also expecting, after years of waiting. Imagine Mary arriving at the door, tired from her journey. Imagine Elizabeth hearing her voice. Luke tells us: *When Elizabeth heard Mary's greeting, the baby leaped in her womb.* And Elizabeth said to her: *For behold, when the voice of your greeting came into my ears, the baby leaped in my womb for joy!* Two women, both carrying new life. Sharing their joy, and their questions, and staying together for months. Somewhere in these weeks, some people begin to notice tiny movements. Flutters, taps, little bubbles. For others, it takes longer. Every pregnancy has its own timing, and there's no right moment for this. Rest your hands on your belly, if you'd like. Let them be still and soft. **Notice the warmth beneath your hands, and the slow rise and fall of your breath.** You don't need to look for any particular sensation right now. Your baby lives surrounded by your rhythms. Your heartbeat. Your breathing. The movement of your body through the day. In their own way, they're getting to know you too. Elizabeth's joy began with a greeting. Imagine greeting your baby now, in your heart. A simple hello, full of love. Who is an Elizabeth for you? Someone you can share this season with? Thank God for them. Or, if you're longing for someone like that, ask him for it. Lord, thank you for the joy of new life, and for the people who share it with me. Let joy find its way into my heart, even in the waiting. Amen. When you're ready, let your attention widen again to the room around you, and slowly open your eyes. May you find small joys to share today.

### Week 24 · The breath of life (about 4:39)

Today we'll spend a few minutes with something simple and powerful: the out-breath. Find a comfortable position, sitting or lying on your side. First, just notice your breathing as it is. No changes yet. Notice where you feel it. Your nose, your chest, your belly. **Each breath is given.** Each one, a quiet reminder of the God who made you. When we breathe out slowly, our bodies tend to relax. Muscles soften. The mind grows a little quieter. It's one of the gentlest tools you have, and it's always with you. Let's try it, only if it feels comfortable. Breathe in naturally. And then let your breath out a little more slowly than usual. Like a sigh that takes its time. Again. A natural breath in. And a long, unhurried breath out. There's no number to reach, and no right length. Just a little longer and softer than before. As you breathe out, you might imagine your shoulders melting down. Or your jaw going soft. Or your hands opening. You might pair your breathing with a simple prayer. Breathing in: You give me life. Breathing out: I rest in you. You give me life. I rest in you. Every breath is part of an extraordinary process. Oxygen moves from your lungs into your bloodstream, helping support both your body and your developing baby. Take a moment to appreciate how much happens naturally, without your having to think about it. This long, slow exhale is something you can return to anytime. Before sleep. In a waiting room. And later, when it's time to meet your baby. The more familiar it becomes, the more easily it will come to you. If you'd like, rest a hand on your belly and thank God for this shared life. Lord, thank you for every breath, and for the life growing in me. Let my breathing remind me of your nearness, today, and in the days to come. Amen. Now let your breathing return to its natural rhythm, and slowly open your eyes. Every breath today is a small gift from him.

### Week 25 · A gift from the Lord (about 4:45)

There's someone else who's been busy in there lately. Let's take a few minutes to say hello. Find a comfortable position. Lying on your side, or reclining, can make it easier to notice what's happening inside. Rest your hands on your belly, wherever feels natural. Let your breath settle. Let your body grow still and quiet. Let your shoulders drop, and your face soften. At this stage, you may be becoming more familiar with the sensation of your baby's movements. Perhaps you've noticed little rolls, nudges, or stretches. These moments can offer a lovely opportunity to pause and feel connected to the little life you're carrying. For these next few moments, simply pay attention. If you feel a movement, notice where it is and what it feels like. If you'd like, you can answer. A gentle press of your hand. A soft pat. A few words: Hello in there. I feel you. Some babies seem to respond to their mother's touch or voice. Whether or not yours moves right now, they're surrounded by your warmth and your rhythm. They know you in their own way. **Many parents find their baby has favorite times to be active. After a meal, maybe, or just as you lie down at night. You might start to notice your baby's own little rhythms, the first hints of their personality.** **Let yourself enjoy this. The quiet company of the little one you're getting to know.** Think of how much is happening in there. Tiny muscles getting stronger. Lungs practicing. Hands opening and closing. Each day, a little more ready for the world. **Your baby is a gift, and every gift reflects the giver.** Your baby's life is a reflection of God's own generosity and delight. **Before you ever held them, he knew them.** Father, thank you for this child, a gift from your hand. Thank you for every movement, every stretch, every sign of life. Help me receive this gift with joy, and care for it with love. Amen. Before we finish, you might tell your baby one thing you're looking forward to. I can't wait to see your face. Or anything that feels true for you. When you're ready, let your hands rest, and open your eyes. A gift from the Lord, growing close to your heart.

### Week 33 · Fullness of joy (about 4:34)

Today, you'll create something you can take with you anywhere: a calm place, all your own. Find a comfortable position, and let your breath slow down. Let a peaceful place come to mind. It might be somewhere you've been. A beach, a garden, a quiet room. Or somewhere completely imagined. Let the first gentle place that appears be enough. Now step into it with your senses. What do you see? The colors. The light. The shapes around you. What do you hear? Maybe water, or wind, or birdsong. Or a lovely quiet. What do you feel? Warm sun. A cool breeze. Soft ground beneath you. Is there a scent? Salt air, fresh rain, flowers, warm bread? Let yourself settle into this place. Notice how your body feels here. Easy. Safe. At home. And notice that you aren't here alone. God is with you. Unhurried. Glad to be with you. Now let's give your calm place a small cue, a way to find it quickly. Gently touch your thumb to the tip of one finger. Keep it there, and keep breathing in your calm place. Let the feeling of this place and the feeling of that touch belong together. Now release your fingers. Whenever you'd like to return, on a busy day, before sleep, or during labor, you can touch your thumb to your finger, breathe slowly, and remember: he is with you. Within you, your baby is surrounded by a world of warmth, movement, and familiar rhythms. Your body has created an extraordinary environment for this little life to develop. Take a moment to appreciate that beautiful connection. If you'd like, rest a hand on your belly, and imagine your baby with you in your calm place. Lord, thank you that in your presence there is fullness of joy. Show me the path of life, and let me walk it with you, one step at a time. Amen. When you're ready, let your calm place fade gently, and open your eyes. His presence is always just a breath away.

### Week 34 · Held up by love (about 4:33)

As your baby's birthday draws closer, let's take a few minutes to think about care. Not the plans or the paperwork. Just the feeling of being cared for. Find a comfortable position, and let yourself be supported. Let your breath slow down. Let your shoulders soften. Support looks different for everyone. A partner, a friend, a family member, a doula, a midwife or doctor, a calm nurse. Some people will have many people beside them. Some, just one or two. Every kind of care counts. Bring them to mind, one by one. Thank God for each of them. Now imagine the kind of care that would help you feel at ease. Not a specific scene. Just the feeling of it. Perhaps it's a calm voice. Perhaps a hand on your shoulder, or someone who knows when to simply be quiet. Perhaps it's a comfort from home. Your own pillow. A favorite song. A soft light. Notice what matters most to you. These are worth sharing with the people who'll be with you. Some people like to write them down as part of their birth preferences, so everyone can see what helps. And remember the care you give yourself too. Resting. Asking for what you need. Being patient and kind with yourself. You're part of your own circle of care. Your baby has been surrounded by care since the very beginning, by you. Your warmth. Your heartbeat. The nourishment your body gives them every moment. Soon, they'll be surrounded by your arms, too. And through it all, God holds you both. If you'd like, rest a hand on your belly, and imagine that circle of care around you. Now take a moment to pray for those who will be with you. For their wisdom, their kindness, and their care. Lord, thank you for the people who hold me up. Give them wisdom, gentleness and strength. Surround my baby and me with your care, and with theirs. Amen. When you're ready, let your hands rest, and open your eyes. You deserve care and support, too. Held up by love, and by him.

### Week 35 · Grace that is enough (about 4:59)

Hello. In these final weeks, you've been growing in so many ways. Not only your body, but your heart, your confidence, your readiness. Let's take a few minutes to notice that. Find a comfortable position, and let yourself be supported. Let your breath slow down by itself. Let your forehead smooth. Your jaw soften. Your hands open. The apostle Paul once asked God, more than once, to take away something that was hard for him. And he received this answer: *My grace is sufficient for you, for my power is made perfect in weakness.* Sufficient. Enough. God's grace doesn't wait until you feel strong. It meets you right where you are, with exactly what you need for today. Think about the extraordinary changes of these past months. From the earliest stages of development to the little one you're carrying today, so much has taken place within you. Your body has adapted in remarkable ways, and there's something beautiful about taking a moment to appreciate that work. Today, let's gather a few gentle words you can carry with you. Words you can return to on any day, and when it's time to meet your baby. Listen to each one, and notice whether it feels right for you. I can take this one moment at a time. His grace is enough for this moment. The Lord is with me. I can rest in him. My baby and I are in this together. Choose one, or one from Scripture that you love. Repeat it slowly to yourself, with each breath out. You might write your words down later, or put them somewhere you'll see them often. A note on the mirror. A message on your phone. These words aren't meant to make anything happen. They're simply companions. Something kind to hold on to. **If you'd like, rest a hand on your belly, and pray your words over your baby too.** Lord, thank you that your grace is enough for me. Give me what I need for each day, and for the day I meet my child. Let me lean on you, and rest in you. Amen. When you're ready, let your eyes open slowly. Enough grace, for today and for every day ahead.

### Week 39 · God of all comfort (about 4:37)

Today, let's gather a little collection of comforts. Things you might reach for in the days ahead, and when it's time to meet your baby. Find a comfortable position, and let your breath slow down. **God is the God of all comfort.** Not some comfort. All of it. Every warm blanket, every kind hand, every quiet moment of relief comes from his heart for you. Different things help different people, and what helps can change from hour to hour. So think of these as possibilities. Gentle options, not a checklist. Warmth. A warm shower or bath, a heat pack, a soft blanket. Imagine warmth spreading through your back and hips. Movement. Swaying, rocking, walking, leaning on something steady. Imagine your hips swaying gently, side to side. Sound. Worship music you love. A familiar voice. Or simple quiet. Touch. A hand on your back. Firm pressure, or a light stroke. Or perhaps no touch at all. Notice what you'd prefer. Scent. A familiar lotion, a soft fabric that smells of home, fresh air through an open window. Prayer. A short phrase of Scripture, like the one you chose a few weeks ago. Breath. A long, slow breath out, whenever it feels right. Rest. Stillness between efforts, eyes closed, held in his care. You won't need all of these, and some may not help you at all. That's completely fine. You can try one thing, let it go, and try another. You get to discover what works for you. Your body has been finding its own comforts all along, shifting to ease your back, seeking rest when it's tired. You know more about what you need than you might think. If you'd like, rest a hand on your belly, close to your baby. Father of mercies, God of all comfort, thank you for every comfort you give. In the days ahead, surround me with your comfort, and show me what helps. Amen. When you're ready, let your eyes open slowly. All comfort, from the God who loves you.

### Week 41 · Rest, and wait (about 4:31)

Hello. Today is a day for slowing down, and savoring. Find a comfortable position, wherever your body feels most at ease. Let yourself be supported. Let your breath slow down by itself. Let your face soften. These days may feel long, and your body may be asking for more comfort and rest. Wherever you find yourself today, let's take a few minutes to appreciate this moment of pregnancy, without asking it to feel any particular way. Think back over this journey with God. The first moment you knew. The first flutter you felt. The prayers you've prayed. The ways your body has grown and carried your baby, week after week. All of it, held by him. Thank him for anything that comes to mind. Maybe you'd like to remember these days. A photo of your belly. A note to your baby. A few words in a journal about how it feels right now. Small keepsakes from a once-in-a-lifetime season. Now notice your baby, here with you. The roundness of your belly. The closeness. A whole person, so near, and almost ready to meet you. Is there something small you'd like to savor today? A warm bath. A slow cup of tea. Sunlight through a window. A nap in the afternoon. Let one simple pleasure come to mind. Imagine enjoying it fully. No rushing. Nowhere else to be. **Notice the warmth of your hands. The rise and fall of your breath. The quiet company of your baby. Simple things, and so precious.** Let your shoulders sink. Let your hands rest open. Rest in the Lord. If you'd like, rest a hand on your belly, and pray a blessing over your baby, in your own words. Lord, I rest in you, and I wait for you. Thank you for every day of this journey. Bless my baby, and be with us as we prepare to meet. Amen. When you're ready, let your eyes open slowly. Savor these days. Your waiting is in good hands.

