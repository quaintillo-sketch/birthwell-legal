# Weeks 31–42 · Faith-centered, woven from Grounded (draft for Leah)

**Status:** draft for Leah's review. The approved scripts are unchanged and nothing is recorded.

**How these are built:** like Week 6, each Faith-centered meditation follows its Grounded partner: its opening, its body, breathing or imagery work, and its close. Faith is woven in with the approved Faith-centered Scripture, reflections and prayers. Titles, descriptions and Scripture are unchanged. The care guidance approved for weeks 37–42 (no promises about comfort or outcomes, never replacing the care team's advice) is kept word for word wherever it appears.

---

## Week 31 · Faith-centered

**Title:** Through / *the* / waters.
**Description:** Five minutes to breathe with the rhythm of waves, and remember God's promise to be with you.
**Approach:** the Grounded sea at sunset and breathing with an imagined wave, with God's promise to be with you through the waters.
**Scripture:** Isaiah 43:2 (verbatim excerpt: the first words of the verse).

[music 6s]

[warm, unhurried] Imagine you're sitting on warm sand, at the edge of a calm sea. The sun is low and golden. The water is gentle.

[pause 6s]

[calm] Let that picture help you settle. Find a comfortable position, and let your body be supported.

[pause 5s]

Let your breath slow down by itself, as easy as the water.

[pause 6s]

[reverent] Long ago, through the prophet Isaiah, God spoke to his people about the journeys ahead of them. Among his words was this:

*When you pass through the waters, I will be with you,*

[pause 8s]

[warm, reflective] God didn't describe the waters. He didn't say how deep, or how long. He simply said: I will be with you. His presence is the heart of the promise.

[pause 6s]

[calm, soothing] Now watch the waves. Each one begins far out, small and quiet. It slowly rises. It reaches its fullest point. And then it eases, spreading softly across the sand, and drawing back into stillness.

[pause 8s]

Rise. Peak. Ease. And then a pause, before the next one begins.

[pause 6s]

[warm] Many people find this a helpful picture for the contractions of labor, sometimes called surges or waves. Each one has a beginning, a middle, and an end. And between them, a time of rest.

[pause 5s]

[calm, clear] Let's practice breathing with an imagined wave. Only if it feels comfortable.

As the wave begins to rise, breathe in naturally.

[pause 5s]

As it reaches its peak and begins to ease, let your breath out long and slow, like the water spreading over the sand.

[pause 7s]

And now, the stillness between. Let your whole body rest.

[pause 8s]

Let's ride one more. The wave rises… breathe in.

[pause 5s]

It peaks and eases… a long, slow breath out.

[pause 7s]

And rest.

[pause 8s]

[tender] The same God who has been with you through every week of this pregnancy is with you in the weeks ahead, and in the moment you meet your baby.

[pause 6s]

[gentle wonder] Your body is full of extraordinary rhythms. Your heart beats steadily, supporting the remarkable work of pregnancy. Your breath rises and falls without conscious effort, while your baby develops within you. Take a moment to appreciate the beautiful connection between your body and the little life you're carrying.

[pause 6s]

[tender] If you'd like, rest a hand on your belly, and imagine the gentle sea holding you both.

[pause 7s]

[prayerful, sincere] Lord, thank you that you are with me. In every wave, and in every rest between, let me know your nearness. Be with my baby, and be with me, every step of the way. Amen.

[pause 7s]

[warm] This picture is yours to keep, and to come back to whenever you like. You'll have other tools too, and there's no single right way to use any of them.

[pause 5s]

When you're ready, let the sea fade gently, and open your eyes.

[pause 4s]

Wherever your path leads, he goes with you.

[music 6s]

---

## Week 32 · Faith-centered

**Title:** A / *quiet* / soul.
**Description:** Five minutes to soften your body and quiet your soul, like a child resting close.
**Approach:** the Grounded softening of face, jaw, hands, shoulders and belly, with David's picture of a soul quieted like a child resting with its mother.
**Scripture:** Psalm 131:2 (verbatim).

[music 6s]

[warm, curious] Let's begin with a small experiment. Clench your jaw, just slightly. Notice how your shoulders and hands want to tighten with it.

[pause 5s]

Now let your jaw go loose. Notice what happens in the rest of your body.

[pause 6s]

[warm] Our bodies are connected in surprising ways. When one place softens, others often follow. That's what we'll practice today.

[pause 4s]

[reverent] There's a short psalm, only three verses long, that paints one of the most tender pictures in Scripture. David writes:

*Surely I have stilled and quieted my soul, like a weaned child with his mother, like a weaned child is my soul within me.*

[pause 8s]

[warm, reflective] A little one resting against their mother. Not asking for anything. Not needing anything. Just content to be close.

[pause 6s]

[warm] That kind of quiet doesn't come from having everything figured out. It comes from trust. From knowing you're held.

[pause 5s]

[calm] Find a comfortable position, supported and easy.

[pause 5s]

Begin with your face. Let your forehead smooth. Let the space between your eyebrows widen.

[pause 5s]

Your jaw. Let your teeth part slightly, and your lips rest softly together.

[pause 6s]

Your hands. Let them open, palms up, fingers loose and curled like a sleeping baby's.

[pause 5s]

Open hands, like a child's, ready to receive rather than hold on.

[pause 5s]

Your shoulders. Let them drop away from your ears. Then let them drop a little more.

[pause 6s]

[tender] Your belly. Allow the muscles to soften, wherever that feels comfortable. There's no need to hold anything in. Take a moment to appreciate the remarkable ways your body has adapted to make room for your growing baby.

[pause 7s]

[calm, soothing] Now, with each slow breath out, imagine all of these places softening together. Face, jaw, hands, shoulders, belly. Soft and open.

[pause 8s]

[warm] Many people find that a soft face and loose hands help the whole body settle, during everyday moments, and during labor too. It's a simple thing you can come back to, anytime.

[pause 5s]

[gentle wonder] Your body has been opening for months. Making room. Stretching. Shifting. Growing around your baby with remarkable flexibility. Softening is something it already knows how to do.

[pause 6s]

[gentle] Rest in his presence for a moment. There's nothing you need to ask for. Simply be near him.

[pause 10s]

[prayerful, sincere] Lord, quiet my soul like a child resting with its mother. Thank you for holding me close, as I hold this little one within me. Amen.

[pause 7s]

[calm] Stay soft for a moment longer. Let your breath move freely through an easy, open body.

[pause 8s]

[warm] When you're ready, let some movement return, and open your eyes.

[pause 4s]

A quiet soul, resting close to him.

[music 6s]

---

## Week 33 · Faith-centered

**Title:** Fullness / *of* / joy.
**Description:** Five minutes to create a calm place, and know God's presence there.
**Approach:** the Grounded calm place explored through the senses, with a simple touch cue to return to it, and the psalmist's joy in God's presence.
**Scripture:** Psalm 16:11 (verbatim excerpt: the first two sentences).

[music 6s]

[warm, unhurried] Today, you'll create something you can take with you anywhere: a calm place, all your own.

Find a comfortable position, and let your breath slow down.

[pause 6s]

[reverent] In Psalm 16, David speaks of the security he finds in God. Near the end, he writes:

*You will show me the path of life. In your presence is fullness of joy.*

[pause 8s]

[warm] In your presence is fullness of joy. Not a distant place. Not somewhere you have to earn your way into. Simply being near God.

[pause 6s]

[calm, peaceful] Let a peaceful place come to mind. It might be somewhere you've been. A beach, a garden, a quiet room. Or somewhere completely imagined. Let the first gentle place that appears be enough.

[pause 7s]

[calm] Now step into it with your senses.

What do you see? The colors. The light. The shapes around you.

[pause 6s]

What do you hear? Maybe water, or wind, or birdsong. Or a lovely quiet.

[pause 6s]

What do you feel? Warm sun. A cool breeze. Soft ground beneath you.

[pause 6s]

Is there a scent? Salt air, fresh rain, flowers, warm bread?

[pause 6s]

[warm] Let yourself settle into this place. Notice how your body feels here. Easy. Safe. At home.

[pause 6s]

[tender] And notice that you aren't here alone. God is with you. Unhurried. Glad to be with you.

[pause 9s]

[calm, clear] Now let's give your calm place a small cue, a way to find it quickly. Gently touch your thumb to the tip of one finger. Keep it there, and keep breathing in your calm place.

[pause 9s]

Let the feeling of this place and the feeling of that touch belong together.

[pause 6s]

Now release your fingers.

[pause 4s]

[warm] Whenever you'd like to return, on a busy day, before sleep, or during labor, you can touch your thumb to your finger, breathe slowly, and remember: he is with you.

[pause 6s]

[gentle wonder] Within you, your baby is surrounded by a world of warmth, movement, and familiar rhythms. Your body has created an extraordinary environment for this little life to develop. Take a moment to appreciate that beautiful connection.

[pause 6s]

[tender] If you'd like, rest a hand on your belly, and imagine your baby with you in your calm place.

[pause 8s]

[prayerful, sincere] Lord, thank you that in your presence there is fullness of joy. Show me the path of life, and let me walk it with you, one step at a time. Amen.

[pause 7s]

[warm] When you're ready, let your calm place fade gently, and open your eyes.

[pause 4s]

His presence is always just a breath away.

[music 6s]

---

## Week 34 · Faith-centered

**Title:** Held / *up* / by love.
**Description:** Five minutes to notice the people who hold you up, and pray for them.
**Approach:** the Grounded circle of care around you and your baby, with the story of Aaron and Hur holding up Moses' hands, thanks for your helpers, and prayer for those who'll be with you.
**Scripture:** Exodus 17:12 (the story retold in Maren's own words, with a verbatim excerpt from the middle of the verse).

[music 6s]

[warm, unhurried] As your baby's birthday draws closer, let's take a few minutes to think about care. Not the plans or the paperwork. Just the feeling of being cared for.

[pause 5s]

[calm] Find a comfortable position, and let yourself be supported.

[pause 5s]

Let your breath slow down. Let your shoulders soften.

[pause 6s]

[reverent] There's a story in the book of Exodus about a long, tiring day. Moses needed to keep his hands raised, and as the hours went on, his arms grew heavy. So his friends found him a stone to sit on. And then:

*Aaron and Hur held up his hands, the one on the one side, and the other on the other side.*

[pause 8s]

[warm, reflective] Moses didn't have to do it alone. Someone stood on each side, holding him up. That's what good support looks like. Steady. Present. Close.

[pause 6s]

[warm] Support looks different for everyone. A partner, a friend, a family member, a doula, a midwife or doctor, a calm nurse. Some people will have many people beside them. Some, just one or two. Every kind of care counts.

[pause 6s]

Bring them to mind, one by one. Thank God for each of them.

[pause 10s]

[calm, peaceful] Now imagine the kind of care that would help you feel at ease. Not a specific scene. Just the feeling of it.

[pause 6s]

Perhaps it's a calm voice. Perhaps a hand on your shoulder, or someone who knows when to simply be quiet.

[pause 7s]

Perhaps it's a comfort from home. Your own pillow. A favorite song. A soft light.

[pause 7s]

[warm] Notice what matters most to you. These are worth sharing with the people who'll be with you. Some people like to write them down as part of their birth preferences, so everyone can see what helps.

[pause 6s]

[warm, reassuring] And remember the care you give yourself too. Resting. Asking for what you need. Being patient and kind with yourself. You're part of your own circle of care.

[pause 6s]

[gentle wonder] Your baby has been surrounded by care since the very beginning, by you. Your warmth. Your heartbeat. The nourishment your body gives them every moment. Soon, they'll be surrounded by your arms, too. And through it all, God holds you both.

[pause 6s]

[tender] If you'd like, rest a hand on your belly, and imagine that circle of care around you both.

[pause 7s]

[gentle] Now take a moment to pray for those who will be with you. For their wisdom, their kindness, and their care.

[pause 10s]

[prayerful, sincere] Lord, thank you for the people who hold me up. Give them wisdom, gentleness and strength. Surround my baby and me with your care, and with theirs. Amen.

[pause 7s]

[warm] When you're ready, let your hands rest, and open your eyes.

[pause 4s]

You deserve care and support, too. Held up by love, and by him.

[music 6s]

---

## Week 35 · Faith-centered

**Title:** Grace / *that is* / enough.
**Description:** Five minutes to gather a few words of faith to carry with you.
**Approach:** the Grounded gathering of gentle words to return to, with God's answer to Paul, "My grace is sufficient for you," and short phrases of faith to pray over yourself and your baby.
**Scripture:** 2 Corinthians 12:9 (verbatim excerpt: the words Paul heard from the Lord).

[music 6s]

[warm, unhurried] Hello. In these final weeks, you've been growing in so many ways. Not only your body, but your heart, your confidence, your readiness. Let's take a few minutes to notice that.

[pause 5s]

[calm] Find a comfortable position, and let yourself be supported. Let your breath slow down by itself.

[pause 6s]

Let your forehead smooth. Your jaw soften. Your hands open.

[pause 6s]

[reverent] The apostle Paul once asked God, more than once, to take away something that was hard for him. And he received this answer:

*My grace is sufficient for you, for my power is made perfect in weakness.*

[pause 8s]

[warm] Sufficient. Enough. God's grace doesn't wait until you feel strong. It meets you right where you are, with exactly what you need for today.

[pause 6s]

[gentle wonder] Think about the extraordinary changes of these past months. From the earliest stages of development to the little one you're carrying today, so much has taken place within you. Your body has adapted in remarkable ways, and there's something beautiful about taking a moment to appreciate that work.

[pause 6s]

[warm] Today, let's gather a few gentle words you can carry with you. Words you can return to on any day, and when it's time to meet your baby.

[pause 5s]

[calm, reassuring] Listen to each one, and notice whether it feels right for you.

I can take this one moment at a time.

[pause 6s]

His grace is enough for this moment.

[pause 6s]

The Lord is with me.

[pause 6s]

I can rest in him.

[pause 6s]

My baby and I are in this together.

[pause 7s]

Choose one, or one from Scripture that you love. Repeat it slowly to yourself, with each breath out.

[pause 12s]

[warm] You might write your words down later, or put them somewhere you'll see them often. A note on the mirror. A message on your phone.

[pause 5s]

[warm, reassuring] These words aren't meant to make anything happen. They're simply companions. Something kind to hold on to.

[pause 6s]

[tender] If you'd like, rest a hand on your belly, and pray your phrase over your baby too.

[pause 8s]

[prayerful, sincere] Lord, thank you that your grace is enough for me. Give me what I need for each day, and for the day I meet my child. Let me lean on you, and rest in you. Amen.

[pause 7s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

Enough grace, for today and for every day ahead.

[music 6s]

---

## Week 36 · Faith-centered

**Title:** My help / *comes* / from the Lord.
**Description:** Five minutes to practice resting between efforts, with your eyes lifted to the Lord.
**Approach:** the Grounded practice of gentle effort and full release, with Psalm 121's reminder that our help comes from the Lord, and a prayer for help in the final weeks.
**Scripture:** Psalm 121:1–2 (verbatim).

[music 6s]

[warm, unhurried] There's a part of any rhythm that's easy to overlook: the rest in between. Today, that's what we'll practice.

[pause 4s]

[calm] Find a comfortable position, and let yourself be fully supported.

[pause 5s]

Let your breath slow down. Let your face soften.

[pause 6s]

[reverent] Psalm 121 is one of the songs God's people sang as they traveled up to Jerusalem. It begins:

*I will lift up my eyes to the hills. Where does my help come from? My help comes from the Lord, who made heaven and earth.*

[pause 8s]

[warm] My help comes from the Lord. The same God who made the mountains, the stars, and the little one within you is the one who helps you.

[pause 6s]

In labor, contractions come and go, like waves. And between them, there's time to rest. Many people find that learning to rest fully, even for a short while, makes a real difference.

[pause 5s]

[calm, clear] Let's practice. If it's comfortable, gently press your palms together in front of you. Not hard. Just enough to feel a little effort. Hold it, and keep breathing.

[pause 6s]

And release. Let your hands fall open. Let your shoulders drop.

[pause 4s]

[calm, soothing] Now rest completely. Let your body go heavy. Let your breath slow. Notice how good it feels to let go.

[pause 10s]

Once more. Press your palms gently together. A little effort. Keep breathing.

[pause 6s]

And release.

[pause 4s]

Rest. Every muscle softening. Your jaw, your hands, your belly. Sinking into whatever holds you.

[pause 10s]

You might notice how quickly your body learns. Each time you let go, it gets a little easier.

[pause 5s]

[gentle wonder] Your baby has rhythms of their own, growing and developing within the remarkable environment your body provides. As you rest here, take a moment to appreciate the life you're carrying and the connection you share.

[pause 6s]

[tender] If you'd like, rest a hand on your belly, and enjoy this quiet moment together.

[pause 8s]

[gentle] Take a quiet moment to lift your eyes to the Lord. Tell him what help you'd like in these final weeks.

[pause 10s]

[prayerful, sincere] Lord, my help comes from you. Thank you for carrying me this far. Teach me to rest in you between every effort, and stay near to me and my baby in the days ahead. Amen.

[pause 7s]

[warm, reassuring] You can practice this kind of rest anytime. After a busy morning. Before sleep. And whenever you notice yourself holding on, you can remember: I'm allowed to let go.

[pause 6s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

Lift your eyes. Your help is near.

[music 6s]

---

## Week 37 · Faith-centered

**Title:** A time / *for* / everything.
**Description:** Five minutes to hold your plans with open hands, and trust God with the timing.
**Approach:** the Grounded practice of open hands, with Ecclesiastes' reminder that there is a season for everything, and your hopes for the birth offered to God.
**Scripture:** Ecclesiastes 3:1 (verbatim).

[music 6s]

[warm, unhurried] Let's begin with your hands. Wherever they're resting, turn them palms up, if that's comfortable.

[pause 5s]

[calm] Find a supported position, and let your breath slow down by itself. Let your shoulders soften.

[pause 6s]

[reverent] The book of Ecclesiastes has a beautiful passage about the rhythm of life. It begins:

*For everything there is a season, and a time for every purpose under heaven:*

[pause 8s]

[warm, reflective] A time for every purpose. A season for everything. Including this season, these final weeks of waiting and preparing, and the day you'll meet your baby.

[pause 6s]

[warm] As your baby's arrival draws near, you may have been thinking about plans. Who will be with you. What might help. The bag by the door. Plans are a lovely way to prepare, and they can be held gently.

[pause 6s]

[calm, clear] Try this. Gently close your hands, as if you were holding something tightly.

[pause 5s]

Notice how that feels. The effort in your fingers, your wrists, your arms.

[pause 5s]

Now let your hands open again, palms up and relaxed.

[pause 6s]

[warm, reassuring] Open hands can still hold things. They just hold them lightly. Your hopes and preferences are still there, resting in your open palms, ready to adapt as the day unfolds.

[pause 6s]

[gentle] Now offer your plans to God, one by one, in your own words. Your hopes. Your preferences. Your questions. Place each one in your open hands, and lift it to him.

[pause 10s]

[gentle wonder] Your body has been adapting for months. Making room, shifting, changing, carrying your baby with remarkable flexibility. There's something remarkable about the ways your body has adapted throughout pregnancy. Take a moment to appreciate that work, and allow yourself to approach the coming days with gentleness and an open heart.

[pause 6s]

[calm] Now let your whole body follow your hands. Open, soft, and easy. Your face. Your jaw. Your shoulders. Your belly.

[pause 8s]

[tender] If you'd like, rest one open hand on your belly. Imagine holding your hopes for your baby the same way. Warmly. Gently. With love.

[pause 8s]

[prayerful, sincere] Lord, thank you for this season. I give you my plans and my hopes for this birth. Help me hold them with open hands, and trust you with the timing. Be near to me and my baby, today and every day. Amen.

[pause 7s]

[warm] Whatever plans you've made, the most important preparation is already happening. You're learning your baby. You're making room in your heart. You're getting ready to meet someone you already love.

[pause 7s]

When you're ready, let your hands rest, and open your eyes.

[pause 4s]

There is a time for everything, and this time is held by him.

[music 6s]

---

## Week 38 · Faith-centered

**Title:** My times / *are in* / your hand.
**Description:** Five minutes to meet one moment at a time, trusting each one to God.
**Approach:** the Grounded practice of returning to this breath and this moment, with David's prayer of trust, "My times are in your hand."
**Scripture:** Psalm 31:14–15 (verbatim excerpt: from "But I trust in you" to "My times are in your hand").

[music 6s]

[warm, unhurried] Here's a gentle thought to rest with today: you only ever have to meet one moment at a time.

[pause 5s]

[calm] Find a comfortable position. Let your breath slow down. Let your body be supported.

[pause 6s]

[reverent] In Psalm 31, David prays honestly to God, and in the middle of his prayer, he says:

*But I trust in you, Lord. I said, "You are my God." My times are in your hand.*

[pause 8s]

[warm, reflective] My times are in your hand. Not just the big moments, but each one. This breath. This hour. This day. And the day you'll meet your baby.

[pause 6s]

[calm, clear] Let's practice. Notice this breath. Only this one. The air coming in, and going out.

[pause 6s]

Now this moment. The feeling of whatever is beneath you. The sounds in the room.

[pause 6s]

If your mind jumps ahead, gently bring it back, and pray: My times are in your hand.

[pause 9s]

Notice one thing you can hear right now. One thing you can feel. One thing you can see, even behind closed eyes, like light or shadow. Each one is a small anchor to now.

[pause 8s]

[warm] Many people find this a steadying way to approach labor. Not thinking about how long it might be, or what comes next. Just meeting each contraction as it comes, and then the rest that follows. One moment, and then the next.

[pause 6s]

[calm, soothing] Between contractions, you can return to this simple prayer. My times are in your hand. Rest, and breathe, and let the next moment come in its own time.

[pause 7s]

[gentle wonder] Your baby lives entirely in the present. Each moment, they grow, and stretch, and rest, without a thought for tomorrow. There's something lovely about joining them there, even for a few minutes.

[pause 6s]

[tender] If you'd like, rest a hand on your belly. This moment, together.

[pause 7s]

[gentle] Now take a moment to entrust your times to God. Today. This week. The day your baby arrives. Tell him, in your own words.

[pause 10s]

[prayerful, sincere] Lord, I trust in you. You are my God. My times are in your hand. Help me meet each moment with you, one breath at a time. Amen.

[pause 7s]

[warm, reassuring] You won't always manage to stay in the present, and that's fine. Every time you notice your mind wandering and gently come back, that is the practice. It grows a little stronger each time.

[pause 6s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

Every moment ahead is already in his hand.

[music 6s]

---

## Week 39 · Faith-centered

**Title:** God / *of all* / comfort.
**Description:** Five minutes to gather comforts for the days ahead, from the God of all comfort.
**Approach:** the Grounded collection of comforts (warmth, movement, sound, touch, scent, prayer, breath and rest), with Paul's praise of the God of all comfort.
**Scripture:** 2 Corinthians 1:3 (verbatim excerpt: the end of the verse).

[music 6s]

[warm, unhurried] Today, let's gather a little collection of comforts. Things you might reach for in the days ahead, and when it's time to meet your baby.

[pause 5s]

[calm] Find a comfortable position, and let your breath slow down.

[pause 6s]

[reverent] At the beginning of his second letter to the Corinthians, Paul praises God with a beautiful name. He calls him:

*the Father of mercies and God of all comfort;*

[pause 8s]

[warm, reflective] God of all comfort. Not some comfort. All of it. Every warm blanket, every kind hand, every quiet moment of relief comes from his heart for you.

[pause 6s]

[warm] Different things help different people, and what helps can change from hour to hour. So think of these as possibilities. Gentle options, not a checklist.

[pause 5s]

[calm, peaceful] Warmth. A warm shower or bath, a heat pack, a soft blanket. Imagine warmth spreading through your back and hips.

[pause 7s]

Movement. Swaying, rocking, walking, leaning on something steady. Imagine your hips swaying gently, side to side.

[pause 7s]

Sound. Worship music you love. A familiar voice. Or simple quiet.

[pause 7s]

Touch. A hand on your back. Firm pressure, or a light stroke. Or perhaps no touch at all. Notice what you'd prefer.

[pause 7s]

Scent. A familiar lotion, a soft fabric that smells of home, fresh air through an open window.

[pause 6s]

Prayer. A short phrase of Scripture, like the one you chose a few weeks ago.

[pause 7s]

Breath. A long, slow breath out, whenever it feels right.

[pause 7s]

Rest. Stillness between efforts, eyes closed, held in his care.

[pause 6s]

[warm, reassuring] You won't need all of these, and some may not help you at all. That's completely fine. You can try one thing, let it go, and try another. You get to discover what works for you.

[pause 6s]

[gentle wonder] Your body has been finding its own comforts all along, shifting to ease your back, seeking rest when it's tired. You know more about what you need than you might think.

[pause 6s]

[tender] If you'd like, rest a hand on your belly. Comfort for you, and closeness with your baby.

[pause 7s]

[prayerful, sincere] Father of mercies, God of all comfort, thank you for every comfort you give. In the days ahead, surround me with your comfort, and show me what helps. Amen.

[pause 7s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

Comfort comes in many forms. All comfort, from the God who loves you.

[music 6s]

---

## Week 40 · Faith-centered

**Title:** I wait / *for* / the Lord.
**Description:** Five minutes to set down the waiting for a while, and rest with God.
**Approach:** the Grounded rest from the waiting days, with the psalmist's hope in God, the women of Scripture who waited, and your waiting brought to God.
**Scripture:** Psalm 130:5 (verbatim).

[music 6s]

[warm, lightly smiling] You may be hearing a lot of the same question lately. Any news yet? Let's take a few minutes away from all of that.

[pause 5s]

[calm] Find your most comfortable position. Let your breath slow down by itself.

[pause 6s]

[warm, reassuring] A due date is an estimate, not an appointment your baby is expected to keep. As you approach this part of pregnancy, you may be following a plan with your care team for the days ahead. For these few minutes, you can set aside the calendar and simply rest.

[pause 6s]

[reverent] In Psalm 130, the psalmist describes what it's like to wait on God:

*I wait for the Lord. My soul waits. I hope in his word.*

[pause 8s]

[warm, reflective] Waiting is woven all through Scripture. Sarah, Hannah, Elizabeth, Mary. Each one waited, in her own way, for a child. Waiting is not empty time. It's time held in God's hands.

[pause 6s]

[gentle wonder] Some people find these last days bring a surprising burst of energy. Others feel slow and heavy. Both are simply your body, doing its work in its own way. Listen to what it asks for.

[pause 6s]

[calm, soothing] Let your forehead smooth. Your jaw soften. Your shoulders drop. Your hands open.

[pause 8s]

[gentle wonder] Waiting can feel long, but it's also full of quiet work. Your body is continuing its remarkable preparation, and your baby is continuing to grow. So much is happening, even in the stillness.

[pause 6s]

[warm] What would make these waiting days a little sweeter? A walk in fresh air. A favorite meal. An early night. Time with someone you love. A good book. Let one or two ideas come to mind.

[pause 9s]

[tender] If you'd like, rest a hand on your belly. These are some of the last days your baby will be this close to you, held entirely within. There's something precious in that.

[pause 9s]

[gentle] Now bring your waiting to God. Your hopes, your impatience, your excitement. Tell him all of it, and let him hold it with you.

[pause 10s]

[prayerful, sincere] Lord, I wait with you. Thank you for the little life I carry and for the remarkable journey of this pregnancy. Give me patience, wisdom for the days ahead, and peace in your presence today. Amen.

[pause 7s]

[warm] Whatever the coming days hold, you can meet each one as it comes, with patience and a little kindness for yourself.

[pause 6s]

When you're ready, let your eyes open slowly.

[pause 4s]

One day at a time. Waiting with hope, and not alone.

[music 6s]

---

## Week 41 · Faith-centered

**Title:** Rest, / *and* / wait.
**Description:** Five minutes to slow down, savor these days, and rest in the Lord.
**Approach:** the Grounded slowing down and savoring of these last days, with David's invitation to rest in the Lord and wait patiently, and a blessing over your baby.
**Scripture:** Psalm 37:7 (verbatim excerpt: the first sentence).

[music 6s]

[warm, unhurried] Hello. Today is a day for slowing down, and savoring.

Find a comfortable position, wherever your body feels most at ease. Let yourself be supported.

[pause 6s]

[calm] Let your breath slow down by itself. Let your face soften.

[pause 6s]

[reverent] In Psalm 37, David offers a simple invitation:

*Rest in the Lord, and wait patiently for him.*

[pause 8s]

[warm, reflective] Rest, and wait. Not restless watching, but peaceful waiting. Settled in God's care, the way a child rests in a parent's arms.

[pause 6s]

[warm] These days may feel long, and your body may be asking for more comfort and rest. Wherever you find yourself today, let's take a few minutes to appreciate this moment of pregnancy, without asking it to feel any particular way.

[pause 6s]

[gentle wonder] Think back over this journey with God. The first moment you knew. The first flutter you felt. The prayers you've prayed. The ways your body has grown and carried your baby, week after week. All of it, held by him.

[pause 9s]

Thank him for anything that comes to mind.

[pause 9s]

[warm] Maybe you'd like to remember these days. A photo of your belly. A note to your baby. A few words in a journal about how it feels right now. Small keepsakes from a once-in-a-lifetime season.

[pause 7s]

[tender] Now notice your baby, here with you. The roundness of your belly. The closeness. A whole person, so near, and almost ready to meet you.

[pause 8s]

[warm] Is there something small you'd like to savor today? A warm bath. A slow cup of tea. Sunlight through a window. A nap in the afternoon. Let one simple pleasure come to mind.

[pause 8s]

Imagine enjoying it fully. No rushing. Nowhere else to be.

[pause 7s]

[calm, soothing] Let your shoulders sink. Let your hands rest open. Rest in the Lord.

[pause 8s]

[tender] If you'd like, rest a hand on your belly, and pray a blessing over your baby, in your own words.

[pause 10s]

[prayerful, sincere] Lord, I rest in you, and I wait for you. Thank you for every day of this journey. Bless my baby, and be with us as we prepare to meet. Amen.

[pause 7s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

Savor these days. Rest in him. Your waiting is in good hands.

[music 6s]

---

## Week 42 · Faith-centered

**Title:** This is / *the* / day.
**Description:** Five minutes to honor the journey, give thanks, and welcome your baby.
**Approach:** the Grounded honoring of your body's, your own and your baby's journey, with thanksgiving for the day the Lord has made and a welcome for your baby.
**Scripture:** Psalm 118:24 (verbatim).

[music 6s]

[warm, tender] Hello. Wherever you are in these final days, you've come such a long way. Let's take a few minutes to honor that, and to welcome your baby.

[pause 5s]

[calm] Find your most comfortable position, and let yourself be fully supported. Let your breath slow down.

[pause 6s]

[reverent, joyful] Psalm 118 is a song of thanksgiving, full of joy. In the middle of it, the psalmist says:

*This is the day that the Lord has made. We will rejoice and be glad in it!*

[pause 8s]

[warm, reflective] This is the day. Not only the day your baby arrives, but today. This ordinary, waiting, precious day, made by God, and full of his goodness.

[pause 6s]

[gentle wonder] Think of everything your body has done. From those very first weeks, when so much was happening out of sight, to now. Growing, adapting, sheltering, carrying. A truly extraordinary journey.

[pause 7s]

[warm] And think of everything you've done. The rest you've taken. The questions you've asked. The love you've already given to someone you haven't yet held.

[pause 7s]

[tender] And think of your baby's journey too. From the tiniest beginning to a whole little person, getting ready for the world. What a story you share.

[pause 7s]

Every day of this pregnancy was a day the Lord made. The tired days and the joyful ones. The quiet ones and the busy ones. He was present in every one.

[pause 6s]

[gentle] Take a moment to give thanks. For your body. For your baby. For the people who've walked with you. For every day of this journey.

[pause 10s]

[warm, reassuring] There may be plans and decisions surrounding your baby's arrival, and each birth experience is different. For these few moments, simply make room for the love and tenderness you hope to share with your little one.

[pause 6s]

[tender] If you'd like, rest a hand on your belly, and offer your baby a welcome. Something like: Whenever you arrive, you are so welcome here.

[pause 10s]

[prayerful, sincere] Lord, this is the day you have made. Thank you for every day of this journey, and for the gift of this child. I trust you with the day we meet. Let us rejoice together in your goodness. Amen.

[pause 7s]

[warm, reassuring] You've practiced so many gentle things along the way. Slowing down. Breathing out. Softening. Finding your calm place. Resting between efforts. They're all with you, ready whenever you need them.

[pause 7s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

Rejoice in today. Whenever you arrive, little one, you are already so loved.

[music 6s]
