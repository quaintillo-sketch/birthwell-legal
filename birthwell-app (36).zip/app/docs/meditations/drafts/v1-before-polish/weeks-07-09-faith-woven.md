# Weeks 7–9 · Faith-centered, woven from Grounded (draft for Leah)

**Status:** draft for Leah's review. The approved scripts are unchanged and nothing is recorded.

**How these are built:** like Week 6, each Faith-centered meditation follows its Grounded partner, using its opening, its body work and its close. Faith is woven in with the approved Faith-centered Scripture, reflections and prayers. Titles, descriptions and Scripture are unchanged.

---

## Week 7 · Faith-centered

**Title:** Come / *and* / rest.
**Description:** Five minutes to lay down what feels heavy and receive the rest Jesus offers.
**Approach:** the Grounded permission to rest, Jesus' invitation to come, setting burdens down in prayer, then progressive heaviness beside still waters.
**Scripture:** Matthew 11:28–29 (verbatim); Psalm 23:2 (verbatim).

[music 6s]

[warm, unhurried] Hi. If you can, let yourself lie down for this one. On your side is lovely, with a pillow wherever you need it. If lying down isn't possible right now, simply lean back and let something hold you.

[pause 5s]

[gentle, understanding] You may be more tired than usual right now. The kind of tired that a good night's sleep doesn't quite reach. Pregnancy can ask so much of you, in body and in heart, even on days when it seems like nothing is happening.

[pause 5s]

That tiredness isn't laziness, and it isn't weakness. Your body is adapting to pregnancy in countless quiet ways, and it asks for energy and rest, sometimes more than you expected. There is something remarkable in that work, even if all you notice today is how tired you feel.

[pause 5s]

[warm, reassuring] So here's your permission. For the next few minutes, you don't need to be useful. You don't need to catch up. Rest doesn't need to be earned.

[pause 4s]

[reverent] Listen to the words of Jesus:

*Come to me, all you who labor and are heavily burdened, and I will give you rest. Take my yoke upon you, and learn from me, for I am gentle and humble in heart; and you will find rest for your souls.*

[pause 8s]

[warm, reassuring] He doesn't say, come once you've finished everything. He doesn't say, come once you've earned it. He simply says, come.

[pause 5s]

[gentle] What are you carrying today? Tell him quietly. The tiredness. The worries. The things you haven't gotten to. You can set each one down in front of him.

[pause 10s]

[prayerful, sincere] Jesus, I'm tired, and you already know it. Thank you that I don't have to earn your rest, or prove that I deserve it. I'm setting these things down with you. Teach me to rest in you. Amen.

[pause 6s]

[calm, soothing] Let's let the heaviness come.

Start with your feet. Imagine them growing warm and heavy, sinking a little into whatever is beneath them.

[pause 5s]

That warmth moves into your calves… your knees… your thighs… your hips and lower back. Heavy. Easy. Held.

[pause 5s]

Your belly, soft, with nothing to hold in. Your arms, heavy all the way down to your fingertips.

[pause 5s]

And your face. The space between your eyebrows. Your jaw. The soft skin around your eyes.

[pause 5s]

[reverent] In Psalm 23, David says of the Lord, his shepherd:

*He makes me lie down in green pastures. He leads me beside still waters.*

[pause 7s]

[calm, peaceful] Let yourself be there. Notice the light. The quiet. How nobody needs anything from you.

[pause 8s]

[gentle] If your mind wanders to the dishes, the emails, the list, that's all right. Notice it, and let your next breath out carry you back to your resting place.

[pause 6s]

[calm, soothing] Rest here a while, beside still waters, in his care.

[pause 10s]

[warm] When you're ready, let your body begin to wake. Gently. There's no rush.

[pause 4s]

Be gentle with yourself today, and rest whenever you can. May you find his rest in the ordinary moments of today.

[music 6s]

---

## Week 8 · Faith-centered

**Title:** Peace / *that* / guards.
**Description:** Five minutes to bring your real worries and hopes to God, and rest in his care.
**Approach:** the Grounded honest check-in and room in the chest, with guided personal prayer: a worry, a hope, and a thanks brought to God in your own words.
**Scripture:** Philippians 4:6–7 (verbatim); 1 Peter 5:7 (verbatim).

[music 6s]

[warm, unhurried] Hi. Before we begin, take a moment to check in with yourself. Not how you think you should be feeling. How you actually are.

[pause 5s]

[calm] Find a comfortable position, and let your breath settle into whatever rhythm feels natural.

[pause 5s]

[warm, lightly smiling] Pregnancy can bring so many feelings, sometimes all at once. Excitement. Worry. Tenderness. Doubt. Moments of wonder, and moments of "what have I gotten myself into?" And some days, not much feeling at all.

[pause 5s]

[reassuring] There's no right way to feel right now. God isn't asking you to sort your feelings out first. He invites you to bring them to him, just as they are.

[pause 5s]

[reverent] Listen to these words from Philippians:

*In nothing be anxious, but in everything, by prayer and petition with thanksgiving, let your requests be made known to God. And the peace of God, which surpasses all understanding, will guard your hearts and your thoughts in Christ Jesus.*

[pause 8s]

[warm, reflective] In everything. Not only the tidy things. Not only the brave ones.

[pause 5s]

[calm] Rest a hand over the center of your chest, if you'd like. Feel the warmth there. As you breathe out, imagine the space beneath your hand growing a little wider. A little more room.

[pause 7s]

[gentle] Let's bring it all to him now, slowly.

Is there a worry you've been carrying? Something you keep turning over? Tell God about it, in your own words. Be as honest as you like.

[pause 12s]

[hopeful] Now, is there a hope in your heart? Something you long for, for yourself, or for your baby? Tell him that too.

[pause 10s]

[warm] And is there anything, even something small, you're thankful for today? Offer him that as well.

[pause 8s]

[gentle] Notice how both can be true at once. The hope and the worry. The wonder and the tiredness. You're holding all of it, right now, and you're still here, still breathing.

[pause 6s]

[gentle wonder] Within you, a new life is developing as your body makes room for the work of pregnancy. That may stir wonder, affection, anxiety, or a mixture that changes by the hour. You can recognize how extraordinary it is without feeling cheerful about every moment.

[pause 5s]

[tender] Even an ordinary appointment or a quiet day can stir up feelings that are hard to explain. You don't need to resolve them here. Rest a hand on your belly if you'd like, and allow one small moment of connection without asking it to predict tomorrow.

[pause 7s]

[reverent] Peter wrote that we can come to God:

*casting all your worries on him, because he cares for you.*

[pause 7s]

[prayerful, sincere] Father, thank you for listening. You know every hope and every fear I've named, and the ones I couldn't put into words. I'm leaving them with you. Guard my heart and my thoughts today, and keep me close to you. Amen.

[pause 7s]

[warm] When you're ready, let your hands rest, and let your eyes slowly open.

[pause 3s]

However today feels, you're not doing it wrong. Take this peace with you into the rest of your day.

[music 6s]

---

## Week 9 · Faith-centered

**Title:** Fearfully, / *wonderfully* / made.
**Description:** Five minutes to bring your changing body to God, with honesty and gratitude.
**Approach:** the Grounded gentle movement and kind body scan, with God as the gentle shepherd, an honest word with him about what's hard, and gratitude offered freely.
**Scripture:** Isaiah 40:11 (verbatim excerpt: the second and third sentences); Psalm 139:14 (verbatim).

[music 6s]

[warm, unhurried] Hello. Let's start by letting your body move a little, before we settle.

If it feels good, roll your shoulders slowly, up, back, and down. Once or twice.

[pause 5s]

[calm] Let your head tip gently toward one shoulder… and then the other.

[pause 5s]

Now find a comfortable position and let yourself be still. If you're feeling queasy or unsettled today, sitting a little upright, with something behind your back, might feel better.

[pause 5s]

There's no need to change your breathing. Just notice it, quietly doing its work.

[pause 5s]

[gentle wonder] This body of yours is responding to pregnancy through changes you can see and changes that remain hidden. Even without your direction, it adjusts and makes space for an extraordinary process. Appreciation doesn't have to mean loving every symptom, every ache, or every new shape.

[pause 5s]

[reverent] The prophet Isaiah describes God as a shepherd caring for his flock:

*He will gather the lambs in his arm, and carry them in his bosom. He will gently lead those who have their young.*

[pause 7s]

[tender] Gently leading those who have their young. Held. Led gently. Not hurried.

[pause 5s]

[warm] Today, let's simply be kind to your body, wherever it is.

[pause 4s]

[calm] Bring your attention to your feet, and whatever is beneath them. They've carried you a long way.

[pause 5s]

Your legs. Notice if they feel heavy or tired, and let them rest.

[pause 5s]

[tender] Your belly, where a new life is growing. Rest your hand here, if you'd like.

[pause 8s]

[calm] Your chest, rising and falling. Your heart, keeping its steady rhythm.

[pause 5s]

Your shoulders, your arms, your hands. Let them grow heavy.

[pause 5s]

Your face. Let the small muscles around your eyes and mouth soften.

[pause 6s]

[gentle, reassuring] If there's a place that feels sore, heavy, or uneasy, you don't need to fix it, or feel grateful for it. You can simply bring it to him, and let it be held. Tell him what's hard.

[pause 10s]

[reverent] The psalmist prayed:

*I will give thanks to you, for I am fearfully and wonderfully made. Your works are wonderful. My soul knows that very well.*

[pause 7s]

[gentle] If thankfulness feels true today, offer it to him, in your own words. If it doesn't, simply rest in his care.

[pause 8s]

[prayerful, sincere] Creator God, you made me with care, and you're near to me in every change. Thank you for this little one. On the hard days, be my comfort. Lead me gently, the way you lead those with young. Amen.

[pause 6s]

[warm] Whatever your body is asking for today, whether that's rest, water, a little food, or some fresh air, you're allowed to give it.

[pause 5s]

When you're ready, let your eyes open, and come back slowly.

[pause 3s]

Go gently, knowing you are held.

[music 6s]
