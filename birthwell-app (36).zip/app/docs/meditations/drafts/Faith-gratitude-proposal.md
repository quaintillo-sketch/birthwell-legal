# BirthWell · Gratitude in every Faith-centered meditation

**Proposal for Leah's approval.** Nothing has been changed and nothing has been recorded.

## What this does

Every Faith-centered meditation now thanks God for the baby, inside its closing prayer, which Maren speaks on the listener's behalf.

- **Already there:** 12 weeks already do this and stay as they are: 6, 9, 13, 18, 22, 24, 25, 27, 29, 40, 41 and 42.
- **One short line added:** the other 24 weeks, weeks 7–39, each get one short line of thanks.
- **Reworded:** week 32's existing line is reworded so it clearly thanks God for the baby.

**How it stays sensitive to miscarriage and loss:**

- **Present tense, "this little one", "today":** gratitude for the life being carried now, with no word about the future.
- **No promises:** never "healthy", "safe", "keep my baby" or "everything will be fine".
- **Varied wording:** this little one, the gift, the blessing, the little life I'm carrying. That way it doesn't sound repeated from week to week.
- **Tied to each week's theme where it helps:** "even on the tired days" (week 7), "even on the heavy days" (week 12), "the little one we're making room for" (week 28), "and for the little one I carry" (week 36).
- **Mixed feelings still welcome:** the reflections that already say gratitude can sit alongside honest, mixed feelings are kept. Thankfulness is offered, never demanded.

**Length:** each line adds about 3–5 seconds. All weeks stay within target, at 4:22–5:46.

**Recording:** each change sits in one prayer paragraph. If week 7 has already been recorded, only its prayer needs recording again, about 250 characters. Week 6 is unchanged.

## The prayers, with the added words in bold

**Week 7 · Come and rest** (about 5:37)

> Jesus, I'm tired, and you already know it. Thank you that I don't have to earn your rest, or prove that I deserve it. **Thank you for the little one I'm carrying, even on the tired days.** I'm setting these things down with you. Teach me to rest in you. Amen.

**Week 8 · Peace that guards** (about 5:41)

> Father, thank you for listening. **Thank you for this little one, and for loving us both.** You know every hope and every fear I've named, and the ones I couldn't put into words. I'm leaving them with you. Guard my heart and my thoughts today, and keep me close to you. Amen.

**Week 10 · Bread for today** (about 5:33)

> Lord, thank you that I don't have to hold every tomorrow today. **Thank you for the gift of this little one, here with me today.** Give me what I need for this day, and help me trust you with the rest. Amen.

**Week 11 · Be still and know** (about 5:11)

> Lord, in all the busyness and change of this season, thank you for being God, so I don't have to be. **Thank you for the quiet gift of the life I'm carrying.** Let me be still with you. Amen.

**Week 12 · Pour out your heart** (about 5:24)

> Lord, thank you for listening to all of it, the big things and the small. **Thank you for this little one, even on the heavy days.** I'm placing these in your hands. Hold me up today. Amen.

**Week 14 · A blessing for the little one** (about 5:27)

> Lord, **thank you for the blessing of this little one. Bless** me and keep me. Let your face shine on me. Give me your peace. Amen.

**Week 15 · New every morning** (about 4:53)

> Lord, so much in me is changing. Thank you that your love doesn't change. **Thank you for the little life growing within me.** Meet me with your compassion each morning, and help me trust you through every new thing. Amen.

**Week 16 · Sleep for the beloved** (about 5:02)

> Lord, I give you this day. **Thank you for the little one resting here with me.** Calm me in your love, and give me the rest I need. Amen.

**Week 17 · Never left alone** (about 4:48)

> Lord, thank you that you never leave me. Thank you for the people who carry my burdens with **me, and for the little one I carry.** Where I feel alone, draw near, and bring the help I need. Amen.

**Week 19 · The one thing** (about 4:57)

> Jesus, my days are full, and my mind is busier still. Thank you for inviting me to sit with **you, and for the little one I carry through every busy day.** Help me find my way back to you, even in the middle of everything. Amen.

**Week 20 · Helped until now** (about 5:01)

> Lord, thank you for helping me until **now, and for the little one I'm carrying today.** I trust you with what's ahead. Go before me, and stay with me, every step of the way. Amen.

**Week 21 · Quietness and confidence** (about 5:37)

> Lord, thank you that strength isn't only found in doing. **Thank you for the gift of this little one.** Teach me to rest in you, to grow quietly confident in your care, and to enjoy these days of carrying new life. Amen.

**Week 23 · Strength that renews** (about 5:26)

> Lord, thank you for the strength you've given my body for this **work, and for the little one it carries.** When I feel tired, renew me. Fill me again, day by day, and let me enjoy this season with you. Amen.

**Week 26 · My peace I give you** (about 4:55)

> Jesus, thank you for giving me your own peace. Let it fill my heart and my home, and rest on this little one too. **Thank you for the blessing of this child.** Amen.

**Week 28 · A place prepared with love** (about 5:09)

> Lord, thank you for preparing a place for me in your **love, and for the little one we're making room for.** Bless the home I'm preparing for this little one. Let it be warm with your presence, and full of welcome. Amen.

**Week 30 · As a mother comforts** (about 4:22)

> Lord, thank you for comforting me the way a mother comforts her child. **Thank you for the gift of my baby.** Teach me to comfort my baby with that same tender love. Amen.

**Week 31 · Through the waters** (about 5:46)

> Lord, thank you that you are with me. **Thank you for this little one.** In every wave, and in every rest between, let me know your nearness. Be with my baby, and be with me, every step of the way. Amen.

**Week 32 · A quiet soul** (about 5:26)

> Lord, quiet my soul like a child resting with its mother. Thank you for holding me close, **and for the gift of the little one I hold** within me. Amen.

**Week 33 · Fullness of joy** (about 4:39)

> Lord, thank you that in your presence there is fullness of joy. **Thank you for the little one with me in this quiet place.** Show me the path of life, and let me walk it with you, one step at a time. Amen.

**Week 34 · Held up by love** (about 4:36)

> Lord, thank you for the people who hold me **up, and for the little one I'm carrying.** Give them wisdom, gentleness and strength. Surround my baby and me with your care, and with theirs. Amen.

**Week 35 · Grace that is enough** (about 5:03)

> Lord, thank you that your grace is enough for me. **Thank you for the blessing of this child.** Give me what I need for each day, and for the day I meet my child. Let me lean on you, and rest in you. Amen.

**Week 36 · My help comes from the Lord** (about 5:22)

> Lord, my help comes from you. Thank you for carrying me this **far, and for the little one I carry.** Teach me to rest in you between every effort, and stay near to me and my baby in the days ahead. Amen.

**Week 37 · A time for everything** (about 5:02)

> Lord, thank you for this **season, and for the little one at the heart of it.** I give you my plans and my hopes for this birth. Help me hold them with open hands, and trust you with the timing. Be near to me and my baby, today and every day. Amen.

**Week 38 · My times are in your hand** (about 5:06)

> Lord, I trust in you. You are my God. My times are in your hand. **Thank you for this little one, and for this moment together.** Help me meet each moment with you, one breath at a time. Amen.

**Week 39 · God of all comfort** (about 4:40)

> Father of mercies, God of all comfort, thank you for every comfort you **give, and for the gift of this little one.** In the days ahead, surround me with your comfort, and show me what helps. Amen.

