# Change log · Weeks 37–42

## Leah's editorial revisions (first draft → revised draft)

Eleven passages were replaced word for word as Leah specified:
- **Week 37 Grounded:** "There's something remarkable about the ways your body has adapted…"
- **Week 38 Faith:** "Within you, your baby has been developing in remarkable ways, moment by moment…"
- **Week 40 Grounded:** "A due date is an estimate, not an appointment your baby is expected to keep…". The ending became "One day at a time. There's still room for peace in the waiting."
- **Week 40 Faith:** "A due date is an estimate, and the days around it may bring plans, appointments, and decisions…". The closing prayer became "Lord, I wait with you…"
- **Week 41 Grounded:** "These days may feel long, and your body may be asking for more comfort and rest…"
- **Week 42 Grounded:** "There may be plans and decisions surrounding your baby's arrival…" and "You may imagine the small moments of getting to know your baby…"
- **Week 42 Faith:** "As you prepare to welcome your baby, bring your hopes and the plans ahead into God's presence…" and "Perhaps you imagine a quiet moment of closeness with your baby…"

**Related adjustments:**
- **Week 40 Grounded:** one sentence changed so it doesn't suggest open-ended waiting. "Whether your baby comes tomorrow, next week, or somewhere in between, you can meet each day as it comes…" became "Whatever the coming days hold, you can meet each one as it comes, with patience and a little kindness for yourself."
- **Overview table and notes:** the week 40 and 42 focus lines were updated. The notes now say these meditations complement, never replace, the guidance of each mother's care team.
- **Week 37 Grounded timing:** four silences were shortened by 1–2 seconds to stay at 5:30 or under.

**Checks after the edits:**
- Every script runs 5:06–5:30.
- The Scripture is unchanged and matches the World English Bible.

## Leah's final changes to week 41 Faith (approved)

- "These days are a gift too. You'll only carry this baby once. Let yourself savor the closeness, even in the waiting." became Leah's "Even in these final days, there can be small moments worth appreciating…"
- The prayer's "bring us into each other's arms in your good time" became Leah's "be with us as we prepare to meet". The prayer already has "and" before the phrase, so it reads "Bless my baby, and be with us as we prepare to meet. Amen." The rest of the prayer is unchanged.
- Week 41 Faith now runs 5:26, so no pause changes were needed.

**Status:** Leah approved weeks 37–42, completing editorial approval of the full weeks 6–42 library. Audio will be approved separately.
