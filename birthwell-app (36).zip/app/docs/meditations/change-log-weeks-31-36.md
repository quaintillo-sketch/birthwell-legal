# Change log · Weeks 31–36

## Leah's refinements (first draft → approved)

Nine passages were replaced word for word as Leah specified:
- **Week 31 Grounded:** "Your body is full of extraordinary rhythms…"
- **Week 32 Grounded:** "Your belly. Allow the muscles to soften, wherever that feels comfortable…"
- **Week 32 Faith:** "Allow your belly to soften comfortably…"
- **Week 33 Grounded:** "Within you, your baby is surrounded by a world of warmth, movement, and familiar rhythms…". The closing became "A small reminder of a peaceful place you can return to, whenever you'd like."
- **Week 34 Grounded:** the closing became "You deserve care and support, too. Let yourself welcome it wherever you find it."
- **Week 35 Grounded:** "Think about the extraordinary changes of these past months…"
- **Week 36 Grounded:** "Your baby has rhythms of their own…"
- **Week 36 Faith:** "Within you, your baby has rhythms of their own…"

No transitions or pauses needed changing.

**Checks after the edits:**
- Every script runs 5:07–5:28.
- The Scripture and prayers are unchanged, and every Bible quote still matches the World English Bible.

**Status:** Leah approved the editorial direction of weeks 31–36.
