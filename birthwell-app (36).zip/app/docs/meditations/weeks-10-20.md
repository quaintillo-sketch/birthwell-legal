# Weekly meditations · Weeks 10–20 (approved)

**Status:** editorial direction approved by Leah. Audio not yet recorded; recordings are approved separately. Edited from Leah's clean revision (revision 5). Every move, cut and wording change is listed in `change-log-weeks-06-20.md`, and Leah's revisions are kept word for word in `archive/`. **Faith-centered, weeks 7–42:** rewritten on each week's Grounded script with faith woven in, and approved by Leah after editorial polish and final review; earlier versions are in `archive/faith-before-woven-weeks-07-42.md`. Weeks 24, 25, 33, 34, 39 and 41 are prayer-only (no Scripture passage). Every Faith-centered closing prayer thanks God for the baby, in words tied to that week's theme.

**Narrator at launch:** Maren, for both Grounded and Faith-centered. The scripts don't depend on a particular voice.

How to read the scripts:
- `[music 4s]` (opening) and `[music 6s]` (ending) are music only: the soundscape plays before Maren starts or after she finishes.
- `[pause 5s]` is a silence of that many seconds between thoughts, with the soundscape underneath.
- A blank line between paragraphs is a short natural breath (about 1 second).
- **Tone tags** such as `[warm, unhurried]`, `[gentle wonder]`, `[reverent]` or `[prayerful, sincere]` direct Maren's delivery in ElevenLabs v4. They aren't spoken. A tag applies to its paragraph and carries on until the next tag. The tags avoid words like "whisper", "softly" or "sleepy", which made earlier recordings drift into a whisper.
- *Italic lines* in the Faith-centered scripts are Scripture from the World English Bible, with God's name shown as "the Lord", as in most English Bibles. Each **Scripture** line says whether a passage is verbatim, a verbatim excerpt (part of a verse, words unchanged), or retold in Maren's own words. Only exact Scripture is in italics.
- The title has three parts. The middle part shows in italic clay in the app.
- Every script runs 5:03–5:30 at a slow, natural pace of about 120 words a minute, including all pauses and music.

---

## Week 10 · Grounded

**Title:** One / *day* / at a time.
**Description:** Five minutes to set down tomorrow's questions and come back to today.
**Approach:** noticing how far ahead the mind runs, gently returning to today, and finding three things that are steady right now.

[music 4s]

[warm, unhurried] Hi. Let's take this one day, and this one moment, at a time.

Get comfortable in whatever way your body likes today. Let your hands rest wherever they land.

[pause 5s]

[calm] Your breath can do whatever it wants. You're just here to keep it company.

[pause 6s]

[gentle, understanding] It's natural, in pregnancy, for the mind to race ahead. To the next appointment. The next test result. How you'll manage work, or sleep, or money, or everything else. Months of questions can fit into a single minute of worrying.

[pause 6s]

[calm] For now, let's notice where your mind has been travelling. You don't need to follow it. Just notice the direction.

[pause 10s]

[warm] Now imagine gently calling it home, the way you might call to someone who's wandered a little too far down the beach. No scolding. Just: *come back.*

[pause 8s]

Here is today. Only today.

[pause 5s]

[gentle wonder] Today, your body is occupied with the remarkable, largely unseen work of pregnancy. You don't need to map every step of it to appreciate what's happening now. You can be curious about your baby and still feel unsettled by questions that haven't been answered.

[pause 6s]

[warm, tender] There's something lovely about returning to the present. This breath. The warmth of your hands. The quiet awareness of the little life you're carrying. You don't need to have every detail of the coming months figured out to appreciate what is happening within you today.

[pause 6s]

[calm] Let's find three things that are steady, right now.

First, something supporting you. The chair, the bed, the floor. Notice it holding you without being asked.

[pause 8s]

Second, something you can hear. Maybe the music. Maybe a sound in the room, or outside.

[pause 8s]

Third, something about your own body that feels okay, even a little. Warm hands. Soft shoulders. A comfortable spot.

[pause 10s]

[warm] Three steady things. They were here all along, while your mind was busy elsewhere.

[pause 6s]

[tender] If you'd like, rest a hand on your belly. Today, you're both simply here.

[pause 10s]

Let yourself stay with today a little longer.

[pause 10s]

[warm] When you're ready, open your eyes, and notice one more steady thing around you.

[pause 4s]

Tomorrow can wait. For now, this day is enough.

[music 6s]

---

## Week 10 · Faith-centered

**Title:** Bread / *for* / today.
**Description:** Five minutes to trust God with tomorrow, and ask him for what you need today.
**Approach:** the Grounded return to today and three steady things, with Jesus' teaching on tomorrow, honest prayer for today's needs, and quiet trust.
**Scripture:** Matthew 6:34 (verbatim excerpt: the first sentence); Matthew 6:11 (verbatim).

[music 4s]

[warm, unhurried] Hi. Let's take this one day, and this one moment, at a time.

Get comfortable in whatever way your body likes today. Let your hands rest wherever they land.

[pause 5s]

[calm] Your breath can do whatever it wants. You're just here to keep it company.

[pause 5s]

[gentle, understanding] It's natural, in pregnancy, for the mind to race ahead. To the next appointment. The next test result. How you'll manage work, or sleep, or money, or everything else. Months of questions can fit into a single minute of worrying.

[pause 5s]

[reverent] Jesus knew how heavy that can be. In the Sermon on the Mount, he said:

*Therefore don't be anxious for tomorrow, for tomorrow will be anxious for itself.*

[pause 7s]

[warm, reassuring] He wasn't scolding anyone for worrying. He was inviting them to put tomorrow down, and let God hold it.

[pause 5s]

[calm] For now, let's notice where your mind has been travelling. You don't need to follow it. Just notice the direction.

[pause 8s]

[warm] Now imagine gently calling it home, the way you might call to someone who's wandered a little too far down the beach. Just: *come back.*

[pause 6s]

Here is today. Only today.

[pause 4s]

[reverent] In that same sermon, he taught his followers to pray, simply:

*Give us today our daily bread.*

[pause 7s]

[warm, reflective] Not bread for the whole year. Bread for today.

[pause 5s]

[gentle wonder] Today, your body is occupied with the remarkable, largely unseen work of pregnancy. You don't need to map every step of it to appreciate what's happening now. You can be curious about your baby and still feel unsettled by questions that haven't been answered.

[pause 5s]

[calm] Let's find three things that are steady, right now.

First, something supporting you. The chair, the bed, the floor. Notice it holding you without being asked.

[pause 6s]

Second, something you can hear. Maybe the music. Maybe a sound in the room, or outside.

[pause 6s]

Third, something about your own body that feels okay, even a little. Warm hands. Soft shoulders. A comfortable spot.

[pause 7s]

[warm] Three steady things. They were here all along, while your mind was busy elsewhere.

[pause 5s]

[gentle] What do you need for today? Rest? Patience? Strength for a hard conversation? A little more comfort in your body? Tell God, in your own words. Nothing is too small.

[pause 10s]

[prayerful, sincere] Lord, thank you that I don't have to hold every tomorrow today. Thank you for the little one here with me today. Each day with my baby is a blessing, and I give this little one into your keeping. Give me what I need for this day, and help me trust you with the rest. Amen.

[pause 6s]

[tender] If you'd like, rest a hand on your belly. Today, you're both simply here.

[pause 8s]

[warm] When you're ready, open your eyes, and notice one more steady thing around you.

[pause 4s]

Tomorrow can wait. Go into today with what you need for today.

[music 6s]

---

## Week 11 · Grounded

**Title:** Small / *and* / steady.
**Description:** Five minutes to find calm in an ordinary moment, the kind that's always within reach.
**Approach:** mindful listening, then noticing one ordinary comfort in close detail, like a warm drink in your hands.

[music 4s]

[warm, unhurried] Let's begin with a few seconds of just listening.

[pause 6s]

[calm] Not trying to relax. Not trying to do anything. Just letting sounds arrive.

[pause 6s]

[warm] There's a kind of calm that doesn't need a quiet house, or a free afternoon, or everything going well. It's small, and it's steady, and it can be found inside an ordinary moment.

[pause 6s]

Let's find one.

[calm] If you have a warm drink nearby, you can hold it. If not, simply imagine one. A mug of tea, or warm milk, or anything that comforts you.

[pause 6s]

Feel the warmth spreading into your palms.

[pause 5s]

Notice the weight of the cup. The texture of it under your fingers.

[pause 6s]

If there's steam, imagine it rising slowly, and fading.

[pause 7s]

[warm] This is all it takes. One ordinary thing, noticed fully.

[pause 5s]

[calm] Notice the smell, if there is one. Notice the first small taste, if you take a sip. Let it be the only thing happening, just for a moment.

[pause 10s]

Now let your attention widen, just a little. To your hands. Your arms. Your shoulders, softening as you breathe out.

[pause 8s]

[tender] To your belly.

[pause 3s]

[gentle wonder] While you're noticing this ordinary comfort, remember that pregnancy is happening within the ordinary hours too. The body you're resting in is continually adjusting to carry this baby. Nothing dramatic needs to happen in this room for this moment to be meaningful.

[pause 6s]

[warm, gentle wonder] Perhaps you notice a little warmth in your hands, a softening in your shoulders, or simply the pleasure of being still. These ordinary moments are worth appreciating. And through them all, your body continues its extraordinary work, carrying a new life through even the simplest parts of your day.

[pause 6s]

[warm] Most days aren't made of big peaceful hours. They're made of minutes. Waiting for the kettle. Sitting in the car before you go inside. Lying down for the first moment at night.

[pause 6s]

Any one of those minutes can become a small, steady place, if you let yourself notice it.

[pause 7s]

[calm] Stay here with your ordinary moment a little longer.

[pause 9s]

[warm] When you're ready, set down your cup, real or imagined, and let your eyes open.

[pause 4s]

Small, steady moments like this are always within reach. You know where to find one now.

[music 6s]

---

## Week 11 · Faith-centered

**Title:** Be / *still* / and know.
**Description:** Five minutes of quiet with one short verse, letting it slowly settle into stillness.
**Approach:** the Grounded ordinary moment, a warm drink noticed fully, then one short verse from Psalm 46 that grows shorter with each repeat, with silence between.
**Scripture:** Psalm 46:10 (verbatim excerpt: the first sentence). The shorter repeats that follow are adapted from it and are not shown in italics.

[music 4s]

[warm, unhurried] Let's begin with a few seconds of just listening.

[pause 5s]

[calm] Not trying to relax. Not trying to do anything. Just letting sounds arrive.

[pause 5s]

[warm] There's a kind of calm that doesn't need a quiet house, or a free afternoon, or everything going well. It's small, and it's steady, and it can be found inside an ordinary moment.

[pause 5s]

Let's find one.

[calm] If you have a warm drink nearby, you can hold it. If not, simply imagine one. A mug of tea, or warm milk, or anything that comforts you.

[pause 5s]

Feel the warmth spreading into your palms.

[pause 4s]

Notice the weight of the cup. The texture of it under your fingers.

[pause 5s]

If there's steam, imagine it rising slowly, and fading.

[pause 6s]

[warm] This is all it takes. One ordinary thing, noticed fully.

[pause 5s]

Hold your cup a little longer, and listen.

[pause 3s]

[reverent] Psalm 46 was written for God's people in a time of upheaval. Nations in uproar, the earth itself shaking. And in the middle of it all, God says:

*Be still, and know that I am God.*

[pause 8s]

[calm, reverent] Let's say it again, a little shorter each time, and rest in the silence between.

Be still, and know that I am God.

[pause 10s]

Be still, and know.

[pause 10s]

Be still.

[pause 12s]

Be.

[pause 16s]

[gentle] Stillness isn't the same as having no thoughts. It's more like resting. Letting God be God, while you simply stay near.

[pause 6s]

[calm] Now let your attention widen, just a little. To your hands. Your arms. Your shoulders, softening as you breathe out.

[pause 6s]

[tender] To your belly.

[pause 3s]

[gentle wonder] While you're noticing this ordinary comfort, remember that pregnancy is happening within the ordinary hours too. The body you're resting in is continually adjusting to carry this baby. Nothing dramatic needs to happen in this room for this moment to be meaningful.

[pause 5s]

[prayerful, sincere] Lord, in all the busyness and change of this season, thank you for being God, so I don't have to be. Thank you for the quiet miracle that this little life began at all. I cherish this moment, and I rest this little one in your hands. Let me be still with you. Amen.

[pause 8s]

[warm] When you're ready, set down your cup, real or imagined, and let your eyes open.

[pause 4s]

Stay in that stillness as long as you'd like. It's yours to come back to.

[music 6s]

---

## Week 12 · Grounded

**Title:** Letting / *it* / go.
**Description:** Five minutes to release the tension your body has been quietly holding.
**Approach:** gentle, optional tense-and-release through the hands, shoulders, and face, then letting the mind loosen too.

[music 4s]

[warm, unhurried] Start by noticing your hands. Where are they resting? Are they open, or curled? Soft, or holding on?

[pause 6s]

[gentle] Many of us carry tension without realizing it. In our hands, our shoulders, our faces. Today, let's gently let some of it go.

Settle in comfortably first.

[pause 4s]

[calm] We'll start with your hands. If it feels good, make a soft fist. Not tight. Just enough to notice the effort.

[pause 4s]

And let it go. Let your fingers uncurl and fall open.

[pause 6s]

Notice the difference. The tingling, or the warmth, or the heaviness after letting go.

[pause 4s]

Now your shoulders. If it's comfortable, lift them gently toward your ears.

[pause 4s]

And let them drop.

[pause 6s]

Let them keep sinking, a little more with each breath out.

[pause 6s]

[gentle wonder] Your body has been adapting to a new life while you manage everything else that fills your days. Its work is remarkable; the tension you carry is understandable. Releasing your shoulders for a moment doesn't mean releasing your care for this baby.

[pause 6s]

[calm] Now your face. Scrunch it gently, if you like. Eyes, nose, mouth, all pulling toward the center.

[pause 3s]

And release. Let your forehead go smooth. Let your jaw hang loose.

[pause 7s]

[warm] Your body knows how to let go. It just sometimes needs reminding.

[pause 4s]

[calm, soothing] Let's go once through your whole body, without tensing this time. Just a soft wave of letting go, from the top of your head, down through your shoulders, your arms, your back, your legs, all the way to your feet.

[pause 7s]

[gentle] Now let your mind follow. Is there something you've been holding tightly, a worry, a plan, an expectation? You don't need to solve it. Just imagine your grip on it softening, the way your hands did.

[pause 7s]

[calm, tender] Notice what it feels like to offer your body a little gentleness. Your muscles can soften, your breathing can settle, and for these few minutes, you can simply rest. Your body is carrying out so many intricate processes without needing your conscious attention. You deserve this moment of ease.

[pause 5s]

[tender] If you'd like, rest your open hand on your belly. No effort. Just warmth. Stay soft. There's nothing you need to hold right now.

[pause 9s]

[warm] When you're ready, let some gentle movement come back, and slowly open your eyes.

[pause 4s]

Whatever you let go of, let it stay down for a while.

[music 6s]

---

## Week 12 · Faith-centered

**Title:** Pour out / *your* / heart.
**Description:** Five minutes to bring God what feels heavy, honestly, and let him hold you up.
**Approach:** the Grounded release of hands, shoulders and face, with an honest prayer pouring out what's heavy, and resting in God's care.
**Scripture:** Psalm 62:8 (verbatim excerpt: the second and third sentences); Psalm 55:22 (verbatim excerpt: the first sentence).

[music 4s]

[warm, unhurried] Start by noticing your hands. Where are they resting? Are they open, or curled? Soft, or holding on?

[pause 5s]

[gentle] Many of us carry tension without realizing it. In our hands, our shoulders, our faces. Today, let's gently let some of it go.

Settle in comfortably first.

[pause 4s]

[calm] We'll start with your hands. If it feels good, make a soft fist. Not tight. Just enough to notice the effort.

[pause 4s]

And let it go. Let your fingers uncurl and fall open.

[pause 5s]

Notice the difference. The tingling, or the warmth, or the heaviness after letting go.

[pause 4s]

Now your shoulders. If it's comfortable, lift them gently toward your ears.

[pause 4s]

And let them drop.

[pause 5s]

Let them keep sinking, a little more with each breath out.

[pause 5s]

[gentle wonder] Your body has been adapting to a new life while you manage everything else that fills your days. Its work is remarkable; the tension you carry is understandable. Releasing your shoulders for a moment doesn't mean releasing your care for this baby.

[pause 5s]

[calm] Now your face. Scrunch it gently, if you like. Eyes, nose, mouth, all pulling toward the center.

[pause 3s]

And release. Let your forehead go smooth. Let your jaw hang loose.

[pause 6s]

[warm] Your body knows how to let go. It just sometimes needs reminding.

[pause 4s]

[reverent] The psalms are full of honest prayers. People telling God exactly how they felt, the fears, the frustrations, the hopes. In Psalm 62, David writes:

*Pour out your heart before him. God is a refuge for us.*

[pause 7s]

[warm, reflective] Not "tidy up your heart first." Pour it out.

[pause 4s]

[gentle] Now tell him what's heavy. Whatever comes.

[pause 12s]

[calm, soothing] Let's go once through your whole body, without tensing this time. Just a soft wave of letting go, from the top of your head, down through your shoulders, your arms, your back, your legs, all the way to your feet.

[pause 6s]

[reverent] Another psalm says:

*Cast your burden on the Lord and he will sustain you.*

[pause 7s]

[warm, reassuring] That doesn't mean every burden disappears. It means you don't carry it alone. He holds you up while you carry it.

[pause 5s]

[prayerful, sincere] Lord, thank you for listening to all of it, the big things and the small. Thank you for this little one, even on the heavy days. However this season unfolds, this time with my baby is beautiful. I'm placing these, and this little one, in your hands. Hold me up today. Amen.

[pause 6s]

[tender] If you'd like, rest your open hand on your belly. No effort. Just warmth. Stay soft. There's nothing you need to hold right now.

[pause 8s]

[warm] When you're ready, let some gentle movement come back, and slowly open your eyes.

[pause 4s]

Walk a little lighter today, knowing he holds what you've given him.

[music 6s]

---

## Week 13 · Grounded

**Title:** Small / *good* / things.
**Description:** Five minutes to notice what's been quietly good, even on an ordinary or difficult day.
**Approach:** three small moments recalled in detail, then letting them warm the body, without any pressure to feel positive.

[music 4s]

[warm, unhurried] Think of one small thing from the last day or so that was good. It doesn't need to be big. A warm shower. A kind text. The first sip of something cold.

[pause 6s]

[calm] Hold that thought, and let yourself get comfortable.

[pause 6s]

[gentle, understanding] This meditation is about noticing good things. Not because everything is good. Some days in pregnancy are hard, and that's real. But even hard days can hold small moments worth noticing.

[pause 6s]

[warm] Let's go back to that first good thing. Picture it clearly. Where were you? What did it feel like? Let yourself enjoy it again, just for a moment.

[pause 10s]

Now let a second one come to mind. Maybe something someone said. Maybe something you saw. Light through a window. A song. A laugh.

[pause 10s]

And a third. Maybe something your body did well. A good night's sleep, a meal that sat right, a walk that felt easy.

[pause 10s]

[gentle wonder] One small good thing may simply be the thought that you're carrying a baby, even if that thought comes with complicated feelings. Your body is involved in an extraordinary process, and it's reasonable to feel both thankful for its work and tired of its demands.

[pause 6s]

[reassuring] You don't have to turn gratitude into another task. A moment of comfort is worth noticing simply because it feels good, right here and now.

[pause 6s]

If it's hard to find three today, that's all right. One is enough. Even making space for these few minutes is a small good thing.

[pause 8s]

[calm] Three small good things. Notice where you feel them in your body. Maybe a softening in your chest. A little warmth. Or maybe nothing much, and that's fine too.

[pause 10s]

[tender] If you'd like, rest a hand on your belly. Your baby is part of your days now, even the ordinary ones.

[pause 10s]

[warm] Small good things are easy to miss. They don't announce themselves. But they add up, quietly, the way the days of this pregnancy are adding up.

[pause 10s]

When you're ready, let your eyes open.

[pause 4s]

May you notice a few more small good things before the day is done.

[music 6s]

---

## Week 13 · Faith-centered

**Title:** Every / *good* / gift.
**Description:** Five minutes to notice small, good gifts, and thank the giver.
**Approach:** the Grounded three small good things, each answered with a simple "thank you" to God, the Father of lights.
**Scripture:** James 1:17 (verbatim excerpt: the first part of the verse).

[music 4s]

[warm, unhurried] Think of one small thing from the last day or so that was good. It doesn't need to be big. A warm shower. A kind text. The first sip of something cold.

[pause 5s]

[calm] Hold that thought, and let yourself get comfortable.

[pause 5s]

[gentle, understanding] This meditation is about noticing good things. Not because everything is good. Some days in pregnancy are hard, and that's real. But even hard days can hold small moments worth noticing.

[pause 5s]

[reverent] James, writing to the early church, said this:

*Every good gift and every perfect gift is from above, coming down from the Father of lights.*

[pause 7s]

[warm, unhurried] Every good gift. Not only the big ones. The small, everyday ones too.

[pause 5s]

[warm] Let's go back to that first good thing. Picture it clearly. Where were you? What did it feel like? Let yourself enjoy it again, just for a moment.

[pause 8s]

[prayerful] Now simply say, in your heart: Thank you.

[pause 6s]

[warm] Let a second one come to mind. Maybe something someone said. Maybe something you saw. Light through a window. A song. A laugh.

[pause 8s]

[prayerful] Thank you.

[pause 6s]

[warm] And a third. Maybe something your body did well. A good night's sleep, a meal that sat right, a walk that felt easy.

[pause 8s]

[prayerful] Thank you.

[pause 6s]

[gentle wonder] One small good thing may simply be the thought that you're carrying a baby, even if that thought comes with complicated feelings.

[pause 5s]

[reassuring] If thankfulness feels hard today, that's all right. God isn't asking you to pretend everything is easy. You can tell him that too. Gratitude and honesty can sit side by side.

[pause 6s]

[prayerful, sincere] Father of lights, every good thing in my life comes from you. Thank you for the small gifts I so often miss, and for the miracle of this little one. Every day I carry this little one is a good gift from you, and I trust this little life to your love. Open my eyes to your goodness today, even in ordinary moments. Amen.

[pause 6s]

[tender] If you'd like, rest a hand on your belly. Your baby is part of your days now, even the ordinary ones.

[pause 8s]

[warm] When you're ready, let your eyes open.

[pause 4s]

Watch for his good gifts today. They're often closer than we think.

[music 6s]

---

## Week 14 · Grounded

**Title:** A few / *words* / for you.
**Description:** Five minutes to speak to your baby, silently or out loud, in whatever way feels natural.
**Approach:** a guided first conversation with the baby, with no pressure on how it feels.

[music 4s]

[warm, unhurried] This meditation is a little different. Today, you're invited to talk to your baby.

[reassuring] If that feels natural, wonderful. If it feels strange, or awkward, or a bit too soon, that's completely okay. You can just listen along, and try it whenever you're ready.

[pause 6s]

[calm] Find a comfortable position. If you'd like, rest one or both hands on your belly.

[pause 6s]

Let your breath settle in its own time.

[pause 6s]

[gentle wonder] Your baby is developing within the shelter of your body, and that relationship is already part of your everyday life, even if you don't yet feel a clear bond. Your body has been making adjustments in the background while you've gone about ordinary routines.

[pause 6s]

[warm] Some people find it meaningful to start talking to their baby early, long before they meet. A voice, a few words, a habit that can grow over the months ahead.

[pause 6s]

[tender] Imagine, for a moment, what this little one might want to know about you.

[pause 8s]

You might start simply. Silently, or in a whisper: *Hello. It's me.*

[pause 9s]

[reassuring] You may feel excited to speak, or a little unsure what to say. There's no test to pass and no particular feeling you need to find. Even a quiet hello, or a hand resting on your belly, can be enough for today.

[pause 6s]

[warm] You could tell your baby something about your day. Where you are right now. What you can hear.

[pause 9s]

You could tell them something about yourself. Something you love. Something you're looking forward to.

[pause 9s]

Maybe a place you'd like to show them one day. A song you might sing. Something you hope you'll do together.

[pause 10s]

[tender] And if there's something you're feeling, hope, or nervousness, or wonder, you can say that too. There's no wrong thing to say.

[pause 9s]

Or you can say nothing at all, and simply be together in the quiet.

[pause 10s]

[warm] Whatever you said, or didn't say, this is how relationships begin. A little at a time.

[pause 10s]

When you're ready, let your hands rest, and slowly open your eyes.

[pause 4s]

You can pick up this conversation any time. There's no rush to it.

[music 6s]

---

## Week 14 · Faith-centered

**Title:** A blessing / *for* / the little one.
**Description:** Five minutes to speak to your baby, and pray an ancient blessing over them.
**Approach:** the Grounded first words to your baby, then the priestly blessing from Numbers prayed slowly, line by line, over your baby and over you.
**Scripture:** Numbers 6:24–26 (verbatim).

[music 4s]

[warm, unhurried] This meditation is a little different. Today, you're invited to talk to your baby.

[reassuring] If that feels natural, wonderful. If it feels strange, or awkward, or a bit too soon, that's completely okay. You can just listen along, and try it whenever you're ready.

[pause 5s]

[calm] Find a comfortable position. If you'd like, rest one or both hands on your belly.

[pause 5s]

Let your breath settle in its own time.

[pause 5s]

[gentle wonder] Your baby is developing within the shelter of your body, and that relationship is already part of your everyday life, even if you don't yet feel a clear bond. Your body has been making adjustments in the background while you've gone about ordinary routines. God has woven a quiet wisdom into your body, and it has been at work all along.

[pause 5s]

[tender] Imagine, for a moment, what this little one might want to know about you.

[pause 6s]

You might start simply. Silently, or in a whisper: *Hello. It's me.*

[pause 7s]

[warm] You could tell your baby something about your day. Where you are right now. What you can hear.

[pause 7s]

You could tell them something about yourself. Something you love. Something you're looking forward to.

[pause 7s]

[warm] Whatever you said, or didn't say, this is how relationships begin. A little at a time.

[pause 6s]

[reverent] Now, one of the oldest blessings in Scripture. In the book of Numbers, God gave Moses these words for Aaron and the priests to speak over his people. People have prayed them over children for thousands of years.

Listen to them once through:

*The Lord bless you, and keep you. The Lord make his face to shine on you, and be gracious to you. The Lord lift up his face toward you, and give you peace.*

[pause 8s]

[warm, reassuring] A blessing isn't a guarantee of an easy road. It's an asking. Placing someone you love into God's care.

[pause 5s]

[reverent, tender] Let's pray it slowly over your baby now, line by line. You can echo the words silently, or simply listen.

The Lord bless you, and keep you.

[pause 7s]

The Lord make his face to shine on you, and be gracious to you.

[pause 7s]

The Lord lift up his face toward you, and give you peace.

[pause 9s]

[gentle] Now take a moment to pray for your baby in your own words. Whatever hopes are in your heart. Perhaps that they'll know they're loved. That they'll have courage, and kindness, and people around them.

[pause 10s]

[warm] And this blessing is for you too. Let it rest on you, as a mother, in this season.

[pause 5s]

[prayerful, sincere] Lord, thank you for the blessing of this little one. Bless me and keep me. Let your face shine on me. Give me your peace. Amen.

[pause 6s]

[warm] When you're ready, let your hands rest, and slowly open your eyes.

[pause 4s]

Go in his peace, both of you.

[music 6s]

---

## Week 15 · Grounded

**Title:** Still / *you* / and growing.
**Description:** Five minutes to honor how you're changing, and everything about you that remains.
**Approach:** a gentle visualization of who you were before, who you are now, and the self that carries through.

[music 4s]

[warm, unhurried] Picture yourself a year or so ago. Before this pregnancy. What did an ordinary day look like? What did you care about? What made you laugh?

[pause 10s]

[calm] Hold that picture gently as you settle into a comfortable position.

[pause 6s]

[gentle, understanding] Pregnancy changes so much. Your body. Your energy. Your plans. Sometimes, how other people see you. It's natural to wonder how much of you is changing too.

[pause 6s]

[warm] Let's take a moment with that.

Bring to mind something you've always loved. A place, a song, a food, a kind of weather.

[pause 9s]

That's still you.

[pause 5s]

Bring to mind something you're good at. Something people come to you for.

[pause 9s]

Still you.

[pause 5s]

Bring to mind a way you've grown in the last few months. Something you've learned, or carried, or handled, that you didn't know you could.

[pause 9s]

That's you too. Growing.

[pause 8s]

[gentle wonder] As your baby develops, your body is changing in visible and invisible ways. It can be astonishing to think of how much it does without your conscious instruction. It can also be strange to feel that your familiar self is changing alongside it.

[pause 6s]

[calm] Think of a tree. Each year it adds a new ring, and grows a little wider and taller. But the heart of it doesn't disappear. Every year is still inside it.

[pause 8s]

[tender, reassuring] Some days you might miss parts of your old life. The freedom, the energy, the body you knew. That isn't ingratitude. It's a natural part of a big change, and those feelings deserve gentleness too.

[pause 6s]

You can admire this process without needing to admire every physical sensation or new limitation. The person you have been and the mother you are becoming don't have to compete. There is room for both.

[pause 8s]

[tender] If you'd like, rest a hand on your belly. Your baby will come to know the person you've always been, as well as who you're becoming.

[pause 10s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

You're still you. And you're growing too.

[music 6s]

---

## Week 15 · Faith-centered

**Title:** New / *every* / morning.
**Description:** Five minutes to bring what's changing to the God whose compassion is new each morning.
**Approach:** the Grounded reflection on who you've always been and how you're growing, with God's compassion, new every morning, and the things about you that won't change.
**Scripture:** Lamentations 3:22–23 (verbatim excerpt: from "his compassion" to the end of verse 23).

[music 4s]

[warm, unhurried] Picture yourself a year or so ago. Before this pregnancy. What did an ordinary day look like? What did you care about? What made you laugh?

[pause 8s]

[calm] Hold that picture gently as you settle into a comfortable position.

[pause 5s]

[gentle, understanding] Pregnancy changes so much. Your body. Your energy. Your plans. Sometimes, how other people see you. It's natural to wonder how much of you is changing too.

[pause 5s]

[warm] Let's take a moment with that.

Bring to mind something you've always loved. A place, a song, a food, a kind of weather.

[pause 7s]

That's still you.

[pause 4s]

Bring to mind something you're good at. Something people come to you for.

[pause 7s]

Still you.

[pause 4s]

Bring to mind a way you've grown in the last few months. Something you've learned, or carried, or handled, that you didn't know you could.

[pause 7s]

That's you too. Growing.

[pause 6s]

[reverent] In the book of Lamentations, written during a time of upheaval, there's a moment of surprising hope. The writer says of God:

*his compassion doesn't fail. They are new every morning. Great is your faithfulness.*

[pause 8s]

[warm, reflective] Everything around the writer had changed. But God's compassion hadn't. It met the writer again, new, each morning.

[pause 6s]

[gentle wonder] As your baby develops, your body is changing in visible and invisible ways. It can be astonishing to think of how much it does without your conscious instruction. It can also be strange to feel that your familiar self is changing alongside it.

[pause 5s]

[tender, reassuring] Some days you might miss parts of your old life. The freedom, the energy, the body you knew. That isn't ingratitude. It's a natural part of a big change, and those feelings deserve gentleness too.

[pause 5s]

[warm, reassuring] Some things about you won't change at all. You are still his. Still loved. Still known, through every season of this pregnancy, and every season after.

[pause 7s]

[prayerful, sincere] Lord, so much in me is changing. Thank you that your love doesn't change. Thank you for the little life growing within me, morning by morning. Every new morning with this little one is a wonder, and I rest them in your faithful love. Meet me with your compassion each morning, and help me trust you through every new thing. Amen.

[pause 7s]

[tender] If you'd like, rest a hand on your belly. Your baby will come to know the person you've always been, as well as who you're becoming.

[pause 8s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

You're still you. His compassion will meet you new, every morning.

[music 6s]

---

## Week 16 · Grounded

**Title:** Into / *a softer* / evening.
**Description:** Five minutes to wind down your body and mind, for the end of the day or whenever you need rest.
**Approach:** an evening wind-down that dims the senses one by one and lets the day go, with a longer quiet ending.

[music 4s]

[calm, soothing] If it's evening, you might dim the lights, or turn them off altogether. If it's daytime, that's okay too. Let this be a small evening, wherever you are.

[pause 6s]

Find the most comfortable position you can. On your side, with a pillow between your knees, is often lovely at this stage. Use whatever support you have.

[pause 6s]

Let your breath slow down by itself. There's nowhere to be.

[pause 6s]

Let's let the day go, one piece at a time.

First, let your eyes rest. Let them grow heavy behind your eyelids.

[pause 5s]

Let your ears soften, so sounds become just a gentle background.

[pause 5s]

Let your jaw loosen, and your tongue rest at the bottom of your mouth.

[pause 5s]

Let your hands lie heavy and open.

[pause 8s]

[gentle wonder] Even as the house grows quiet, pregnancy doesn't stop being present. Your body continues the remarkable work of supporting this developing baby through the night. You don't have to stay awake to supervise that work, and you don't need to make yourself feel grateful before you rest.

[pause 6s]

[tender, reassuring] Whatever the day brought, tenderness toward your baby, worry, discomfort, or simple exhaustion, can come into this softer evening with you. Let tonight be a place to set down the expectation that you must feel one certain way.

[pause 6s]

[calm, soothing] Now think back over today, without judging any of it. The things that went well. The things that didn't. The things left undone.

[pause 8s]

Imagine each one as a lamp in a long hallway. One by one, you walk past them, turning each lamp down.

[pause 10s]

Notice the hallway growing softer and dimmer. Quieter. Your footsteps slowing. At the end of it, there's a warm, dark room, with a bed made up just for you.

[pause 10s]

The day is finished, or nearly. Whatever is left can wait until morning.

[pause 6s]

[tender] If you'd like, rest a hand on your belly. Let yourself feel the warmth there as you both settle.

[pause 7s]

[calm, soothing] Stay here. Let your body grow heavier and softer.

[pause 14s]

If you're drifting toward sleep, let yourself go. If not, simply enjoy the quiet.

[pause 6s]

Goodnight, or good rest, whichever you need.

[music 6s]

---

## Week 16 · Faith-centered

**Title:** Sleep / *for* / the beloved.
**Description:** Five minutes to give the day to God and rest in his love.
**Approach:** the Grounded softer evening, letting the day go piece by piece, with each part of the day given to God and the promise of being calmed in his love.
**Scripture:** Psalm 127:2 (verbatim excerpt: the end of the verse); Zephaniah 3:17 (verbatim excerpt: the third and fourth sentences).

[music 4s]

[calm, soothing] If it's evening, you might dim the lights, or turn them off altogether. If it's daytime, that's okay too. Let this be a small evening, wherever you are.

[pause 5s]

Find the most comfortable position you can. On your side, with a pillow between your knees, is often lovely at this stage. Use whatever support you have.

[pause 5s]

Let your breath slow down by itself. There's nowhere to be.

[pause 5s]

[reverent, calm] There's a line at the end of Psalm 127 that says:

*for he gives sleep to his loved ones.*

[pause 7s]

[warm, soothing] Sleep, and rest, as a gift. Not something you have to earn by finishing everything first.

[pause 5s]

[calm, soothing] Let's begin with your body, one piece at a time.

First, let your eyes rest. Let them grow heavy behind your eyelids.

[pause 4s]

Let your ears soften, so sounds become just a gentle background.

[pause 4s]

Let your jaw loosen, and your tongue rest at the bottom of your mouth.

[pause 4s]

Let your hands lie heavy and open.

[pause 6s]

[gentle wonder] Even as the house grows quiet, pregnancy doesn't stop being present. Your body continues the remarkable work of supporting this developing baby through the night, just as God designed it to. You don't have to stay awake to supervise that work, and you don't need to make yourself feel grateful before you rest.

[pause 5s]

[calm, soothing] Now let's give the day to God, without judging any of it.

[gentle] What went well today? Thank him for it.

[pause 8s]

What was hard? Tell him about it, and leave it with him.

[pause 8s]

What's left undone? Let it wait. It's in his hands until morning.

[pause 8s]

[reverent, calm] Now listen to these words, spoken by the prophet Zephaniah to God's people:

*He will calm you in his love. He will rejoice over you with singing.*

[pause 8s]

[tender, soothing] Imagine being sung over. Calmed. The way you might one day sing over your own child.

[pause 6s]

[tender] If you'd like, rest a hand on your belly. Let yourself feel the warmth there as you both settle.

[pause 6s]

[prayerful, soothing] Lord, I give you this day. Thank you for the little one resting here with me. Calm me in your love, and give me the rest I need. Amen.

[pause 8s]

[calm, soothing] Stay here. Let your body grow heavier and softer.

[pause 10s]

If you're drifting toward sleep, let yourself go. If not, rest here in his care.

[pause 5s]

Rest well, beloved.

[music 6s]

---

## Week 17 · Grounded

**Title:** Held / *by* / many hands.
**Description:** Five minutes to notice the support around you, whatever shape it takes.
**Approach:** noticing physical support first, then the people and places that help, with room for those who feel short on support.

[music 4s]

[warm, unhurried] Let's begin by noticing what's holding you up, right now. Literally.

The surface beneath you. The pillow behind your head, or the chair at your back. Let yourself lean into it.

[pause 8s]

[calm] You don't have to hold yourself up. Something is already doing it for you.

[pause 8s]

[warm, reassuring] Support comes in many shapes. Some people have a partner, a family, a close circle of friends. Some have one or two people. Some are doing a lot of this on their own. Wherever you are, this meditation is for you.

[pause 6s]

[warm] Let's notice the support that's there, even in small ways.

Bring to mind a person who's been kind to you during this pregnancy. It might be someone close. It might be a nurse, a coworker, a neighbor, a stranger who held a door.

[pause 12s]

Picture their face, if you can. Notice how it feels to remember their kindness.

[pause 10s]

[gentle wonder] Your body is offering this baby a place to develop, while you deserve care and support in your own right. Pregnancy isn't a project you should have to manage alone. The extraordinary work happening inside you doesn't make your ordinary needs less important.

[pause 6s]

[tender, reassuring] If your support system feels complicated, or you're not ready to share every feeling about this pregnancy, you can start smaller. A message, a meal, a quiet check-in: receiving any of those is part of caring for yourself.

[pause 6s]

[warm] Now think of a place that helps you feel supported. A favorite room. A walk you love. A spot where you can breathe more easily.

[pause 12s]

And think of something that supports you that isn't a person or a place. A routine. A song. A favorite blanket. Even this quiet moment.

[pause 12s]

And notice the ways you support yourself, too. Resting when you need to. Eating when you're hungry. Choosing to spend these minutes here. That's support as well.

[pause 8s]

[tender] If you'd like, rest a hand on your belly. Your baby is being held too, every moment, by you.

[pause 10s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

You don't have to do this all by yourself. Let yourself be held, in whatever ways you can.

[music 6s]

---

## Week 17 · Faith-centered

**Title:** Never / *left* / alone.
**Description:** Five minutes to rest in God's presence, and notice the people he sends to help carry the load.
**Approach:** the Grounded noticing of what holds you up and who has been kind, with God's promise never to leave you and thanks for the people who share your burdens.
**Scripture:** Hebrews 13:5 (verbatim excerpt: the words quoted as God's, at the end of the verse); Galatians 6:2 (verbatim).

[music 4s]

[warm, unhurried] Let's begin by noticing what's holding you up, right now. Literally.

The surface beneath you. The pillow behind your head, or the chair at your back. Let yourself lean into it.

[pause 6s]

[calm] You don't have to hold yourself up. Something is already doing it for you.

[pause 6s]

[reverent] The letter to the Hebrews reminds its readers of something God has said:

*I will in no way leave you, neither will I in any way forsake you.*

[pause 8s]

[warm, reassuring] In no way. Not in the hard moments. Not in the uncertain ones. Not when you feel strong, and not when you feel weak.

[pause 6s]

Support comes in many shapes. Some people have a partner, a family, a close circle of friends. Some have one or two people. Some are doing a lot of this on their own. Wherever you are, this meditation is for you.

[pause 5s]

[reverent] God often shows his care through people. Paul wrote to the churches in Galatia:

*Bear one another's burdens, and so fulfill the law of Christ.*

[pause 7s]

[warm] Bring to mind a person who's been kind to you during this pregnancy. It might be someone close. It might be a nurse, a coworker, a neighbor, a stranger who held a door.

[pause 9s]

Picture their face, if you can. Notice how it feels to remember their kindness. Thank God for them.

[pause 8s]

[gentle wonder] Your body is offering this baby a place to develop, while you deserve care and support in your own right. Pregnancy isn't a project you should have to manage alone. The extraordinary work happening inside you doesn't make your ordinary needs less important.

[pause 5s]

[tender, reassuring] If your support system feels complicated, or you're not ready to share every feeling about this pregnancy, you can start smaller. A message, a meal, a quiet check-in: receiving any of those is part of caring for yourself.

[pause 5s]

[warm] And notice the ways you support yourself, too. Resting when you need to. Eating when you're hungry. Choosing to spend these minutes here. That's support as well.

[pause 6s]

[prayerful, sincere] Lord, thank you that you never leave me. Thank you for the people who carry my burdens with me, and for the little one I carry. Where I feel alone, draw near, and bring the help I need. Amen.

[pause 7s]

[tender] If you'd like, rest a hand on your belly. Your baby is being held too, every moment, by you.

[pause 8s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

You don't have to do this all by yourself. He goes with you into the rest of today.

[music 6s]

---

## Week 18 · Grounded

**Title:** Listening / *for* / you.
**Description:** Five minutes of quiet attention inward, wherever you are in getting to know your baby.
**Approach:** turning attention inward like listening to the sea, with no expectation of feeling movement.

[music 4s]

[warm, unhurried] Let's get quiet enough to listen inward.

Find a comfortable position. Lying on your side, or sitting reclined, often makes it easier to notice what's happening inside.

[pause 8s]

[calm] Let the sounds of the room fade into the background, like distant waves.

[pause 8s]

[warm, reassuring] Somewhere in these weeks, some people begin to notice tiny movements. Flutters, taps, little bubbles. For others, it takes longer. Every pregnancy has its own timing, and there's no right moment for this.

[pause 6s]

[tender] Rest your hands on your belly, if you'd like. Let them be still and soft.

[pause 8s]

[calm] Now bring your attention down to where your hands are resting. Notice warmth. Notice the slow rise and fall of your breath.

[pause 12s]

[gentle] You don't need to look for any particular sensation right now. Let this be a moment to notice your own breath, the warmth of your hands, and the quiet connection of being here with your baby.

[pause 6s]

[gentle wonder] Instead, simply recognize the remarkable changes taking place as your body carries this baby. You can feel curious, amazed, or uncertain. A gentle hand on your belly can be a gesture of connection without expecting anything in return.

[pause 6s]

[calm] Notice the stillness, too. Stillness is part of listening.

[pause 10s]

[tender] Your baby lives surrounded by your rhythms. Your heartbeat. Your breathing. The movement of your body through the day. In their own way, they're getting to know you too.

[pause 10s]

[warm] If you feel something, a flutter, a nudge, a little rolling sensation, you can greet it, silently. *Hi. I'm here.*

[pause 8s]

[calm] Whether you notice a gentle sensation or only the warmth of your hands, you can let this be a moment of quiet attention, without needing to achieve anything.

[pause 14s]

[warm] Over the coming weeks, quiet moments like this may become some of your favorite times together.

[pause 6s]

When you're ready, let your attention widen again to the room around you, and slowly open your eyes.

[pause 4s]

You can return to this gentle moment of connection whenever you'd like.

[music 6s]

---

## Week 18 · Faith-centered

**Title:** A greeting / *of* / joy.
**Description:** Five minutes with Mary and Elizabeth, and a quiet hello to your own baby.
**Approach:** the Grounded quiet listening inward, with the meeting of Mary and Elizabeth, a greeting to your baby, and thanks for the people who share this season.
**Scripture:** Luke 1:39–45 (the story retold in Maren's own words); Luke 1:41 (verbatim excerpt: the first part of the verse); Luke 1:44 (verbatim).

[music 4s]

[warm, unhurried] Let's get quiet enough to listen inward.

Find a comfortable position. Lying on your side, or sitting reclined, often makes it easier to notice what's happening inside.

[pause 6s]

[calm] Let the sounds of the room fade into the background, like distant waves.

[pause 6s]

[warm, storytelling] As you settle, here's a story. Long ago, two expectant mothers met in a house in the hill country of Judah.

Mary was young, and newly pregnant, carrying news she was still trying to understand. She hurried to visit her relative, Elizabeth, who was also expecting, after years of waiting.

[pause 4s]

Imagine Mary arriving at the door, tired from her journey. Imagine Elizabeth hearing her voice.

[reverent] Luke tells us:

*When Elizabeth heard Mary's greeting, the baby leaped in her womb.*

[pause 6s]

[reverent, joyful] And Elizabeth said to her:

*For behold, when the voice of your greeting came into my ears, the baby leaped in my womb for joy!*

[pause 7s]

[warm] Two women, both carrying new life. Sharing their joy, and their questions, and staying together for months.

[pause 5s]

[warm, reassuring] Somewhere in these weeks, some people begin to notice tiny movements. Flutters, taps, little bubbles. For others, it takes longer. Every pregnancy has its own timing, and there's no right moment for this.

[pause 5s]

[tender] Rest your hands on your belly, if you'd like. Let them be still and soft.

[pause 6s]

[calm] Notice the warmth beneath your hands, and the slow rise and fall of your breath.

[pause 8s]

[gentle] You don't need to look for any particular sensation right now.

[pause 5s]

[tender] Your baby lives surrounded by your rhythms. Your heartbeat. Your breathing. The movement of your body through the day. In their own way, they're getting to know you too.

[pause 6s]

[warm] Elizabeth's joy began with a greeting. Imagine greeting your baby now, in your heart. A simple hello, full of love.

[pause 8s]

[gentle] Who is an Elizabeth for you? Someone you can share this season with? Thank God for them. Or, if you're longing for someone like that, ask him for it.

[pause 7s]

[prayerful, sincere] Lord, thank you for the joy of new life, and for the people who share it with me. Help me treasure these sweet days of getting to know my baby, one tender hello at a time. Let joy find its way into my heart, even in the waiting. Amen.

[pause 7s]

[warm] When you're ready, let your attention widen again to the room around you, and slowly open your eyes.

[pause 4s]

May you find small joys to share today.

[music 6s]

---

## Week 19 · Grounded

**Title:** The pause / *between* / things.
**Description:** Five minutes to learn a one-minute pause you can carry into any busy day.
**Approach:** a short, practical practice, rehearsed twice, for using between tasks.

[music 4s]

[warm, lightly smiling] Some days feel like one long list. Work, errands, appointments, meals, messages, and somewhere in there, growing a baby.

[pause 5s]

[warm] Today, let's practice a small pause you can take anywhere. Between meetings. In a parking lot. While the kettle boils. It takes about a minute.

Let yourself settle first.

[pause 6s]

[calm, clear] Here's how it goes. There are just three steps.

First: stop. Let your hands go still, wherever they are.

[pause 5s]

Second: feel your feet. Notice where they touch the floor, or the bed, or each other.

[pause 7s]

Third: let one breath out be a little longer and softer than the rest. Not forced. Just unhurried.

[pause 7s]

That's it. Stop. Feet. One soft breath out.

[pause 8s]

[warm] It's small on purpose. Small enough to remember on a hard day. Small enough to do with a phone in your hand, or a toddler on your hip, or in a waiting room before an appointment.

[pause 6s]

[gentle wonder] Wherever you pause, in a hallway, beside the car, or between errands, your body is carrying this pregnancy with you. Remarkable work is unfolding even when the rest of life seems ordinary. You can appreciate it for a second without having to stop your entire day.

[pause 6s]

[calm] Let's practice it once more, slowly.

Stop. Let everything go still.

[pause 5s]

Feet. Feel them, heavy and grounded.

[pause 7s]

One soft breath out.

[pause 8s]

[warm] Notice how you feel now. Maybe a little more here. Maybe just the same. Either is fine.

[pause 6s]

[tender] If you'd like, add a fourth step whenever you have a moment: a hand on your belly, as a small hello to your baby in the middle of your day.

One gentle breath can hold both gratitude for this developing life and whatever thoughts happen to be on your mind. You don't have to push either away.

[pause 10s]

[warm, reassuring] These pauses won't make a busy day less busy. But they can give you small places to land, in between all the things.

[pause 8s]

When you're ready, let your eyes open.

[pause 4s]

This pause is yours. It fits into any part of your day.

[music 6s]

---

## Week 19 · Faith-centered

**Title:** The / *one* / thing.
**Description:** Five minutes to pause in a full day, and sit with Jesus for a moment.
**Approach:** the Grounded one-minute pause (stop, feet, one soft breath out), with the story of Martha and Mary and an invitation to sit at Jesus' feet.
**Scripture:** Luke 10:38–42 (the story retold in Maren's own words); Luke 10:41–42 (verbatim excerpt: Jesus' words, from "you are anxious" to "one thing is needed").

[music 4s]

[warm, lightly smiling] Some days feel like one long list. Work, errands, appointments, meals, messages, and somewhere in there, growing a baby.

[pause 5s]

[warm] Today, let's practice a small pause you can take anywhere. Between meetings. In a parking lot. While the kettle boils. It takes about a minute.

Let yourself settle first.

[pause 5s]

[calm, clear] Here's how it goes. There are just three steps.

First: stop. Let your hands go still, wherever they are.

[pause 5s]

Second: feel your feet. Notice where they touch the floor, or the bed, or each other.

[pause 6s]

Third: let one breath out be a little longer and softer than the rest. Not forced. Just unhurried.

[pause 6s]

That's it. Stop. Feet. One soft breath out.

[pause 6s]

[tender] If you'd like, add a fourth step whenever you have a moment: a hand on your belly, as a small hello to your baby in the middle of your day.

[pause 6s]

[gentle wonder] Wherever you pause, in a hallway, beside the car, or between errands, your body is carrying this pregnancy with you. Remarkable work is unfolding even when the rest of life seems ordinary. You can appreciate it for a second without having to stop your entire day.

[pause 5s]

[warm, storytelling] In Luke's Gospel, Jesus visits the home of two sisters, Martha and Mary. Martha is busy getting everything ready. Mary sits at Jesus' feet, listening.

[pause 5s]

[reverent, tender] Martha, worn out, asks Jesus to tell her sister to help. And Jesus answers her, gently:

*Martha, Martha, you are anxious and troubled about many things, but one thing is needed.*

[pause 8s]

[warm, reassuring] Notice that he says her name twice. Kindly. He isn't scolding her for caring, or for working hard. He's inviting her to stop for a moment, and be with him.

[pause 6s]

[tender] Imagine Jesus saying your name the same way. Kindly. Twice.

[pause 7s]

[gentle] What are the many things you're anxious and troubled about right now? You can name them to him.

[pause 8s]

[calm] Now imagine setting them down, just for these few minutes, and sitting at his feet. There's nothing to prepare. Nothing to prove. Just be with him.

[pause 10s]

[prayerful, sincere] Jesus, my days are full, and my mind is busier still. Thank you for inviting me to sit with you, and for the little one who is with me in every busy hour. Help me find my way back to you, even in the middle of everything. Amen.

[pause 7s]

[warm] When you're ready, let your eyes open.

[pause 4s]

This pause is yours. Sit at his feet whenever you can, even for a moment in a busy day.

[music 6s]

---

## Week 20 · Grounded

**Title:** Halfway, / *and* / here.
**Description:** Five minutes to look back on how far you've come, and ahead with openness.
**Approach:** a reflective look back over the weeks so far, then looking ahead with curiosity rather than pressure.

[music 4s]

[warm, unhurried] Wherever you are in your pregnancy, you've likely reached somewhere around the middle. A good place to pause, and look around.

Find a comfortable position, and let yourself settle.

[pause 8s]

[warm, reflective] Let's look back first.

Think of the day you found out you were pregnant. Where were you? What did you feel?

[pause 10s]

Whatever you felt then, joy, shock, fear, all of it, it was a real beginning.

[pause 6s]

[gentle] Now think of one thing that's been hard since then. Something you've carried, or handled, or simply gotten through.

[pause 10s]

[warm, reassuring] You got through it. Notice that.

[pause 6s]

[warm] And think of one moment you'd like to remember from these weeks. A small one is fine.

[pause 10s]

That's part of your story now.

[pause 6s]

Think of someone, or something, that helped you get here. A person who listened. A routine that steadied you. Even your own quiet determination to keep going.

[pause 10s]

[gentle wonder] You've reached a point where you can look back and notice how much has changed: appointments, expectations, sensations, and the quiet work your body has been doing all along. There may be milestones worth celebrating, and there may be memories or uncertainties that make celebrating complicated.

[pause 6s]

[tender] If you'd like, lay a hand on your belly. Think of the developing baby you are carrying today, rather than trying to picture every step ahead. Let appreciation for this remarkable process be possible without asking your feelings to become simple.

[pause 8s]

[warm, hopeful] Now let's turn, gently, toward what's ahead.

You don't need to plan it all, or know how it will go. Just notice what you feel when you think about the months to come. Curiosity? Nerves? Hope? A mix?

[pause 10s]

[reassuring] Whatever's there, you'll meet the coming weeks the same way you've met these ones. One day at a time, learning as you go.

[pause 6s]

There will be new things to learn. New changes in your body, new decisions, new feelings. You don't have to be ready for all of them today. Only for the next small step.

[pause 10s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

Wherever the road goes from here, you can meet it as you are.

[music 6s]

---

## Week 20 · Faith-centered

**Title:** Helped / *until* / now.
**Description:** Five minutes at the halfway point to remember God's help and trust him with what's ahead.
**Approach:** the Grounded look back and look ahead at the halfway point, with Samuel's stone of help and God's promise to go before you.
**Scripture:** 1 Samuel 7:12 (verbatim excerpt: Samuel's words at the end of the verse); Deuteronomy 31:8 (verbatim excerpt: the first three sentences).

[music 4s]

[warm, unhurried] Wherever you are in your pregnancy, you've likely reached somewhere around the middle. A good place to pause, and look around.

Find a comfortable position, and let yourself settle.

[pause 6s]

[warm, storytelling] In the book of First Samuel, after a hard-won season, the prophet Samuel set up a large stone as a marker. He named it Ebenezer, which means "stone of help," saying:

*the Lord helped us until now.*

[pause 8s]

[warm] Let's set up a small Ebenezer of your own today.

[warm, reflective] First, think of the day you found out you were pregnant. Where were you? What did you feel?

[pause 8s]

Whatever you felt then, joy, shock, fear, all of it, it was a real beginning.

[pause 5s]

[gentle] Now think of one thing that's been hard since then. Something you've carried, or handled, or simply gotten through.

[pause 8s]

[warm, reassuring] You got through it. Notice that.

[pause 5s]

[gentle, reflective] Where have you seen God's help? Maybe in a person. A kind word. Strength you didn't know you had.

[pause 8s]

[prayerful] Thank him for each one, in your own words.

[pause 8s]

[warm] Now imagine placing a stone, right here, in this moment. A marker that says: God has helped me until now.

[pause 7s]

[gentle wonder] You've reached a point where you can look back and notice how much has changed: appointments, expectations, sensations, and the quiet work your body has been doing all along. There may be milestones worth celebrating, and there may be memories or uncertainties that make celebrating complicated.

[pause 5s]

[warm, hopeful] Now let's turn, gently, toward what's ahead.

[reverent] Moses spoke these words to Joshua and the people of Israel, as they faced a new and uncertain land:

*The Lord himself is who goes before you. He will be with you. He will not fail you nor forsake you.*

[pause 8s]

[warm, reassuring] He doesn't promise that the road will be easy. He promises to be with you on it.

[pause 5s]

[gentle] What feels uncertain about the months ahead? Name it to him. And picture him already there, going before you into each of those places.

[pause 9s]

[tender] If you'd like, lay a hand on your belly, and think of the developing baby you are carrying today.

[pause 6s]

[prayerful, sincere] Lord, thank you for helping me until now, and for the little one I've carried with you this far. I trust you with what's ahead, and I place this precious little one, so wonderfully made, in your hands. Go before me, and stay with me, every step of the way. Amen.

[pause 7s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

Wherever the road goes from here, the God who has helped you until now is with you still.

[music 6s]
