# Weekly meditations · Weeks 37–42 (approved)

**Status:** editorial direction approved by Leah. Audio not yet recorded; recordings are approved separately. **Faith-centered, weeks 7–42:** rewritten on each week's Grounded script with faith woven in, and approved by Leah after editorial polish and final review; earlier versions are in `archive/faith-before-woven-weeks-07-42.md`. Weeks 24, 25, 33, 34, 39 and 41 are prayer-only (no Scripture passage). Every Faith-centered closing prayer thanks God for the baby, in words tied to that week's theme.

**Narrator at launch:** Maren, for both Grounded and Faith-centered.

**Themes for weeks 37–42** (approaching birth). Every meditation suits someone who is still waiting, whatever the week. No week is treated as a delivery date, and these meditations complement, never replace, the individual guidance of each mother's care team.

| Week | Grounded | Faith-centered | Focus |
|---|---|---|---|
| 37 | Open hands | A time for everything | Holding plans gently, staying flexible |
| 38 | Just this moment | My times are in your hand | Meeting each moment as it comes |
| 39 | Many kinds of comfort | God of all comfort | Comforts to try, knowing what helps can change |
| 40 | The waiting days | I wait for the Lord | Rest and peace around the due date |
| 41 | Slow and sweet | Rest, and wait | Savoring the final days of pregnancy |
| 42 | Whenever you arrive | This is the day | Making room for the love you hope to share |

Same format as weeks 6–36: `[music]` and `[pause]` markers, tone tags at the start of paragraphs, and Scripture from the World English Bible in italics, with God's name shown as "the Lord", as in most English Bibles. Each **Scripture** line says whether a passage is verbatim or a verbatim excerpt. Only exact Scripture is in italics.

---

## Week 37 · Grounded

**Title:** Open / *hands.*
**Description:** Five minutes to hold your plans gently, with open hands and an open heart.
**Approach:** a hands-open practice for flexibility, gratitude for the journey so far, and gentle readiness.

[music 4s]

[warm, unhurried] Let's begin with your hands. Wherever they're resting, turn them palms up, if that's comfortable.

[pause 6s]

[calm] Find a supported position, and let your breath slow down by itself. Let your shoulders soften.

[pause 8s]

[warm] As your baby's arrival draws near, you may have been thinking about plans. Who will be with you. What might help. The bag by the door. Plans are a lovely way to prepare, and they can be held gently.

[pause 8s]

[calm, clear] Try this. Gently close your hands, as if you were holding something tightly.

[pause 5s]

Notice how that feels. The effort in your fingers, your wrists, your arms.

[pause 5s]

Now let your hands open again, palms up and relaxed.

[pause 8s]

[warm, reassuring] Open hands can still hold things. They just hold them lightly. Your hopes and preferences are still there, resting in your open palms, ready to adapt as the day unfolds.

[pause 8s]

[warm] Think of one hope you have for your baby's birth. Imagine resting it in your open hand. Notice that you can care about it deeply, and still hold it lightly.

[pause 10s]

[gentle wonder] Your body has been adapting for months. Making room, shifting, changing, carrying your baby with remarkable flexibility. There's something remarkable about the ways your body has adapted throughout pregnancy. Take a moment to appreciate that work, and allow yourself to approach the coming days with gentleness and an open heart.

[pause 8s]

[calm] Now let your whole body follow your hands. Open, soft, and easy. Your face. Your jaw. Your shoulders. Your belly.

[pause 11s]

[tender] If you'd like, rest one open hand on your belly. Imagine holding your hopes for your baby the same way. Warmly. Gently. With love.

[pause 12s]

[gentle] You might also think of something you'd like to set down. A pressure to get everything right. An expectation that feels heavy. Imagine it lifting gently off your open palm, like a leaf on a breeze.

[pause 8s]

[warm] Whatever plans you've made, the most important preparation is already happening. You're learning your baby. You're making room in your heart. You're getting ready to meet someone you already love.

[pause 10s]

When you're ready, let your hands rest, and open your eyes.

[pause 4s]

Hold your plans gently, and your baby close.

[music 6s]

---

## Week 37 · Faith-centered

**Title:** A time / *for* / everything.
**Description:** Five minutes to hold your plans with open hands, and trust God with the timing.
**Approach:** the Grounded practice of open hands, with Ecclesiastes' reminder that there is a season for everything, and your hopes for the birth offered to God.
**Scripture:** Ecclesiastes 3:1 (verbatim).

[music 4s]

[warm, unhurried] Let's begin with your hands. Wherever they're resting, turn them palms up, if that's comfortable.

[pause 5s]

[calm] Find a supported position, and let your breath slow down by itself. Let your shoulders soften.

[pause 6s]

[reverent] The book of Ecclesiastes has a beautiful passage about the rhythm of life. It begins:

*For everything there is a season, and a time for every purpose under heaven:*

[pause 8s]

[warm, reflective] A time for every purpose. A season for everything. Including this season, these final weeks of waiting and preparing, and the day you'll meet your baby.

[pause 6s]

[warm] As your baby's arrival draws near, you may have been thinking about plans. Who will be with you. What might help. The bag by the door. Plans are a lovely way to prepare, and they can be held gently.

[pause 6s]

[calm, clear] Try this. Gently close your hands, as if you were holding something tightly.

[pause 5s]

Notice how that feels. The effort in your fingers, your wrists, your arms.

[pause 5s]

Now let your hands open again, palms up and relaxed.

[pause 6s]

[warm, reassuring] Open hands can still hold things. They just hold them lightly. Your hopes and preferences are still there, resting in your open palms, ready to adapt as the day unfolds.

[pause 6s]

[gentle] Now offer your plans to God, one by one, in your own words. Place each one in your open hands, and lift it to him.

[pause 10s]

[gentle wonder] Your body has been adapting for months. Making room, shifting, changing, carrying your baby with remarkable flexibility. Take a moment to appreciate that work, and allow yourself to approach the coming days with gentleness and an open heart.

[pause 6s]

[calm] Now let your whole body follow your hands. Open, soft, and easy. Your face. Your jaw. Your shoulders. Your belly.

[pause 8s]

[tender] If you'd like, rest one open hand on your belly. Imagine holding your hopes for your baby the same way. Warmly. Gently. With love.

[pause 8s]

[warm] Whatever plans you've made, the most important preparation is already happening. You're learning your baby. You're making room in your heart. You're getting ready to meet someone you already love.

[pause 7s]

[prayerful, sincere] Lord, thank you for this season, and for the little one at the heart of it. I give you my plans and my hopes for this birth. Help me hold them with open hands, and trust you through the days ahead. Be near to me and my baby, today and every day. Amen.

[pause 7s]

[warm] When you're ready, let your hands rest, and open your eyes.

[pause 4s]

There is a time for everything, and this time is held by him.

[music 6s]

---

## Week 38 · Grounded

**Title:** Just / *this* / moment.
**Description:** Five minutes to practice meeting each moment as it comes, a gentle way to approach the days ahead.
**Approach:** a present-moment practice that returns, again and again, to this breath and this moment.

[music 4s]

[warm, unhurried] Here's a gentle thought to rest with today: you only ever have to meet one moment at a time.

[pause 6s]

[calm] Find a comfortable position. Let your breath slow down. Let your body be supported.

[pause 8s]

[calm, clear] Let's practice. Notice this breath. Only this one. The air coming in, and going out.

[pause 8s]

Now this moment. The feeling of whatever is beneath you. The sounds in the room.

[pause 8s]

If your mind jumps ahead, to tomorrow, to next week, to the day you meet your baby, that's natural. Gently bring it back. Just this breath. Just this moment.

[pause 12s]

Notice one thing you can hear right now. One thing you can feel. One thing you can see, even behind closed eyes, like light or shadow. Each one is a small anchor to now.

[pause 10s]

[warm] Many people find this a steadying way to approach labor. Not thinking about how long it might be, or what comes next. Just meeting each contraction as it comes, and then the rest that follows. One moment, and then the next.

[pause 8s]

[calm, soothing] Between contractions, this same practice can help you rest. The moment that just passed is over. The next has not yet come. This moment is for resting.

[pause 8s]

[calm] Let's practice once more. This breath.

[pause 6s]

This moment.

[pause 6s]

This feeling of being held by the ground beneath you.

[pause 10s]

[gentle wonder] Your baby lives entirely in the present. Each moment, they grow, and stretch, and rest, without a thought for tomorrow. There's something lovely about joining them there, even for a few minutes.

[pause 8s]

[tender] If you'd like, rest a hand on your belly. This moment, together.

[pause 14s]

[warm, reassuring] You won't always manage to stay in the present, and that's fine. Every time you notice your mind wandering and gently come back, that is the practice. It grows a little stronger each time.

[pause 8s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

One breath, one moment, and then the next.

[music 6s]

---

## Week 38 · Faith-centered

**Title:** My times / *are in* / your hand.
**Description:** Five minutes to meet one moment at a time, trusting each one to God.
**Approach:** the Grounded practice of returning to this breath and this moment, with David's prayer of trust, "My times are in your hand."
**Scripture:** Psalm 31:14–15 (verbatim excerpt: from "But I trust in you" to "My times are in your hand").

[music 4s]

[warm, unhurried] Here's a gentle thought to rest with today: you only ever have to meet one moment at a time.

[pause 5s]

[calm] Find a comfortable position. Let your breath slow down. Let your body be supported.

[pause 6s]

[reverent] In Psalm 31, David prays honestly to God, and in the middle of his prayer, he says:

*But I trust in you, Lord. I said, "You are my God." My times are in your hand.*

[pause 8s]

[warm, reflective] My times are in your hand. Not just the big moments, but each one. This breath. This hour. This day. And the day you'll meet your baby.

[pause 6s]

[calm, clear] Let's practice. Notice this breath. Only this one. The air coming in, and going out.

[pause 6s]

Now this moment. The feeling of whatever is beneath you. The sounds in the room.

[pause 6s]

If your mind jumps ahead, gently bring it back, and pray: My times are in your hand.

[pause 9s]

Notice one thing you can hear right now. One thing you can feel. One thing you can see, even behind closed eyes, like light or shadow. Each one is a small anchor to now.

[pause 8s]

[warm, reassuring] You won't always manage to stay in the present, and that's fine. Every time you notice your mind wandering and gently come back, that is the practice. It grows a little stronger each time.

[pause 6s]

[warm] Many people find this a steadying way to approach labor. Not thinking about how long it might be, or what comes next. Just meeting each contraction as it comes, and then the rest that follows. One moment, and then the next.

[pause 6s]

[calm, soothing] Between contractions, you can return to this simple prayer. My times are in your hand. Rest, and breathe, and let the next moment come in its own time.

[pause 7s]

[gentle wonder] Your baby lives entirely in the present. Each moment, they grow, and stretch, and rest, without a thought for tomorrow. There's something lovely about joining them there, even for a few minutes.

[pause 6s]

[tender] If you'd like, rest a hand on your belly. This moment, together.

[pause 7s]

[gentle] Now take a moment to entrust your times to God. Today. This week. The day your baby arrives. Tell him, in your own words.

[pause 10s]

[prayerful, sincere] Lord, I trust in you. You are my God. My times are in your hand, and so is this precious little life. Thank you for this little one, and for this moment together. Help me meet each moment with you, one breath at a time. Amen.

[pause 7s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

Every moment ahead is already in his hand.

[music 6s]

---

## Week 39 · Grounded

**Title:** Many / *kinds of* / comfort.
**Description:** Five minutes exploring the many comforts you might reach for, and the freedom to choose what helps.
**Approach:** a gentle tour of comforts (warmth, water, movement, sound, touch, words), held lightly and without promises.

[music 4s]

[warm, unhurried] Today, let's gather a little collection of comforts. Things you might reach for in the days ahead, and when it's time to meet your baby.

[pause 6s]

[calm] Find a comfortable position, and let your breath slow down.

[pause 8s]

[warm] Different things help different people, and what helps can change from hour to hour. So think of these as possibilities. Gentle options, not a checklist.

[pause 6s]

[calm, peaceful] Warmth. A warm shower or bath, a heat pack, a soft blanket. Imagine warmth spreading through your back and hips.

[pause 10s]

Movement. Swaying, rocking, walking, leaning on something steady. Imagine your hips swaying gently, side to side.

[pause 10s]

Sound. Music you love. A soundscape. A familiar voice. Or simple quiet. Notice what feels soothing.

[pause 10s]

Touch. A hand on your back. Firm pressure, or a light stroke. Or perhaps no touch at all. Notice what you'd prefer.

[pause 10s]

Scent. A familiar lotion, a soft fabric that smells of home, fresh air through an open window.

[pause 8s]

Words. A few kind words, like the ones you chose a few weeks ago. Something to come back to.

[pause 10s]

Breath. A long, slow breath out, whenever it feels right.

[pause 10s]

Rest. Stillness between efforts. Lying on your side, eyes closed, letting everything go soft.

[pause 8s]

[warm, reassuring] You won't need all of these, and some may not help you at all. That's completely fine. You can try one thing, let it go, and try another. You get to discover what works for you.

[pause 8s]

[gentle wonder] Your body has been finding its own comforts all along, shifting to ease your back, seeking rest when it's tired. You know more about what you need than you might think.

[pause 8s]

[tender] If you'd like, rest a hand on your belly. Comfort for you, and closeness with your baby.

[pause 12s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

Comfort comes in many forms. You're free to find yours.

[music 6s]

---

## Week 39 · Faith-centered

**Title:** God / *of all* / comfort.
**Description:** Five minutes to gather comforts for the days ahead, from the God of all comfort.
**Approach:** the Grounded collection of comforts (warmth, movement, sound, touch, scent, prayer, breath and rest), received from the God of all comfort.
**Scripture:** none; prayer only.

[music 4s]

[warm, unhurried] Today, let's gather a little collection of comforts. Things you might reach for in the days ahead, and when it's time to meet your baby.

[pause 5s]

[calm] Find a comfortable position, and let your breath slow down.

[pause 6s]

[warm, reflective] God is the God of all comfort. Not some comfort. All of it. Every warm blanket, every kind hand, every quiet moment of relief comes from his heart for you.

[pause 6s]

[warm] Different things help different people, and what helps can change from hour to hour. So think of these as possibilities. Gentle options, not a checklist.

[pause 5s]

[calm, peaceful] Warmth. A warm shower or bath, a heat pack, a soft blanket. Imagine warmth spreading through your back and hips.

[pause 7s]

Movement. Swaying, rocking, walking, leaning on something steady. Imagine your hips swaying gently, side to side.

[pause 7s]

Sound. Worship music you love. A familiar voice. Or simple quiet.

[pause 7s]

Touch. A hand on your back. Firm pressure, or a light stroke. Or perhaps no touch at all. Notice what you'd prefer.

[pause 7s]

Scent. A familiar lotion, a soft fabric that smells of home, fresh air through an open window.

[pause 6s]

Prayer. A short phrase of Scripture, like the one you chose a few weeks ago.

[pause 7s]

Breath. A long, slow breath out, whenever it feels right.

[pause 7s]

Rest. Stillness between efforts, eyes closed, held in his care.

[pause 6s]

[warm, reassuring] You won't need all of these, and some may not help you at all. That's completely fine. You can try one thing, let it go, and try another. You get to discover what works for you.

[pause 6s]

[gentle wonder] Your body has been finding its own comforts all along, shifting to ease your back, seeking rest when it's tired. You know more about what you need than you might think.

[pause 6s]

[tender] If you'd like, rest a hand on your belly, close to your baby.

[pause 7s]

[prayerful, sincere] Father of mercies, God of all comfort, thank you for every comfort you give, and for this little one, so close to me now. In the days ahead, surround me with your comfort, and show me what helps. Amen.

[pause 7s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

All comfort, from the God who loves you.

[music 6s]

---

## Week 40 · Grounded

**Title:** The / *waiting* / days.
**Description:** Five minutes of patience and ease for the days around your due date, whenever your baby arrives.
**Approach:** reframing the due date as a gentle estimate, settling into patience, and enjoying the present.

[music 4s]

[warm, lightly smiling] You may be hearing a lot of the same question lately. Any news yet? Let's take a few minutes away from all of that.

[pause 6s]

[calm] Find your most comfortable position. Let your breath slow down by itself.

[pause 8s]

[warm, reassuring] A due date is an estimate, not an appointment your baby is expected to keep. As you approach this part of pregnancy, you may be following a plan with your care team for the days ahead. For these few minutes, you can set aside the calendar and simply rest.

[pause 8s]

[calm] Let's set the waiting down for a moment. Imagine placing it on a shelf beside you. It will still be there later. For now, you can rest.

[pause 10s]

[gentle wonder] Some people find these last days bring a surprising burst of energy. Others feel slow and heavy. Both are simply your body, doing its work in its own way. Listen to what it asks for.

[pause 8s]

[calm, soothing] Let your forehead smooth. Your jaw soften. Your shoulders drop. Your hands open.

[pause 10s]

[gentle wonder] Waiting can feel long, but it's also full of quiet work. Your body is continuing its remarkable preparation, and your baby is continuing to grow. So much is happening, even in the stillness.

[pause 8s]

[warm] What would make these waiting days a little sweeter? A walk in fresh air. A favorite meal. An early night. Time with someone you love. A good book. Let one or two ideas come to mind.

[pause 12s]

[calm, peaceful] Imagine a quiet, golden afternoon with nothing on the calendar. Just you, your baby, and time. Every nap, every early night, every slow afternoon is a gift to yourself.

[pause 10s]

[tender] If you'd like, rest a hand on your belly. These are some of the last days your baby will be this close to you, held entirely within. There's something precious in that.

[pause 14s]

[warm] Whatever the coming days hold, you can meet each one as it comes, with patience and a little kindness for yourself.

[pause 8s]

When you're ready, let your eyes open slowly.

[pause 4s]

One day at a time. There's still room for peace in the waiting.

[music 6s]

---

## Week 40 · Faith-centered

**Title:** I wait / *for* / the Lord.
**Description:** Five minutes to set down the waiting for a while, and rest with God.
**Approach:** the Grounded rest from the waiting days, with the psalmist's hope in God, the women of Scripture who waited, and your waiting brought to God.
**Scripture:** Psalm 130:5 (verbatim).

[music 4s]

[warm, lightly smiling] You may be hearing a lot of the same question lately. Any news yet? Let's take a few minutes away from all of that.

[pause 5s]

[calm] Find your most comfortable position. Let your breath slow down by itself.

[pause 6s]

[warm, reassuring] A due date is an estimate, not an appointment your baby is expected to keep. As you approach this part of pregnancy, you may be following a plan with your care team for the days ahead. For these few minutes, you can set aside the calendar and simply rest.

[pause 6s]

[reverent] In Psalm 130, the psalmist describes what it's like to wait on God:

*I wait for the Lord. My soul waits. I hope in his word.*

[pause 8s]

[warm, reflective] Waiting is woven all through Scripture. Sarah, Hannah, Elizabeth, Mary. Each one waited, in her own way, for a child. Waiting is not empty time. It's time held in God's hands.

[pause 6s]

[gentle wonder] Some people find these last days bring a surprising burst of energy. Others feel slow and heavy. Both are simply your body, doing its work in its own way. Listen to what it asks for.

[pause 6s]

[calm, soothing] Let your forehead smooth. Your jaw soften. Your shoulders drop. Your hands open.

[pause 8s]

[gentle wonder] Waiting can feel long, but it's also full of quiet work. Your body is continuing its remarkable preparation, and your baby is continuing to grow. So much is happening, even in the stillness.

[pause 6s]

[warm] What would make these waiting days a little sweeter? A walk in fresh air. A favorite meal. An early night. Time with someone you love. A good book. Let one or two ideas come to mind.

[pause 9s]

[tender] If you'd like, rest a hand on your belly. These are some of the last days your baby will be this close to you, held entirely within. There's something precious in that.

[pause 9s]

[warm] Whatever the coming days hold, you can meet each one as it comes, with patience and a little kindness for yourself.

[pause 6s]

[gentle] Now bring your waiting to God. Your hopes, your impatience, your excitement. Tell him all of it, and let him hold it with you.

[pause 10s]

[prayerful, sincere] Lord, I wait with you. Thank you for the little life I carry and for the remarkable journey of this pregnancy. Give me patience, wisdom for the days ahead, and peace in your presence today. Amen.

[pause 7s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

One day at a time. Waiting with hope, and not alone.

[music 6s]

---

## Week 41 · Grounded

**Title:** Slow / *and* / sweet.
**Description:** Five minutes to savor these final days of pregnancy, and the closeness you share with your baby.
**Approach:** a savoring practice of gentle pleasures, gratitude for the journey, and quiet connection.

[music 4s]

[warm, unhurried] Hello. Today is a day for slowing down, and savoring.

Find a comfortable position, wherever your body feels most at ease. Let yourself be supported.

[pause 8s]

[calm] Let your breath slow down by itself. Let your face soften.

[pause 8s]

[warm] These days may feel long, and your body may be asking for more comfort and rest. Wherever you find yourself today, let's take a few minutes to appreciate this moment of pregnancy, without asking it to feel any particular way.

[pause 8s]

[gentle wonder] Think back over the journey. The first moment you knew. The first flutter you felt. The way your body has grown and changed and carried your baby, week after week. All of it, remarkable.

[pause 12s]

[warm] Maybe you'd like to remember these days. A photo of your belly. A note to your baby. A few words in a journal about how it feels right now. Small keepsakes from a once-in-a-lifetime season.

[pause 10s]

[tender] Now notice your baby, here with you. The roundness of your belly. The closeness. A whole person, so near, and almost ready to meet you.

[pause 12s]

[warm] Is there something small you'd like to savor today? A warm bath. A slow cup of tea. Sunlight through a window. A nap in the afternoon. Let one simple pleasure come to mind.

[pause 12s]

Imagine enjoying it fully. No rushing. Nowhere else to be.

[pause 10s]

[gentle wonder] Notice the warmth of your hands. The rise and fall of your breath. The quiet company of your baby. Simple things, and so precious.

[pause 10s]

[calm, soothing] Let your shoulders sink. Let your hands rest. Let this moment be slow, and sweet.

[pause 12s]

[tender] If you'd like, rest a hand on your belly, and say something to your baby. Perhaps thank you for this time together. Or simply, I can't wait to meet you.

[pause 14s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

Savor these days. They're yours, and your baby's.

[music 6s]

---

## Week 41 · Faith-centered

**Title:** Rest, / *and* / wait.
**Description:** Five minutes to slow down, savor these days, and rest in the Lord.
**Approach:** the Grounded slowing down and savoring of these last days, resting in the Lord, and a blessing over your baby.
**Scripture:** none; prayer only.

[music 4s]

[warm, unhurried] Hello. Today is a day for slowing down, and savoring.

Find a comfortable position, wherever your body feels most at ease. Let yourself be supported.

[pause 6s]

[calm] Let your breath slow down by itself. Let your face soften.

[pause 6s]

[warm] These days may feel long, and your body may be asking for more comfort and rest. Wherever you find yourself today, let's take a few minutes to appreciate this moment of pregnancy, without asking it to feel any particular way.

[pause 6s]

[gentle wonder] Think back over this journey with God. The first moment you knew. The first flutter you felt. The prayers you've prayed. The ways your body has grown and carried your baby, week after week. All of it, held by him.

[pause 9s]

Thank him for anything that comes to mind.

[pause 9s]

[warm] Maybe you'd like to remember these days. A photo of your belly. A note to your baby. A few words in a journal about how it feels right now. Small keepsakes from a once-in-a-lifetime season.

[pause 7s]

[tender] Now notice your baby, here with you. The roundness of your belly. The closeness. A whole person, so near, and almost ready to meet you.

[pause 8s]

[warm] Is there something small you'd like to savor today? A warm bath. A slow cup of tea. Sunlight through a window. A nap in the afternoon. Let one simple pleasure come to mind.

[pause 8s]

Imagine enjoying it fully. No rushing. Nowhere else to be.

[pause 7s]

[gentle wonder] Notice the warmth of your hands. The rise and fall of your breath. The quiet company of your baby. Simple things, and so precious.

[pause 7s]

[calm, soothing] Let your shoulders sink. Let your hands rest open. Rest in the Lord.

[pause 8s]

[tender] If you'd like, rest a hand on your belly, and pray a blessing over your baby, in your own words.

[pause 10s]

[prayerful, sincere] Lord, I rest in you, and I wait for you. Thank you for being with me in these final days, and for the little one now so near. Bless my baby, and be with us as we prepare to meet. Amen.

[pause 7s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

Be gentle with yourself in these days. You are held in his care.

[music 6s]

---

## Week 42 · Grounded

**Title:** Whenever / *you* / arrive.
**Description:** Five minutes to welcome your baby, whenever and however they arrive, with gratitude for the whole journey.
**Approach:** a closing reflection on the journey, an open welcome for the baby, and a gentle blessing.

[music 4s]

[warm, tender] Hello. Wherever you are in these final days, you've come such a long way. Let's take a few minutes to honor that, and to welcome your baby.

[pause 6s]

[calm] Find your most comfortable position, and let yourself be fully supported. Let your breath slow down.

[pause 8s]

[gentle wonder] Think of everything your body has done. From those very first weeks, when so much was happening out of sight, to now. Growing, adapting, sheltering, carrying. A truly extraordinary journey.

[pause 10s]

[warm] And think of everything you've done. The rest you've taken. The questions you've asked. The love you've already given to someone you haven't yet held.

[pause 10s]

[tender] And think of your baby's journey too. From the tiniest beginning to a whole little person, getting ready for the world. What a story you share.

[pause 10s]

[warm, reassuring] There may be plans and decisions surrounding your baby's arrival, and each birth experience is different. For these few moments, simply make room for the love and tenderness you hope to share with your little one.

[pause 8s]

[warm] You may imagine the small moments of getting to know your baby. A familiar voice. A gentle touch. A quiet moment of closeness. You don't need to picture exactly how those moments will unfold.

[pause 8s]

[tender] If you'd like, rest a hand on your belly, and imagine a moment of welcome. You don't need to picture any details. Just the love you hope to share.

[pause 14s]

[warm] If you'd like, offer your baby a simple welcome, silently or out loud. Something like: Whenever you arrive, you are so welcome here.

[pause 14s]

[calm, soothing] Let your shoulders sink. Let your hands rest. Let your whole body be soft and supported.

[pause 12s]

[warm, reassuring] You've practiced so many gentle things along the way. Slowing down. Breathing out. Softening. Finding your calm place. Resting between efforts. They're all with you, ready whenever you need them.

[pause 10s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

Whenever you arrive, little one, you are already so loved.

[music 6s]

---

## Week 42 · Faith-centered

**Title:** This is / *the* / day.
**Description:** Five minutes to honor the journey, give thanks, and welcome your baby.
**Approach:** the Grounded honoring of your body's, your own and your baby's journey, with thanksgiving for the day the Lord has made and a welcome for your baby.
**Scripture:** Psalm 118:24 (verbatim).

[music 4s]

[warm, tender] Hello. Wherever you are in these final days, you've come such a long way. Let's take a few minutes to honor that, and to welcome your baby.

[pause 5s]

[calm] Find your most comfortable position, and let yourself be fully supported. Let your breath slow down.

[pause 6s]

[reverent, joyful] Psalm 118 is a song of thanksgiving, full of joy. In the middle of it, the psalmist says:

*This is the day that the Lord has made. We will rejoice and be glad in it!*

[pause 8s]

[warm, reflective] This is the day. Not only the day your baby arrives, but today. This ordinary, waiting, precious day, made by God, and full of his goodness.

[pause 6s]

[gentle wonder] Think of everything your body has done. From those very first weeks, when so much was happening out of sight, to now. Growing, adapting, sheltering, carrying. A truly extraordinary journey.

[pause 7s]

[warm] And think of everything you've done. The rest you've taken. The questions you've asked. The love you've already given to someone you haven't yet held.

[pause 7s]

[tender] And think of your baby's journey too. From the tiniest beginning to a whole little person, getting ready for the world. What a story you share.

[pause 7s]

Every day of this pregnancy was a day the Lord made. The tired days and the joyful ones. The quiet ones and the busy ones. He was present in every one.

[pause 6s]

[gentle] Take a moment to give thanks. For your body. For your baby. For the people who've walked with you.

[pause 10s]

[warm, reassuring] You've practiced so many gentle things along the way. Slowing down. Breathing out. Softening. Finding your calm place. Resting between efforts. They're all with you, ready whenever you need them.

[pause 7s]

[warm, reassuring] There may be plans and decisions surrounding your baby's arrival, and each birth experience is different. For these few moments, simply make room for the love and tenderness you hope to share with your little one.

[pause 6s]

[tender] If you'd like, rest a hand on your belly, and offer your baby a welcome. Something like: Whenever you arrive, you are so welcome here.

[pause 10s]

[prayerful, sincere] Lord, this is the day you have made. Thank you for every day of this journey, and for the gift of this child. I trust you with the day we meet. Let us rejoice together in your goodness. Amen.

[pause 7s]

[warm] When you're ready, let your eyes open slowly.

[pause 4s]

Your little one is already so loved.

[music 6s]
