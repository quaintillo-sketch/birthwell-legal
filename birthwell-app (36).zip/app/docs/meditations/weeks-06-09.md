# Weekly meditations · Weeks 6–9 (approved)

**Status:** editorial direction approved by Leah. Audio not yet recorded; recordings are approved separately. Edited from Leah's clean revision (revision 5). Every move, cut and wording change is listed in `change-log-weeks-06-20.md`, and Leah's revisions are kept word for word in `archive/`. **Faith-centered, weeks 7–42:** rewritten on each week's Grounded script with faith woven in, and approved by Leah after editorial polish and final review; earlier versions are in `archive/faith-before-woven-weeks-07-42.md`. Weeks 24, 25, 33, 34, 39 and 41 are prayer-only (no Scripture passage). Every Faith-centered closing prayer thanks God for the baby, in words tied to that week's theme.

**Narrator at launch:** Maren, for both Grounded and Faith-centered. The scripts don't depend on a particular voice.

How to read the scripts:
- `[music 4s]` (opening) and `[music 6s]` (ending) are music only: the soundscape plays before Maren starts or after she finishes.
- `[pause 5s]` is a silence of that many seconds between thoughts, with the soundscape underneath.
- A blank line between paragraphs is a short natural breath (about 1 second).
- **Tone tags** such as `[warm, unhurried]`, `[gentle wonder]`, `[reverent]` or `[prayerful, sincere]` direct Maren's delivery in ElevenLabs v4. They aren't spoken. A tag applies to its paragraph and carries on until the next tag. The tags avoid words like "whisper", "softly" or "sleepy", which made earlier recordings drift into a whisper.
- *Italic lines* in the Faith-centered scripts are Scripture from the World English Bible, with God's name shown as "the Lord", as in most English Bibles. Each **Scripture** line says whether a passage is verbatim, a verbatim excerpt (part of a verse, words unchanged), or retold in Maren's own words. Only exact Scripture is in italics.
- The title has three parts. The middle part shows in italic clay in the app.
- Every script runs 5:03–5:30 at a slow, natural pace of about 120 words a minute, including all pauses and music.

---

## Week 6 · Grounded

**Title:** Simply / *to* / arrive.
**Description:** Five quiet minutes to land in your body, just as it is today, with nothing to figure out.
**Approach:** arriving through the senses, an optional hand on the belly, and stillness.

[music 4s]

[warm, unhurried] Hello. Before anything else, just notice that you've stopped. Whatever came before this moment, and whatever comes after, can wait a few minutes.

Settle into a position that feels easy. Sitting, lying down, leaning back against something soft. There's nothing to get right here.

[pause 4s]

[calm] You might let your eyes close, or let your gaze rest somewhere gentle.

[pause 4s]

There's no need to change anything about your breathing. Just notice your next breath as it comes… and as it goes.

[pause 6s]

Now let's arrive, one sense at a time.

Notice the sounds around you. Some near, some farther away. You don't need to name them. Just let them be part of the room.

[pause 7s]

Notice where your body is being held. The weight of your legs. Your back. Your head. Let whatever is beneath you take a little more of you.

[pause 7s]

Notice the air on your skin. Warm or cool. Still, or gently moving.

[pause 4s]

You're here.

[pause 4s]

[gentle wonder] There's something extraordinary about these earliest weeks. Cells are multiplying and beginning to take on different roles, while your body adapts in ways you may not even notice. You don't need to direct any of that work. You may be astonished by it, or still be taking in the news. Either response belongs here.

[pause 6s]

[warm, gentle wonder] Every pregnancy begins with its own mix of feelings. Whatever yours may be today, give yourself permission to simply be present. Take a moment to appreciate the remarkable changes taking place within you, and the little life at the heart of it all.

[pause 6s]

[warm] If it feels right, rest one hand low on your belly, and the other over your heart.

[pause 5s]

You don't have to feel anything in particular. Just notice the warmth of your own hands, and the small movement beneath them as you breathe.

[pause 5s]

You don't need to have this figured out. Not the plans, not the feelings, not the months ahead. Right now there is only this breath, and the one after it.

[pause 7s]

[calm] Let your shoulders soften as you breathe out. Let your jaw loosen.

[pause 5s]

Let your hands simply rest. For these last moments, there's nothing to do at all. Just be here, as you are.

[pause 12s]

[warm] When you're ready, let a little movement come back. Your fingers. Your toes. Notice the light around you.

[pause 4s]

You arrived, and that was enough. You can return to this quiet whenever you need it.

[music 6s]

---

## Week 6 · Faith-centered

**Title:** Known / *before* / the beginning.
**Description:** Five quiet minutes to rest in being known and loved by God, right where you are.
**Approach:** the Grounded arrival through the senses, with God's call by name, the psalmist's words over the hand on the belly, and a moment of personal prayer before the close.
**Scripture:** Isaiah 43:1 (verbatim excerpt: the words God speaks to Israel, from the second half of the verse); Psalm 139:13 (verbatim).

[music 4s]

[warm, unhurried] Hello. Before anything else, just notice that you've stopped. Whatever came before this moment, and whatever comes after, can wait a few minutes.

Settle into a position that feels easy. Sitting, lying down, leaning back against something soft. There's nothing to get right here.

[pause 4s]

[calm] You might let your eyes close, or let your gaze rest somewhere gentle.

[pause 4s]

There's no need to change anything about your breathing. Just notice your next breath as it comes… and as it goes.

[pause 5s]

Now let's arrive, one sense at a time.

Notice the sounds around you. Some near, some farther away. You don't need to name them. Just let them be part of the room.

[pause 5s]

Notice where your body is being held. The weight of your legs. Your back. Your head. Let whatever is beneath you take a little more of you.

[pause 5s]

Notice the air on your skin. Warm or cool. Still, or gently moving.

[pause 4s]

You're here. And God is here with you.

[pause 5s]

[reverent] Through the prophet Isaiah, God spoke these words to his people Israel, reminding them that they belonged to him:

*Don't be afraid, for I have redeemed you. I have called you by your name. You are mine.*

[pause 7s]

[warm, reflective] Whatever today holds, you are not a stranger to God.

[pause 5s]

[gentle wonder] There's something extraordinary about these earliest weeks. Cells are multiplying and beginning to take on different roles, while your body adapts in ways you may not even notice. You don't need to direct any of that work. You may be astonished by it, or still be taking in the news. Either response belongs here, and you can bring it to God just as it is.

[pause 5s]

[warm, gentle wonder] Every pregnancy begins with its own mix of feelings. Whatever yours may be today, give yourself permission to simply be present. Take a moment to appreciate the remarkable changes taking place within you, and the little life at the heart of it all.

[pause 5s]

[warm] If it feels right, rest one hand low on your belly, and the other over your heart.

[pause 4s]

[reverent] The psalmist prayed:

*For you formed my inmost being. You knit me together in my mother's womb.*

[pause 7s]

[warm] Just notice the warmth of your own hands as you breathe.

[pause 5s]

You don't need to have this figured out. Not the plans, not the feelings, not the months ahead. You don't have to hold all of it by yourself.

[pause 5s]

[calm] Let your shoulders soften as you breathe out. Let your jaw loosen.

[pause 5s]

[gentle] Take a quiet moment to talk with God about this new beginning, in words or simply in stillness. He already knows what you're feeling.

[pause 10s]

[prayerful, sincere] Lord, thank you that you know me by name. Thank you for this blessing I get to hold within me, and for all the tiny miracles that had to happen for this little life to begin. Every moment I carry this little one is precious, and I place this little life in your hands. I don't know everything that's ahead, but I know I'm not alone in it. Help me rest in your love today. Amen.

[pause 6s]

[warm] When you're ready, let a little movement come back. Your fingers. Your toes. Notice the light around you.

[pause 4s]

You arrived, and that was enough. Go into your day knowing you are known, and you are loved.

[music 6s]

---

## Week 7 · Grounded

**Title:** Rest / *is* / enough.
**Description:** Five minutes of permission to slow down, because growing a new life is real work.
**Approach:** permission to rest, progressive heaviness, and a peaceful resting place.

[music 4s]

[warm, unhurried] Hi. If you can, let yourself lie down for this one. On your side is lovely, with a pillow wherever you need it. If lying down isn't possible right now, simply lean back and let something hold you.

[pause 5s]

[gentle, understanding] You may be more tired than usual right now. The kind of tired that a good night's sleep doesn't quite reach. Pregnancy can ask so much of you, in body and in heart, even on days when it seems like nothing is happening.

[pause 5s]

That tiredness isn't laziness, and it isn't weakness. Your body is adapting to pregnancy in countless quiet ways, and it asks for energy and rest, sometimes more than you expected. There is something remarkable in that work, even if all you notice today is how tired you feel.

[pause 6s]

[tender] You can appreciate the life you're carrying and still wish this part felt easier. Pregnancy asks a great deal of your body, and rest is one way to care for yourself through it. Take a moment to acknowledge how much your body is doing, even when you're doing nothing at all.

[pause 6s]

[warm, reassuring] So here's your permission. For the next few minutes, you don't need to be useful. You don't need to catch up. Rest doesn't need to be earned.

[pause 5s]

[calm, soothing] Let's let the heaviness come.

Start with your feet. Imagine them growing warm and heavy, sinking a little into whatever is beneath them.

[pause 6s]

That warmth moves into your calves… your knees… your thighs… your hips and lower back. Heavy. Easy. Held.

[pause 6s]

Your belly, soft, with nothing to hold in. Your arms, heavy all the way down to your fingertips.

[pause 6s]

And your face. The space between your eyebrows. Your jaw. The soft skin around your eyes.

[pause 6s]

[calm, peaceful] Now picture a place where you could rest completely. Maybe a sunlit room on a slow afternoon, with nowhere to be. A hammock in the shade. Or somewhere only you know.

[pause 7s]

Let yourself be there. Notice the light. The quiet. How nobody needs anything from you.

[pause 8s]

[gentle] If your mind wanders to the dishes, the emails, the list, that's all right. Notice it, and let your next breath out carry you back to your resting place.

[pause 7s]

You're allowed to stay a little longer.

[pause 10s]

[warm] When you're ready, let your body begin to wake. Gently. There's no rush.

[pause 4s]

Be gentle with yourself today, and rest whenever you can. It counts.

[music 6s]

---

## Week 7 · Faith-centered

**Title:** Come / *and* / rest.
**Description:** Five minutes to lay down what feels heavy and receive the rest Jesus offers.
**Approach:** the Grounded permission to rest, Jesus' invitation to come, setting burdens down in prayer, then progressive heaviness beside still waters.
**Scripture:** Matthew 11:28–29 (verbatim); Psalm 23:2 (verbatim).

[music 4s]

[warm, unhurried] Hi. If you can, let yourself lie down for this one. On your side is lovely, with a pillow wherever you need it. If lying down isn't possible right now, simply lean back and let something hold you.

[pause 5s]

[gentle, understanding] You may be more tired than usual right now. The kind of tired that a good night's sleep doesn't quite reach. Pregnancy can ask so much of you, in body and in heart, even on days when it seems like nothing is happening.

[pause 5s]

That tiredness isn't laziness, and it isn't weakness. Your body is adapting to pregnancy in countless quiet ways, and it asks for energy and rest, sometimes more than you expected. There is something remarkable in that work, even if all you notice today is how tired you feel.

[pause 5s]

[warm, reassuring] So here's your permission. For the next few minutes, you don't need to be useful. You don't need to catch up.

[pause 4s]

[reverent] Listen to the words of Jesus:

*Come to me, all you who labor and are heavily burdened, and I will give you rest. Take my yoke upon you, and learn from me, for I am gentle and humble in heart; and you will find rest for your souls.*

[pause 8s]

[warm, reassuring] He doesn't say, come once you've finished everything. He doesn't say, come once you've earned it. He simply says, come.

[pause 5s]

[gentle] What are you carrying today? Tell him quietly. The tiredness. The worries. The things you haven't gotten to. You can set each one down in front of him.

[pause 10s]

[prayerful, sincere] Jesus, I'm tired, and you already know it. Thank you that I don't have to earn your rest, or prove that I deserve it. Thank you for the little one I'm carrying. Even on the tired days, this time with my baby is a treasure, and I rest this little one in your care. I'm setting these things down with you. Teach me to rest in you. Amen.

[pause 6s]

[calm, soothing] Let's let the heaviness come.

Start with your feet. Imagine them growing warm and heavy, sinking a little into whatever is beneath them.

[pause 5s]

That warmth moves into your calves… your knees… your thighs… your hips and lower back. Heavy. Easy. Held.

[pause 5s]

Your belly, soft, with nothing to hold in. Your arms, heavy all the way down to your fingertips.

[pause 5s]

And your face. The space between your eyebrows. Your jaw. The soft skin around your eyes.

[pause 5s]

[reverent] In Psalm 23, David says of the Lord, his shepherd:

*He makes me lie down in green pastures. He leads me beside still waters.*

[pause 7s]

[calm, peaceful] Let yourself be there. Notice the light. The quiet. How nobody needs anything from you.

[pause 8s]

[gentle] If your mind wanders to the dishes, the emails, the list, that's all right. Notice it, and let your next breath out carry you back to your resting place.

[pause 6s]

[calm, soothing] Rest here a while, beside still waters, in his care.

[pause 10s]

[warm] When you're ready, let your body begin to wake. Gently. There's no rush.

[pause 4s]

Be gentle with yourself, and may you find his rest in the ordinary moments of today.

[music 6s]

---

## Week 8 · Grounded

**Title:** Room for / *every* / feeling.
**Description:** Five minutes to let joy, worry, and everything in between sit side by side.
**Approach:** an honest check-in, making room in the chest, and welcoming mixed feelings.

[music 4s]

[warm, unhurried] Hi. Before we begin, take a moment to check in with yourself. Not how you think you should be feeling. How you actually are.

[pause 6s]

[calm] Find a comfortable position, and let your breath settle into whatever rhythm feels natural.

[pause 6s]

[warm, lightly smiling] Pregnancy can bring so many feelings, sometimes all at once. Excitement. Worry. Tenderness. Doubt. Moments of wonder, and moments of "what have I gotten myself into?" And some days, not much feeling at all.

[pause 6s]

[reassuring] There's no right way to feel right now. Whatever you're feeling is welcome here.

[pause 6s]

[calm] Rest a hand over the center of your chest, if you'd like. Feel the warmth there. As you breathe out, imagine the space beneath your hand growing a little wider. A little more room.

[pause 8s]

[gentle] Now gently ask yourself: *What's here today?*

You don't need words. Just notice. Is there lightness? Heaviness? A flutter? A knot?

[pause 10s]

[reassuring] Whatever you find, you don't need to fix it or explain it. You can simply say to it: *There's room for this feeling, too.*

[pause 6s]

[calm] If worry is here, let it sit beside you, like someone on a park bench. It doesn't have to leave for you to feel some peace. You can keep breathing with it there.

[pause 8s]

[warm, hopeful] And if there's joy, even a small spark of it, let yourself feel that too. Joy doesn't need to wait until everything is certain. It's allowed to be here now.

[pause 8s]

[gentle] Notice how both can be true at once. The hope and the worry. The wonder and the tiredness. You're holding all of it, right now, and you're still here, still breathing.

[pause 8s]

[gentle wonder] Within you, a new life is developing as your body makes room for the work of pregnancy. That may stir wonder, affection, anxiety, or a mixture that changes by the hour. You can recognize how extraordinary it is without feeling cheerful about every moment.

[pause 6s]

[tender] Even an ordinary appointment or a quiet day can stir up feelings that are hard to explain. You don't need to resolve them here. Rest a hand on your belly if you'd like, and allow one small moment of connection without asking it to predict tomorrow.

[pause 10s]

[warm] When you're ready, let your hands rest, and let your eyes slowly open.

[pause 3s]

However today feels, you're not doing it wrong. There's room for all of you.

[music 6s]

---

## Week 8 · Faith-centered

**Title:** Peace / *that* / guards.
**Description:** Five minutes to bring your real worries and hopes to God, and rest in his care.
**Approach:** the Grounded honest check-in and room in the chest, with guided personal prayer: a worry, a hope, and a thanks brought to God in your own words.
**Scripture:** Philippians 4:6–7 (verbatim); 1 Peter 5:7 (verbatim).

[music 4s]

[warm, unhurried] Hi. Before we begin, take a moment to check in with yourself. Not how you think you should be feeling. How you actually are.

[pause 5s]

[calm] Find a comfortable position, and let your breath settle into whatever rhythm feels natural.

[pause 5s]

[warm, lightly smiling] Pregnancy can bring so many feelings, sometimes all at once. Excitement. Worry. Tenderness. Doubt. Moments of wonder, and moments of "what have I gotten myself into?" And some days, not much feeling at all.

[pause 5s]

[reassuring] There's no right way to feel right now. God isn't asking you to sort your feelings out first. He invites you to bring them to him, just as they are.

[pause 5s]

[reverent] Listen to these words from Philippians:

*In nothing be anxious, but in everything, by prayer and petition with thanksgiving, let your requests be made known to God. And the peace of God, which surpasses all understanding, will guard your hearts and your thoughts in Christ Jesus.*

[pause 8s]

[warm, reflective] In everything. Not only the tidy things. Not only the brave ones.

[pause 5s]

[calm] Rest a hand over the center of your chest, if you'd like. Feel the warmth there. As you breathe out, imagine the space beneath your hand growing a little wider. A little more room.

[pause 7s]

[gentle] Let's bring it all to him now, slowly.

Is there a worry you've been carrying? Something you keep turning over? Tell God about it, in your own words. Be as honest as you like.

[pause 12s]

[hopeful] Now, is there a hope in your heart? Something you long for, for yourself, or for your baby? Tell him that too.

[pause 10s]

[warm] And is there anything, even something small, you're thankful for today? Offer him that as well.

[pause 8s]

[gentle] Notice how both can be true at once. The hope and the worry. The wonder and the tiredness. You're holding all of it, right now, and you're still here, still breathing.

[pause 6s]

[gentle wonder] Within you, a new life is developing as your body makes room for the work of pregnancy. That may stir wonder, affection, anxiety, or a mixture that changes by the hour. You can recognize how extraordinary it is without feeling cheerful about every moment.

[pause 5s]

[tender] Even an ordinary appointment or a quiet day can stir up feelings that are hard to explain. You don't need to resolve them here. Rest a hand on your belly if you'd like, and allow one small moment of connection without asking it to predict tomorrow.

[pause 7s]

[reverent] Peter wrote that we can come to God:

*casting all your worries on him, because he cares for you.*

[pause 7s]

[prayerful, sincere] Father, thank you for listening. Thank you for this child, and for loving us both. These days with my baby are precious to me. You know every hope and every fear I've named, and the ones I couldn't put into words. I'm leaving them, and this little one, with you. Guard my heart and my thoughts today, and keep me close to you. Amen.

[pause 7s]

[warm] When you're ready, let your hands rest, and let your eyes slowly open.

[pause 3s]

However today feels, you're not doing it wrong. Take this peace with you into the rest of your day.

[music 6s]

---

## Week 9 · Grounded

**Title:** Kind / *to your* / body.
**Description:** Five minutes of gentle attention for a body that's changing every day.
**Approach:** gentle movement first, then a kind body scan with no pressure to feel grateful.

[music 4s]

[warm, unhurried] Hello. Let's start by letting your body move a little, before we settle.

If it feels good, roll your shoulders slowly, up, back, and down. Once or twice.

[pause 6s]

[calm] Let your head tip gently toward one shoulder… and then the other.

[pause 6s]

Now find a comfortable position and let yourself be still. If you're feeling queasy or unsettled today, sitting a little upright, with something behind your back, might feel better.

[pause 6s]

There's no need to change your breathing. Just notice it, quietly doing its work.

[pause 6s]

[gentle wonder] This body of yours is responding to pregnancy through changes you can see and changes that remain hidden. Even without your direction, it adjusts and makes space for an extraordinary process. Appreciation doesn't have to mean loving every symptom, every ache, or every new shape.

[pause 6s]

[tender] Perhaps today gratitude is simply noticing that your body deserves care. Perhaps it's feeling a quiet connection to the baby you're carrying. And perhaps today all you can manage is rest. Each of those can be enough.

[pause 6s]

[warm] Today, let's simply be kind to your body, wherever it is.

[pause 4s]

[calm] Bring your attention to your feet, and whatever is beneath them. They've carried you a long way.

[pause 7s]

Your legs. Notice if they feel heavy or tired, and let them rest.

[pause 7s]

[tender] Your belly, where a new life is growing. Rest your hand here, if you'd like.

[pause 10s]

[calm] Your chest, rising and falling. Your heart, keeping its steady rhythm.

[pause 7s]

Your shoulders, your arms, your hands. Let them grow heavy.

[pause 7s]

Your face. Let the small muscles around your eyes and mouth soften.

[pause 8s]

[gentle, reassuring] If there's a place that feels sore, heavy, or uneasy, you don't need to fix it, or feel grateful for it. Just notice it with kindness, the way you might rest a warm hand on someone you love.

[pause 12s]

[warm] Whatever your body is asking for today, whether that's rest, water, a little food, or some fresh air, you're allowed to give it.

[pause 6s]

When you're ready, let your eyes open, and come back slowly.

[pause 3s]

Carry a little of this kindness with you today.

[music 6s]

---

## Week 9 · Faith-centered

**Title:** Fearfully, / *wonderfully* / made.
**Description:** Five minutes to bring your changing body to God, with honesty and gratitude.
**Approach:** the Grounded gentle movement and kind body scan, with God as the gentle shepherd, an honest word with him about what's hard, and gratitude offered freely.
**Scripture:** Isaiah 40:11 (verbatim excerpt: the second and third sentences); Psalm 139:14 (verbatim).

[music 4s]

[warm, unhurried] Hello. Let's start by letting your body move a little, before we settle.

If it feels good, roll your shoulders slowly, up, back, and down. Once or twice.

[pause 5s]

[calm] Let your head tip gently toward one shoulder… and then the other.

[pause 5s]

Now find a comfortable position and let yourself be still. If you're feeling queasy or unsettled today, sitting a little upright, with something behind your back, might feel better.

[pause 5s]

There's no need to change your breathing. Just notice it, quietly doing its work.

[pause 5s]

[gentle wonder] This body of yours is responding to pregnancy through changes you can see and changes that remain hidden. Even without your direction, it adjusts and makes space for an extraordinary process. Appreciation doesn't have to mean loving every symptom, every ache, or every new shape.

[pause 5s]

[reverent] The prophet Isaiah describes God as a shepherd caring for his flock:

*He will gather the lambs in his arm, and carry them in his bosom. He will gently lead those who have their young.*

[pause 7s]

[tender] Gently leading those who have their young. Held. Led gently. Not hurried.

[pause 5s]

[warm] Today, let's simply be kind to your body, wherever it is.

[pause 4s]

[calm] Bring your attention to your feet, and whatever is beneath them. They've carried you a long way.

[pause 5s]

Your legs. Notice if they feel heavy or tired, and let them rest.

[pause 5s]

[tender] Your belly, where a new life is growing. Rest your hand here, if you'd like.

[pause 8s]

[calm] Your chest, rising and falling. Your heart, keeping its steady rhythm.

[pause 5s]

Your shoulders, your arms, your hands. Let them grow heavy.

[pause 5s]

Your face. Let the small muscles around your eyes and mouth soften.

[pause 6s]

[gentle, reassuring] If there's a place that feels sore, heavy, or uneasy, you don't need to fix it, or feel grateful for it. You can simply bring it to God, and let it be held. Tell him what's hard.

[pause 10s]

[reverent] The psalmist prayed:

*I will give thanks to you, for I am fearfully and wonderfully made. Your works are wonderful. My soul knows that very well.*

[pause 7s]

[gentle] If thankfulness feels true today, offer it to him, in your own words. If it doesn't, simply rest in his care.

[pause 8s]

[warm] Whatever your body is asking for today, whether that's rest, water, a little food, or some fresh air, you're allowed to give it.

[pause 5s]

[prayerful, sincere] Creator God, you made me with care, and you're near to me in every change. Thank you for this little one. It's a miracle that this life began at all, and I'm grateful for every day I get to carry them. I entrust them to your gentle care. On the hard days, be my comfort. Lead me gently, the way you lead those with young. Amen.

[pause 6s]

[warm] When you're ready, let your eyes open, and come back slowly.

[pause 3s]

Go gently, knowing you are held.

[music 6s]
