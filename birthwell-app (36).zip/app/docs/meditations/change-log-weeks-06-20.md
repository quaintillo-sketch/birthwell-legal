# Change log · Production edit of weeks 6–20

**Starting point:** Leah's clean revision (revision 5), kept word for word in `archive/rev5-leah-clean-revision-weeks-06-20.md`.
**Goal:** every meditation at 5:30 or under, passages moved where they interrupted an exercise, and tone tags added to direct Maren in ElevenLabs v4.

**What was not changed:** Scripture, prayers (apart from one opening word in week 10, below), titles, descriptions, and the order and wording of everything not listed here.

**Applies to all 30:**
- **Tone tags** were added at the start of paragraphs where the tone shifts. There are 5–15 per script, and they aren't spoken.
- **Silences:** some were shortened by 1–3 seconds, and closing music mostly went from 10 to 8 seconds. Silences for personal prayer and reflection were kept at 10 seconds or more.
- **Dashes:** the long dashes (—) in weeks 14, 16 and 19 became commas, because ElevenLabs reads dashes unevenly. The words are unchanged.

| Week | Moved | Cut | Wording changed |
|---|---|---|---|
| **6 Grounded** | — | "Something new has begun in you. You might feel it clearly… quiet and out of sight." (overlaps your new passage about the earliest weeks) | Merged "Let your shoulders soften" with "Let your jaw loosen", and "Let your hands simply rest" with "For these last moments…", so each pair is one paragraph |
| **6 Faith** | — | "You may feel it, or hardly at all yet. You may feel joy, or worry, or a mix you can't quite sort out." Also the closing "Let your shoulders soften… Let your hands rest." | "Whatever is true for you today" → "Whatever you're feeling about it today". "rest one hand low on your belly" → "…on your belly as you listen" (joins it to the psalm). "You can use words, or simply rest your heart before him" → "in words or simply in stillness" |
| **7 Grounded** | Your two new passages now come before the body scan instead of in the middle of it | Duplicate wording where your new passage and "That tiredness isn't laziness…" said the same thing | Joined into one paragraph: "That tiredness isn't laziness, and it isn't weakness. Your body is adapting to pregnancy in countless quiet ways, and it asks for energy…". Hips joined to the thighs line, and belly joined to arms |
| **7 Faith** | — | "Let your jaw go soft." | "Let your shoulders sink. Let your hands open." → "Let your shoulders sink, and your hands open." Joined "Picture yourself coming to him" and "imagine him making room" into one paragraph |
| **8 Grounded** | Your two new passages now come near the end, after "Notice how both can be true at once," instead of between "What's here today?" and "You don't need words" | "If you'd like, move your hand to your belly. Whatever you're feeling about this pregnancy today, there's room for that too." (your new passage already invites the hand on the belly) | — |
| **8 Faith** | Your two new passages now come before the guided prayer, so the prayer follows its introduction directly | "Sometimes they all arrive at once." | "Let's do that now, slowly." → "Let's bring it all to him now, slowly." (it now follows your passages, not the verse) |
| **9 Grounded** | Your two new passages now come before the body scan instead of between the legs and the belly | "Your body is changing in ways you can feel… You don't have to love every one of them." (your new passage says the same). Also "And if some part of you feels like saying thank you…" (your "Perhaps today gratitude…" covers it) | — |
| **9 Faith** | Your passage and prayer now come before the body prayer instead of in the middle of it | "Your body is changing in ways you can feel… he isn't asking you to pretend." (overlaps your new passage). Also "you don't have to give thanks for the discomfort" (your prayer now says this) | Joined heart/breath with shoulders/hands/face. Joined "Find a comfortable position" with "Let your breath be easy" |
| **10 Grounded** | Your two new passages now come before "Let's find three things…", so the three steady things run together | "The questions about tomorrow will still be there later… You don't have to answer them all today." (your "Tomorrow can have its own space" says the same) | — |
| **10 Faith** | The manna story now follows "Bread for today" directly, with your passage and prayer after it | — | The closing prayer now begins "Lord, thank you…" instead of "Father, thank you…", because your new prayer just before it also begins "Father" |
| **11 Grounded** | Your two new passages now come after "To your belly" instead of between the steam and the smell and taste, so the warm-drink exercise runs without a break | "Your baby is part of this moment too, growing quietly while you rest." (your new passage says the same) | — |
| **11 Faith** | Your two new passages now come before "Let's say it again, a little shorter each time", so the "Be still… Be." sequence runs without a break | "In this season, so much is happening in you without any effort of your own…" (your new passage says the same). The silences inside the "Be still" sequence were lengthened to 12–20 seconds | "As you sit in stillness" → "As you settle into stillness" (it now comes before the stillness) |
| **12 Grounded** | Your second passage ("If your mind is staying alert…") now follows "Now let your mind follow", which it answers | — | Joined "Stay soft…" to the belly line |
| **12 Faith** | — | — | Joined "Find a comfortable position" to the opening |
| **13 Grounded** | — | "Stay here a moment longer with whatever good you found." | — |
| **13 Faith** | Your two new passages now come after the third "Thank you", so the three gifts run together. "If thankfulness feels hard…" moved before your "Your prayer can be simple and sincere…" | "Now take a moment to talk with God about the gifts you noticed…" (your "Whatever is on your heart, you can bring it to him" now leads into the same silence) | — |
| **14 Grounded** | Your first new passage now replaces "Your baby is growing in a warm, dark, cushioned world…", which said the same | "Your baby is growing in a warm, dark, cushioned world, gently rocked as you move." | — |
| **14 Faith** | Your passage and prayer now come before "Let's pray it slowly over your baby now, line by line", so the three blessing lines follow straight after it | — | — |
| **15 Grounded** | Your two new passages now come after "That's you too. Growing." instead of in the middle of loved / good at / grown. Your second passage now follows "Some days you might miss parts of your old life…" | "You're becoming a mother, or a mother again… Both are true." (your "The person you have been and the mother you are becoming don't have to compete" says the same) | — |
| **15 Faith** | — | — | — |
| **16 Grounded** | — | — | — |
| **16 Faith** | — | — | Joined "Let your breath slow down by itself" to the dim-the-lights paragraph. Joined "Let your shoulders sink into the pillow…" to the belly line |
| **17 Grounded** | — | "If support feels thin right now, that's important to notice too… It's part of being human, especially now." (your new passages cover this) | — |
| **17 Faith** | Your second passage ("Some women share joyful news openly…") now follows "Bring to mind someone who has helped carry your burdens" | "If support feels thin right now, tell God about that too. Ask him for the help you need. It's okay to ask." (your passage now asks for that) | — |
| **18 Grounded** | — | "Today isn't about feeling anything in particular…" (your new passage says the same). "Let yourself simply stay here, listening, with nothing to achieve." (the line before it now ends "without needing to achieve anything," and its silence was kept) | — |
| **18 Faith** | Your two new passages now come after the movement-timing paragraph instead of in the middle of the story | — | — |
| **19 Grounded** | Your hand-on-belly passage merged with the later "fourth step" | "Try placing a hand over your belly, if it feels comfortable." (the fourth step already says this). Also "Over time, your body may start to remember this pause on its own…" | — |
| **19 Faith** | — | — | — |
| **20 Grounded** | "That's part of your story now" now comes straight after the moment it refers to, with your two new passages after it | "If you'd like, rest a hand on your belly, and let your baby share this moment of looking back and looking ahead." (your new passage already invites the hand on the belly) | — |
| **20 Faith** | — | "Samuel's stone wasn't a sign that every hard time was over…" (your new "not a guarantee about tomorrow" says the same) | — |

---

## Leah's final wording revisions

Eleven passages were replaced word for word as Leah specified, to make these meditations feel more peaceful, grateful and full of wonder: week 6 Grounded, week 6 Faith (the short prayer), week 7 Grounded, week 7 Faith, week 10 Grounded, week 10 Faith, week 11 Grounded, week 11 Faith, week 12 Grounded and week 12 Faith. The closing prayer in week 6 Faith is unchanged.

**Related adjustments:**
- **Week 12 Faith:** the transition into personal prayer was shortened from "Now tell him what's heavy. Whatever comes. You don't need the right words." to "Now tell him what's heavy. Whatever comes." Leah's new passage just before it already says "You don't need to find perfect words."
- **Tone tags:** the tags on the new passages changed to warmer ones, such as `[warm, gentle wonder]`, `[prayerful, grateful]` and `[warm, reverent]`.
- **Timing:** the new passages are slightly longer, so a few silences in weeks 6, 7, 10, 11 and 12 were shortened by about a second each, keeping every script at 5:30 or under. Silences for personal prayer and reflection stay at 10 seconds or more. Week 7 Faith's closing music went from 10 to 8 seconds.

## Leah's softening revisions (approved)

Five more passages were replaced as Leah specified:
- week 12 Faith ("God welcomes your wonder at creation…")
- week 15 Faith ("Sometimes God's mercies are found in the simplest moments…")
- week 16 Faith ("If your mind wanders back to the busyness of the day…")
- week 19 Grounded ("…whatever thoughts happen to be on your mind")
- week 19 Faith ("If your thoughts wander during this moment…")

**Small transitions and formatting:**
- **Week 15 Faith:** "Ask for that courage as freely as you ask for peace" became "Ask for those small mercies as freely as you ask for peace", because "that courage" no longer refers to anything.
- **Week 15 Faith:** the dash in the new passage became a colon, because ElevenLabs reads dashes unevenly.
- **Week 15 Faith:** "His" became "his", matching the rest of the scripts. It's spoken the same way.
- **Tone tags:** the tags on the new passages in weeks 16 and 19 are calmer. Week 16 now uses `[calm, soothing]` and week 19 uses `[warm, gentle]`.
- **Timing:** a few silences in weeks 15, 16 and 19 were shortened by a second to stay at 5:30 or under.

**Status:** Leah approved the editorial direction of weeks 6–20. These scripts are the writing benchmark for weeks 21–42. Audio will be approved separately.
