# BirthWell Meditations · Audio Production Plan

**Status:** overall approach approved by Leah. **Week 6 pilot approved** with conditions (section 11). Revised with her six adjustments: premium audio security, credit verification, audio continuity, timing, script integrity and approval. The recorder is built and the free dry run is done (section 6). **No paid audio has been recorded.** The pilot is run by Leah on her Mac.

**What we're making:** 74 recordings in Maren's voice, one for each approved script (weeks 6–42, Grounded and Faith-centered). Each runs about 5 minutes, about 6.5 hours of audio in all.

---

## 1. How each meditation is recorded

The meditation recorder (`npm run meditations`) is separate from the coaching-line recorder. It reads the five approved script files directly, so the recordings always match the approved words.

For each meditation it:

1. **Reads the script** and splits it into its paragraphs and silences, exactly as marked.
2. **Removes everything that isn't spoken:** headings, titles, notes, the `[pause]` and `[music]` markers, italics marks and quotation marks. Scripture and prayers are spoken exactly as written.
3. **Records Maren one paragraph at a time** with ElevenLabs v4. Each paragraph is sent with its tone tag, such as `[warm, unhurried]` or `[reverent]`. The tags shape her delivery and aren't spoken.
4. **Keeps her voice consistent between paragraphs.** It sends a fixed "seed", plus the neighbouring paragraphs as context, so each paragraph continues naturally from the last. If v4 turns either option down, the recorder carries on without it and says so. The pilot tests how well this works (section 3).
5. **Builds the silences as real silence.** After each paragraph there's a natural 1-second breath. A `[pause 10s]` adds exactly 10 seconds of silence on top of that breath. The opening and closing `[music]` marks become quiet space of exactly their length. The recordings are voice only, and your soundscapes play underneath in the app, as they do now.
6. **Joins, levels and saves** each meditation as one file. Every meditation is set to the same comfortable volume (−16 LUFS), so Maren is always clear over the soundscape. Maren's own light and shade within a meditation is kept. The files are AAC mono, about 3 MB each.
7. **Keeps every paragraph it has recorded.** If one paragraph needs redoing, only that paragraph is recorded again, at the cost of its characters alone.
8. **Writes a review sheet** next to each file. It lists every paragraph with its start time, length, tone and pace, so you can jump straight to it and note a redo by paragraph number.

**Built-in safety checks:**

- **Dry run:** shows the exact characters and credits for any selection before anything is spent.
- **Credit limit:** every paid run needs a `--max-credits` limit, and the recorder stops before it would go over.
- **Typed confirmation:** you type "yes" before anything is spent.
- **Charge check on the first paragraph:** after the first paragraph of each run, the recorder checks your ElevenLabs account. If more was charged than expected, it stops at once.
- **No double charges:** a finished paragraph is never recorded again unless you ask for it by number.
- **Script check:** the recorder refuses to run unless the words it will send match the approved scripts exactly (section 4).

**Where you'll run it:** on your Mac, the same way you recorded the coaches. Your API key stays on your computer.

---

## 2. Maren's voice settings for meditations

The meditations use Maren's existing voice and the v4 model, with settings of their own, separate from her coaching settings:

- **Pace:** slow and natural, without stretched words.
- **Tone:** warm, clear and reassuring, led by the tone tags. As with Esme's earlier recordings, the tags avoid anything that drifts toward a whisper.
- **Steadiness:** stability 0.6 and similarity 0.75 to start. The pilot may adjust these, and the settings are then locked for the whole library.
- **Pronunciation:**
  - Two rare names get spoken spellings in the text sent to ElevenLabs: Zephaniah and Elihu.
  - Other names are flagged on the review sheets so you can check them by ear: Ebenezer, Hur, Lamentations, Ecclesiastes, Corinthians, Philippians, Galatia, Elizabeth and Isaiah.
  - If one is mispronounced, it gets a spoken spelling and only that paragraph is recorded again.

---

## 3. The pilot and audio continuity

The pilot records **week 6 Grounded and week 6 Faith-centered** (4,689 credits). These come to 35 paragraphs, each generated separately, so the pilot is also a test of how they sound joined together.

**What we check:**

| | How it's checked |
|---|---|
| **Tone** | Listening: does Maren sound like the same person in the same mood from start to finish? Changes of tone should come only from the tone tags. |
| **Volume** | The review sheet flags any paragraph more than 3 dB louder or quieter than the rest of the meditation. Then listening. |
| **Pacing** | The review sheet flags any paragraph more than 20% faster or slower than the rest. Then listening. |
| **Emotion** | Listening, especially where one paragraph follows another after only a 1-second breath. These are the joins most likely to give it away. |

**If the joins are noticeable,** we improve the assembly before any batch is recorded. In order:

1. **Steadier settings:** raise stability (for example to 0.7) and re-record the pilot. The neighbouring-paragraph context stays on.
2. **Longer recordings:** switch to recording each stretch between two silences as one request (`"unit": "block"`). Joins then fall only at silences, where they can't be heard. A redo then covers that stretch of a few paragraphs rather than a single one.
3. **Gentler joins:** adjust the trimming and breath length at the joins. This costs nothing to try, because it only rebuilds the files from the paragraphs already recorded.

Each re-recorded pilot costs about 4,700 credits. The budget allows for two.

---

## 4. Timing and script integrity

**Timing:**

- **Target (updated after the pilot):** Grounded 4:15–5:30 and Faith-centered 4:15–6:00, with small exceptions of up to 10 seconds where the pace sounds more natural. Leah kept Maren's natural pace, which is faster than the 120 words a minute the scripts were timed at.
- **Report:** every file's length is reported against the target, and anything outside it is flagged for listening.
- **Never:** stretching syllables, slowing the audio artificially, or padding pauses to reach a length.
- **If Maren reads noticeably faster or slower than expected:** we adjust her settings in the pilot and re-record.
- **Estimates:** the scripts estimate 4:49–5:30 at about 120 words a minute. The pilot will show Maren's real pace.

**Script integrity:**

- **Spoken words:** every spoken word matches the approved scripts exactly. The scripts in `docs/meditations/weeks-*.md` are never edited by the recorder.
- **Pronunciation fixes:** these change only the text sent to ElevenLabs.
- **Automatic check before every run:** the recorder removes the tone tags, undoes the pronunciation fixes, and compares the result word for word with the approved script. If anything differs, it stops without recording.
- **Tested:** an automatic test checks all 74 scripts. It also confirms that a changed, missing or extra word is caught.

---

## 5. Step by step, with an approval at each step

| Step | What happens | Credits | Your approval |
|---|---|---|---|
| **A. Plan** | This document | none | ✓ Approved |
| **B. Build** | Recorder built and free dry run done | none | ✓ Done |
| **C. Pilot** | Week 6 Grounded and Faith-centered | 4,689 | **Approve spending credits first.** Then listen to both and check continuity (section 3), and adjust if needed. **Lock Maren's settings.** |
| **D. Batch 1** | Weeks 7–20 (28 meditations; week 6 is already done) | 59,623 | Listen through. Any paragraph needing a redo is recorded again on its own. |
| **E. Batch 2** | Weeks 21–42 (44 meditations) | 83,067 | Listen through, plus any redos |
| **F. Go live** | Private hosting, connect the app, test on your iPhone | none | Approve going live |

---

## 6. Verified credit budget (from the dry run)

These are the exact characters the recorder will send, counted from the approved scripts, including the tone tags.

| | Meditations | Requests | Characters sent |
|---|---|---|---|
| **Pilot** (week 6, both versions) | 2 | 35 | **4,689** |
| **Batch 1** (weeks 7–20) | 28 | 486 | **59,623** |
| **Batch 2** (weeks 21–42) | 44 | 685 | **83,067** |
| **First pass, all 74** | 74 | 1,206 | **147,379** |

Of the 147,379 characters, 132,566 are spoken words and 14,803 are tone tags. Pilot paragraphs are saved and never charged again, so batch 1 doesn't count them twice.

**Credit rate:**

- **Expected:** 1 credit per character, so 147,379 credits for the first pass.
- **Check before the pilot (free):** `npm run meditations -- --check` shows your plan, the credits you have left and v4's listed rate.
- **Check during the pilot:** the recorder confirms the real charge after the first paragraph, and again at the end of the run.
- **If the rate isn't 1:** multiply the figures here by it.

**Neighbouring-paragraph context** (about 253,500 characters across the library) is sent for continuity and isn't expected to be billed. The charge check after the first paragraph confirms this. If it is billed, the recorder stops after that one paragraph, and we turn the context off. The figures in this section then stay the same.

**Full budget:**

| | Credits |
|---|---|
| First pass | 147,379 |
| Pilot re-takes, if settings change (up to 2) | 9,378 |
| Redos in the batches (allowance of 15%) | about 21,400 |
| **Total, at most** | **about 178,000** |

**Recommended plan: Creator for two months.** Check current prices in ElevenLabs before upgrading. When last checked, Creator was about $22 a month for 121,000 credits, with a discount on the first month.

| Month | What's recorded | Credits (at most) |
|---|---|---|
| 1 | Pilot, re-takes, batch 1 and its redos | about 83,000 of 121,000 |
| 2 | Batch 2 and its redos | about 96,000 of 121,000 |

- **Why Creator:** two months fit the step-by-step approvals naturally, with room to spare each month, and cost less than Pro. Pro is about $99 a month for 600,000 credits, worth it only if you'd rather record everything in one month.
- **Commercial use:** using the recordings commercially needs a paid plan. Creator and above include it, but please confirm this in your ElevenLabs account terms.

---

## 7. Listening and quality checks

**Automatic checks on every file:**

- **Length:** reported against the targets in section 4.
- **Volume:** every file is levelled to the same loudness, with a ceiling that prevents clipping.
- **Silences:** exact, because they're built as silence rather than generated.
- **Consistency:** the review sheet flags paragraphs that differ in volume or pace from the rest of their meditation.

**Your listening checklist:**

- mispronunciations (names are flagged on the sheet);
- tone drifting (too sleepy, too bright, or whispery);
- joins between paragraphs that sound like a new take;
- rushed or dragging sections;
- odd emphasis;
- background artifacts.

**Fixes:** a redo is one command naming the meditation and paragraph numbers. A mispronounced word gets a spoken spelling in the settings, then that paragraph is recorded again.

**Listening time:** about 2.5 hours per batch at normal speed, or about 2 hours at 1.25×.

---

## 8. Hosting and Premium audio security (before launch)

Premium recordings will be protected before launch, rather than kept in a public folder.

**How it works:**

- **Two storage buckets in Supabase:**
  - A **public bucket** holds the three free meditations (weeks 6, 21 and 36, both versions), so they stay easy to reach without an account or purchase.
  - A **private bucket** holds the other 68. Nobody can open these files directly.
- **Temporary links for Premium:**
  - When the app needs a Premium meditation, it asks a small Supabase server function for it.
  - The function checks with RevenueCat that this person really has Premium, using the app's anonymous RevenueCat ID. No account or login is needed.
  - It then returns a link that works for only a few minutes.
- **Offline listening is unchanged:** Premium listeners still download meditations for offline use. The app uses the short-lived link to download the file once and keeps it on the phone, as it does now. An expired link only matters for a new download, and the app simply asks for a fresh one.
- **Before going live:** if a phone isn't Premium, the function says no and the player shows the Premium screen.

**Organized for future narrators:**

- **Folders:** files are filed by narrator, for example `maren/faith/week-06.m4a`.
- **Manifest:** a small manifest lists each meditation's file, version and exact length. When a recording is replaced, its version changes, so phones that saved the old one fetch the new one.

**Size:** about 230 MB in all, within Supabase's free storage. Please check their current limits when you set it up.

**What you'll need at step F:** a Supabase project, and a RevenueCat secret API key for the server function. That key stays on Supabase, never in the app. I'll write the setup steps when we get there.

---

## 9. App updates once the recordings are approved

- **Real details:** the approved titles, descriptions and exact lengths replace the placeholder titles ("Rooted like the mesa", etc.) and the fixed 6–7 minute lengths.
- **Narrator:** the player shows Maren as narrator. The meditation voice choice is removed until other narrators are added.
- **Meditate list:** each week shows its real title and length, with favorites still working.
- **Free and Premium:** weeks 6, 21 and 36 stay free and the rest are Premium, now protected by temporary links (section 8).
- **Before files are available:** the player keeps working with the iPhone voice until the hosted files are live.
- **Checks:** an automatic test confirms the app's titles and descriptions match the approved scripts.

---

## 10. Timeline

| Step | My time | Your time |
|---|---|---|
| Build the recorder and dry run | ✓ Done | — |
| Pilot | — | about 10 minutes to run it, and 15 minutes to listen and give notes |
| Batch 1 | — | about 1–2 hours of recording (unattended), and about 2.5 hours of listening |
| Batch 2 | — | about 2–3 hours of recording (unattended), and about 3.5 hours of listening |
| Private hosting and app updates | 2–3 sessions | about 45 minutes to set up Supabase and RevenueCat's key, and to test on your iPhone |

---

## 11. Pilot (approved, with conditions)

Leah approved the Week 6 pilot on these conditions, all enforced by the recorder:

1. **Free account check first:** confirms the v4 credit rate and remaining balance.
2. **Capped at 5,000 credits:**
   - The recorder won't start if the verified rate would take the pilot over the cap.
   - It stops after the first paragraph if the measured rate would.
   - In either case, it reports the new estimate.
3. **Week 6 only:** Grounded and Faith-centered.
4. **No batch yet:** weeks 7–42 stay locked until Leah approves the pilot's voice, pacing, pronunciation, paragraph continuity and overall quality.
5. **Recordings kept:** every completed paragraph is kept and reused without being charged again.

Step-by-step instructions for the Mac, including setting up the API key: `pilot-instructions.md`.
