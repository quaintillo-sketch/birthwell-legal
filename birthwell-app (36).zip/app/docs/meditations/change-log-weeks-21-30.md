# Change log · Weeks 21–30

## Leah's editorial revisions (first draft → revised draft)

Replaced word for word as Leah specified:
- **Week 21 Faith:** "Your heart is working in remarkable ways to support this pregnancy…"
- **Week 22 Grounded:** "Imagine the warmth of the world surrounding your baby." Also "Think about the extraordinary ways your body adapts throughout pregnancy…"
- **Week 23 Grounded:** "There's beauty in both strength and softness…"
- **Week 24 Grounded:** "Every breath is part of an extraordinary process…"
- **Week 25 Grounded:** "At this stage, you may be becoming more familiar with the sensation of your baby's movements…". This removes the earlier line about busy days and quiet days, so nothing suggests a change in movement is normal. The rest of the meditation stays optional ("If you feel a movement…", "Whether or not yours moves right now…").

**Week 30, both versions:** the joyful anticipation stays, but listeners are no longer asked to picture a specific scene.
- **Grounded:** "Now imagine your baby being placed close to you…" and the run of specific images after it were replaced with Leah's open invitation: "If you'd like, imagine a moment of welcoming your baby. You don't need to picture every detail. Simply allow yourself to reflect on the love and tenderness you hope to share." What follows is optional ("Perhaps you imagine… Or perhaps no picture comes at all, only a feeling. Whatever comes is enough."). The rest focuses on the tenderness she hopes to share. The description and approach lines were updated to match.
- **Faith-centered:** "Imagine holding your baby close…" became the same open invitation, about comforting her baby. "the way you'll wrap your arms around your baby" became "the way a mother wraps her arms around her child". The approach line was updated to match.

**Checks after the edits:**
- Every script runs 4:50–5:23.
- Every Bible quote matches the World English Bible.
- No opening or ending repeats across weeks 6–30.
- No script mentions loss, complications or worry.
