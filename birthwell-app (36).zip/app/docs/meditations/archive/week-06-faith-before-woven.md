# Week 6 · Faith-centered, as approved before the woven revision

Kept word for word for reference. Replaced at Leah's request by the version built on Grounded, with faith woven in.

### Week 6 · Faith-centered

**Title:** Known / *before* / the beginning.
**Description:** Five quiet minutes to rest in being known and loved by God, right where you are.
**Approach:** God's call by name, the hidden work he sees, and a moment of personal prayer in the middle.
**Scripture:** Isaiah 43:1 (verbatim excerpt: the words God speaks to Israel, from the second half of the verse); Psalm 139:13 (verbatim).

[music 6s]

[warm, unhurried] Welcome. Let these few minutes be set apart, for you and for God.

Find a position that feels restful. There's nothing you need to prepare, and nothing you need to say yet.

[pause 4s]

[calm] Let your breath find a comfortable rhythm. Notice it moving in… and out… without changing a thing.

[pause 5s]

[reverent] Through the prophet Isaiah, God spoke these words to his people Israel, reminding them that they belonged to him:

*Don't be afraid, for I have redeemed you. I have called you by your name. You are mine.*

[pause 8s]

[warm, reflective] Those words were first spoken to a whole people, long ago. But they show us the heart of a God who knows his own by name. Not by their to-do lists, or by how well they're coping. By name.

[pause 6s]

Let your own name settle quietly in your mind. Whatever today holds, you are not a stranger to God.

[pause 7s]

[tender] Something new has begun in you. Whatever you're feeling about it today, you are already known by God, and you are loved.

[pause 5s]

[gentle wonder] Even at this early beginning, pregnancy is full of intricate, unseen changes. Your body is participating in the work of carrying a new life, and you can bring your awe at that mystery to God. You need not feel strong or certain to give thanks for this moment.

[pause 6s]

[prayerful, grateful] Lord, thank you for the wonder of this new beginning. For the intricate ways you've designed the human body, and for the precious life I carry today. Help me slow down, recognize your goodness, and receive this moment with gratitude and peace.

[pause 5s]

[reverent] If it feels right, rest one hand low on your belly as you listen. The psalmist prayed:

*For you formed my inmost being. You knit me together in my mother's womb.*

[pause 8s]

[warm, reassuring] The God who saw you before anyone else did sees this little one now. You don't have to understand what's ahead. You don't have to hold all of it by yourself.

[pause 6s]

[gentle] Take a quiet moment to talk with God about this new beginning, in words or simply in stillness. He already knows what you're feeling.

[pause 12s]

[prayerful, sincere] Lord, thank you that you know me by name. Thank you for seeing this little life, hidden from everyone but you. I don't know everything that's ahead, but I know I'm not alone in it. Help me rest in your love today. Amen.

[pause 8s]

[warm] When you're ready, gently open your eyes.

[pause 3s]

Go into your day knowing you are known, and you are loved.

[music 6s]

