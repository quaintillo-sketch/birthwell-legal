# Weekly meditations · Weeks 6–20 (revision 5: Leah's clean revision, as written)

Converted word for word from the PDF "BirthWell_Meditations_Weeks_06-20_Clean_Revision". Scripture is in italics. This is the reference copy; the production scripts in weeks-06-09.md and weeks-10-20.md are edited from it, and every change is listed in change-log-weeks-06-20.md.

---

## Week 6 · Grounded

**Title:** Simply / *to* / arrive.
**Description:** Five quiet minutes to land in your body, just as it is today, with nothing to figure out.
**Approach:** arriving through the senses, an optional hand on the belly, and stillness.

[music 8s]

Hello. Before anything else, just notice that you've stopped. Whatever came before this moment, and whatever comes after, can wait a few minutes.

Settle into a position that feels easy. Sitting, lying down, leaning back against something soft. There's nothing to get right here.

[pause 4s]

You might let your eyes close, or let your gaze rest somewhere gentle.

[pause 4s]

There's no need to change anything about your breathing. Just notice your next breath as it comes… and as it goes.

[pause 6s]

Now let's arrive, one sense at a time.

Notice the sounds around you. Some near, some farther away. You don't need to name them. Just let them be part of the room.

[pause 7s]

Notice where your body is being held. The weight of your legs. Your back. Your head. Let whatever is beneath you take a little more of you.

[pause 7s]

Notice the air on your skin. Warm or cool. Still, or gently moving.

[pause 6s]

You're here.

[pause 5s]

There's something extraordinary about these earliest weeks. Cells are multiplying and beginning to take on different roles, while your body adapts in ways you may not even notice. You don't need to direct any of that work. You may be astonished by it, or still be taking in the news. Either response belongs here.

[pause 6s]

If this beginning feels tender or uncertain, there's no need to talk yourself out of that feeling. You can notice the wonder of this moment without asking it to promise you anything about tomorrow.

[pause 6s]

Something new has begun in you. You might feel it clearly, or hardly at all yet. You might feel happy, unsure, overwhelmed, or simply tired. All of that is welcome. Early on, so much of what's happening is quiet and out of sight.

[pause 6s]

If it feels right, rest one hand low on your belly, and the other over your heart.

[pause 5s]

You don't have to feel anything in particular. Just notice the warmth of your own hands, and the small movement beneath them as you breathe.

[pause 10s]

You don't need to have this figured out. Not the plans, not the feelings, not the months ahead. Right now there is only this breath, and the one after it.

[pause 8s]

Let your shoulders soften as you breathe out.

[pause 6s]

Let your jaw loosen.

[pause 6s]

Let your hands simply rest.

[pause 12s]

For these last moments, there's nothing to do at all. Just be here, as you are.

[pause 10s]

When you're ready, let a little movement come back. Your fingers. Your toes. Notice the light around you.

[pause 4s]

You arrived, and that was enough. You can return to this quiet whenever you need it.

[music 10s]

---

## Week 6 · Faith-centered

**Title:** Known / *before* / the beginning.
**Description:** Five quiet minutes to rest in being known and loved by God, right where you are.
**Approach:** God's call by name, the hidden work he sees, and a moment of personal prayer in the middle.
**Scripture:** Isaiah 43:1 (verbatim excerpt: the words God speaks to Israel, from the second half of the verse); Psalm 139:13 (verbatim).

[music 8s]

Welcome. Let these few minutes be set apart, for you and for God.

Find a position that feels restful. There's nothing you need to prepare, and nothing you need to say yet.

[pause 4s]

Let your breath find a comfortable rhythm. Notice it moving in… and out… without changing a thing.

[pause 6s]

Through the prophet Isaiah, God spoke these words to his people Israel, reminding them that they belonged to him:

*Don't be afraid, for I have redeemed you. I have called you by your name. You are mine.*

[pause 8s]

Those words were first spoken to a whole people, long ago. But they show us the heart of a God who knows his own by name. Not by their to-do lists, or by how well they're coping. By name.

[pause 6s]

Let your own name settle quietly in your mind. Whatever today holds, you are not a stranger to God.

[pause 10s]

Something new has begun in you. You may feel it, or hardly at all yet. You may feel joy, or worry, or a mix you can't quite sort out. Whatever is true for you today, you are already known by God, and you are loved.

[pause 6s]

Even at this early beginning, pregnancy is full of intricate, unseen changes. Your body is participating in the work of carrying a new life, and you can bring your awe at that mystery to God. You need not feel strong or certain to give thanks for this moment.

[pause 6s]

Lord, if hope comes easily today, receive my joy. If it comes cautiously, receive that too. Help me be gentle with myself as I entrust to you what I cannot know.

[pause 6s]

If it feels right, rest one hand low on your belly.

[pause 4s]

The psalmist prayed:

*For you formed my inmost being. You knit me together in my mother's womb.*

[pause 8s]

The God who saw you before anyone else did sees this little one now. You don't have to understand what's ahead. You don't have to hold all of it by yourself.

[pause 6s]

Take a quiet moment to talk with God about this new beginning. You can use words, or simply rest your heart before him. He already knows what you're feeling.

[pause 15s]

Lord, thank you that you know me by name. Thank you for seeing this little life, hidden from everyone but you. I don't know everything that's ahead, but I know I'm not alone in it. Help me rest in your love today. Amen.

[pause 8s]

Let your shoulders soften as you breathe out. Let your hands rest.

[pause 10s]

When you're ready, gently open your eyes.

[pause 3s]

Go into your day knowing you are known, and you are loved.

[music 10s]

---

## Week 7 · Grounded

**Title:** Rest / *is* / enough.
**Description:** Five minutes of permission to slow down, because growing a new life is real work.
**Approach:** permission to rest, progressive heaviness, and a peaceful resting place.

[music 8s]

Hi. If you can, let yourself lie down for this one. On your side is lovely, with a pillow wherever you need it. If lying down isn't possible right now, simply lean back and let something hold you.

[pause 5s]

You may be more tired than usual right now. The kind of tired that a good night's sleep doesn't quite reach. Pregnancy can ask so much of you, in body and in heart, even on days when it seems like nothing is happening.

[pause 5s]

That tiredness isn't laziness, and it isn't weakness. It's what it can feel like when your body is quietly doing a great deal of work.

[pause 6s]

So here's your permission. For the next few minutes, you don't need to be useful. You don't need to catch up. Rest doesn't need to be earned.

[pause 8s]

Let's let the heaviness come.

Start with your feet. Imagine them growing warm and heavy, sinking a little into whatever is beneath them.

[pause 6s]

That warmth moves into your calves… your knees… your thighs. Heavy. Easy. Held.

[pause 7s]

Your hips and lower back, letting go.

[pause 6s]

While you lie here, your body is already adapting to pregnancy in countless quiet ways. It asks for energy and rest, sometimes more than you expected. There is something remarkable in that work, even if all you notice today is how tired you feel.

[pause 6s]

You can appreciate the life you're carrying and still wish this part felt easier. If worry visits you, there's room for it too. Rest doesn't require confidence about tomorrow; it only asks you to give yourself a little kindness right now.

[pause 6s]

Your belly, soft, with nothing to hold in.

[pause 6s]

Your arms, heavy all the way down to your fingertips.

[pause 6s]

And your face. The space between your eyebrows. Your jaw. The soft skin around your eyes.

[pause 8s]

Now picture a place where you could rest completely. Maybe a sunlit room on a slow afternoon, with nowhere to be. A hammock in the shade. Or somewhere only you know.

[pause 8s]

Let yourself be there. Notice the light. The quiet. How nobody needs anything from you.

[pause 10s]

If your mind wanders to the dishes, the emails, the list, that's all right. Notice it, and let your next breath out carry you back to your resting place.

[pause 10s]

You're allowed to stay a little longer.

[pause 12s]

When you're ready, let your body begin to wake. Gently. There's no rush.

[pause 4s]

Be gentle with yourself today, and rest whenever you can. It counts.

[music 10s]

---

## Week 7 · Faith-centered

**Title:** Come / *and* / rest.
**Description:** Five minutes to lay down what feels heavy and receive the rest Jesus offers.
**Approach:** coming to Jesus as you are, setting burdens down in prayer, then resting in his care.
**Scripture:** Matthew 11:28–29 (verbatim); Psalm 23:2 (verbatim).

[music 8s]

Welcome. Let yourself get comfortable. Lie down if you can, perhaps on your side with a pillow. Or simply lean back and let yourself be supported.

[pause 5s]

You may be more tired than usual right now. Pregnancy can ask so much of you, in body and in heart. And it can be hard to slow down when there's so much to carry.

[pause 5s]

Listen to the words of Jesus:

*Come to me, all you who labor and are heavily burdened, and I will give you rest. Take my yoke upon you, and learn from me, for I am gentle and humble in heart; and you will find rest for your souls.*

[pause 10s]

He doesn't say, come once you've finished everything. He doesn't say, come once you've earned it. He simply says, come.

[pause 6s]

Picture yourself coming to him now, just as you are. Tired, perhaps. Unfinished. A little worn.

[pause 6s]

And imagine him making room for you. Gentle. Unhurried. Glad you came.

[pause 10s]

Your body is doing quiet, demanding work as this pregnancy continues. The little life within you is precious, and so are you, the mother carrying it. You don't have to turn your exhaustion into a lesson or hide it from Jesus.

[pause 6s]

Perhaps you feel grateful. Perhaps hope feels difficult today. Bring both to him. His invitation to rest doesn't require you to stop feeling afraid; it's an invitation to come as you are.

[pause 6s]

What are you carrying today? Tell him quietly. The tiredness. The worries. The things you haven't gotten to. You can set each one down in front of him.

[pause 15s]

Jesus, I'm tired, and you already know it. Thank you that I don't have to earn your rest, or prove that I deserve it. I'm setting these things down with you. Teach me to rest in you. Amen.

[pause 8s]

Now let your body follow your heart. Let your shoulders sink. Let your hands open. Let your jaw go soft.

[pause 8s]

In Psalm 23, David says of the Lord, his shepherd:

*He makes me lie down in green pastures. He leads me beside still waters.*

[pause 8s]

Rest here a while, beside still waters, in his care.

[pause 13s]

When you're ready, let some movement return, slowly.

[pause 3s]

May you find his rest in the ordinary moments of today.

[music 12s]

---

## Week 8 · Grounded

**Title:** Room for / *every* / feeling.
**Description:** Five minutes to let joy, worry, and everything in between sit side by side.
**Approach:** an honest check-in, making room in the chest, and welcoming mixed feelings.

[music 8s]

Hi. Before we begin, take a moment to check in with yourself. Not how you think you should be feeling. How you actually are.

[pause 8s]

Find a comfortable position, and let your breath settle into whatever rhythm feels natural.

[pause 6s]

Pregnancy can bring so many feelings, sometimes all at once. Excitement. Worry. Tenderness. Doubt. Moments of wonder, and moments of "what have I gotten myself into?" And some days, not much feeling at all.

[pause 6s]

There's no right way to feel right now. Whatever you're feeling is welcome here.

[pause 6s]

Rest a hand over the center of your chest, if you'd like. Feel the warmth there.

[pause 5s]

As you breathe out, imagine the space beneath your hand growing a little wider. A little more room.

[pause 8s]

Now gently ask yourself: *What's here today?*

Within you, a new life is developing as your body makes room for the work of pregnancy. That may stir wonder, affection, anxiety, or a mixture that changes by the hour. You can recognize how extraordinary it is without feeling cheerful about every moment.

[pause 6s]

Even an ordinary appointment or a quiet day can stir up feelings that are hard to explain. You don't need to resolve them here. Rest a hand on your belly if you'd like, and allow one small moment of connection without asking it to predict tomorrow.

[pause 6s]

You don't need words. Just notice. Is there lightness? Heaviness? A flutter? A knot?

[pause 12s]

Whatever you find, you don't need to fix it or explain it. You can simply say to it: *There's room for this feeling, too.*

[pause 8s]

If worry is here, let it sit beside you, like someone on a park bench. It doesn't have to leave for you to feel some peace. You can keep breathing with it there.

[pause 10s]

And if there's joy, even a small spark of it, let yourself feel that too. Joy doesn't need to wait until everything is certain. It's allowed to be here now.

[pause 10s]

Notice how both can be true at once. The hope and the worry. The wonder and the tiredness. You're holding all of it, right now, and you're still here, still breathing.

[pause 12s]

If you'd like, move your hand to your belly. Whatever you're feeling about this pregnancy today, there's room for that too.

[pause 10s]

When you're ready, let your hands rest, and let your eyes slowly open.

[pause 3s]

However today feels, you're not doing it wrong. There's room for all of you.

[music 10s]

---

## Week 8 · Faith-centered

**Title:** Peace / *that* / guards.
**Description:** Five minutes to bring your real worries and hopes to God, and rest in his care.
**Approach:** guided personal prayer, with silence to bring a worry, a hope, and a thanks to God in your own words.
**Scripture:** Philippians 4:6–7 (verbatim); 1 Peter 5:7 (verbatim).

[music 8s]

Welcome. Let this be a quiet place to be honest with God.

Settle in, and let your breath find its own comfortable pace.

[pause 6s]

Pregnancy can stir up so many feelings. Hope and fear. Gratitude and questions. Sometimes they all arrive at once.

[pause 5s]

God isn't asking you to sort them out first. He invites you to bring them to him, just as they are.

[pause 5s]

Listen to these words from Philippians:

*In nothing be anxious, but in everything, by prayer and petition with thanksgiving, let your requests be made known to God. And the peace of God, which surpasses all understanding, will guard your hearts and your thoughts in Christ Jesus.*

[pause 8s]

In everything. Not only the tidy things. Not only the brave ones.

[pause 5s]

Let's do that now, slowly.

There is an extraordinary tenderness in carrying a baby while carrying questions too. Your body is engaged in the work of pregnancy, and your heart may be doing its own difficult work of hoping. God welcomes the whole of you, not only the thankful or peaceful parts.

[pause 6s]

If relaxing feels difficult today, you can tell God that plainly. You are allowed to marvel at this life and ask for courage at the same time. Neither feeling cancels the other.

[pause 6s]

Is there a worry you've been carrying? Something you keep turning over? Tell God about it, in your own words. Be as honest as you like.

[pause 15s]

Now, is there a hope in your heart? Something you long for, for yourself, or for your baby? Tell him that too.

[pause 13s]

And is there anything, even something small, you're thankful for today? Offer him that as well.

[pause 10s]

Peter wrote that we can come to God:

*casting all your worries on him, because he cares for you.*

[pause 8s]

Peace doesn't always arrive all at once. Sometimes it comes quietly, like someone sitting down beside you. Whatever you still feel, you're not carrying it alone.

[pause 8s]

Father, thank you for listening. You know every hope and every fear I've named, and the ones I couldn't put into words. I'm leaving them with you. Guard my heart and my thoughts today, and keep me close to you. Amen.

[pause 10s]

When you're ready, let your eyes open gently.

[pause 3s]

Take this peace with you into the rest of your day.

[music 10s]

---

## Week 9 · Grounded

**Title:** Kind / *to your* / body.
**Description:** Five minutes of gentle attention for a body that's changing every day.
**Approach:** gentle movement first, then a kind body scan with no pressure to feel grateful.

[music 8s]

Hello. Let's start by letting your body move a little, before we settle.

If it feels good, roll your shoulders slowly, up, back, and down. Once or twice.

[pause 6s]

Let your head tip gently toward one shoulder… and then the other.

[pause 6s]

Now find a comfortable position and let yourself be still. If you're feeling queasy or unsettled today, sitting a little upright, with something behind your back, might feel better.

[pause 6s]

There's no need to change your breathing. Just notice it, quietly doing its work.

[pause 6s]

Your body is changing in ways you can feel, and in many ways you can't. Some changes might feel welcome. Others might feel uncomfortable, or just unfamiliar. You don't have to love every one of them.

[pause 6s]

Today, let's simply be kind to your body, wherever it is.

[pause 4s]

Bring your attention to your feet, and whatever is beneath them. They've carried you a long way.

[pause 7s]

Your legs. Notice if they feel heavy or tired, and let them rest.

[pause 7s]

This body of yours is responding to pregnancy through changes you can see and changes that remain hidden. Even without your direction, it adjusts and makes space for an extraordinary process. Appreciation doesn't have to mean loving every symptom, every ache, or every new shape.

[pause 6s]

Perhaps today gratitude is simply noticing that your body deserves care. Perhaps it's feeling a quiet connection to the baby you're carrying. And perhaps today all you can manage is rest. Each of those can be enough.

[pause 6s]

Your belly, where a new life is growing. Rest your hand here, if you'd like.

[pause 10s]

Your chest, rising and falling. Your heart, keeping its steady rhythm.

[pause 7s]

Your shoulders, your arms, your hands. Let them grow heavy.

[pause 7s]

Your face. Let the small muscles around your eyes and mouth soften.

[pause 8s]

If there's a place that feels sore, heavy, or uneasy, you don't need to fix it, or feel grateful for it. Just notice it with kindness, the way you might rest a warm hand on someone you love.

[pause 12s]

And if some part of you feels like saying thank you, you can quietly do that too.

[pause 12s]

Whatever your body is asking for today, whether that's rest, water, a little food, or some fresh air, you're allowed to give it.

[pause 6s]

When you're ready, let your eyes open, and come back slowly.

[pause 3s]

Carry a little of this kindness with you today.

[music 10s]

---

## Week 9 · Faith-centered

**Title:** Fearfully, / *wonderfully* / made.
**Description:** Five minutes to bring your changing body to God, with honesty and gratitude.
**Approach:** opens with prayer, God as the gentle shepherd, an honest body prayer, and gratitude offered freely.
**Scripture:** Isaiah 40:11 (verbatim excerpt: the second and third sentences); Psalm 139:14 (verbatim).

[music 8s]

Welcome. Let's begin this time with a short prayer.

Lord, thank you for this moment to slow down. Be near to me as I rest. Amen.

[pause 6s]

Find a comfortable position. If you're feeling unsettled or queasy today, sitting a little upright, with support behind your back, may help.

[pause 5s]

Let your breath be easy. There's nothing you need to change.

[pause 6s]

Your body is changing in ways you can feel, and in many ways you can't. Some days that might feel wonderful. Other days, uncomfortable, or just strange. God sees all of it, and he isn't asking you to pretend.

[pause 6s]

The prophet Isaiah describes God as a shepherd caring for his flock:

*He will gather the lambs in his arm, and carry them in his bosom. He will gently lead those who have their young.*

[pause 8s]

Gently leading those who have their young. Held. Led gently. Not hurried.

[pause 8s]

Let's bring your body before God, one part at a time.

Your feet and legs, carrying you through each day.

[pause 6s]

Your body's changes may leave you amazed one day and uncomfortable the next. Pregnancy asks a great deal of you, and God's care does not depend on how gracefully you bear it. You can thank him for the wonder of this growing life while still asking for relief and strength.

[pause 6s]

Lord, teach me to treat this body with tenderness. When trust feels difficult, help me bring my questions to you without shame. Let gratitude be an invitation, never a demand.

[pause 6s]

Your belly, where a new life is growing. Rest your hand here, if you'd like.

[pause 10s]

Your heart, beating steadily. Your breath, coming and going.

[pause 7s]

Your shoulders, your hands, your face. Let them soften.

[pause 7s]

If there's a place that aches or feels uneasy, you don't have to give thanks for the discomfort. You can simply bring it to him, and let it be held. Tell him what's hard.

[pause 12s]

The psalmist prayed:

*I will give thanks to you, for I am fearfully and wonderfully made. Your works are wonderful. My soul knows that very well.*

[pause 8s]

If thankfulness feels true today, offer it to him, in your own words. If it doesn't, simply rest in his care.

[pause 12s]

Creator God, you made me with care, and you're near to me in every change. Thank you for this little one. On the hard days, be my comfort. Lead me gently, the way you lead those with young. Amen.

[pause 8s]

When you're ready, open your eyes and come back slowly.

[pause 3s]

Go gently, knowing you are held.

[music 10s]

---

## Week 10 · Grounded

**Title:** One / *day* / at a time.
**Description:** Five minutes to set down tomorrow's questions and come back to today.
**Approach:** noticing how far ahead the mind runs, gently returning to today, and finding three things that are steady right now.

[music 8s]

Hi. Let's take this one day, and this one moment, at a time.

Get comfortable in whatever way your body likes today. Let your hands rest wherever they land.

[pause 5s]

Your breath can do whatever it wants. You're just here to keep it company.

[pause 6s]

It's natural, in pregnancy, for the mind to race ahead. To the next appointment. The next test result. How you'll manage work, or sleep, or money, or everything else. Months of questions can fit into a single minute of worrying.

[pause 6s]

For now, let's notice where your mind has been travelling. You don't need to follow it. Just notice the direction.

[pause 10s]

Now imagine gently calling it home, the way you might call to someone who's wandered a little too far down the beach. No scolding. Just: *come back.*

[pause 8s]

Here is today. Only today.

[pause 6s]

Let's find three things that are steady, right now.

Today, your body is occupied with the remarkable, largely unseen work of pregnancy. You don't need to map every step of it to appreciate what's happening now. You can be curious about your baby and still feel unsettled by questions that haven't been answered.

[pause 6s]

If hope feels cautious, there's no need to force it to grow faster. Return to the present: this breath, these hands, this moment of carrying a little life. Tomorrow can have its own space when it arrives.

[pause 6s]

First, something supporting you. The chair, the bed, the floor. Notice it holding you without being asked.

[pause 8s]

Second, something you can hear. Maybe the music. Maybe a sound in the room, or outside.

[pause 8s]

Third, something about your own body that feels okay, even a little. Warm hands. Soft shoulders. A comfortable spot.

[pause 10s]

Three steady things. They were here all along, while your mind was busy elsewhere.

[pause 6s]

The questions about tomorrow will still be there later, and you'll meet them when they come, with whatever you know then. You don't have to answer them all today.

[pause 8s]

If you'd like, rest a hand on your belly. Today, you're both simply here.

[pause 10s]

Let yourself stay with today a little longer.

[pause 14s]

When you're ready, open your eyes, and notice one more steady thing around you.

[pause 4s]

Tomorrow can wait. For now, this day is enough.

[music 10s]

---

## Week 10 · Faith-centered

**Title:** Bread / *for* / today.
**Description:** Five minutes to trust God with tomorrow, and ask him for what you need today.
**Approach:** Jesus' teaching on tomorrow, honest prayer for today's needs, and quiet trust.
**Scripture:** Matthew 6:34 (verbatim excerpt: the first sentence); Matthew 6:11 (verbatim).

[music 8s]

Welcome. For the next few minutes, today is the only day you need to think about.

Settle in comfortably, and let your breath find its own easy pace.

[pause 6s]

It's natural, in pregnancy, for the mind to race ahead. The next appointment. Results you're waiting for. How everything will work out. It can feel like trying to carry months of tomorrows all at once.

[pause 6s]

Jesus knew how heavy that can be. In the Sermon on the Mount, he said:

*Therefore don't be anxious for tomorrow, for tomorrow will be anxious for itself.*

[pause 8s]

He wasn't scolding anyone for worrying. He was inviting them to put tomorrow down, and let God hold it.

[pause 6s]

In that same sermon, he taught his followers to pray, simply:

*Give us today our daily bread.*

[pause 8s]

Not bread for the whole year. Bread for today.

[pause 6s]

So much of pregnancy unfolds beyond your conscious effort. Your body is adapting as a little life develops within you. This can inspire deep gratitude and just as deep uncertainty; God doesn't require you to choose one feeling before bringing him the other.

[pause 6s]

Father, when unanswered questions make tomorrow seem heavy, give me the grace to live this one day. Help me cherish what is here without pretending I know what comes next.

[pause 6s]

Long before, in the wilderness, God gave his people manna each morning. Just enough for each day. They couldn't store it up for the week ahead. They had to trust that tomorrow's would come with tomorrow.

[pause 8s]

What do you need for today? Rest? Patience? Strength for a hard conversation? A little more comfort in your body? Tell God, in your own words. Nothing is too small.

[pause 15s]

And if there's a tomorrow you've been carrying, an appointment, a decision, a fear, picture yourself placing it into his hands. It will still be there when its day comes. And so will he.

[pause 10s]

Father, thank you that I don't have to hold every tomorrow today. Give me what I need for this day, and help me trust you with the rest. Amen.

[pause 10s]

If you'd like, rest a hand on your belly, and simply be here, with God, today.

[pause 12s]

When you're ready, let your eyes open slowly.

[pause 3s]

Go into today with what you need for today.

[music 10s]

---

## Week 11 · Grounded

**Title:** Small / *and* / steady.
**Description:** Five minutes to find calm in an ordinary moment, the kind that's always within reach.
**Approach:** mindful listening, then noticing one ordinary comfort in close detail, like a warm drink in your hands.

[music 8s]

Let's begin with a few seconds of just listening.

[pause 8s]

Not trying to relax. Not trying to do anything. Just letting sounds arrive.

[pause 8s]

There's a kind of calm that doesn't need a quiet house, or a free afternoon, or everything going well. It's small, and it's steady, and it can be found inside an ordinary moment.

[pause 6s]

Let's find one.

If you have a warm drink nearby, you can hold it. If not, simply imagine one. A mug of tea, or warm milk, or anything that comforts you.

[pause 6s]

Feel the warmth spreading into your palms.

[pause 6s]

Notice the weight of the cup. The texture of it under your fingers.

[pause 6s]

If there's steam, imagine it rising slowly, and fading.

[pause 8s]

While you're noticing this ordinary comfort, remember that pregnancy is happening within the ordinary hours too. The body you're resting in is continually adjusting to carry this baby. Nothing dramatic needs to happen in this room for this moment to be meaningful.

[pause 6s]

You might feel a flicker of wonder, or simply notice warmth in your palms. Even if anxiety makes calm hard to find, you can offer yourself this small kindness without demanding a particular feeling in return.

[pause 6s]

This is all it takes. One ordinary thing, noticed fully.

[pause 6s]

Notice the smell, if there is one. Notice the first small taste, if you take a sip. Let it be the only thing happening, just for a moment.

[pause 10s]

Now let your attention widen, just a little. To your hands. Your arms. Your shoulders, softening as you breathe out.

[pause 8s]

To your belly. Your baby is part of this moment too, growing quietly while you rest.

[pause 10s]

Most days aren't made of big peaceful hours. They're made of minutes. Waiting for the kettle. Sitting in the car before you go inside. Lying down for the first moment at night.

[pause 6s]

Any one of those minutes can become a small, steady place, if you let yourself notice it.

[pause 10s]

Stay here with your ordinary moment a little longer.

[pause 10s]

When you're ready, set down your cup, real or imagined, and let your eyes open.

[pause 4s]

Small, steady moments like this are always within reach. You know where to find one now.

[music 10s]

---

## Week 11 · Faith-centered

**Title:** Be / *still* / and know.
**Description:** Five minutes of quiet with one short verse, letting it slowly settle into stillness.
**Approach:** a slow, contemplative reading where the verse grows shorter with each repeat, with silence between.
**Scripture:** Psalm 46:10 (verbatim excerpt: the first sentence). The shorter repeats that follow are adapted from it and are not shown in italics.

[music 8s]

Welcome.

[pause 5s]

This meditation uses very few words, and a lot of quiet.

We'll stay with one short line from Psalm 46, and let it slowly settle, the way snow settles in a snow globe once you stop shaking it.

[pause 6s]

Find a comfortable way to sit or lie down. Let your hands rest open.

[pause 6s]

Psalm 46 was written for God's people in a time of upheaval. Nations in uproar, the earth itself shaking. And in the middle of it all, God says:

*Be still, and know that I am God.*

[pause 10s]

Let's say it again, a little shorter each time, and rest in the silence between.

Be still, and know that I am God.

[pause 10s]

Be still, and know.

[pause 10s]

As you sit in stillness, your body continues its remarkable work of carrying new life. You don't have to keep watch over every unseen change. Let the quiet remind you that this baby matters, and that you matter to God too.

[pause 6s]

If fear interrupts the silence, it doesn't mean you've failed at prayer. You can place that fear here alongside your gratitude, then return gently to the words of the psalm.

[pause 6s]

Be still.

[pause 10s]

Be.

[pause 15s]

Stillness isn't the same as having no thoughts. It's more like resting. Letting God be God, while you simply stay near.

[pause 8s]

If your mind wanders, that's all right. Come back to whichever word feels like home.

[pause 12s]

In this season, so much is happening in you without any effort of your own. Your baby is growing even now, while you are still. That's a kind of trust too.

[pause 12s]

Lord, in all the busyness and change of this season, thank you for being God, so I don't have to be. Let me be still with you. Amen.

[pause 10s]

When you're ready, let your eyes open gently.

[pause 3s]

Stay in that stillness as long as you'd like. It's yours to come back to.

[music 10s]

---

## Week 12 · Grounded

**Title:** Letting / *it* / go.
**Description:** Five minutes to release the tension your body has been quietly holding.
**Approach:** gentle, optional tense-and-release through the hands, shoulders, and face, then letting the mind loosen too.

[music 8s]

Start by noticing your hands. Where are they resting? Are they open, or curled? Soft, or holding on?

[pause 6s]

Many of us carry tension without realizing it. In our hands, our shoulders, our faces. Today, let's gently let some of it go.

Settle in comfortably first.

[pause 6s]

We'll start with your hands. If it feels good, make a soft fist. Not tight. Just enough to notice the effort.

[pause 4s]

And let it go. Let your fingers uncurl and fall open.

[pause 8s]

Notice the difference. The tingling, or the warmth, or the heaviness after letting go.

[pause 6s]

Now your shoulders. If it's comfortable, lift them gently toward your ears.

[pause 4s]

And let them drop.

[pause 8s]

Let them keep sinking, a little more with each breath out.

[pause 8s]

Your body has been adapting to a new life while you manage everything else that fills your days. Its work is remarkable; the tension you carry is understandable. Releasing your shoulders for a moment doesn't mean releasing your care for this baby.

[pause 6s]

If your mind is staying alert, softening may feel unfamiliar. You can choose just a little ease without asking yourself to be certain of anything ahead. Let your body receive this small act of gentleness.

[pause 6s]

Now your face. Scrunch it gently, if you like. Eyes, nose, mouth, all pulling toward the center.

[pause 3s]

And release. Let your forehead go smooth. Let your jaw hang loose.

[pause 10s]

Your body knows how to let go. It just sometimes needs reminding.

[pause 6s]

Let's go once through your whole body, without tensing this time. Just a soft wave of letting go, from the top of your head, down through your shoulders, your arms, your back, your legs, all the way to your feet.

[pause 10s]

Now let your mind follow. Is there something you've been holding tightly, a worry, a plan, an expectation? You don't need to solve it. Just imagine your grip on it softening, the way your hands did.

[pause 10s]

If you'd like, rest your open hand on your belly. No effort. Just warmth.

[pause 12s]

Stay soft. There's nothing you need to hold right now.

[pause 10s]

When you're ready, let some gentle movement come back, and slowly open your eyes.

[pause 4s]

Whatever you let go of, let it stay down for a while.

[music 10s]

---

## Week 12 · Faith-centered

**Title:** Pour out / *your* / heart.
**Description:** Five minutes to tell God what's heavy, and release your grip as you hand it to him.
**Approach:** honest prayer paired with gently letting go in the hands and shoulders.
**Scripture:** Psalm 62:8 (verbatim excerpt: the second and third sentences); Psalm 55:22 (verbatim excerpt: the first sentence).

[music 8s]

What feels heavy today?

[pause 6s]

You don't have to answer right away. Just let the question rest with you as you settle in.

[pause 6s]

Find a comfortable position, and let your breath come and go in its own time.

[pause 6s]

The psalms are full of honest prayers. People telling God exactly how they felt, the fears, the frustrations, the hopes. In Psalm 62, David writes:

*Pour out your heart before him. God is a refuge for us.*

[pause 8s]

Not "tidy up your heart first." Pour it out.

[pause 6s]

A refuge is a safe place to run to when things feel like too much. Not a place you have to be strong to enter. A place you go because you need it.

[pause 8s]

So let's do that. Notice your hands. If they're curled or tense, let them open slowly, palms up, as if you were holding something out to God.

[pause 8s]

As this little life develops, your body is doing work you cannot oversee, and your heart may wish it could oversee every part. God can hear both your wonder at creation and the fear that makes your hands tighten.

[pause 6s]

You may not be ready to let every worry go. That's all right. Offering even one small burden in prayer is enough for this moment. You can bring it back to him whenever you need to.

[pause 6s]

Now tell him what's heavy. Whatever comes. You don't need the right words.

[pause 15s]

As you finish, let your shoulders drop. Let your jaw soften. Let your body follow your heart in letting go.

[pause 8s]

Another psalm says:

*Cast your burden on the Lord and he will sustain you.*

[pause 8s]

That doesn't mean every burden disappears. It means you don't carry it alone. He holds you up while you carry it.

[pause 8s]

Lord, thank you for listening to all of it, the big things and the small. I'm placing these in your hands. Hold me up today. Amen.

[pause 10s]

If you'd like, rest your open hand on your belly, and let your hands stay soft.

[pause 12s]

When you're ready, let your eyes open.

[pause 3s]

Walk a little lighter today, knowing he holds what you've given him.

[music 10s]

---

## Week 13 · Grounded

**Title:** Small / *good* / things.
**Description:** Five minutes to notice what's been quietly good, even on an ordinary or difficult day.
**Approach:** three small moments recalled in detail, then letting them warm the body, without any pressure to feel positive.

[music 8s]

Think of one small thing from the last day or so that was good. It doesn't need to be big. A warm shower. A kind text. The first sip of something cold.

[pause 8s]

Hold that thought, and let yourself get comfortable.

[pause 6s]

This meditation is about noticing good things. Not because everything is good. Some days in pregnancy are hard, and that's real. But even hard days can hold small moments worth noticing.

[pause 6s]

Let's go back to that first good thing. Picture it clearly. Where were you? What did it feel like? Let yourself enjoy it again, just for a moment.

[pause 12s]

Now let a second one come to mind. Maybe something someone said. Maybe something you saw. Light through a window. A song. A laugh.

[pause 12s]

And a third. Maybe something your body did well. A good night's sleep, a meal that sat right, a walk that felt easy.

[pause 12s]

One small good thing may simply be the thought that you're carrying a baby, even if that thought comes with complicated feelings. Your body is involved in an extraordinary process, and it's reasonable to feel both thankful for its work and tired of its demands.

[pause 6s]

You don't have to turn gratitude into another task. A moment of comfort is worth noticing simply because it feels good, right here and now.

[pause 6s]

If it's hard to find three today, that's all right. One is enough. Even making space for these few minutes is a small good thing.

[pause 8s]

Three small good things. Notice where you feel them in your body. Maybe a softening in your chest. A little warmth. Or maybe nothing much, and that's fine too.

[pause 10s]

If you'd like, rest a hand on your belly. Your baby is part of your days now, even the ordinary ones.

[pause 12s]

Small good things are easy to miss. They don't announce themselves. But they add up, quietly, the way the days of this pregnancy are adding up.

[pause 10s]

Stay here a moment longer with whatever good you found.

[pause 12s]

When you're ready, let your eyes open.

[pause 4s]

May you notice a few more small good things before the day is done.

[music 10s]

---

## Week 13 · Faith-centered

**Title:** Every / *good* / gift.
**Description:** Five minutes to recognize God's goodness in the small gifts of your days.
**Approach:** recalling small gifts one by one, thanking God for each, and making room for days when thankfulness is hard.
**Scripture:** James 1:17 (verbatim excerpt: the first part of the verse).

[music 8s]

James, writing to the early church, said this:

*Every good gift and every perfect gift is from above, coming down from the Father of lights.*

[pause 8s]

Let those words settle as you find a comfortable position.

[pause 6s]

Every good gift. Not only the big ones. The small, everyday ones too.

[pause 6s]

James calls God the Father of lights. The one who made the sun and the stars, and who still notices the smallest good thing in your day.

[pause 8s]

Let's look for some. Think back over the last day or so. What was one good thing, however small? A warm meal. A kind word. A quiet moment. Picture it clearly.

[pause 10s]

Now simply say, in your heart: Thank you.

[pause 8s]

Let a second gift come to mind. Maybe a person. Someone who helped, or listened, or made you laugh.

[pause 10s]

Among the gifts you may notice is the wonder of a body carrying new life. Even as you rest, so many intricate changes are taking place beyond your awareness. You can appreciate this remarkable work in your own way, without needing to feel any particular emotion.

[pause 6s]

Your prayer can be simple and sincere: 'Thank you for this moment, Lord. Help me be present to the gift of today.' Whatever is on your heart, you can bring it to him.

[pause 6s]

Thank you.

[pause 8s]

And a third. Perhaps something about this pregnancy. Or perhaps just that you're here, breathing, right now.

[pause 10s]

Thank you.

[pause 8s]

If thankfulness feels hard today, that's all right. God isn't asking you to pretend everything is easy. You can tell him that too. Gratitude and honesty can sit side by side.

[pause 12s]

Now take a moment to talk with God about the gifts you noticed, or about anything else on your heart.

[pause 13s]

Father of lights, every good thing in my life comes from you. Thank you for the small gifts I so often miss, and for the gift of this little one. Open my eyes to your goodness today, even in ordinary moments. Amen.

[pause 10s]

When you're ready, let your eyes open slowly.

[pause 3s]

Watch for his good gifts today. They're often closer than we think.

[music 10s]

---

## Week 14 · Grounded

**Title:** A few / *words* / for you.
**Description:** Five minutes to speak to your baby, silently or out loud, in whatever way feels natural.
**Approach:** a guided first conversation with the baby, with no pressure on how it feels.

[music 8s]

This meditation is a little different. Today, you're invited to talk to your baby.

If that feels natural, wonderful. If it feels strange, or awkward, or a bit too soon, that's completely okay. You can just listen along, and try it whenever you're ready.

[pause 6s]

Find a comfortable position. If you'd like, rest one or both hands on your belly.

[pause 6s]

Let your breath settle in its own time.

[pause 8s]

Your baby is growing in a warm, dark, cushioned world, gently rocked as you move.

[pause 6s]

Some people find it meaningful to start talking to their baby early, long before they meet. A voice, a few words, a habit that can grow over the months ahead.

[pause 6s]

Imagine, for a moment, what this little one might want to know about you.

[pause 8s]

You might start simply. Silently, or in a whisper: *Hello. It's me.*

[pause 10s]

Your baby is developing within the shelter of your body, and that relationship is already part of your everyday life—even if you don't yet feel a clear bond. Your body has been making adjustments in the background while you've gone about ordinary routines.

[pause 6s]

You may feel excited to speak, or a little unsure what to say. There's no test to pass and no particular feeling you need to find. Even a quiet hello, or a hand resting on your belly, can be enough for today.

[pause 6s]

You could tell your baby something about your day. Where you are right now. What you can hear.

[pause 10s]

You could tell them something about yourself. Something you love. Something you're looking forward to.

[pause 10s]

Maybe a place you'd like to show them one day. A song you might sing. Something you hope you'll do together.

[pause 12s]

And if there's something you're feeling, hope, or nervousness, or wonder, you can say that too. There's no wrong thing to say.

[pause 10s]

Or you can say nothing at all, and simply be together in the quiet.

[pause 12s]

Whatever you said, or didn't say, this is how relationships begin. A little at a time.

[pause 12s]

When you're ready, let your hands rest, and slowly open your eyes.

[pause 4s]

You can pick up this conversation any time. There's no rush to it.

[music 10s]

---

## Week 14 · Faith-centered

**Title:** A blessing / *for* / the little one.
**Description:** Five minutes to pray an ancient blessing over your baby, and receive it for yourself too.
**Approach:** praying the priestly blessing slowly, line by line, over the baby, then personally.
**Scripture:** Numbers 6:24–26 (verbatim).

[music 8s]

Welcome. Today we'll pray a blessing over your baby. One of the oldest blessings in Scripture.

Settle in, and if you'd like, rest your hands on your belly.

[pause 6s]

Let your breath slow in its own time.

[pause 6s]

In the book of Numbers, God gave Moses these words for Aaron and the priests to speak over his people. People have prayed them over children for thousands of years.

Listen to them once through:

*The Lord bless you, and keep you. The Lord make his face to shine on you, and be gracious to you. The Lord lift up his face toward you, and give you peace.*

[pause 10s]

A blessing isn't a guarantee of an easy road. It's an asking. Placing someone you love into God's care.

[pause 6s]

Notice the shape of it. Blessing. Keeping. His face shining toward you, the way a parent's face lights up when their child walks into the room. Grace. Peace.

[pause 8s]

Let's pray it slowly over your baby now, line by line. You can echo the words silently, or simply listen. The life you're carrying is part of the remarkable work unfolding within your body. You might feel joy, tenderness, or uncertainty as you pray. Each is welcome in this moment.

[pause 6s]

God, thank you for the ways this body is carrying new life today. Teach me to care for myself with the same tenderness I hope to give my child, and receive whatever feelings rise as I speak these words.

[pause 6s]

The Lord bless you, and keep you.

[pause 10s]

The Lord make his face to shine on you, and be gracious to you.

[pause 10s]

The Lord lift up his face toward you, and give you peace.

[pause 12s]

Now take a moment to pray for your baby in your own words. Whatever hopes are in your heart. Perhaps that they'll know they're loved. That they'll have courage, and kindness, and people around them.

[pause 15s]

And this blessing is for you too. Let it rest on you, as a mother, in this season.

[pause 6s]

Lord, bless me and keep me. Let your face shine on me. Give me your peace. Amen.

[pause 10s]

When you're ready, let your eyes open slowly.

[pause 3s]

Go in his peace, both of you.

[music 10s]

---

## Week 15 · Grounded

**Title:** Still / *you* / and growing.
**Description:** Five minutes to honor how you're changing, and everything about you that remains.
**Approach:** a gentle visualization of who you were before, who you are now, and the self that carries through.

[music 8s]

Picture yourself a year or so ago. Before this pregnancy. What did an ordinary day look like? What did you care about? What made you laugh?

[pause 10s]

Hold that picture gently as you settle into a comfortable position.

[pause 6s]

Pregnancy changes so much. Your body. Your energy. Your plans. Sometimes, how other people see you. It's natural to wonder how much of you is changing too.

[pause 6s]

Let's take a moment with that.

Bring to mind something you've always loved. A place, a song, a food, a kind of weather.

[pause 10s]

That's still you.

[pause 6s]

Bring to mind something you're good at. Something people come to you for.

[pause 10s]

Still you.

[pause 6s]

As your baby develops, your body is changing in visible and invisible ways. It can be astonishing to think of how much it does without your conscious instruction. It can also be strange to feel that your familiar self is changing alongside it.

[pause 6s]

You can admire this process without needing to admire every physical sensation or new limitation. The person you have been and the mother you are becoming don't have to compete. There is room for both.

[pause 6s]

Bring to mind a way you've grown in the last few months. Something you've learned, or carried, or handled, that you didn't know you could.

[pause 10s]

That's you too. Growing.

[pause 8s]

Think of a tree. Each year it adds a new ring, and grows a little wider and taller. But the heart of it doesn't disappear. Every year is still inside it.

[pause 10s]

Some days you might miss parts of your old life. The freedom, the energy, the body you knew. That isn't ingratitude. It's a natural part of a big change, and those feelings deserve gentleness too.

[pause 8s]

You're becoming a mother, or a mother again, and you're still the person in that picture from a year ago. Both are true.

[pause 8s]

If you'd like, rest a hand on your belly. Your baby will come to know the person you've always been, as well as who you're becoming.

[pause 10s]

When you're ready, let your eyes open slowly.

[pause 4s]

You're still you. And you're growing too.

[music 10s]

---

## Week 15 · Faith-centered

**Title:** New / *every* / morning.
**Description:** Five minutes to rest in God's unchanging faithfulness while so much in you is changing.
**Approach:** reflecting on change and constancy, with God's mercies as the steady center, and a quiet prayer of trust.
**Scripture:** Lamentations 3:22–23 (verbatim excerpt: from "his compassion" to the end of verse 23).

[music 8s]

Imagine the early light of morning. The first gray glow at the window. The world quiet, before the day begins.

[pause 8s]

Let that quiet be with you as you settle in.

[pause 6s]

So much is changing right now. Your body. Your energy. Your plans, maybe even how you see yourself. Some changes might feel exciting. Others might feel unsettling. Probably both.

[pause 8s]

In the book of Lamentations, written during a time of upheaval, there's a moment of surprising hope. The writer says of God:

*his compassion doesn't fail. They are new every morning. Great is your faithfulness.*

[pause 10s]

Everything around the writer had changed. But God's compassion hadn't. It met the writer again, new, each morning.

[pause 8s]

New every morning. Not leftover from yesterday. Not rationed out. On the mornings when you wake up tired, or queasy, or anxious, his compassion is already there.

[pause 8s]

The life growing within you is a quiet reminder of how intricate creation can be. Your body is meeting this pregnancy with changes you did not have to plan, and you can offer God thanks for that work without insisting every change feels good.

[pause 6s]

New mercies may look like courage for one ordinary day rather than the sudden end of every worry. Ask for that courage as freely as you ask for peace.

[pause 6s]

What feels most changed in your life right now? Bring it to God, honestly.

[pause 10s]

Now, what do you need to stay steady? Patience? Comfort? A reminder of who you are in him? Ask him for it.

[pause 10s]

Some things about you won't change at all. You are still his. Still loved. Still known, through every season of this pregnancy, and every season after.

[pause 10s]

If you'd like, rest a hand on your belly. You and your baby are both changing every day, and both held by the same faithful God.

[pause 12s]

Lord, so much in me is changing. Thank you that your love doesn't change. Meet me with your compassion each morning, and help me trust you through every new thing. Amen.

[pause 10s]

When you're ready, let your eyes open.

[pause 3s]

His compassion will meet you new, every morning.

[music 10s]

---

## Week 16 · Grounded

**Title:** Into / *a softer* / evening.
**Description:** Five minutes to wind down your body and mind, for the end of the day or whenever you need rest.
**Approach:** an evening wind-down that dims the senses one by one and lets the day go, with a longer quiet ending.

[music 8s]

If it's evening, you might dim the lights, or turn them off altogether. If it's daytime, that's okay too. Let this be a small evening, wherever you are.

[pause 6s]

Find the most comfortable position you can. On your side, with a pillow between your knees, is often lovely at this stage. Use whatever support you have.

[pause 8s]

Let your breath slow down by itself. There's nowhere to be.

[pause 8s]

Let's let the day go, one piece at a time.

First, let your eyes rest. Let them grow heavy behind your eyelids.

[pause 6s]

Let your ears soften, so sounds become just a gentle background.

[pause 6s]

Let your jaw loosen, and your tongue rest at the bottom of your mouth.

[pause 6s]

Let your hands lie heavy and open.

[pause 8s]

Even as the house grows quiet, pregnancy doesn't stop being present. Your body continues the remarkable work of supporting this developing baby through the night. You don't have to stay awake to supervise that work, and you don't need to make yourself feel grateful before you rest.

[pause 6s]

Whatever the day brought—tenderness toward your baby, worry, discomfort, or simple exhaustion —can come into this softer evening with you. Let tonight be a place to set down the expectation that you must feel one certain way.

[pause 6s]

Now think back over today, without judging any of it. The things that went well. The things that didn't. The things left undone.

[pause 8s]

Imagine each one as a lamp in a long hallway. One by one, you walk past them, turning each lamp down.

[pause 12s]

Notice the hallway growing softer and dimmer. Quieter. Your footsteps slowing. At the end of it, there's a warm, dark room, with a bed made up just for you.

[pause 10s]

The day is finished, or nearly. Whatever is left can wait until morning.

[pause 8s]

If you'd like, rest a hand on your belly. Let yourself feel the warmth there as you both settle.

[pause 10s]

Stay here. Let your body grow heavier and softer.

[pause 15s]

If you're drifting toward sleep, let yourself go. If not, simply enjoy the quiet.

[pause 6s]

Goodnight, or good rest, whichever you need.

[music 12s]

---

## Week 16 · Faith-centered

**Title:** Sleep / *for* / the beloved.
**Description:** Five minutes to lay down the day and rest in God's love, for evenings or any time you're weary.
**Approach:** handing the day over to God, piece by piece, then resting in his love, with a long quiet ending.
**Scripture:** Psalm 127:2 (verbatim excerpt: the end of the verse); Zephaniah 3:17 (verbatim excerpt: the third and fourth sentences).

[music 8s]

There's a line at the end of Psalm 127 that says:

*for he gives sleep to his loved ones.*

[pause 8s]

Sleep, and rest, as a gift. Not something you have to earn by finishing everything first.

[pause 6s]

If it's evening, you might dim the lights. If it's daytime, let this be a small evening wherever you are. Find the most comfortable position you can, with whatever pillows or support you need.

[pause 8s]

Let your breath slow down by itself.

[pause 6s]

Let's give the day to God, one piece at a time.

What went well today? Thank him for it.

[pause 12s]

What was hard? Tell him about it, and leave it with him.

[pause 12s]

What's left undone? Let it wait. It's in his hands until morning.

[pause 12s]

As you settle, remember the quiet wonder of carrying a developing child. Your body is adjusting in ways you may never see directly, and you can thank God for this mystery without needing to understand every part of it.

[pause 6s]

If your mind returns to a worry, an appointment, or an unanswered question, bring that into your prayer too. God is present whether sleep comes easily or not. Rest can begin with simply being here with him.

[pause 6s]

Now listen to these words, spoken by the prophet Zephaniah to God's people:

*He will calm you in his love. He will rejoice over you with singing.*

[pause 10s]

Imagine being sung over. Calmed. The way you might one day sing over your own child.

[pause 10s]

Not because you've earned it, or finished your list, or handled today perfectly. Simply because you are his, and he delights in you.

[pause 8s]

If you'd like, rest a hand on your belly. You are both held in his love tonight.

[pause 12s]

Let your shoulders sink into the pillow. Let your hands rest open, like a child asleep.

[pause 8s]

Lord, I give you this day. Calm me in your love, and give me the rest I need. Amen.

[pause 15s]

If you're drifting toward sleep, let yourself go. If not, rest here in his care.

[pause 6s]

Rest well, beloved.

[music 12s]

---

## Week 17 · Grounded

**Title:** Held / *by* / many hands.
**Description:** Five minutes to notice the support around you, whatever shape it takes.
**Approach:** noticing physical support first, then the people and places that help, with room for those who feel short on support.

[music 8s]

Let's begin by noticing what's holding you up, right now. Literally.

The surface beneath you. The pillow behind your head, or the chair at your back. Let yourself lean into it.

[pause 8s]

You don't have to hold yourself up. Something is already doing it for you.

[pause 8s]

Support comes in many shapes. Some people have a partner, a family, a close circle of friends. Some have one or two people. Some are doing a lot of this on their own. Wherever you are, this meditation is for you.

[pause 6s]

Let's notice the support that's there, even in small ways.

Bring to mind a person who's been kind to you during this pregnancy. It might be someone close. It might be a nurse, a coworker, a neighbor, a stranger who held a door.

[pause 12s]

Picture their face, if you can. Notice how it feels to remember their kindness.

[pause 10s]

Your body is offering this baby a place to develop, while you deserve care and support in your own right. Pregnancy isn't a project you should have to manage alone. The extraordinary work happening inside you doesn't make your ordinary needs less important.

[pause 6s]

If your support system feels complicated, or you're not ready to share every feeling about this pregnancy, you can start smaller. A message, a meal, a quiet check-in: receiving any of those is part of caring for yourself.

[pause 6s]

Now think of a place that helps you feel supported. A favorite room. A walk you love. A spot where you can breathe more easily.

[pause 12s]

And think of something that supports you that isn't a person or a place. A routine. A song. A favorite blanket. Even this quiet moment.

[pause 12s]

And notice the ways you support yourself, too. Resting when you need to. Eating when you're hungry. Choosing to spend these minutes here. That's support as well.

[pause 8s]

If support feels thin right now, that's important to notice too. It's okay to want more help, and it's okay to ask for it. Needing support isn't a weakness. It's part of being human, especially now.

[pause 10s]

If you'd like, rest a hand on your belly. Your baby is being held too, every moment, by you.

[pause 10s]

When you're ready, let your eyes open slowly.

[pause 4s]

You don't have to do this all by yourself. Let yourself be held, in whatever ways you can.

[music 10s]

---

## Week 17 · Faith-centered

**Title:** Never / *left* / alone.
**Description:** Five minutes to rest in God's promise never to leave you, and see his care through others.
**Approach:** God's presence first, then the people he places around us, with room for those who feel alone.
**Scripture:** Hebrews 13:5 (verbatim excerpt: the words quoted as God's, at the end of the verse); Galatians 6:2 (verbatim).

[music 8s]

Welcome. Wherever you're listening from, and whoever is or isn't beside you right now, you're not alone in this moment.

Find a comfortable position, and let yourself lean into whatever is supporting you.

[pause 8s]

The letter to the Hebrews reminds its readers of something God has said:

*I will in no way leave you, neither will I in any way forsake you.*

[pause 10s]

In no way. Not in the hard moments. Not in the uncertain ones. Not when you feel strong, and not when you feel weak.

[pause 8s]

This letter was written to people who were struggling. Some had lost their possessions. Some felt forgotten. And God's answer to them wasn't a list of instructions. It was his presence.

[pause 8s]

Take a moment to rest in his presence. You don't need to feel anything particular. Just know he's here.

[pause 10s]

God often shows his care through people. Paul wrote to the churches in Galatia:

*Bear one another's burdens, and so fulfill the law of Christ.*

[pause 8s]

As a new life develops within your body, you are giving and carrying so much. God's care for you isn't an instruction to handle everything without help; you are worthy of comfort and practical support too.

[pause 6s]

Some women share joyful news openly. Others prefer to keep it close for a while. God knows what you're carrying in your heart. You can ask him for trustworthy people and the courage to accept help in whatever measure feels right.

[pause 6s]

Sometimes God answers our prayers for help through other people's hands and voices. A meal dropped off. A message at just the right moment. Someone who simply sits with us.

[pause 8s]

Bring to mind someone who has helped carry your burdens lately. A partner, a friend, a family member, a nurse, someone at church, someone unexpected. Thank God for them.

[pause 10s]

If support feels thin right now, tell God about that too. Ask him for the help you need. It's okay to ask.

[pause 10s]

If you'd like, rest a hand on your belly.

[pause 6s]

Lord, thank you that you never leave me. Thank you for the people who carry my burdens with me. Where I feel alone, draw near, and bring the help I need. Amen.

[pause 10s]

When you're ready, let your eyes open slowly.

[pause 3s]

He goes with you into the rest of today.

[music 10s]

---

## Week 18 · Grounded

**Title:** Listening / *for* / you.
**Description:** Five minutes of quiet attention inward, wherever you are in getting to know your baby.
**Approach:** turning attention inward like listening to the sea, with no expectation of feeling movement.

[music 8s]

Let's get quiet enough to listen inward.

Find a comfortable position. Lying on your side, or sitting reclined, often makes it easier to notice what's happening inside.

[pause 8s]

Let the sounds of the room fade into the background, like distant waves.

[pause 8s]

Somewhere in these weeks, some people begin to notice tiny movements. Flutters, taps, little bubbles. For others, it takes longer. Every pregnancy has its own timing, and there's no right moment for this.

[pause 6s]

Today isn't about feeling anything in particular. It's simply about paying attention, the way you might sit by the sea and listen.

[pause 8s]

Rest your hands on your belly, if you'd like. Let them be still and soft.

[pause 8s]

Now bring your attention down to where your hands are resting. Notice warmth. Notice the slow rise and fall of your breath.

[pause 12s]

You don't need to look for any particular sensation right now. Let this be a moment to notice your own breath, the warmth of your hands, and the quiet connection of being here with your baby.

[pause 6s]

Instead, simply recognize the remarkable changes taking place as your body carries this baby. You can feel curious, amazed, or uncertain. A gentle hand on your belly can be a gesture of connection without expecting anything in return.

[pause 6s]

Notice the stillness, too. Stillness is part of listening.

[pause 12s]

Your baby lives surrounded by your rhythms. Your heartbeat. Your breathing. The movement of your body through the day. In their own way, they're getting to know you too.

[pause 10s]

If you feel something, a flutter, a nudge, a little rolling sensation, you can greet it, silently. *Hi. I'm here.*

[pause 10s]

Whether you notice a gentle sensation or only the warmth of your hands, you can let this be a moment of quiet attention, without needing to achieve anything.

[pause 12s]

Let yourself simply stay here, listening, with nothing to achieve.

[pause 15s]

Over the coming weeks, quiet moments like this may become some of your favorite times together.

[pause 8s]

When you're ready, let your attention widen again to the room around you, and slowly open your eyes.

[pause 4s]

You can return to this gentle moment of connection whenever you'd like.

[music 10s]

---

## Week 18 · Faith-centered

**Title:** A greeting / *of* / joy.
**Description:** Five minutes with Mary and Elizabeth, two expectant mothers who shared their joy and their waiting.
**Approach:** imaginative reflection on the visitation, then praying for companionship and joy, with no expectation of feeling movement.
**Scripture:** Luke 1:39–45 (the story retold in Maren's own words); Luke 1:41 (verbatim excerpt: the first part of the verse); Luke 1:44 (verbatim).

[music 8s]

Long ago, two expectant mothers met in a house in the hill country of Judah.

Find a comfortable position as we step into their story.

[pause 6s]

Mary was young, and newly pregnant, carrying news she was still trying to understand. She hurried to visit her relative, Elizabeth, who was also expecting, after years of waiting.

[pause 6s]

Imagine Mary arriving at the door, tired from her journey. Imagine Elizabeth hearing her voice.

Luke tells us:

*When Elizabeth heard Mary's greeting, the baby leaped in her womb.*

[pause 8s]

And Elizabeth said to her:

*For behold, when the voice of your greeting came into my ears, the baby leaped in my womb for joy!*

[pause 10s]

Two women, both carrying new life. Sharing their joy, and their questions, and staying together for months.

[pause 8s]

In the meeting of Mary and Elizabeth, joy rises through an encounter with the child each woman is carrying. Your own relationship with your baby may feel quieter or more complicated. There is no single right way for it to begin.

[pause 6s]

You can bring God your wonder at the life developing within you, along with any other feelings today holds. Let Mary and Elizabeth's story be an invitation to notice this moment with gratitude, not a standard for how you ought to feel.

[pause 6s]

Imagine the conversations they might have had. Talking about what their bodies were going through. Wondering together about the children they would hold. Laughing, maybe. Praising God, as Mary did.

[pause 10s]

Some people begin to feel small movements around this time, and others not for a while yet. This story isn't about a timeline. It's about joy shared, and about not waiting alone.

[pause 8s]

If you'd like, rest your hands on your belly. Simply be with your baby, whatever you feel or don't feel.

[pause 12s]

Elizabeth's joy began with a greeting. Imagine greeting your baby now, in your heart. A simple hello, full of love.

[pause 12s]

Who is an Elizabeth for you? Someone you can share this season with? Thank God for them. Or, if you're longing for someone like that, ask him for it.

[pause 10s]

Lord, thank you for the joy of new life, and for the people who share it with me. Let joy find its way into my heart, even in the waiting. Amen.

[pause 10s]

When you're ready, let your eyes open slowly.

[pause 3s]

May you find small joys to share today.

[music 10s]

---

## Week 19 · Grounded

**Title:** The pause / *between* / things.
**Description:** Five minutes to learn a one-minute pause you can carry into any busy day.
**Approach:** a short, practical practice, rehearsed twice, for using between tasks.

[music 8s]

Some days feel like one long list. Work, errands, appointments, meals, messages, and somewhere in there, growing a baby.

[pause 6s]

Today, let's practice a small pause you can take anywhere. Between meetings. In a parking lot. While the kettle boils. It takes about a minute.

Let yourself settle first.

[pause 8s]

Here's how it goes. There are just three steps.

First: stop. Let your hands go still, wherever they are.

[pause 6s]

Second: feel your feet. Notice where they touch the floor, or the bed, or each other.

[pause 8s]

Third: let one breath out be a little longer and softer than the rest. Not forced. Just unhurried.

[pause 8s]

That's it. Stop. Feet. One soft breath out.

[pause 10s]

It's small on purpose. Small enough to remember on a hard day. Small enough to do with a phone in your hand, or a toddler on your hip, or in a waiting room before an appointment.

[pause 6s]

Wherever you pause—in a hallway, beside the car, or between errands—your body is carrying this pregnancy with you. Remarkable work is unfolding even when the rest of life seems ordinary. You can appreciate it for a second without having to stop your entire day.

[pause 6s]

Try placing a hand over your belly, if it feels comfortable. One gentle breath can hold both gratitude for this developing life and any worry that happens to be nearby. You don't have to push either away.

[pause 6s]

Let's practice it once more, slowly.

Stop. Let everything go still.

[pause 6s]

Feet. Feel them, heavy and grounded.

[pause 8s]

One soft breath out.

[pause 10s]

Notice how you feel now. Maybe a little more here. Maybe just the same. Either is fine.

[pause 8s]

Over time, your body may start to remember this pause on its own. Your hands going still. Your feet finding the floor.

[pause 8s]

If you'd like, add a fourth step whenever you have a moment: a hand on your belly, as a small hello to your baby in the middle of your day.

[pause 12s]

These pauses won't make a busy day less busy. But they can give you small places to land, in between all the things.

[pause 10s]

When you're ready, let your eyes open.

[pause 4s]

This pause is yours. It fits into any part of your day.

[music 10s]

---

## Week 19 · Faith-centered

**Title:** The / *one* / thing.
**Description:** Five minutes to sit at Jesus' feet in the middle of a busy season.
**Approach:** imaginative reflection on Mary and Martha, with gentle permission to stop, and quiet time with Jesus.
**Scripture:** Luke 10:38–42 (the story retold in Maren's own words); Luke 10:41–42 (verbatim excerpt: Jesus' words, from "you are anxious" to "one thing is needed").

[music 8s]

Before we begin, notice how full your mind feels right now. Crowded? Quiet? Somewhere in between?

[pause 6s]

Whatever is there, let it wait a few minutes. Settle in, and let your body rest.

[pause 6s]

In Luke's Gospel, Jesus visits the home of two sisters, Martha and Mary. Martha is busy getting everything ready. Mary sits at Jesus' feet, listening.

[pause 6s]

Martha, worn out, asks Jesus to tell her sister to help. And Jesus answers her, gently:

*Martha, Martha, you are anxious and troubled about many things, but one thing is needed.*

[pause 10s]

Notice that he says her name twice. Kindly. He isn't scolding her for caring, or for working hard. He's inviting her to stop for a moment, and be with him.

[pause 8s]

Martha's work mattered. Someone had to make the meal. But in that moment, Jesus himself was sitting in her home, and she was missing time with him.

[pause 8s]

Pregnancy can bring a thousand little demands, yet within the rush your body is carrying a new life. That is worthy of wonder, and you don't need a long stretch of silence to bring that wonder to God.

[pause 6s]

If fear interrupts this moment, offer that as honestly as your thanksgiving. A brief prayer isn't less real because your feelings are mixed. You can meet God in this ordinary pause, as you are.

[pause 6s]

Imagine Jesus saying your name the same way. Kindly. Twice.

[pause 10s]

What are the many things you're anxious and troubled about right now? You can name them to him.

[pause 10s]

Now imagine setting them down, just for these few minutes, and sitting at his feet. There's nothing to prepare. Nothing to prove. Just be with him.

[pause 15s]

If you'd like, rest a hand on your belly. Your baby is here with you, in this quiet place.

[pause 10s]

Jesus, my days are full, and my mind is busier still. Thank you for inviting me to sit with you. Help me find my way back to you, even in the middle of everything. Amen.

[pause 10s]

When you're ready, let your eyes open slowly.

[pause 3s]

Sit at his feet whenever you can, even for a moment in a busy day.

[music 10s]

---

## Week 20 · Grounded

**Title:** Halfway, / *and* / here.
**Description:** Five minutes to look back on how far you've come, and ahead with openness.
**Approach:** a reflective look back over the weeks so far, then looking ahead with curiosity rather than pressure.

[music 8s]

Wherever you are in your pregnancy, you've likely reached somewhere around the middle. A good place to pause, and look around.

Find a comfortable position, and let yourself settle.

[pause 8s]

Let's look back first.

Think of the day you found out you were pregnant. Where were you? What did you feel?

[pause 12s]

Whatever you felt then, joy, shock, fear, all of it, it was a real beginning.

[pause 6s]

Now think of one thing that's been hard since then. Something you've carried, or handled, or simply gotten through.

[pause 12s]

You got through it. Notice that.

[pause 6s]

And think of one moment you'd like to remember from these weeks. A small one is fine.

[pause 12s]

You've reached a point where you can look back and notice how much has changed: appointments, expectations, sensations, and the quiet work your body has been doing all along. There may be milestones worth celebrating, and there may be memories or uncertainties that make celebrating complicated.

[pause 6s]

If you'd like, lay a hand on your belly. Think of the developing baby you are carrying today, rather than trying to picture every step ahead. Let appreciation for this remarkable process be possible without asking your feelings to become simple.

[pause 6s]

That's part of your story now.

[pause 6s]

Think of someone, or something, that helped you get here. A person who listened. A routine that steadied you. Even your own quiet determination to keep going.

[pause 10s]

Now let's turn, gently, toward what's ahead.

You don't need to plan it all, or know how it will go. Just notice what you feel when you think about the months to come. Curiosity? Nerves? Hope? A mix?

[pause 12s]

Whatever's there, you'll meet the coming weeks the same way you've met these ones. One day at a time, learning as you go.

[pause 8s]

There will be new things to learn. New changes in your body, new decisions, new feelings. You don't have to be ready for all of them today. Only for the next small step.

[pause 10s]

If you'd like, rest a hand on your belly, and let your baby share this moment of looking back and looking ahead.

[pause 10s]

When you're ready, let your eyes open slowly.

[pause 4s]

Wherever the road goes from here, you can meet it as you are.

[music 10s]

---

## Week 20 · Faith-centered

**Title:** Helped / *until* / now.
**Description:** Five minutes to remember God's faithfulness so far, and trust him with the road ahead.
**Approach:** setting up a "stone of help" in remembrance, giving thanks for the past, and entrusting the future to God.
**Scripture:** 1 Samuel 7:12 (verbatim excerpt: Samuel's words at the end of the verse); Deuteronomy 31:8 (verbatim excerpt: the first three sentences).

[music 8s]

In the book of First Samuel, after a hard-won season, the prophet Samuel set up a large stone as a marker. He named it Ebenezer, which means "stone of help," saying:

*the Lord helped us until now.*

[pause 10s]

Samuel's stone wasn't a sign that every hard time was over. It was a way to remember, before the next season began, that God had been faithful.

[pause 8s]

Let's set up a small Ebenezer of your own today.

Find a comfortable position, and let yourself settle.

[pause 8s]

Look back over these weeks of pregnancy. Where have you seen God's help? Maybe in a person. A kind word. A hard day you made it through. Strength you didn't know you had.

[pause 10s]

Thank him for each one, in your own words.

[pause 10s]

Now imagine placing a stone, right here, in this moment. A marker that says: God has helped me until now.

[pause 10s]

Looking back on these weeks, you may see moments of gratitude, stretches of uncertainty, and the intricate work of a body carrying new life. You can thank God for what this day holds without needing to explain every part of the journey.

[pause 6s]

If reaching this milestone stirs up tender feelings, bring them into your reflection. The faithfulness you remember is not a guarantee about tomorrow; it is an invitation to meet this moment with God, as you are.

[pause 6s]

Now look ahead. The coming months may hold joy, and challenge, and things you can't yet imagine.

Moses spoke these words to Joshua and the people of Israel, as they faced a new and uncertain land:

*The Lord himself is who goes before you. He will be with you. He will not fail you nor forsake you.*

[pause 10s]

He doesn't promise that the road will be easy. He promises to be with you on it.

[pause 8s]

What feels uncertain about the months ahead? Name it to him. And picture him already there, going before you into each of those places.

[pause 12s]

If you'd like, rest a hand on your belly.

[pause 6s]

Lord, thank you for helping me until now. I trust you with what's ahead. Go before me, and stay with me, every step of the way. Amen.

[pause 10s]

When you're ready, let your eyes open slowly.

[pause 3s]

The God who has helped you until now is with you still.

[music 10s]
