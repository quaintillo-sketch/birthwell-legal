# Faith-centered weeks 7–42, as approved before the woven revision

Kept word for word for reference. Replaced at Leah's request by versions built on each Grounded script, with faith woven in (approved after review, editorial polish and final review).

---

### Week 7 · Faith-centered

**Title:** Come / *and* / rest.
**Description:** Five minutes to lay down what feels heavy and receive the rest Jesus offers.
**Approach:** coming to Jesus as you are, setting burdens down in prayer, then resting in his care.
**Scripture:** Matthew 11:28–29 (verbatim); Psalm 23:2 (verbatim).

[music 6s]

[warm, unhurried] Welcome. Let yourself get comfortable. Lie down if you can, perhaps on your side with a pillow. Or simply lean back and let yourself be supported.

[pause 5s]

[gentle, understanding] You may be more tired than usual right now. Pregnancy can ask so much of you, in body and in heart. And it can be hard to slow down when there's so much to carry.

[pause 4s]

[reverent] Listen to the words of Jesus:

*Come to me, all you who labor and are heavily burdened, and I will give you rest. Take my yoke upon you, and learn from me, for I am gentle and humble in heart; and you will find rest for your souls.*

[pause 10s]

[warm, reassuring] He doesn't say, come once you've finished everything. He doesn't say, come once you've earned it. He simply says, come.

[pause 5s]

[calm] Picture yourself coming to him now, just as you are. Tired, perhaps. Unfinished. A little worn. And imagine him making room for you. Gentle. Unhurried. Glad you came.

[pause 9s]

[tender] Your body is doing quiet, demanding work as this pregnancy continues. The little life within you is precious, and so are you, the mother carrying it. You don't have to turn your exhaustion into a lesson or hide it from Jesus.

[pause 6s]

[warm, reassuring] Whatever this season feels like for you, Jesus invites you to come as you are. You can bring him your gratitude, your exhaustion, and everything else on your heart. Let these few minutes be an opportunity to rest in his love while your body continues the remarkable work of carrying new life.

[pause 5s]

[gentle] What are you carrying today? Tell him quietly. The tiredness. The worries. The things you haven't gotten to. You can set each one down in front of him.

[pause 12s]

[prayerful, sincere] Jesus, I'm tired, and you already know it. Thank you that I don't have to earn your rest, or prove that I deserve it. I'm setting these things down with you. Teach me to rest in you. Amen.

[pause 8s]

[calm, soothing] Now let your body follow your heart. Let your shoulders sink, and your hands open.

[pause 6s]

[reverent] In Psalm 23, David says of the Lord, his shepherd:

*He makes me lie down in green pastures. He leads me beside still waters.*

[pause 8s]

[calm, soothing] Rest here a while, beside still waters, in his care.

[pause 11s]

[warm] When you're ready, let some movement return, slowly.

[pause 3s]

May you find his rest in the ordinary moments of today.

[music 6s]

---

### Week 8 · Faith-centered

**Title:** Peace / *that* / guards.
**Description:** Five minutes to bring your real worries and hopes to God, and rest in his care.
**Approach:** guided personal prayer, with silence to bring a worry, a hope, and a thanks to God in your own words.
**Scripture:** Philippians 4:6–7 (verbatim); 1 Peter 5:7 (verbatim).

[music 6s]

[warm, unhurried] Welcome. Let this be a quiet place to be honest with God.

Settle in, and let your breath find its own comfortable pace.

[pause 6s]

[gentle] Pregnancy can stir up so many feelings. Hope and fear. Gratitude and questions.

[pause 5s]

[reassuring] God isn't asking you to sort them out first. He invites you to bring them to him, just as they are.

[pause 5s]

[reverent] Listen to these words from Philippians:

*In nothing be anxious, but in everything, by prayer and petition with thanksgiving, let your requests be made known to God. And the peace of God, which surpasses all understanding, will guard your hearts and your thoughts in Christ Jesus.*

[pause 8s]

[warm, reflective] In everything. Not only the tidy things. Not only the brave ones.

[pause 5s]

[tender] There is an extraordinary tenderness in carrying a baby while carrying questions too. Your body is engaged in the work of pregnancy, and your heart may be doing its own difficult work of hoping. God welcomes the whole of you, not only the thankful or peaceful parts.

[pause 6s]

If relaxing feels difficult today, you can tell God that plainly. You are allowed to marvel at this life and ask for courage at the same time. Neither feeling cancels the other.

[pause 6s]

[gentle] Let's bring it all to him now, slowly.

Is there a worry you've been carrying? Something you keep turning over? Tell God about it, in your own words. Be as honest as you like.

[pause 13s]

[hopeful] Now, is there a hope in your heart? Something you long for, for yourself, or for your baby? Tell him that too.

[pause 10s]

[warm] And is there anything, even something small, you're thankful for today? Offer him that as well.

[pause 8s]

[reverent] Peter wrote that we can come to God:

*casting all your worries on him, because he cares for you.*

[pause 8s]

[gentle, reassuring] Peace doesn't always arrive all at once. Sometimes it comes quietly, like someone sitting down beside you. Whatever you still feel, you're not carrying it alone.

[pause 6s]

[prayerful, sincere] Father, thank you for listening. You know every hope and every fear I've named, and the ones I couldn't put into words. I'm leaving them with you. Guard my heart and my thoughts today, and keep me close to you. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open gently.

[pause 3s]

Take this peace with you into the rest of your day.

[music 6s]

---

### Week 9 · Faith-centered

**Title:** Fearfully, / *wonderfully* / made.
**Description:** Five minutes to bring your changing body to God, with honesty and gratitude.
**Approach:** opens with prayer, God as the gentle shepherd, an honest body prayer, and gratitude offered freely.
**Scripture:** Isaiah 40:11 (verbatim excerpt: the second and third sentences); Psalm 139:14 (verbatim).

[music 6s]

[warm, unhurried] Welcome. Let's begin this time with a short prayer.

[prayerful, sincere] Lord, thank you for this moment to slow down. Be near to me as I rest. Amen.

[pause 5s]

[calm] Find a comfortable position. If you're feeling unsettled or queasy today, sitting a little upright, with support behind your back, may help. Let your breath be easy. There's nothing you need to change.

[pause 6s]

[reverent] The prophet Isaiah describes God as a shepherd caring for his flock:

*He will gather the lambs in his arm, and carry them in his bosom. He will gently lead those who have their young.*

[pause 8s]

[tender] Gently leading those who have their young. Held. Led gently. Not hurried.

[pause 6s]

[gentle wonder] Your body's changes may leave you amazed one day and uncomfortable the next. Pregnancy asks a great deal of you, and God's care does not depend on how gracefully you bear it. You can thank him for the wonder of this growing life while still asking for relief and strength.

[pause 6s]

[prayerful, sincere] Lord, teach me to treat this body with tenderness. When trust feels difficult, help me bring my questions to you without shame. Let gratitude be an invitation, never a demand.

[pause 6s]

[calm] Let's bring your body before God, one part at a time.

Your feet and legs, carrying you through each day.

[pause 6s]

[tender] Your belly, where a new life is growing. Rest your hand here, if you'd like.

[pause 8s]

[calm] Your heart, beating steadily. Your breath, coming and going. Your shoulders, your hands, your face. Let them soften.

[pause 8s]

[gentle] If there's a place that aches or feels uneasy, you can simply bring it to him, and let it be held. Tell him what's hard.

[pause 10s]

[reverent] The psalmist prayed:

*I will give thanks to you, for I am fearfully and wonderfully made. Your works are wonderful. My soul knows that very well.*

[pause 8s]

[gentle] If thankfulness feels true today, offer it to him, in your own words. If it doesn't, simply rest in his care.

[pause 10s]

[prayerful, sincere] Creator God, you made me with care, and you're near to me in every change. Thank you for this little one. On the hard days, be my comfort. Lead me gently, the way you lead those with young. Amen.

[pause 8s]

[warm] When you're ready, open your eyes and come back slowly.

[pause 3s]

Go gently, knowing you are held.

[music 6s]

---

### Week 10 · Faith-centered

**Title:** Bread / *for* / today.
**Description:** Five minutes to trust God with tomorrow, and ask him for what you need today.
**Approach:** Jesus' teaching on tomorrow, honest prayer for today's needs, and quiet trust.
**Scripture:** Matthew 6:34 (verbatim excerpt: the first sentence); Matthew 6:11 (verbatim).

[music 6s]

[warm, unhurried] Welcome. For the next few minutes, today is the only day you need to think about.

Settle in comfortably, and let your breath find its own easy pace.

[pause 6s]

[gentle, understanding] It's natural, in pregnancy, for the mind to race ahead. The next appointment. Results you're waiting for. How everything will work out. It can feel like trying to carry months of tomorrows all at once.

[pause 6s]

[reverent] Jesus knew how heavy that can be. In the Sermon on the Mount, he said:

*Therefore don't be anxious for tomorrow, for tomorrow will be anxious for itself.*

[pause 8s]

[warm, reassuring] He wasn't scolding anyone for worrying. He was inviting them to put tomorrow down, and let God hold it.

[pause 5s]

[reverent] In that same sermon, he taught his followers to pray, simply:

*Give us today our daily bread.*

[pause 8s]

[warm, reflective] Not bread for the whole year. Bread for today.

Long before, in the wilderness, God gave his people manna each morning. Just enough for each day. They couldn't store it up for the week ahead. They had to trust that tomorrow's would come with tomorrow.

[pause 7s]

[gentle wonder] So much of pregnancy unfolds beyond your conscious effort. Your body is adapting in countless intricate ways as a little life develops within you. What a remarkable part of God's creation. You can pause here, appreciate this quiet work, and thank him for the gift of carrying new life today.

[pause 6s]

[prayerful, sincere] Father, when unanswered questions make tomorrow seem heavy, give me the grace to live this one day. Help me cherish what is here without pretending I know what comes next.

[pause 6s]

[gentle] What do you need for today? Rest? Patience? Strength for a hard conversation? A little more comfort in your body? Tell God, in your own words. Nothing is too small.

[pause 13s]

[tender, reassuring] And if there's a tomorrow you've been carrying, an appointment, a decision, a fear, picture yourself placing it into his hands. It will still be there when its day comes. And so will he.

[pause 10s]

[prayerful, sincere] Lord, thank you that I don't have to hold every tomorrow today. Give me what I need for this day, and help me trust you with the rest. Amen.

[pause 7s]

[tender] If you'd like, rest a hand on your belly, and simply be here, with God, today.

[pause 10s]

[warm] When you're ready, let your eyes open slowly.

[pause 3s]

Go into today with what you need for today.

[music 6s]

---

### Week 11 · Faith-centered

**Title:** Be / *still* / and know.
**Description:** Five minutes of quiet with one short verse, letting it slowly settle into stillness.
**Approach:** a slow, contemplative reading where the verse grows shorter with each repeat, with silence between.
**Scripture:** Psalm 46:10 (verbatim excerpt: the first sentence). The shorter repeats that follow are adapted from it and are not shown in italics.

[music 6s]

[warm, unhurried] Welcome.

[pause 5s]

This meditation uses very few words, and a lot of quiet.

[calm] We'll stay with one short line from Psalm 46, and let it slowly settle, the way snow settles in a snow globe once you stop shaking it.

[pause 6s]

Find a comfortable way to sit or lie down. Let your hands rest open.

[pause 6s]

[reverent] Psalm 46 was written for God's people in a time of upheaval. Nations in uproar, the earth itself shaking. And in the middle of it all, God says:

*Be still, and know that I am God.*

[pause 10s]

[gentle wonder] As you settle into stillness, your body continues its remarkable work of carrying new life. You don't have to keep watch over every unseen change. Let the quiet remind you that this baby matters, and that you matter to God too.

[pause 6s]

[warm, reverent] There's no special feeling you need to achieve in these moments with God. You can simply rest in his presence, grateful for the beautiful complexity of the life he's created and the remarkable work taking place within your body. Let the words of the psalm gently draw your attention back to him.

[pause 6s]

[calm, reverent] Let's say it again, a little shorter each time, and rest in the silence between.

Be still, and know that I am God.

[pause 12s]

Be still, and know.

[pause 12s]

Be still.

[pause 14s]

Be.

[pause 20s]

[gentle] Stillness isn't the same as having no thoughts. It's more like resting. Letting God be God, while you simply stay near.

[pause 8s]

If your mind wanders, that's all right. Come back to whichever word feels like home.

[pause 14s]

[prayerful, sincere] Lord, in all the busyness and change of this season, thank you for being God, so I don't have to be. Let me be still with you. Amen.

[pause 10s]

[warm] When you're ready, let your eyes open gently.

[pause 3s]

Stay in that stillness as long as you'd like. It's yours to come back to.

[music 6s]

---

### Week 12 · Faith-centered

**Title:** Pour out / *your* / heart.
**Description:** Five minutes to tell God what's heavy, and release your grip as you hand it to him.
**Approach:** honest prayer paired with gently letting go in the hands and shoulders.
**Scripture:** Psalm 62:8 (verbatim excerpt: the second and third sentences); Psalm 55:22 (verbatim excerpt: the first sentence).

[music 6s]

[warm, unhurried] What feels heavy today?

[pause 6s]

[gentle] You don't have to answer right away. Just let the question rest with you as you settle in. Find a comfortable position, and let your breath come and go in its own time.

[pause 6s]

[reverent] The psalms are full of honest prayers. People telling God exactly how they felt, the fears, the frustrations, the hopes. In Psalm 62, David writes:

*Pour out your heart before him. God is a refuge for us.*

[pause 8s]

[warm, reflective] Not "tidy up your heart first." Pour it out.

[pause 5s]

A refuge is a safe place to run to when things feel like too much. Not a place you have to be strong to enter. A place you go because you need it.

[pause 6s]

[calm] So let's do that. Notice your hands. If they're curled or tense, let them open slowly, palms up, as if you were holding something out to God.

[pause 6s]

[gentle wonder] As this little life develops, your body is doing work you cannot oversee, and your heart may wish it could oversee every part. God welcomes your wonder at creation, your gratitude for the little life you're carrying, and everything else resting on your heart today.

[pause 6s]

[warm, tender] You don't need to find perfect words for this moment with God. You can simply open your heart to him. Bring your gratitude for the little life you're carrying, your appreciation for the body he's given you, and anything else that rests on your heart today.

[pause 6s]

[gentle] Now tell him what's heavy. Whatever comes.

[pause 15s]

[calm] As you finish, let your shoulders drop. Let your jaw soften. Let your body follow your heart in letting go.

[pause 6s]

[reverent] Another psalm says:

*Cast your burden on the Lord and he will sustain you.*

[pause 8s]

[warm, reassuring] That doesn't mean every burden disappears. It means you don't carry it alone. He holds you up while you carry it.

[pause 6s]

[prayerful, sincere] Lord, thank you for listening to all of it, the big things and the small. I'm placing these in your hands. Hold me up today. Amen.

[pause 8s]

[tender] If you'd like, rest your open hand on your belly, and let your hands stay soft.

[pause 10s]

[warm] When you're ready, let your eyes open.

[pause 3s]

Walk a little lighter today, knowing he holds what you've given him.

[music 6s]

---

### Week 13 · Faith-centered

**Title:** Every / *good* / gift.
**Description:** Five minutes to recognize God's goodness in the small gifts of your days.
**Approach:** recalling small gifts one by one, thanking God for each, and making room for days when thankfulness is hard.
**Scripture:** James 1:17 (verbatim excerpt: the first part of the verse).

[music 6s]

[reverent] James, writing to the early church, said this:

*Every good gift and every perfect gift is from above, coming down from the Father of lights.*

[pause 8s]

[warm, unhurried] Let those words settle as you find a comfortable position.

[pause 6s]

Every good gift. Not only the big ones. The small, everyday ones too.

[pause 6s]

[gentle wonder] James calls God the Father of lights. The one who made the sun and the stars, and who still notices the smallest good thing in your day.

[pause 8s]

[warm] Let's look for some. Think back over the last day or so. What was one good thing, however small? A warm meal. A kind word. A quiet moment. Picture it clearly.

[pause 10s]

[prayerful] Now simply say, in your heart: Thank you.

[pause 8s]

[warm] Let a second gift come to mind. Maybe a person. Someone who helped, or listened, or made you laugh.

[pause 10s]

[prayerful] Thank you.

[pause 8s]

[warm] And a third. Perhaps something about this pregnancy. Or perhaps just that you're here, breathing, right now.

[pause 10s]

[prayerful] Thank you.

[pause 8s]

[gentle wonder] Among the gifts you may notice is the wonder of a body carrying new life. Even as you rest, so many intricate changes are taking place beyond your awareness. You can appreciate this remarkable work in your own way, without needing to feel any particular emotion.

[pause 6s]

[reassuring] If thankfulness feels hard today, that's all right. God isn't asking you to pretend everything is easy. You can tell him that too. Gratitude and honesty can sit side by side.

[pause 8s]

[gentle] Your prayer can be simple and sincere: 'Thank you for this moment, Lord. Help me be present to the gift of today.' Whatever is on your heart, you can bring it to him.

[pause 12s]

[prayerful, sincere] Father of lights, every good thing in my life comes from you. Thank you for the small gifts I so often miss, and for the gift of this little one. Open my eyes to your goodness today, even in ordinary moments. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open slowly.

[pause 3s]

Watch for his good gifts today. They're often closer than we think.

[music 6s]

---

### Week 14 · Faith-centered

**Title:** A blessing / *for* / the little one.
**Description:** Five minutes to pray an ancient blessing over your baby, and receive it for yourself too.
**Approach:** praying the priestly blessing slowly, line by line, over the baby, then personally.
**Scripture:** Numbers 6:24–26 (verbatim).

[music 6s]

[warm, unhurried] Welcome. Today we'll pray a blessing over your baby. One of the oldest blessings in Scripture.

Settle in, and if you'd like, rest your hands on your belly.

[pause 6s]

[calm] Let your breath slow in its own time.

[pause 5s]

[reverent] In the book of Numbers, God gave Moses these words for Aaron and the priests to speak over his people. People have prayed them over children for thousands of years.

Listen to them once through:

*The Lord bless you, and keep you. The Lord make his face to shine on you, and be gracious to you. The Lord lift up his face toward you, and give you peace.*

[pause 10s]

[warm, reassuring] A blessing isn't a guarantee of an easy road. It's an asking. Placing someone you love into God's care.

[pause 6s]

[tender] Notice the shape of it. Blessing. Keeping. His face shining toward you, the way a parent's face lights up when their child walks into the room. Grace. Peace.

[pause 6s]

[gentle wonder] The life you're carrying is part of the remarkable work unfolding within your body. You might feel joy, tenderness, or uncertainty as you pray. Each is welcome in this moment.

[pause 6s]

[prayerful, sincere] God, thank you for the ways this body is carrying new life today. Teach me to care for myself with the same tenderness I hope to give my child, and receive whatever feelings rise as I speak these words.

[pause 6s]

[reverent, tender] Let's pray it slowly over your baby now, line by line. You can echo the words silently, or simply listen.

The Lord bless you, and keep you.

[pause 9s]

The Lord make his face to shine on you, and be gracious to you.

[pause 9s]

The Lord lift up his face toward you, and give you peace.

[pause 12s]

[gentle] Now take a moment to pray for your baby in your own words. Whatever hopes are in your heart. Perhaps that they'll know they're loved. That they'll have courage, and kindness, and people around them.

[pause 13s]

[warm] And this blessing is for you too. Let it rest on you, as a mother, in this season.

[pause 6s]

[prayerful, sincere] Lord, bless me and keep me. Let your face shine on me. Give me your peace. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open slowly.

[pause 3s]

Go in his peace, both of you.

[music 6s]

---

### Week 15 · Faith-centered

**Title:** New / *every* / morning.
**Description:** Five minutes to rest in God's unchanging faithfulness while so much in you is changing.
**Approach:** reflecting on change and constancy, with God's mercies as the steady center, and a quiet prayer of trust.
**Scripture:** Lamentations 3:22–23 (verbatim excerpt: from "his compassion" to the end of verse 23).

[music 6s]

[warm, unhurried] Imagine the early light of morning. The first gray glow at the window. The world quiet, before the day begins.

[pause 6s]

[calm] Let that quiet be with you as you settle in.

[pause 5s]

[gentle, understanding] So much is changing right now. Your body. Your energy. Your plans, maybe even how you see yourself. Some changes might feel exciting. Others might feel unsettling. Probably both.

[pause 5s]

[reverent] In the book of Lamentations, written during a time of upheaval, there's a moment of surprising hope. The writer says of God:

*his compassion doesn't fail. They are new every morning. Great is your faithfulness.*

[pause 10s]

[warm, reflective] Everything around the writer had changed. But God's compassion hadn't. It met the writer again, new, each morning.

[pause 8s]

[tender] New every morning. Not leftover from yesterday. Not rationed out. On the mornings when you wake up tired, or queasy, or anxious, his compassion is already there.

[pause 8s]

[gentle wonder] The life growing within you is a quiet reminder of how intricate creation can be. Your body is meeting this pregnancy with changes you did not have to plan, and you can offer God thanks for that work without insisting every change feels good.

[pause 6s]

[warm, reassuring] Sometimes God's mercies are found in the simplest moments: a little more patience, a moment of rest, or a quiet reminder of his love woven into an ordinary day. Ask for those small mercies as freely as you ask for peace.

[pause 6s]

[gentle] What feels most changed in your life right now? Bring it to God, honestly.

[pause 9s]

Now, what do you need to stay steady? Patience? Comfort? A reminder of who you are in him? Ask him for it.

[pause 9s]

[warm, reassuring] Some things about you won't change at all. You are still his. Still loved. Still known, through every season of this pregnancy, and every season after.

[pause 9s]

[tender] If you'd like, rest a hand on your belly. You and your baby are both changing every day, and both held by the same faithful God.

[pause 10s]

[prayerful, sincere] Lord, so much in me is changing. Thank you that your love doesn't change. Meet me with your compassion each morning, and help me trust you through every new thing. Amen.

[pause 10s]

[warm] When you're ready, let your eyes open.

[pause 3s]

His compassion will meet you new, every morning.

[music 6s]

---

### Week 16 · Faith-centered

**Title:** Sleep / *for* / the beloved.
**Description:** Five minutes to lay down the day and rest in God's love, for evenings or any time you're weary.
**Approach:** handing the day over to God, piece by piece, then resting in his love, with a long quiet ending.
**Scripture:** Psalm 127:2 (verbatim excerpt: the end of the verse); Zephaniah 3:17 (verbatim excerpt: the third and fourth sentences).

[music 6s]

[reverent, calm] There's a line at the end of Psalm 127 that says:

*for he gives sleep to his loved ones.*

[pause 8s]

[warm, soothing] Sleep, and rest, as a gift. Not something you have to earn by finishing everything first.

[pause 6s]

[calm, soothing] If it's evening, you might dim the lights. If it's daytime, let this be a small evening wherever you are. Find the most comfortable position you can, with whatever pillows or support you need. Let your breath slow down by itself.

[pause 8s]

[gentle] Let's give the day to God, one piece at a time.

What went well today? Thank him for it.

[pause 10s]

What was hard? Tell him about it, and leave it with him.

[pause 10s]

What's left undone? Let it wait. It's in his hands until morning.

[pause 10s]

[gentle wonder] As you settle, remember the quiet wonder of carrying a developing child. Your body is adjusting in ways you may never see directly, and you can thank God for this mystery without needing to understand every part of it.

[pause 6s]

[calm, soothing] If your mind wanders back to the busyness of the day or the things waiting for your attention, bring that into your prayer too. God is present whether sleep comes easily or not. Rest can begin with simply being here with him.

[pause 6s]

[reverent, calm] Now listen to these words, spoken by the prophet Zephaniah to God's people:

*He will calm you in his love. He will rejoice over you with singing.*

[pause 10s]

[tender, soothing] Imagine being sung over. Calmed. The way you might one day sing over your own child.

[pause 7s]

Not because you've earned it, or finished your list, or handled today perfectly. Simply because you are his, and he delights in you.

[pause 8s]

[calm, soothing] If you'd like, rest a hand on your belly. You are both held in his love tonight. Let your shoulders sink into the pillow. Let your hands rest open, like a child asleep.

[pause 10s]

[prayerful, soothing] Lord, I give you this day. Calm me in your love, and give me the rest I need. Amen.

[pause 12s]

[calm, soothing] If you're drifting toward sleep, let yourself go. If not, rest here in his care.

[pause 6s]

Rest well, beloved.

[music 6s]

---

### Week 17 · Faith-centered

**Title:** Never / *left* / alone.
**Description:** Five minutes to rest in God's promise never to leave you, and see his care through others.
**Approach:** God's presence first, then the people he places around us, with room for those who feel alone.
**Scripture:** Hebrews 13:5 (verbatim excerpt: the words quoted as God's, at the end of the verse); Galatians 6:2 (verbatim).

[music 6s]

[warm, unhurried] Welcome. Wherever you're listening from, and whoever is or isn't beside you right now, you're not alone in this moment.

Find a comfortable position, and let yourself lean into whatever is supporting you.

[pause 8s]

[reverent] The letter to the Hebrews reminds its readers of something God has said:

*I will in no way leave you, neither will I in any way forsake you.*

[pause 10s]

[warm, reassuring] In no way. Not in the hard moments. Not in the uncertain ones. Not when you feel strong, and not when you feel weak.

[pause 8s]

[warm, reflective] This letter was written to people who were struggling. Some had lost their possessions. Some felt forgotten. And God's answer to them wasn't a list of instructions. It was his presence.

[pause 8s]

[calm] Take a moment to rest in his presence. You don't need to feel anything particular. Just know he's here.

[pause 10s]

[reverent] God often shows his care through people. Paul wrote to the churches in Galatia:

*Bear one another's burdens, and so fulfill the law of Christ.*

[pause 8s]

[gentle wonder] As a new life develops within your body, you are giving and carrying so much. God's care for you isn't an instruction to handle everything without help; you are worthy of comfort and practical support too.

[pause 6s]

[warm] Sometimes God answers our prayers for help through other people's hands and voices. A meal dropped off. A message at just the right moment. Someone who simply sits with us.

[pause 8s]

[gentle] Bring to mind someone who has helped carry your burdens lately. A partner, a friend, a family member, a nurse, someone at church, someone unexpected. Thank God for them.

[pause 10s]

[tender, reassuring] Some women share joyful news openly. Others prefer to keep it close for a while. God knows what you're carrying in your heart. You can ask him for trustworthy people and the courage to accept help in whatever measure feels right.

[pause 8s]

[tender] If you'd like, rest a hand on your belly.

[pause 6s]

[prayerful, sincere] Lord, thank you that you never leave me. Thank you for the people who carry my burdens with me. Where I feel alone, draw near, and bring the help I need. Amen.

[pause 10s]

[warm] When you're ready, let your eyes open slowly.

[pause 3s]

He goes with you into the rest of today.

[music 6s]

---

### Week 18 · Faith-centered

**Title:** A greeting / *of* / joy.
**Description:** Five minutes with Mary and Elizabeth, two expectant mothers who shared their joy and their waiting.
**Approach:** imaginative reflection on the visitation, then praying for companionship and joy, with no expectation of feeling movement.
**Scripture:** Luke 1:39–45 (the story retold in Maren's own words); Luke 1:41 (verbatim excerpt: the first part of the verse); Luke 1:44 (verbatim).

[music 6s]

[warm, storytelling] Long ago, two expectant mothers met in a house in the hill country of Judah. Find a comfortable position as we step into their story.

[pause 5s]

Mary was young, and newly pregnant, carrying news she was still trying to understand. She hurried to visit her relative, Elizabeth, who was also expecting, after years of waiting.

[pause 5s]

Imagine Mary arriving at the door, tired from her journey. Imagine Elizabeth hearing her voice.

[reverent] Luke tells us:

*When Elizabeth heard Mary's greeting, the baby leaped in her womb.*

[pause 7s]

[reverent, joyful] And Elizabeth said to her:

*For behold, when the voice of your greeting came into my ears, the baby leaped in my womb for joy!*

[pause 9s]

[warm] Two women, both carrying new life. Sharing their joy, and their questions, and staying together for months.

[pause 5s]

[warm, smiling] Imagine the conversations they might have had. Talking about what their bodies were going through. Wondering together about the children they would hold. Laughing, maybe. Praising God, as Mary did.

[pause 7s]

[gentle, reassuring] Some people begin to feel small movements around this time, and others not for a while yet. This story isn't about a timeline. It's about joy shared, and about not waiting alone.

[pause 5s]

[tender] In the meeting of Mary and Elizabeth, joy rises through an encounter with the child each woman is carrying. Your own relationship with your baby may feel quieter or more complicated. There is no single right way for it to begin.

[pause 6s]

[gentle wonder] You can bring God your wonder at the life developing within you, along with any other feelings today holds. Let Mary and Elizabeth's story be an invitation to notice this moment with gratitude, not a standard for how you ought to feel.

[pause 6s]

[tender] If you'd like, rest your hands on your belly. Simply be with your baby, whatever you feel or don't feel.

[pause 10s]

[warm] Elizabeth's joy began with a greeting. Imagine greeting your baby now, in your heart. A simple hello, full of love.

[pause 9s]

[gentle] Who is an Elizabeth for you? Someone you can share this season with? Thank God for them. Or, if you're longing for someone like that, ask him for it.

[pause 8s]

[prayerful, sincere] Lord, thank you for the joy of new life, and for the people who share it with me. Let joy find its way into my heart, even in the waiting. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open slowly.

[pause 3s]

May you find small joys to share today.

[music 6s]

---

### Week 19 · Faith-centered

**Title:** The / *one* / thing.
**Description:** Five minutes to sit at Jesus' feet in the middle of a busy season.
**Approach:** imaginative reflection on Mary and Martha, with gentle permission to stop, and quiet time with Jesus.
**Scripture:** Luke 10:38–42 (the story retold in Maren's own words); Luke 10:41–42 (verbatim excerpt: Jesus' words, from "you are anxious" to "one thing is needed").

[music 6s]

[warm, unhurried] Before we begin, notice how full your mind feels right now. Crowded? Quiet? Somewhere in between?

[pause 6s]

[calm] Whatever is there, let it wait a few minutes. Settle in, and let your body rest.

[pause 6s]

[warm, storytelling] In Luke's Gospel, Jesus visits the home of two sisters, Martha and Mary. Martha is busy getting everything ready. Mary sits at Jesus' feet, listening.

[pause 6s]

[reverent, tender] Martha, worn out, asks Jesus to tell her sister to help. And Jesus answers her, gently:

*Martha, Martha, you are anxious and troubled about many things, but one thing is needed.*

[pause 10s]

[warm, reassuring] Notice that he says her name twice. Kindly. He isn't scolding her for caring, or for working hard. He's inviting her to stop for a moment, and be with him.

[pause 8s]

[warm, reflective] Martha's work mattered. Someone had to make the meal. But in that moment, Jesus himself was sitting in her home, and she was missing time with him.

[pause 8s]

[gentle wonder] Pregnancy can bring a thousand little demands, yet within the rush your body is carrying a new life. That is worthy of wonder, and you don't need a long stretch of silence to bring that wonder to God.

[pause 6s]

[warm, gentle] If your thoughts wander during this moment, gently return your attention to God, knowing you can bring your whole heart to him. A brief prayer isn't less real because your feelings are mixed. You can meet God in this ordinary pause, as you are.

[pause 5s]

[tender] Imagine Jesus saying your name the same way. Kindly. Twice.

[pause 9s]

[gentle] What are the many things you're anxious and troubled about right now? You can name them to him.

[pause 9s]

[calm] Now imagine setting them down, just for these few minutes, and sitting at his feet. There's nothing to prepare. Nothing to prove. Just be with him.

[pause 13s]

[tender] If you'd like, rest a hand on your belly. Your baby is here with you, in this quiet place.

[pause 10s]

[prayerful, sincere] Jesus, my days are full, and my mind is busier still. Thank you for inviting me to sit with you. Help me find my way back to you, even in the middle of everything. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open slowly.

[pause 3s]

Sit at his feet whenever you can, even for a moment in a busy day.

[music 6s]

---

### Week 20 · Faith-centered

**Title:** Helped / *until* / now.
**Description:** Five minutes to remember God's faithfulness so far, and trust him with the road ahead.
**Approach:** setting up a "stone of help" in remembrance, giving thanks for the past, and entrusting the future to God.
**Scripture:** 1 Samuel 7:12 (verbatim excerpt: Samuel's words at the end of the verse); Deuteronomy 31:8 (verbatim excerpt: the first three sentences).

[music 6s]

[warm, storytelling] In the book of First Samuel, after a hard-won season, the prophet Samuel set up a large stone as a marker. He named it Ebenezer, which means "stone of help," saying:

*the Lord helped us until now.*

[pause 10s]

[warm] Let's set up a small Ebenezer of your own today.

Find a comfortable position, and let yourself settle.

[pause 8s]

[gentle, reflective] Look back over these weeks of pregnancy. Where have you seen God's help? Maybe in a person. A kind word. A hard day you made it through. Strength you didn't know you had.

[pause 10s]

[prayerful] Thank him for each one, in your own words.

[pause 10s]

[warm] Now imagine placing a stone, right here, in this moment. A marker that says: God has helped me until now.

[pause 10s]

[gentle wonder] Looking back on these weeks, you may see moments of gratitude, stretches of uncertainty, and the intricate work of a body carrying new life. You can thank God for what this day holds without needing to explain every part of the journey.

[pause 6s]

[tender, reassuring] If reaching this milestone stirs up tender feelings, bring them into your reflection. The faithfulness you remember is not a guarantee about tomorrow; it is an invitation to meet this moment with God, as you are.

[pause 6s]

[warm, hopeful] Now look ahead. The coming months may hold joy, and challenge, and things you can't yet imagine.

[reverent] Moses spoke these words to Joshua and the people of Israel, as they faced a new and uncertain land:

*The Lord himself is who goes before you. He will be with you. He will not fail you nor forsake you.*

[pause 10s]

[warm, reassuring] He doesn't promise that the road will be easy. He promises to be with you on it.

[pause 8s]

[gentle] What feels uncertain about the months ahead? Name it to him. And picture him already there, going before you into each of those places.

[pause 12s]

[tender] If you'd like, rest a hand on your belly.

[pause 6s]

[prayerful, sincere] Lord, thank you for helping me until now. I trust you with what's ahead. Go before me, and stay with me, every step of the way. Amen.

[pause 10s]

[warm] When you're ready, let your eyes open slowly.

[pause 3s]

The God who has helped you until now is with you still.

[music 6s]

---

### Week 21 · Faith-centered

**Title:** Quietness / *and* / confidence.
**Description:** Five minutes to rest in God's strength, discovered in quiet rather than effort.
**Approach:** a gentle settling into quiet, reflection on Isaiah's words about rest, and silent trust before God.
**Scripture:** Isaiah 30:15 (verbatim excerpt: the second sentence of God's words).

[music 6s]

[warm, unhurried] Let's begin by simply getting quiet.

Find a position that feels restful and well supported. Let your hands lie open.

[pause 6s]

[calm] Notice your breath, coming and going on its own. No need to manage it. Notice the sounds around you, near and far, and let them fade into the background.

[pause 8s]

[reverent] Through the prophet Isaiah, God spoke to his people about where real strength is found. Among his words is this line:

*Your strength will be in quietness and in confidence.*

[pause 10s]

[warm, reflective] Quietness and confidence. Not hurry. Not effort. Not trying harder.

[pause 6s]

There's a lot of doing in pregnancy. Appointments to keep, things to prepare, plans to make. And there's a lot that's good about that. But this verse invites you to remember that strength can also grow in stillness.

[pause 6s]

[gentle wonder] Even now, as you rest, your body is doing extraordinary work. Your heart is working in remarkable ways to support this pregnancy, while your baby's own heart beats within. So much intricate activity unfolds quietly, without your conscious direction.

[pause 8s]

[warm] Confidence, too, can grow quietly. Not the loud kind that has every answer. The settled kind that comes from knowing who holds you. Week by week, as you rest in God's care, that confidence can take root.

[pause 8s]

[calm] Let's practice that quiet now. Let your shoulders soften. Let your jaw loosen. Let your whole body rest against what's holding you.

[pause 10s]

[tender] If you'd like, rest a hand on your belly. Let this be a quiet moment shared by the two of you, held in God's care.

[pause 12s]

[gentle] Now, in your heart, simply rest before God. You don't need to say anything. Let your quietness be your prayer.

[pause 18s]

[prayerful, sincere] Lord, thank you that strength isn't only found in doing. Teach me to rest in you, to grow quietly confident in your care, and to enjoy these days of carrying new life. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open, and come back gently.

[pause 3s]

May quietness and confidence go with you through this day.

[music 6s]

---

### Week 22 · Faith-centered

**Title:** Life / *and loving* / kindness.
**Description:** Five minutes to marvel at how God forms and cares for life, in you and in your baby.
**Approach:** reflecting on Job's wonder at being formed by God, then gratitude for the life within you.
**Scripture:** Job 10:11–12 (verbatim excerpt: the first two sentences).

[music 6s]

[warm, reflective] There's a moment in the book of Job where Job, speaking honestly to God, pauses to remember how he was made. He says:

*You have clothed me with skin and flesh, and knit me together with bones and sinews. You have granted me life and loving kindness.*

[pause 10s]

[warm, unhurried] Let his words settle as you find a comfortable position. Let your breath slow down on its own, and your shoulders soften.

[pause 6s]

[gentle wonder] Skin and flesh. Bones and sinews. Even now, these are being formed in your baby. Tiny fingers and toes. A heartbeat. Eyes, ears, a face that's uniquely theirs.

[pause 8s]

And your own body is part of that work. Supplying, sheltering, adapting, every moment of every day. What a remarkable thing to be part of.

[pause 8s]

[tender] If you'd like, rest your hands on your belly, and simply marvel for a moment at the life God is forming there.

[pause 12s]

[warm, reverent] Notice the last line of Job's words. Life and loving kindness. God doesn't only make us. He gives us life wrapped in his kindness.

[pause 8s]

[warm] That kindness surrounds you too. In the rest you can take today. In the people who care for you. In a good meal, a warm bed, a quiet moment like this one. In the small, good gifts of this season.

[pause 8s]

[tender] And one day, you'll show that same loving kindness to your child. In a thousand small ways. Feeding, holding, soothing, delighting in them. Love, learned first from the God who loves you.

[pause 10s]

[gentle] Take a moment to thank God, in your own words, for the life he's forming, and for his kindness to you.

[pause 15s]

[prayerful, sincere] Creator God, thank you for knitting this little one together with such care. Thank you for my body, and for all it's doing. Surround us both with your loving kindness, today and every day. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open slowly.

[pause 3s]

Life and loving kindness, given to you, and to your little one.

[music 6s]

---

### Week 23 · Faith-centered

**Title:** Strength / *that* / renews.
**Description:** Five minutes to receive God's strength for this season, with gratitude for all your body is doing.
**Approach:** reflection on Isaiah 40, gratitude for the body's strength, and prayer for renewed energy.
**Scripture:** Isaiah 40:29 (verbatim); Isaiah 40:31 (verbatim excerpt: the first part of the verse).

[music 6s]

[warm, unhurried] Pregnancy asks a lot of your body, and your body has been rising to meet it, week after week.

Let's take a few minutes to rest, and to receive.

[pause 4s]

[calm] Find a comfortable position. Let your breath come and go easily. Let your shoulders settle, and your hands rest.

[pause 6s]

[reverent] Isaiah chapter 40 was written to encourage God's people when they felt worn out. It reminds them that the Creator of the whole earth never grows tired. And then it says:

*He gives power to the weak. He increases the strength of him who has no might.*

[pause 8s]

And a little later:

*those who wait for the Lord will renew their strength.*

[pause 10s]

[warm, reflective] Renew. Not invent from nothing. Renew. Like a well that fills again, or a field that grows green after rain.

[pause 6s]

[gentle wonder] Think of all your body has done these past months. Growing your baby from the very first cells. Adapting, stretching, carrying more each week. That's a remarkable kind of strength, and it comes from the God who designed you.

[pause 8s]

[warm] And strength isn't only physical. Think of the patience you've found. The kindness you've shown yourself on tired days. The love already growing for someone you haven't met yet. Those are gifts of strength too.

[pause 8s]

[calm] Let's rest in that now. Let your shoulders soften. Let your arms and legs grow heavy. Let your body be carried for a while, instead of carrying.

[pause 10s]

[tender] If you'd like, rest a hand on your belly. Your baby is growing in strength too, held within yours.

[pause 10s]

[gentle] Waiting on the Lord can be as simple as this: being still, and receiving. Take a quiet moment to tell God what you need today. Energy, patience, rest, joy.

[pause 15s]

[prayerful, sincere] Lord, thank you for the strength you've given my body for this work. When I feel tired, renew me. Fill me again, day by day, and let me enjoy this season with you. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open.

[pause 3s]

May his strength meet you, fresh and new, as you go.

[music 6s]

---

### Week 24 · Faith-centered

**Title:** The breath / *of* / life.
**Description:** Five minutes to rest in the God who gives every breath, with a gentle, prayerful practice of slowing down.
**Approach:** breath as God's gift, a slow and easy breathing prayer, and gratitude for shared life.
**Scripture:** Job 33:4 (verbatim).

[music 6s]

[warm, reflective] Every breath you've ever taken has been a gift. Today, let's slow down enough to notice that.

Find a comfortable position, and let yourself be supported.

[pause 6s]

[reverent] In the book of Job, a young man named Elihu says:

*The Spirit of God has made me, and the breath of the Almighty gives me life.*

[pause 10s]

[warm] The breath of the Almighty. Each breath, given. Each one, a quiet reminder of the God who made you.

[pause 6s]

[calm] Notice your breathing now, just as it is. Feel it moving in, and out. You don't need to change anything yet.

[pause 8s]

[calm, clear] If it's comfortable, let your next breath out be a little slower. Unhurried. Like a long sigh.

[pause 8s]

And again. A natural breath in, and a long, easy breath out.

[pause 8s]

[warm] Slow breathing like this helps the body soften and settle. It's a gentle gift you can return to anytime: in a waiting room, before sleep, and one day, when you're welcoming your baby.

[pause 8s]

[prayerful] You might pair your breathing with a simple prayer. Breathing in: You give me life. Breathing out: I rest in you.

[pause 15s]

You give me life.

I rest in you.

[pause 15s]

[gentle wonder] Each breath you take is shared with your baby. Through your body, life and nourishment flow to them, moment by moment. God's gift of breath, passed along in love.

[pause 8s]

[tender] If you'd like, rest a hand on your belly and thank God for this shared life.

[pause 10s]

[prayerful, sincere] Lord, thank you for every breath, and for the life growing in me. Let my breathing remind me of your nearness, today, and in the days to come. Amen.

[pause 8s]

[warm] Let your breathing return to its own rhythm, and when you're ready, open your eyes.

[pause 3s]

Every breath today is a small gift from him.

[music 6s]

---

### Week 25 · Faith-centered

**Title:** A gift / *from* / the Lord.
**Description:** Five minutes to receive your baby as God's good gift, and thank him for this growing life.
**Approach:** reflection on Psalm 127, attention to the baby's movements, and a prayer of thankfulness.
**Scripture:** Psalm 127:3 (verbatim).

[music 6s]

[warm, unhurried] Let's begin by simply resting your hands on your belly, if you'd like, and noticing the life within.

Settle into a comfortable position, lying on your side or reclining, well supported.

[pause 6s]

[calm] Let your breath slow down. Let your shoulders soften. Let your face relax.

[pause 6s]

[reverent] In Psalm 127, the psalmist says:

*Behold, children are a heritage of the Lord. The fruit of the womb is his reward.*

[pause 10s]

[warm, reflective] A heritage. A gift handed down with love. Not something earned, but something given, by a generous God.

[pause 6s]

In Bible times, a heritage was something precious passed down through a family. Land, a home, a name. The psalmist uses that word for children. A treasure, entrusted with love.

[pause 8s]

[gentle wonder] Your baby is that kind of gift. Growing now, moving, stretching, becoming more themselves every day. Knit together in the quiet, with a care only God could give.

[pause 8s]

[warm] Take a few moments to notice your baby. If you feel a movement, a roll, a nudge, let it be a reminder of the gift you're carrying.

[pause 14s]

[tender] You might greet your baby in your heart. Or simply rest your hand where you feel them, and enjoy their company.

[pause 12s]

[gentle wonder] Every gift reflects the giver. Your baby's life is a reflection of God's own generosity and delight. Before you ever held them, he knew them, and he chose to give them to you.

[pause 8s]

[gentle] Now think of the things you're grateful for in this pregnancy. Maybe a first flutter you'll never forget. The way your body has adapted. People who've celebrated with you. Thank God for each one, in your own words.

[pause 15s]

[prayerful, sincere] Father, thank you for this child, a gift from your hand. Thank you for every movement, every stretch, every sign of life. Help me receive this gift with joy, and care for it with love. Amen.

[pause 8s]

[warm] Let your hands rest, and when you're ready, open your eyes.

[pause 3s]

A gift from the Lord, growing close to your heart.

[music 6s]

---

### Week 26 · Faith-centered

**Title:** My peace / *I* / give you.
**Description:** Five minutes to receive the peace Jesus offers, a peace that's his own gift to you.
**Approach:** reflection on Jesus' promise of peace, a guided receiving of that peace, and personal prayer.
**Scripture:** John 14:27 (verbatim excerpt: the first two sentences).

[music 6s]

[warm, storytelling] On the night before he died, Jesus sat with his closest friends and spoke to them tenderly about the days ahead. Among his words was this gift:

*Peace I leave with you. My peace I give to you;*

[pause 10s]

[warm, unhurried] Let his words rest with you as you settle in. Let your breath slow down, and your hands rest open.

[pause 6s]

[warm, reflective] My peace. Not a peace that depends on everything going perfectly. Jesus' own peace. The kind he carried with him through every day of his life, through crowds and storms and quiet hillsides alike.

[pause 8s]

And notice that he gives it. You don't have to manufacture it, or earn it, or find it on your own. It's a gift, offered freely.

[pause 6s]

His peace goes with you into every room and every day. Into quiet mornings and busy afternoons, and into the days ahead when you'll welcome your baby.

[pause 8s]

[calm] Let's receive it slowly. Imagine that peace as a gentle warmth, beginning at the top of your head.

[pause 6s]

Let it flow down over your face, softening your forehead, your eyes, your jaw.

[pause 6s]

Down through your shoulders and arms, all the way to your fingertips.

[pause 6s]

Through your chest, with each breath you take.

[pause 6s]

[tender] And into your belly, surrounding your baby with warmth and calm.

[pause 8s]

Down through your legs, and into your feet.

[pause 8s]

[gentle wonder] Your body is doing remarkable work, and your baby is growing in the shelter of it. Let this peace rest over both of you, gentle and steady.

[pause 10s]

[gentle] Now take a moment to talk with Jesus. Thank him for his peace, and tell him anything that's on your heart.

[pause 15s]

[prayerful, sincere] Jesus, thank you for giving me your own peace. Let it fill my heart and my home, and rest on this little one too. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open slowly.

[pause 3s]

His peace is yours to keep.

[music 6s]

---

### Week 27 · Faith-centered

**Title:** In wisdom / *you* / made them.
**Description:** Five minutes to praise God for the wisdom and beauty of his creation, including the life within you.
**Approach:** a psalm of wonder, gratitude for the wisdom woven into the body, and a prayer of praise.
**Scripture:** Psalm 104:24 (verbatim excerpt: the first two sentences).

[music 6s]

[warm, reflective] Psalm 104 is one long song of wonder. It moves through mountains and springs, birds and trees, sunrise and moonlight. And then the psalmist breaks into praise:

*Lord, how many are your works! In wisdom, you have made them all.*

[pause 10s]

[warm, unhurried] Let those words of praise settle as you find a comfortable position. Let your breath slow down, and your shoulders soften.

[pause 6s]

[warm, reflective] Imagine the psalmist looking out at the world. Rivers running through valleys. Birds nesting in the trees. Lions in the night, and people heading out to work in the morning. Everywhere he looks, he sees God's wisdom.

[pause 8s]

[gentle wonder] In wisdom, you have made them all. That includes the wisdom built into your own body. The way it knows how to grow a placenta. How it makes more blood, and shifts and stretches to make room. How it shelters your baby through every hour of every day.

[pause 10s]

And it includes your baby. Tiny lungs practicing. Eyes beginning to open. A heartbeat steady and strong. All of it unfolding according to God's careful design.

[pause 10s]

[tender] If you'd like, rest your hands on your belly, and simply marvel at the wisdom at work there.

[pause 12s]

[warm] Now, like the psalmist, let your wonder turn into praise. Thank God for anything you've noticed about his work in you. Your body. Your baby. The beauty of this season.

[pause 15s]

[calm] Rest for a moment in the knowledge that you, and your baby, are part of God's good creation. Made with wisdom. Made with care.

[pause 8s]

[tender] One day, your baby will look out at the world with wonder of their own. The first sunrise. The first snowfall. The first time they see your face. You'll get to share that wonder with them.

[pause 8s]

[prayerful, sincere] Lord, how many are your works! Thank you for the wisdom woven into my body, and for the little one you're forming. Let me see your goodness everywhere I look today. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open.

[pause 3s]

You are part of his wise and wonderful work.

[music 6s]

---

### Week 28 · Faith-centered

**Title:** A place / *prepared* / with love.
**Description:** Five minutes to reflect on preparing for your baby, and on the God who prepares a place for us.
**Approach:** Jesus' words about preparing a place, a nesting visualization, and prayer over the home you're making.
**Scripture:** John 14:2 (verbatim excerpt: the last sentence).

[music 6s]

[warm, lightly smiling] Around this time, many people feel the urge to get ready. Washing tiny clothes. Setting up a corner of a room. Making a nest.

[pause 4s]

[calm] Find a comfortable position, and let your breath settle. Let your shoulders soften as you breathe out.

[pause 8s]

[reverent] On the night before he died, Jesus comforted his friends by telling them about his Father's house, with room for all of them. And he said:

*I am going to prepare a place for you.*

[pause 10s]

[warm, reflective] There's something deeply loving about preparing a place for someone. It says: I've been thinking of you. I want you to feel at home. Jesus offers that kind of love to each of us.

[pause 8s]

[calm, peaceful] Now imagine the place you're preparing for your baby. It doesn't need to be finished. Just picture the light, the softness, a blanket folded and waiting.

[pause 10s]

Imagine bringing your baby into that space for the first time. The warmth. The quiet. The feeling of welcome.

[pause 10s]

[gentle wonder] Your body has been preparing too, making room, week by week, sheltering your baby until it's time to meet. What a beautiful, God-given kind of preparation.

[pause 8s]

[warm] And your heart is preparing. Every prayer you pray for your baby, every moment you spend imagining them, is part of the place you're making. A home is more than a room. It's a place where someone is known and loved.

[pause 8s]

[tender] If you'd like, rest a hand on your belly.

[pause 6s]

[gentle] Now take a moment to pray over your home, and the place you're making. Ask God to fill it with peace, and love, and joy.

[pause 15s]

[prayerful, sincere] Lord, thank you for preparing a place for me in your love. Bless the home I'm preparing for this little one. Let it be warm with your presence, and full of welcome. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open.

[pause 3s]

A place made ready, with love, for someone dearly wanted.

[music 6s]

---

### Week 29 · Faith-centered

**Title:** In the shadow / *of* / your wings.
**Description:** Five minutes of comfort and rest under God's care, imagined as the shelter of wings.
**Approach:** finding comfort in the body, reflecting on the psalmist's image of shelter, and resting there in prayer.
**Scripture:** Psalm 63:7 (verbatim).

[music 6s]

[warm, understanding] As your baby grows, finding a comfortable position can take a little more effort. Let's begin by taking our time with that.

[pause 4s]

[calm] Lie on your side if you can, with a pillow between your knees and another under your belly. Or recline, well supported. Adjust until you feel held.

[pause 10s]

[calm] Let your breath settle. Let your shoulders soften. Let the pillows take your weight.

[pause 6s]

[reverent] David wrote Psalm 63 while he was out in the wilderness. Even there, he remembered God through the night, and wrote:

*For you have been my help. I will rejoice in the shadow of your wings.*

[pause 10s]

[warm, reflective] The shadow of wings. Imagine a mother bird gathering her little ones close, sheltering them beneath her. Warm. Safe. Completely covered.

[pause 8s]

[calm, peaceful] Let yourself rest beneath that shelter now. Let your whole body soften, as if you were tucked in close and warm.

[pause 12s]

[gentle wonder] Notice the shelter you are providing too. Your baby rests within you, surrounded by warmth, cushioned and close. Just as God shelters you, you shelter your little one.

[pause 10s]

[warm] And notice David's words: I will rejoice. Not just rest, but rejoice. There's joy in being sheltered. Joy in being cared for. Let yourself feel a little of that joy now, in this quiet, covered place.

[pause 10s]

[tender] If you'd like, rest a hand on your belly, and enjoy that layered shelter. Your baby, held in you. You, held in God.

[pause 12s]

[gentle] Take a quiet moment to thank God for being your help, and to rest in his care.

[pause 15s]

[prayerful, sincere] Lord, you have been my help. Thank you for sheltering me, and for letting me shelter this little one. Let me rest and rejoice in the shadow of your wings. Amen.

[pause 8s]

[warm] When you're ready, move slowly, and open your eyes.

[pause 3s]

Sheltered, and sheltering, in his care.

[music 6s]

---

### Week 30 · Faith-centered

**Title:** As / *a mother* / comforts.
**Description:** Five minutes to rest in the comfort of God, pictured as a mother's tender love.
**Approach:** reflection on God's motherly comfort in Isaiah, the comfort you hope to give your baby, and receiving comfort yourself.
**Scripture:** Isaiah 66:13 (verbatim excerpt: the first sentence).

[music 6s]

[warm, tender] Picture, for a moment, a mother holding her child close. Rocking gently. Humming softly. Everything about her saying: You're safe. I'm here.

[pause 8s]

[calm] Hold that picture as you find a comfortable position. Let your breath slow down. Let your shoulders soften.

[pause 6s]

[reverent] Through the prophet Isaiah, God spoke these tender words to his people:

*As one whom his mother comforts, so I will comfort you.*

[pause 10s]

[warm, reflective] Of all the ways God could describe his love, here he chooses a mother's comfort. Close. Patient. Tender. Unhurried.

[pause 8s]

Think of what that kind of comfort looks like. A warm embrace. A quiet voice. A hand smoothing hair from a forehead. Staying close until the little one settles. God says: that is how I comfort you.

[pause 10s]

[tender] Soon, you'll be offering that kind of comfort too. If you'd like, imagine a moment of comforting your baby. You don't need to picture every detail. Simply reflect on the love and tenderness you hope to share.

[pause 12s]

[gentle wonder] Your body has been preparing for that all along. Your heart, your arms, your voice. Even now, your baby is learning the sound of you, and the rhythm of your heartbeat.

[pause 8s]

[calm, soothing] Now let yourself be the one comforted. Imagine God's comfort wrapping around you, the way a mother wraps her arms around her child. Let your shoulders soften. Let your whole body rest.

[pause 12s]

[tender] If you'd like, rest a hand on your belly. You, comforted by God. Your baby, comforted by you.

[pause 10s]

[gentle] Take a quiet moment to receive God's comfort, and to thank him for it.

[pause 14s]

[prayerful, sincere] Lord, thank you for comforting me the way a mother comforts her child. Teach me to comfort my baby with that same tender love. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open slowly.

[pause 3s]

Comforted, and ready to comfort, in his love.

[music 6s]

---

### Week 31 · Faith-centered

**Title:** Through / *the* / waters.
**Description:** Five minutes to rest in God's presence, with a gentle wave breathing practice for the weeks ahead.
**Approach:** Isaiah's promise of presence, an ocean visualization with slow breathing, and prayer.
**Scripture:** Isaiah 43:2 (verbatim excerpt: the first words of the verse).

[music 6s]

[reverent] Long ago, through the prophet Isaiah, God spoke to his people about the journeys ahead of them. Among his words was this:

*When you pass through the waters, I will be with you,*

[pause 10s]

[warm, unhurried] Let those words settle as you find a comfortable position. Let your breath slow down, and your shoulders soften.

[pause 6s]

[warm, reflective] God didn't describe the waters. He didn't say how deep, or how long. He simply said: I will be with you. His presence is the heart of the promise.

[pause 8s]

[tender] The same God who has been with you through every week of this pregnancy is with you in the weeks ahead, and in the moment you meet your baby.

[pause 6s]

[calm, soothing] Picture a calm sea at sunset. Watch the waves. Each one begins small, rises to its fullest, and then eases back into stillness. Rise. Peak. Ease. And rest.

[pause 10s]

[warm] Many people find waves a helpful picture for the contractions of labor. Each one with a beginning, a middle, and an end, and a time of rest between.

[pause 6s]

[calm, clear] Let's breathe with an imagined wave, only if it feels comfortable. As it rises, breathe in naturally.

[pause 5s]

As it peaks and eases, let your breath out long and slow.

[pause 8s]

And rest. Let your whole body soften in the stillness.

[pause 10s]

One more. The wave rises… breathe in.

[pause 5s]

It eases… a long, slow breath out. And rest.

[pause 10s]

[gentle wonder] Your body has been carrying your baby with such quiet strength. The rhythm of your heart, your breath, your baby's movements, all held within God's care.

[pause 8s]

[tender] If you'd like, rest a hand on your belly.

[pause 6s]

[prayerful, sincere] Lord, thank you that you are with me. In every wave, and in every rest between, let me know your nearness. Be with my baby, and be with me, every step of the way. Amen.

[pause 8s]

[warm] When you're ready, let the sea fade gently, and open your eyes.

[pause 3s]

Wherever your path leads, he goes with you.

[music 6s]

---

### Week 32 · Faith-centered

**Title:** A / *quiet* / soul.
**Description:** Five minutes to quiet your heart before God, like a child resting with its mother.
**Approach:** reflection on Psalm 131, a gentle softening of the body, and resting in God's care.
**Scripture:** Psalm 131:2 (verbatim).

[music 6s]

[reverent] There's a short psalm, only three verses long, that paints one of the most tender pictures in Scripture. David writes:

*Surely I have stilled and quieted my soul, like a weaned child with his mother, like a weaned child is my soul within me.*

[pause 10s]

[warm, unhurried] Let that picture settle as you find a comfortable position.

[pause 6s]

[warm, reflective] A little one resting against their mother. Not asking for anything. Not needing anything. Just content to be close.

[pause 8s]

[warm] That kind of quiet doesn't come from having everything figured out. It comes from trust. From knowing you're held.

[pause 6s]

[calm] Let's quiet the body first, so the soul can follow.

Let your forehead smooth. Let your jaw loosen, and your teeth part slightly.

[pause 6s]

Let your hands open and rest, palms up.

[pause 6s]

Open hands, like a child's, ready to receive rather than hold on.

[pause 5s]

Let your shoulders drop, and then drop a little more.

[pause 6s]

[tender] Allow your belly to soften comfortably. Even in these quiet moments, your body continues its remarkable work. You can appreciate that gift as you rest in God's presence.

[pause 8s]

[calm, soothing] Now let your thoughts grow quiet too. If they wander, gently bring them back, the way a mother gathers a little one back into her arms.

[pause 12s]

[warm] Many people find that a soft face and open hands help the whole body settle, both in everyday moments and in labor. It's a small, gentle practice you can return to, anytime.

[pause 6s]

[gentle wonder] Your body has been opening and making room for months, with a flexibility and strength God built into it. Soon, you'll hold your own little one close. And even now, God holds you close like that.

[pause 10s]

[gentle] Rest in his presence for a moment. There's nothing you need to ask for. Simply be near him.

[pause 15s]

[prayerful, sincere] Lord, quiet my soul like a child resting with its mother. Thank you for holding me close, as I hold this little one within me. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open slowly.

[pause 3s]

A quiet soul, resting close to him.

[music 6s]

---

### Week 33 · Faith-centered

**Title:** Fullness / *of* / joy.
**Description:** Five minutes walking in God's presence, a place of peace you can return to in any season.
**Approach:** reflection on Psalm 16, a visualization of walking with God, and a simple cue for returning to his presence.
**Scripture:** Psalm 16:11 (verbatim excerpt: the first two sentences).

[music 6s]

[reverent] In Psalm 16, David speaks of the security he finds in God. Near the end, he writes:

*You will show me the path of life. In your presence is fullness of joy.*

[pause 10s]

[warm, unhurried] Let those words settle as you find a comfortable position. Let your breath slow down.

[pause 6s]

[warm] In your presence is fullness of joy. Not a distant place. Not somewhere you have to earn your way into. Simply being near God.

[pause 8s]

[calm, peaceful] Let's imagine that nearness. Picture a peaceful path. Maybe through a meadow, along a shoreline, or beneath tall trees. The light is warm and soft.

[pause 10s]

Imagine walking slowly along that path, and becoming aware that you aren't walking alone. God is with you. Unhurried. Glad to be with you.

[pause 12s]

[tender] Perhaps you share what's on your heart as you walk. Or perhaps you simply walk together in comfortable quiet, the way old friends do.

[pause 10s]

What do you notice here? The light, the air, the sounds around you. Let this be a place of peace.

[pause 10s]

[calm, clear] Now, gently touch your thumb to the tip of one finger, and let that touch remind you of this nearness. Keep breathing, and resting, in his presence.

[pause 12s]

[warm] Whenever you'd like to return, on a busy day, before sleep, or during labor, you can touch your thumb to your finger, breathe slowly, and remember: he is with you.

[pause 8s]

Release your fingers now.

[pause 4s]

[gentle wonder] Your baby, too, is growing in a place of peace, warm and held within you. God's care surrounds you both, in every season.

[pause 8s]

[tender] If you'd like, rest a hand on your belly.

[pause 6s]

[prayerful, sincere] Lord, thank you that in your presence there is fullness of joy. Show me the path of life, and let me walk it with you, one step at a time. Amen.

[pause 8s]

[warm] When you're ready, let the path fade gently, and open your eyes.

[pause 3s]

His presence is always just a breath away.

[music 6s]

---

### Week 34 · Faith-centered

**Title:** Held / *up* / by love.
**Description:** Five minutes to thank God for the people who support you, and pray for those who'll be with you.
**Approach:** the story of Aaron and Hur holding up Moses' hands, gratitude for support, and prayer for your birth team.
**Scripture:** Exodus 17:12 (the story retold in Maren's own words, with a verbatim excerpt from the middle of the verse).

[music 6s]

[reverent] There's a story in the book of Exodus about a long, tiring day. Moses needed to keep his hands raised, and as the hours went on, his arms grew heavy. So his friends found him a stone to sit on. And then:

*Aaron and Hur held up his hands, the one on the one side, and the other on the other side.*

[pause 10s]

[warm, unhurried] Let that picture settle as you find a comfortable position. Let your breath slow down.

[pause 6s]

[warm, reflective] Moses didn't have to do it alone. Someone stood on each side, holding him up. That's what good support looks like. Steady. Present. Close.

[pause 8s]

[warm] As your baby's birth draws closer, think of the people who hold you up. A partner, a friend, family, a doula, a midwife or doctor, a nurse, people from your church. Some may be close by, and some may be praying from far away.

[pause 10s]

Bring them to mind, one by one. Thank God for each of them.

[pause 15s]

[warm] Support continues after the birth too. Meals, a helping hand, someone who lets you rest. Thank God for those helpers as well.

[pause 8s]

[calm, peaceful] Now think about the kind of care that helps you feel at ease. A calm voice. A hand to hold. A quiet presence. Prayer. A favorite song. These are worth sharing with the people who'll be with you.

[pause 10s]

[gentle wonder] Your baby has been held up by you since the very beginning. Sheltered, nourished, carried every moment. Soon, you'll hold them in your arms. And through it all, God holds you both.

[pause 8s]

[tender] If you'd like, rest a hand on your belly.

[pause 6s]

[gentle] Now take a moment to pray for those who will be with you. For their wisdom, their kindness, and their care.

[pause 14s]

[prayerful, sincere] Lord, thank you for the people who hold me up. Give them wisdom, gentleness and strength. Surround my baby and me with your care, and with theirs. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open.

[pause 3s]

Held up by love, and by him.

[music 6s]

---

### Week 35 · Faith-centered

**Title:** Grace / *that is* / enough.
**Description:** Five minutes to rest in God's grace, which meets you day by day, and to carry a few words of Scripture with you.
**Approach:** reflection on God's words to Paul, relaxation, and choosing a short phrase of faith to carry into labor.
**Scripture:** 2 Corinthians 12:9 (verbatim excerpt: the words Paul heard from the Lord).

[music 6s]

[reverent] The apostle Paul once asked God, more than once, to take away something that was hard for him. And he received this answer:

*My grace is sufficient for you, for my power is made perfect in weakness.*

[pause 10s]

[warm, unhurried] Let those words settle as you find a comfortable position. Let your breath slow down, and your hands rest open.

[pause 6s]

[warm] Sufficient. Enough. God's grace doesn't wait until you feel strong. It meets you right where you are, with exactly what you need for today.

[pause 8s]

[gentle wonder] Think of all your body has done these past months, the little life it has nurtured, the changes it has carried with grace. And think of how God has met you, day after day. Not all at once, but always enough.

[pause 10s]

[calm] Let your forehead smooth. Your jaw soften. Your shoulders drop.

[pause 8s]

[warm] Let's gather a few words of faith you can carry with you. Short phrases you can return to anytime, and when it's time to meet your baby.

[pause 6s]

[calm, reassuring] Listen to each one, and notice which feels right for you.

His grace is enough for this moment.

[pause 8s]

The Lord is with me.

[pause 8s]

I can rest in him.

[pause 8s]

One breath, one moment, one prayer at a time.

[pause 10s]

Choose one, or one from Scripture that you love. Repeat it slowly to yourself, with each breath out.

[pause 15s]

[warm] You might write your phrase on a card, or save it somewhere you'll see it often.

[pause 6s]

[tender] If you'd like, rest a hand on your belly, and pray your phrase over your baby too.

[pause 10s]

[prayerful, sincere] Lord, thank you that your grace is enough for me. Give me what I need for each day, and for the day I meet my child. Let me lean on you, and rest in you. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open.

[pause 3s]

Enough grace, for today and for every day ahead.

[music 6s]

---

### Week 36 · Faith-centered

**Title:** My help / *comes* / from the Lord.
**Description:** Five minutes to lift your eyes to God, practice resting between efforts, and receive his help.
**Approach:** Psalm 121, a gentle effort-and-rest practice, and a prayer for help in the days ahead.
**Scripture:** Psalm 121:1–2 (verbatim).

[music 6s]

[reverent] Psalm 121 is one of the songs God's people sang as they traveled up to Jerusalem. It begins:

*I will lift up my eyes to the hills. Where does my help come from? My help comes from the Lord, who made heaven and earth.*

[pause 10s]

[warm, unhurried] Let those words settle as you find a comfortable position, fully supported. Let your breath slow down.

[pause 6s]

[warm] My help comes from the Lord. The same God who made the mountains, the stars, and the little one within you is the one who helps you.

[pause 8s]

And notice that the psalmist doesn't stop at the hills. He looks past them, to the God who made them.

[pause 6s]

[warm] In labor, contractions come and go, like waves, with time to rest between them. Learning to rest fully in those moments can be a real gift. Let's practice.

[pause 6s]

[calm, clear] If it's comfortable, gently press your palms together. A little effort. Keep breathing.

[pause 6s]

And release. Let your hands fall open. Let your shoulders drop.

[pause 4s]

[calm, soothing] Now rest completely. Let your body grow heavy. Breathe slowly. Let God's help be the ground beneath you.

[pause 12s]

Once more. Press gently. Keep breathing.

[pause 6s]

And release. Rest. Every muscle softening.

[pause 14s]

[gentle wonder] Within you, your baby has rhythms of their own. So much of their development takes place beyond what you can see or feel. Take a quiet moment to marvel at this little life, and thank God for the extraordinary work of creation.

[pause 8s]

[tender] If you'd like, rest a hand on your belly.

[pause 6s]

[gentle] Take a quiet moment to lift your eyes to the Lord. Tell him what help you'd like in these final weeks.

[pause 14s]

[prayerful, sincere] Lord, my help comes from you. Thank you for carrying me this far. Teach me to rest in you between every effort, and stay near to me and my baby in the days ahead. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open.

[pause 3s]

Lift your eyes. Your help is near.

[music 6s]

---

### Week 37 · Faith-centered

**Title:** A time / *for* / everything.
**Description:** Five minutes to rest in God's timing, holding your plans with open hands.
**Approach:** reflection on Ecclesiastes 3, an open-hands prayer posture, and trusting God with the days ahead.
**Scripture:** Ecclesiastes 3:1 (verbatim).

[music 6s]

[reverent] The book of Ecclesiastes has a beautiful passage about the rhythm of life. It begins:

*For everything there is a season, and a time for every purpose under heaven:*

[pause 10s]

[warm, unhurried] Let those words settle as you find a comfortable position. Let your breath slow down, and your shoulders soften.

[pause 6s]

[warm, reflective] A time for every purpose. A season for everything. Including this season, these final weeks of waiting and preparing, and the day you'll meet your baby.

[pause 8s]

[warm] You may have been making plans. Who will be with you. What might help. The bag by the door. Planning is a lovely way to prepare. And it can be held with open hands, trusting God with the timing and the details.

[pause 8s]

[calm, clear] If it's comfortable, turn your hands palms up, resting open. A posture of trust. Ready to receive, rather than holding on tightly.

[pause 10s]

[gentle] Now offer your plans to God, one by one, in your own words. Your hopes. Your preferences. Your questions. Place each one in your open hands, and lift it to him.

[pause 15s]

[warm, reflective] Ecclesiastes goes on to name many seasons. A time to plant. A time to laugh. A time to embrace. Every one of them is held in God's hands, and so is this one.

[pause 8s]

[calm] Notice how your hands feel, resting open. Light. Unclenched. Ready to receive.

[pause 6s]

[gentle wonder] Your body has been adapting for months, with a flexibility God designed. Making room. Carrying your baby. Growing ready, in its own time.

[pause 8s]

[tender] If you'd like, rest an open hand on your belly. Your baby, too, has a season, and a time to be born, known fully by God.

[pause 12s]

[prayerful, sincere] Lord, thank you for this season. I give you my plans and my hopes for this birth. Help me hold them with open hands, and trust you with the timing. Be near to me and my baby, today and every day. Amen.

[pause 8s]

[warm] When you're ready, let your hands rest, and open your eyes.

[pause 3s]

There is a time for everything, and this time is held by him.

[music 6s]

---

### Week 38 · Faith-centered

**Title:** My times / *are in* / your hand.
**Description:** Five minutes to entrust each moment, and every moment ahead, to God.
**Approach:** reflection on Psalm 31, a present-moment practice of trust, and prayer.
**Scripture:** Psalm 31:14–15 (verbatim excerpt: from "But I trust in you" to "My times are in your hand").

[music 6s]

[reverent] In Psalm 31, David prays honestly to God, and in the middle of his prayer, he says:

*But I trust in you, Lord. I said, "You are my God." My times are in your hand.*

[pause 10s]

[warm, unhurried] Let those words settle as you find a comfortable position. Let your breath slow down.

[pause 6s]

[warm, reflective] My times are in your hand. Not just the big moments, but each one. This breath. This hour. This day. And the day you'll meet your baby.

[pause 8s]

[warm, reassuring] David wrote these words in a difficult season of his life. And still he could say: my times are in your hand. Trust doesn't need every answer. It simply chooses where to rest.

[pause 8s]

[calm, clear] Let's practice resting in that trust, one moment at a time. Notice this breath. Only this one.

[pause 8s]

Now this moment. Whatever is supporting you. The sounds around you. God's presence, here, now.

[pause 10s]

If your mind jumps ahead, gently bring it back, and pray: My times are in your hand.

[pause 12s]

[warm] Many people find this a steadying way to approach labor. Not looking far ahead, but meeting each contraction as it comes, and then the rest that follows. One moment at a time, held in God's hand.

[pause 8s]

[calm, soothing] Between contractions, you can return to this simple prayer. My times are in your hand. Rest, and breathe, and let the next moment come in its own time.

[pause 8s]

[gentle wonder] Within you, your baby has been developing in remarkable ways, moment by moment. Take a moment to appreciate the little life you're carrying, and the extraordinary work of creation that has brought you to today.

[pause 8s]

[tender] If you'd like, rest a hand on your belly.

[pause 6s]

[gentle] Now take a moment to entrust your times to God. Today. This week. The day your baby arrives. Tell him, in your own words.

[pause 15s]

[prayerful, sincere] Lord, I trust in you. You are my God. My times are in your hand. Help me meet each moment with you, one breath at a time. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open.

[pause 3s]

Every moment ahead is already in his hand.

[music 6s]

---

### Week 39 · Faith-centered

**Title:** God / *of all* / comfort.
**Description:** Five minutes to rest in the God of all comfort, and gather comforts for the days ahead.
**Approach:** reflection on 2 Corinthians 1, a gentle tour of comforts held lightly, and prayer.
**Scripture:** 2 Corinthians 1:3 (verbatim excerpt: the end of the verse).

[music 6s]

[reverent] At the beginning of his second letter to the Corinthians, Paul praises God with a beautiful name. He calls him:

*the Father of mercies and God of all comfort;*

[pause 10s]

[warm, unhurried] Let those words settle as you find a comfortable position. Let your breath slow down.

[pause 6s]

[warm, reflective] God of all comfort. Not some comfort. All of it. Every warm blanket, every kind hand, every quiet moment of relief comes from his heart for you.

[pause 8s]

[warm] Let's gather a little collection of comforts you might reach for in the days ahead, and when it's time to meet your baby. Different things help different people, and what helps can change. Hold these lightly, as possibilities.

[pause 6s]

[calm, peaceful] Warmth. A warm shower, a heat pack, a soft blanket.

[pause 8s]

Movement. Swaying, rocking, walking, leaning on something steady.

[pause 8s]

Sound. Worship music you love. A familiar voice. Or simple quiet.

[pause 8s]

Touch. A hand on your back, or no touch at all, whichever you prefer.

[pause 8s]

Prayer. A short phrase of Scripture, like the one you chose a few weeks ago.

[pause 8s]

Breath. A long, slow breath out, whenever it feels right.

[pause 8s]

Rest. Stillness between efforts, eyes closed, held in his care.

[pause 8s]

[warm, reassuring] You won't need all of these, and some may not help you at all. That's fine. You're free to try, and let go, and try again.

[pause 8s]

[gentle wonder] Your body has been seeking its own comforts all along, shifting to ease, resting when it's tired. God made it wonderfully responsive.

[pause 8s]

[tender] If you'd like, rest a hand on your belly.

[pause 6s]

[prayerful, sincere] Father of mercies, God of all comfort, thank you for every comfort you give. In the days ahead, surround me with your comfort, and show me what helps. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open.

[pause 3s]

All comfort, from the God who loves you.

[music 6s]

---

### Week 40 · Faith-centered

**Title:** I wait / *for* / the Lord.
**Description:** Five minutes of patient hope around your due date, waiting with God rather than alone.
**Approach:** reflection on Psalm 130, setting down impatience, and hopeful prayer.
**Scripture:** Psalm 130:5 (verbatim).

[music 6s]

[warm, lightly smiling] You may be hearing the same question often these days. Any news yet? Let's step away from all of that for a few minutes, and rest with God.

[pause 6s]

[calm] Find your most comfortable position. Let your breath slow down by itself.

[pause 6s]

[reverent] In Psalm 130, the psalmist describes what it's like to wait on God:

*I wait for the Lord. My soul waits. I hope in his word.*

[pause 10s]

[warm, reflective] Waiting is woven all through Scripture. Sarah, Hannah, Elizabeth, Mary. Each one waited, in her own way, for a child. Waiting is not empty time. It's time held in God's hands.

[pause 8s]

Think of Hannah, praying year after year at the temple. Or Elizabeth, rejoicing when her son was finally born. Their stories remind us that waiting and joy often belong together.

[pause 8s]

[warm, reassuring] A due date is an estimate, and the days around it may bring plans, appointments, and decisions. You can approach those responsibilities thoughtfully while also giving yourself permission to rest. For these few moments, bring your attention back to God's presence today.

[pause 8s]

[calm, soothing] Let your forehead smooth. Your jaw soften. Your shoulders drop. Let your hands rest open.

[pause 10s]

[warm] Rest these days, if you can. An afternoon nap. An early night. A slow walk in the fresh air. Let each one be a small act of trust.

[pause 8s]

[gentle wonder] Even in the waiting, so much is happening. Your body continues its remarkable preparation. Your baby continues to grow, held within you, in God's care.

[pause 8s]

[tender] If you'd like, rest a hand on your belly, and enjoy these last days of carrying your baby so close.

[pause 12s]

[gentle] Now bring your waiting to God. Your hopes, your impatience, your excitement. Tell him all of it, and let him hold it with you.

[pause 15s]

[prayerful, sincere] Lord, I wait with you. Thank you for the little life I carry and for the remarkable journey of this pregnancy. Give me patience, wisdom for the days ahead, and peace in your presence today. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open.

[pause 3s]

Waiting with hope, and not alone.

[music 6s]

---

### Week 41 · Faith-centered

**Title:** Rest, / *and* / wait.
**Description:** Five minutes to rest in God and savor these final days with your baby.
**Approach:** reflection on Psalm 37, gratitude for the journey, and resting patiently in God's care.
**Scripture:** Psalm 37:7 (verbatim excerpt: the first sentence).

[music 6s]

[reverent] In Psalm 37, David offers a simple invitation:

*Rest in the Lord, and wait patiently for him.*

[pause 10s]

[warm, unhurried] Let those words settle as you find a comfortable position, wherever your body feels most at ease. Let your breath slow down.

[pause 6s]

[warm, reflective] Rest, and wait. Not restless watching, but peaceful waiting. Settled in God's care, the way a child rests in a parent's arms.

[pause 8s]

[gentle wonder] Think back over this journey with God. The first moment you knew. The first flutter you felt. The prayers you've prayed. The ways your body has grown and carried your baby, week after week. All of it, held by him.

[pause 12s]

Thank him for anything that comes to mind.

[pause 12s]

[warm] Maybe you'd like to remember these days. A photo of your belly. A prayer written down for your baby to read one day. Small keepsakes from a once-in-a-lifetime season.

[pause 10s]

[tender] Now notice your baby, here with you. The roundness of your belly. The closeness. A whole person, knit together by God, and almost ready to meet you.

[pause 12s]

[warm] Even in these final days, there can be small moments worth appreciating. The warmth of your hand resting on your belly. The quiet connection you share with your little one. Whatever today feels like, you can simply pause and thank God for the remarkable life you're carrying.

[pause 8s]

[gentle wonder] Notice the warmth of your hands. The rise and fall of your breath. The quiet company of your baby. Simple gifts, each one from God.

[pause 10s]

[calm, soothing] Let your shoulders sink. Let your hands rest open. Rest in the Lord.

[pause 12s]

[tender] If you'd like, rest a hand on your belly, and pray a blessing over your baby, in your own words.

[pause 14s]

[prayerful, sincere] Lord, I rest in you, and I wait for you. Thank you for every day of this journey. Bless my baby, and be with us as we prepare to meet. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open.

[pause 3s]

Rest in him. Your waiting is in good hands.

[music 6s]

---

### Week 42 · Faith-centered

**Title:** This is / *the* / day.
**Description:** Five minutes to rejoice in today, give thanks for the whole journey, and welcome your baby in God's time.
**Approach:** reflection on Psalm 118, thanksgiving for the pregnancy, and a blessing of welcome.
**Scripture:** Psalm 118:24 (verbatim).

[music 6s]

[reverent, joyful] Psalm 118 is a song of thanksgiving, full of joy. In the middle of it, the psalmist says:

*This is the day that the Lord has made. We will rejoice and be glad in it!*

[pause 10s]

[warm, unhurried] Let those words settle as you find your most comfortable position. Let your breath slow down.

[pause 6s]

[warm, reflective] This is the day. Not only the day your baby arrives, but today. This ordinary, waiting, precious day, made by God, and full of his goodness.

[pause 8s]

[gentle wonder] Think of everything God has done through this pregnancy. From the very first weeks, when so much was hidden, to now. Your body growing, adapting, sheltering, carrying. A little life, knit together with care.

[pause 10s]

[tender] Every day of this pregnancy was a day the Lord made. The tired days and the joyful ones. The quiet ones and the busy ones. He was present in every one.

[pause 8s]

[gentle] Take a moment to give thanks. For your body. For your baby. For the people who've walked with you. For every day of this journey.

[pause 15s]

[warm, reassuring] As you prepare to welcome your baby, bring your hopes and the plans ahead into God's presence. Take a moment to appreciate the love you've been growing for this little one, and ask God to guide and care for you both.

[pause 8s]

[warm] Perhaps you imagine a quiet moment of closeness with your baby. A familiar voice, a gentle touch, or simply the tenderness of beginning to know one another. You can bring those hopes to God without needing to picture every detail.

[pause 8s]

[tender] If you'd like, rest a hand on your belly, and offer your baby a welcome. Something like: Whenever you arrive, you are so welcome here.

[pause 14s]

[calm, soothing] Let your shoulders sink. Let your hands rest open. Rest in his care.

[pause 10s]

[prayerful, sincere] Lord, this is the day you have made. Thank you for every day of this journey, and for the gift of this child. I trust you with the day we meet. Let us rejoice together in your goodness. Amen.

[pause 8s]

[warm] When you're ready, let your eyes open.

[pause 3s]

Rejoice in today. Your little one is already so loved.

[music 6s]
