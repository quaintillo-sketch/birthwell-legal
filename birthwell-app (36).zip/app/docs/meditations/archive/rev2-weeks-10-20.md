# Weekly meditations · Weeks 10–20 (draft for review)

**Narrator at launch:** Maren, for both Grounded and Faith-centered.

Same format as weeks 6–9:
- `[music 8s]` is music only, with the soundscape playing before Maren starts or after she finishes.
- `[pause 5s]` is a silence between thoughts, with the soundscape underneath.
- A blank line between paragraphs is a short natural breath (about 1 second).
- *Italic lines* in the Faith-centered scripts are Scripture from the World English Bible, with "Yahweh" shown as "the Lord". Each **Scripture** line says whether a passage is verbatim, a verbatim excerpt (part of a verse, words unchanged), or adapted. Adapted wording is never shown in italics as a quotation.
- The title has three parts. The middle part shows in italic clay in the app.

**Themes for weeks 10–20** (early pregnancy and connection):

| Week | Grounded | Faith-centered |
|---|---|---|
| 10 | Living one day at a time | Enough for today |
| 11 | Small, steady moments of calm | Stillness before God |
| 12 | Letting tension go | Pouring out your heart |
| 13 | Noticing small good things | Every good gift |
| 14 | Words for your baby | A blessing for your baby |
| 15 | Changing, and still yourself | Mercies new every morning |
| 16 | An evening wind-down | Rest for the beloved |
| 17 | The support around you | Never alone |
| 18 | Listening inward | Two mothers, and joy |
| 19 | A pause you can take anywhere | The one thing |
| 20 | Halfway: looking back and ahead | Helped until now |

---

## Week 10 · Grounded

**Title:** One / *day* / at a time.
**Description:** Five minutes to set down tomorrow's questions and come back to today.
**Approach:** noticing how far ahead the mind runs, gently returning to today, and finding three things that are steady right now.

[music 8s]

Hi. Let's take this one day, and this one moment, at a time.

Get comfortable in whatever way your body likes today. Let your hands rest wherever they land.

[pause 5s]

Your breath can do whatever it wants. You're just here to keep it company.

[pause 6s]

It's natural, in pregnancy, for the mind to race ahead. To the next appointment. The next test result. How you'll manage work, or sleep, or money, or everything else. Months of questions can fit into a single minute of worrying.

[pause 6s]

For now, let's notice where your mind has been travelling. You don't need to follow it. Just notice the direction.

[pause 10s]

Now imagine gently calling it home, the way you might call to someone who's wandered a little too far down the beach. No scolding. Just: *come back.*

[pause 8s]

Here is today. Only today.

[pause 6s]

Let's find three things that are steady, right now.

First, something supporting you. The chair, the bed, the floor. Notice it holding you without being asked.

[pause 8s]

Second, something you can hear. Maybe the music. Maybe a sound in the room, or outside.

[pause 8s]

Third, something about your own body that feels okay, even a little. Warm hands. Soft shoulders. A comfortable spot.

[pause 10s]

Three steady things. They were here all along, while your mind was busy elsewhere.

[pause 6s]

The questions about tomorrow will still be there later, and you'll meet them when they come, with whatever you know then. You don't have to answer them all today.

[pause 8s]

If you'd like, rest a hand on your belly. Today, you're both simply here.

[pause 15s]

Let yourself stay with today a little longer.

[pause 14s]

When you're ready, open your eyes, and notice one more steady thing around you.

[pause 4s]

Tomorrow can wait. For now, this day is enough.

[music 10s]

---

## Week 10 · Faith-centered

**Title:** Bread / *for* / today.
**Description:** Five minutes to trust God with tomorrow, and ask him for what you need today.
**Approach:** Jesus' teaching on tomorrow, honest prayer for today's needs, and quiet trust.
**Scripture:** Matthew 6:34 (verbatim excerpt: the first sentence); Matthew 6:11 (verbatim).

[music 8s]

Welcome. For the next few minutes, today is the only day you need to think about.

Settle in comfortably, and let your breath find its own easy pace.

[pause 6s]

It's natural, in pregnancy, for the mind to race ahead. The next appointment. Results you're waiting for. How everything will work out. It can feel like trying to carry months of tomorrows all at once.

[pause 6s]

Jesus knew how heavy that can be. In the Sermon on the Mount, he said:

*Therefore don't be anxious for tomorrow, for tomorrow will be anxious for itself.*

[pause 8s]

He wasn't scolding anyone for worrying. He was inviting them to put tomorrow down, and let God hold it.

[pause 6s]

In that same sermon, he taught his followers to pray, simply:

*Give us today our daily bread.*

[pause 8s]

Not bread for the whole year. Bread for today.

[pause 6s]

Long before, in the wilderness, God gave his people manna each morning. Just enough for each day. They couldn't store it up for the week ahead. They had to trust that tomorrow's would come with tomorrow.

[pause 8s]

What do you need for today? Rest? Patience? Strength for a hard conversation? A little more comfort in your body? Tell God, in your own words. Nothing is too small.

[pause 20s]

And if there's a tomorrow you've been carrying, an appointment, a decision, a fear, picture yourself placing it into his hands. It will still be there when its day comes. And so will he.

[pause 15s]

Father, thank you that I don't have to hold every tomorrow today. Give me what I need for this day, and help me trust you with the rest. Amen.

[pause 10s]

If you'd like, rest a hand on your belly, and simply be here, with God, today.

[pause 12s]

When you're ready, let your eyes open slowly.

[pause 3s]

Go into today with what you need for today.

[music 10s]

---

## Week 11 · Grounded

**Title:** Small / *and* / steady.
**Description:** Five minutes to find calm in an ordinary moment, the kind that's always within reach.
**Approach:** mindful listening, then noticing one ordinary comfort in close detail, like a warm drink in your hands.

[music 8s]

Let's begin with a few seconds of just listening.

[pause 8s]

Not trying to relax. Not trying to do anything. Just letting sounds arrive.

[pause 8s]

There's a kind of calm that doesn't need a quiet house, or a free afternoon, or everything going well. It's small, and it's steady, and it can be found inside an ordinary moment.

[pause 6s]

Let's find one.

If you have a warm drink nearby, you can hold it. If not, simply imagine one. A mug of tea, or warm milk, or anything that comforts you.

[pause 6s]

Feel the warmth spreading into your palms.

[pause 6s]

Notice the weight of the cup. The texture of it under your fingers.

[pause 6s]

If there's steam, imagine it rising slowly, and fading.

[pause 8s]

This is all it takes. One ordinary thing, noticed fully.

[pause 6s]

Notice the smell, if there is one. Notice the first small taste, if you take a sip. Let it be the only thing happening, just for a moment.

[pause 10s]

Now let your attention widen, just a little. To your hands. Your arms. Your shoulders, softening as you breathe out.

[pause 8s]

To your belly. Your baby is part of this moment too, growing quietly while you rest.

[pause 10s]

Most days aren't made of big peaceful hours. They're made of minutes. Waiting for the kettle. Sitting in the car before you go inside. Lying down for the first moment at night.

[pause 6s]

Any one of those minutes can become a small, steady place, if you let yourself notice it.

[pause 15s]

Stay here with your ordinary moment a little longer.

[pause 15s]

When you're ready, set down your cup, real or imagined, and let your eyes open.

[pause 4s]

Small, steady moments like this are always within reach. You know where to find one now.

[music 10s]

---

## Week 11 · Faith-centered

**Title:** Be / *still* / and know.
**Description:** Five minutes of quiet with one short verse, letting it slowly settle into stillness.
**Approach:** a slow, contemplative reading where the verse grows shorter with each repeat, with silence between.
**Scripture:** Psalm 46:10 (verbatim excerpt: the first sentence). The shorter repeats that follow are adapted from it and are not shown in italics.

[music 8s]

Welcome.

[pause 5s]

This meditation uses very few words, and a lot of quiet.

We'll stay with one short line from Psalm 46, and let it slowly settle, the way snow settles in a snow globe once you stop shaking it.

[pause 6s]

Find a comfortable way to sit or lie down. Let your hands rest open.

[pause 6s]

Psalm 46 was written for God's people in a time of upheaval. Nations in uproar, the earth itself shaking. And in the middle of it all, God says:

*Be still, and know that I am God.*

[pause 15s]

Let's say it again, a little shorter each time, and rest in the silence between.

Be still, and know that I am God.

[pause 15s]

Be still, and know.

[pause 15s]

Be still.

[pause 15s]

Be.

[pause 20s]

Stillness isn't the same as having no thoughts. It's more like resting. Letting God be God, while you simply stay near.

[pause 8s]

If your mind wanders, that's all right. Come back to whichever word feels like home.

[pause 12s]

In this season, so much is happening in you without any effort of your own. Your baby is growing even now, while you are still. That's a kind of trust too.

[pause 12s]

Lord, in all the busyness and change of this season, thank you for being God, so I don't have to be. Let me be still with you. Amen.

[pause 10s]

When you're ready, let your eyes open gently.

[pause 3s]

Stay in that stillness as long as you'd like. It's yours to come back to.

[music 10s]

---

## Week 12 · Grounded

**Title:** Letting / *it* / go.
**Description:** Five minutes to release the tension your body has been quietly holding.
**Approach:** gentle, optional tense-and-release through the hands, shoulders, and face, then letting the mind loosen too.

[music 8s]

Start by noticing your hands. Where are they resting? Are they open, or curled? Soft, or holding on?

[pause 6s]

Many of us carry tension without realizing it. In our hands, our shoulders, our faces. Today, let's gently let some of it go.

Settle in comfortably first.

[pause 6s]

We'll start with your hands. If it feels good, make a soft fist. Not tight. Just enough to notice the effort.

[pause 4s]

And let it go. Let your fingers uncurl and fall open.

[pause 8s]

Notice the difference. The tingling, or the warmth, or the heaviness after letting go.

[pause 6s]

Now your shoulders. If it's comfortable, lift them gently toward your ears.

[pause 4s]

And let them drop.

[pause 8s]

Let them keep sinking, a little more with each breath out.

[pause 8s]

Now your face. Scrunch it gently, if you like. Eyes, nose, mouth, all pulling toward the center.

[pause 3s]

And release. Let your forehead go smooth. Let your jaw hang loose.

[pause 10s]

Your body knows how to let go. It just sometimes needs reminding.

[pause 6s]

Let's go once through your whole body, without tensing this time. Just a soft wave of letting go, from the top of your head, down through your shoulders, your arms, your back, your legs, all the way to your feet.

[pause 10s]

Now let your mind follow. Is there something you've been holding tightly, a worry, a plan, an expectation? You don't need to solve it. Just imagine your grip on it softening, the way your hands did.

[pause 15s]

If you'd like, rest your open hand on your belly. No effort. Just warmth.

[pause 12s]

Stay soft. There's nothing you need to hold right now.

[pause 15s]

When you're ready, let some gentle movement come back, and slowly open your eyes.

[pause 4s]

Whatever you let go of, let it stay down for a while.

[music 10s]

---

## Week 12 · Faith-centered

**Title:** Pour out / *your* / heart.
**Description:** Five minutes to tell God what's heavy, and release your grip as you hand it to him.
**Approach:** honest prayer paired with gently letting go in the hands and shoulders.
**Scripture:** Psalm 62:8 (verbatim excerpt: the second and third sentences); Psalm 55:22 (verbatim excerpt: the first sentence).

[music 8s]

What feels heavy today?

[pause 6s]

You don't have to answer right away. Just let the question rest with you as you settle in.

[pause 6s]

Find a comfortable position, and let your breath come and go in its own time.

[pause 6s]

The psalms are full of honest prayers. People telling God exactly how they felt, the fears, the frustrations, the hopes. In Psalm 62, David writes:

*Pour out your heart before him. God is a refuge for us.*

[pause 8s]

Not "tidy up your heart first." Pour it out.

[pause 6s]

A refuge is a safe place to run to when things feel like too much. Not a place you have to be strong to enter. A place you go because you need it.

[pause 8s]

So let's do that. Notice your hands. If they're curled or tense, let them open slowly, palms up, as if you were holding something out to God.

[pause 8s]

Now tell him what's heavy. Whatever comes. You don't need the right words.

[pause 20s]

As you finish, let your shoulders drop. Let your jaw soften. Let your body follow your heart in letting go.

[pause 8s]

Another psalm says:

*Cast your burden on the Lord and he will sustain you.*

[pause 8s]

That doesn't mean every burden disappears. It means you don't carry it alone. He holds you up while you carry it.

[pause 8s]

Lord, thank you for listening to all of it, the big things and the small. I'm placing these in your hands. Hold me up today. Amen.

[pause 10s]

If you'd like, rest your open hand on your belly, and let your hands stay soft.

[pause 12s]

When you're ready, let your eyes open.

[pause 3s]

Walk a little lighter today, knowing he holds what you've given him.

[music 10s]

---

## Week 13 · Grounded

**Title:** Small / *good* / things.
**Description:** Five minutes to notice what's been quietly good, even on an ordinary or difficult day.
**Approach:** three small moments recalled in detail, then letting them warm the body, without any pressure to feel positive.

[music 8s]

Think of one small thing from the last day or so that was good. It doesn't need to be big. A warm shower. A kind text. The first sip of something cold.

[pause 8s]

Hold that thought, and let yourself get comfortable.

[pause 6s]

This meditation is about noticing good things. Not because everything is good. Some days in pregnancy are hard, and that's real. But even hard days can hold small moments worth noticing.

[pause 6s]

Let's go back to that first good thing. Picture it clearly. Where were you? What did it feel like? Let yourself enjoy it again, just for a moment.

[pause 12s]

Now let a second one come to mind. Maybe something someone said. Maybe something you saw. Light through a window. A song. A laugh.

[pause 12s]

And a third. Maybe something your body did well. A good night's sleep, a meal that sat right, a walk that felt easy.

[pause 12s]

If it's hard to find three today, that's all right. One is enough. Even making space for these few minutes is a small good thing.

[pause 8s]

Three small good things. Notice where you feel them in your body. Maybe a softening in your chest. A little warmth. Or maybe nothing much, and that's fine too.

[pause 10s]

If you'd like, rest a hand on your belly. Your baby is part of your days now, even the ordinary ones.

[pause 12s]

Small good things are easy to miss. They don't announce themselves. But they add up, quietly, the way the days of this pregnancy are adding up.

[pause 15s]

Stay here a moment longer with whatever good you found.

[pause 12s]

When you're ready, let your eyes open.

[pause 4s]

May you notice a few more small good things before the day is done.

[music 10s]

---

## Week 13 · Faith-centered

**Title:** Every / *good* / gift.
**Description:** Five minutes to recognize God's goodness in the small gifts of your days.
**Approach:** recalling small gifts one by one, thanking God for each, and making room for days when thankfulness is hard.
**Scripture:** James 1:17 (verbatim excerpt: the first part of the verse).

[music 8s]

James, writing to the early church, said this:

*Every good gift and every perfect gift is from above, coming down from the Father of lights.*

[pause 8s]

Let those words settle as you find a comfortable position.

[pause 6s]

Every good gift. Not only the big ones. The small, everyday ones too.

[pause 6s]

James calls God the Father of lights. The one who made the sun and the stars, and who still notices the smallest good thing in your day.

[pause 8s]

Let's look for some. Think back over the last day or so. What was one good thing, however small? A warm meal. A kind word. A quiet moment. Picture it clearly.

[pause 10s]

Now simply say, in your heart: Thank you.

[pause 8s]

Let a second gift come to mind. Maybe a person. Someone who helped, or listened, or made you laugh.

[pause 10s]

Thank you.

[pause 8s]

And a third. Perhaps something about this pregnancy. Or perhaps just that you're here, breathing, right now.

[pause 10s]

Thank you.

[pause 8s]

If thankfulness feels hard today, that's all right. God isn't asking you to pretend everything is easy. You can tell him that too. Gratitude and honesty can sit side by side.

[pause 12s]

Now take a moment to talk with God about the gifts you noticed, or about anything else on your heart.

[pause 18s]

Father of lights, every good thing in my life comes from you. Thank you for the small gifts I so often miss, and for the gift of this little one. Open my eyes to your goodness today, even in ordinary moments. Amen.

[pause 10s]

When you're ready, let your eyes open slowly.

[pause 3s]

Watch for his good gifts today. They're often closer than we think.

[music 10s]

---

## Week 14 · Grounded

**Title:** A few / *words* / for you.
**Description:** Five minutes to speak to your baby, silently or out loud, in whatever way feels natural.
**Approach:** a guided first conversation with the baby, with no pressure on how it feels.

[music 8s]

This meditation is a little different. Today, you're invited to talk to your baby.

If that feels natural, wonderful. If it feels strange, or awkward, or a bit too soon, that's completely okay. You can just listen along, and try it whenever you're ready.

[pause 6s]

Find a comfortable position. If you'd like, rest one or both hands on your belly.

[pause 6s]

Let your breath settle in its own time.

[pause 8s]

Your baby is growing in a warm, dark, cushioned world, gently rocked as you move.

[pause 6s]

Some people find it meaningful to start talking to their baby early, long before they meet. A voice, a few words, a habit that can grow over the months ahead.

[pause 6s]

Imagine, for a moment, what this little one might want to know about you.

[pause 8s]

You might start simply. Silently, or in a whisper: *Hello. It's me.*

[pause 10s]

You could tell your baby something about your day. Where you are right now. What you can hear.

[pause 15s]

You could tell them something about yourself. Something you love. Something you're looking forward to.

[pause 15s]

Maybe a place you'd like to show them one day. A song you might sing. Something you hope you'll do together.

[pause 12s]

And if there's something you're feeling, hope, or nervousness, or wonder, you can say that too. There's no wrong thing to say.

[pause 15s]

Or you can say nothing at all, and simply be together in the quiet.

[pause 12s]

Whatever you said, or didn't say, this is how relationships begin. A little at a time.

[pause 12s]

When you're ready, let your hands rest, and slowly open your eyes.

[pause 4s]

You can pick up this conversation any time. There's no rush to it.

[music 10s]

---

## Week 14 · Faith-centered

**Title:** A blessing / *for* / the little one.
**Description:** Five minutes to pray an ancient blessing over your baby, and receive it for yourself too.
**Approach:** praying the priestly blessing slowly, line by line, over the baby, then personally.
**Scripture:** Numbers 6:24–26 (verbatim).

[music 8s]

Welcome. Today we'll pray a blessing over your baby. One of the oldest blessings in Scripture.

Settle in, and if you'd like, rest your hands on your belly.

[pause 6s]

Let your breath slow in its own time.

[pause 6s]

In the book of Numbers, God gave Moses these words for Aaron and the priests to speak over his people. People have prayed them over children for thousands of years.

Listen to them once through:

*The Lord bless you, and keep you. The Lord make his face to shine on you, and be gracious to you. The Lord lift up his face toward you, and give you peace.*

[pause 10s]

A blessing isn't a guarantee of an easy road. It's an asking. Placing someone you love into God's care.

[pause 6s]

Notice the shape of it. Blessing. Keeping. His face shining toward you, the way a parent's face lights up when their child walks into the room. Grace. Peace.

[pause 8s]

Let's pray it slowly over your baby now, line by line. You can echo the words silently, or simply listen.

The Lord bless you, and keep you.

[pause 10s]

The Lord make his face to shine on you, and be gracious to you.

[pause 10s]

The Lord lift up his face toward you, and give you peace.

[pause 12s]

Now take a moment to pray for your baby in your own words. Whatever hopes are in your heart. Perhaps that they'll know they're loved. That they'll have courage, and kindness, and people around them.

[pause 20s]

And this blessing is for you too. Let it rest on you, as a mother, in this season.

[pause 6s]

Lord, bless me and keep me. Let your face shine on me. Give me your peace. Amen.

[pause 10s]

When you're ready, let your eyes open slowly.

[pause 3s]

Go in his peace, both of you.

[music 10s]

---

## Week 15 · Grounded

**Title:** Still / *you* / and growing.
**Description:** Five minutes to honor how you're changing, and everything about you that remains.
**Approach:** a gentle visualization of who you were before, who you are now, and the self that carries through.

[music 8s]

Picture yourself a year or so ago. Before this pregnancy. What did an ordinary day look like? What did you care about? What made you laugh?

[pause 10s]

Hold that picture gently as you settle into a comfortable position.

[pause 6s]

Pregnancy changes so much. Your body. Your energy. Your plans. Sometimes, how other people see you. It's natural to wonder how much of you is changing too.

[pause 6s]

Let's take a moment with that.

Bring to mind something you've always loved. A place, a song, a food, a kind of weather.

[pause 10s]

That's still you.

[pause 6s]

Bring to mind something you're good at. Something people come to you for.

[pause 10s]

Still you.

[pause 6s]

Bring to mind a way you've grown in the last few months. Something you've learned, or carried, or handled, that you didn't know you could.

[pause 10s]

That's you too. Growing.

[pause 8s]

Think of a tree. Each year it adds a new ring, and grows a little wider and taller. But the heart of it doesn't disappear. Every year is still inside it.

[pause 10s]

Some days you might miss parts of your old life. The freedom, the energy, the body you knew. That isn't ingratitude. It's a natural part of a big change, and those feelings deserve gentleness too.

[pause 8s]

You're becoming a mother, or a mother again, and you're still the person in that picture from a year ago. Both are true.

[pause 8s]

If you'd like, rest a hand on your belly. Your baby will come to know the person you've always been, as well as who you're becoming.

[pause 15s]

When you're ready, let your eyes open slowly.

[pause 4s]

You're still you. And you're growing too.

[music 10s]

---

## Week 15 · Faith-centered

**Title:** New / *every* / morning.
**Description:** Five minutes to rest in God's unchanging faithfulness while so much in you is changing.
**Approach:** reflecting on change and constancy, with God's mercies as the steady center, and a quiet prayer of trust.
**Scripture:** Lamentations 3:22–23 (verbatim excerpt: from "his compassion" to the end of verse 23).

[music 8s]

Imagine the early light of morning. The first gray glow at the window. The world quiet, before the day begins.

[pause 8s]

Let that quiet be with you as you settle in.

[pause 6s]

So much is changing right now. Your body. Your energy. Your plans, maybe even how you see yourself. Some changes might feel exciting. Others might feel unsettling. Probably both.

[pause 8s]

In the book of Lamentations, written in a time of great loss and upheaval, there's a moment of surprising hope. The writer says of God:

*his compassion doesn't fail. They are new every morning. Great is your faithfulness.*

[pause 10s]

Everything around the writer had changed. But God's compassion hadn't. It met the writer again, new, each morning.

[pause 8s]

New every morning. Not leftover from yesterday. Not rationed out. On the mornings when you wake up tired, or queasy, or anxious, his compassion is already there.

[pause 8s]

What feels most changed in your life right now? Bring it to God, honestly.

[pause 15s]

Now, what do you need to stay steady? Patience? Comfort? A reminder of who you are in him? Ask him for it.

[pause 15s]

Some things about you won't change at all. You are still his. Still loved. Still known, through every season of this pregnancy, and every season after.

[pause 10s]

If you'd like, rest a hand on your belly. You and your baby are both changing every day, and both held by the same faithful God.

[pause 12s]

Lord, so much in me is changing. Thank you that your love doesn't change. Meet me with your compassion each morning, and help me trust you through every new thing. Amen.

[pause 10s]

When you're ready, let your eyes open.

[pause 3s]

His compassion will meet you new, every morning.

[music 10s]

---

## Week 16 · Grounded

**Title:** Into / *a softer* / evening.
**Description:** Five minutes to wind down your body and mind, for the end of the day or whenever you need rest.
**Approach:** an evening wind-down that dims the senses one by one and lets the day go, with a longer quiet ending.

[music 8s]

If it's evening, you might dim the lights, or turn them off altogether. If it's daytime, that's okay too. Let this be a small evening, wherever you are.

[pause 6s]

Find the most comfortable position you can. On your side, with a pillow between your knees, is often lovely at this stage. Use whatever support you have.

[pause 8s]

Let your breath slow down by itself. There's nowhere to be.

[pause 8s]

Let's let the day go, one piece at a time.

First, let your eyes rest. Let them grow heavy behind your eyelids.

[pause 6s]

Let your ears soften, so sounds become just a gentle background.

[pause 6s]

Let your jaw loosen, and your tongue rest at the bottom of your mouth.

[pause 6s]

Let your hands lie heavy and open.

[pause 8s]

Now think back over today, without judging any of it. The things that went well. The things that didn't. The things left undone.

[pause 8s]

Imagine each one as a lamp in a long hallway. One by one, you walk past them, turning each lamp down.

[pause 12s]

Notice the hallway growing softer and dimmer. Quieter. Your footsteps slowing. At the end of it, there's a warm, dark room, with a bed made up just for you.

[pause 10s]

The day is finished, or nearly. Whatever is left can wait until morning.

[pause 8s]

If you'd like, rest a hand on your belly. Let yourself feel the warmth there as you both settle.

[pause 15s]

Stay here. Let your body grow heavier and softer.

[pause 20s]

If you're drifting toward sleep, let yourself go. If not, simply enjoy the quiet.

[pause 6s]

Goodnight, or good rest, whichever you need.

[music 12s]

---

## Week 16 · Faith-centered

**Title:** Sleep / *for* / the beloved.
**Description:** Five minutes to lay down the day and rest in God's love, for evenings or any time you're weary.
**Approach:** handing the day over to God, piece by piece, then resting in his love, with a long quiet ending.
**Scripture:** Psalm 127:2 (verbatim excerpt: the end of the verse); Zephaniah 3:17 (verbatim excerpt: the third and fourth sentences).

[music 8s]

There's a line at the end of Psalm 127 that says:

*for he gives sleep to his loved ones.*

[pause 8s]

Sleep, and rest, as a gift. Not something you have to earn by finishing everything first.

[pause 6s]

If it's evening, you might dim the lights. If it's daytime, let this be a small evening wherever you are. Find the most comfortable position you can, with whatever pillows or support you need.

[pause 8s]

Let your breath slow down by itself.

[pause 6s]

Let's give the day to God, one piece at a time.

What went well today? Thank him for it.

[pause 12s]

What was hard? Tell him about it, and leave it with him.

[pause 12s]

What's left undone? Let it wait. It's in his hands until morning.

[pause 12s]

Now listen to these words, spoken by the prophet Zephaniah to God's people:

*He will calm you in his love. He will rejoice over you with singing.*

[pause 10s]

Imagine being sung over. Calmed. The way you might one day sing over your own child.

[pause 10s]

Not because you've earned it, or finished your list, or handled today perfectly. Simply because you are his, and he delights in you.

[pause 8s]

If you'd like, rest a hand on your belly. You are both held in his love tonight.

[pause 12s]

Let your shoulders sink into the pillow. Let your hands rest open, like a child asleep.

[pause 8s]

Lord, I give you this day. Calm me in your love, and give me the rest I need. Amen.

[pause 20s]

If you're drifting toward sleep, let yourself go. If not, rest here in his care.

[pause 6s]

Rest well, beloved.

[music 12s]

---

## Week 17 · Grounded

**Title:** Held / *by* / many hands.
**Description:** Five minutes to notice the support around you, whatever shape it takes.
**Approach:** noticing physical support first, then the people and places that help, with room for those who feel short on support.

[music 8s]

Let's begin by noticing what's holding you up, right now. Literally.

The surface beneath you. The pillow behind your head, or the chair at your back. Let yourself lean into it.

[pause 8s]

You don't have to hold yourself up. Something is already doing it for you.

[pause 8s]

Support comes in many shapes. Some people have a partner, a family, a close circle of friends. Some have one or two people. Some are doing a lot of this on their own. Wherever you are, this meditation is for you.

[pause 6s]

Let's notice the support that's there, even in small ways.

Bring to mind a person who's been kind to you during this pregnancy. It might be someone close. It might be a nurse, a coworker, a neighbor, a stranger who held a door.

[pause 12s]

Picture their face, if you can. Notice how it feels to remember their kindness.

[pause 10s]

Now think of a place that helps you feel supported. A favorite room. A walk you love. A spot where you can breathe more easily.

[pause 12s]

And think of something that supports you that isn't a person or a place. A routine. A song. A favorite blanket. Even this quiet moment.

[pause 12s]

And notice the ways you support yourself, too. Resting when you need to. Eating when you're hungry. Choosing to spend these minutes here. That's support as well.

[pause 8s]

If support feels thin right now, that's important to notice too. It's okay to want more help, and it's okay to ask for it. Needing support isn't a weakness. It's part of being human, especially now.

[pause 10s]

If you'd like, rest a hand on your belly. Your baby is being held too, every moment, by you.

[pause 15s]

When you're ready, let your eyes open slowly.

[pause 4s]

You don't have to do this all by yourself. Let yourself be held, in whatever ways you can.

[music 10s]

---

## Week 17 · Faith-centered

**Title:** Never / *left* / alone.
**Description:** Five minutes to rest in God's promise never to leave you, and see his care through others.
**Approach:** God's presence first, then the people he places around us, with room for those who feel alone.
**Scripture:** Hebrews 13:5 (verbatim excerpt: the words quoted as God's, at the end of the verse); Galatians 6:2 (verbatim).

[music 8s]

Welcome. Wherever you're listening from, and whoever is or isn't beside you right now, you're not alone in this moment.

Find a comfortable position, and let yourself lean into whatever is supporting you.

[pause 8s]

The letter to the Hebrews reminds its readers of something God has said:

*I will in no way leave you, neither will I in any way forsake you.*

[pause 10s]

In no way. Not in the hard moments. Not in the uncertain ones. Not when you feel strong, and not when you feel weak.

[pause 8s]

This letter was written to people who were struggling. Some had lost their possessions. Some felt forgotten. And God's answer to them wasn't a list of instructions. It was his presence.

[pause 8s]

Take a moment to rest in his presence. You don't need to feel anything particular. Just know he's here.

[pause 15s]

God often shows his care through people. Paul wrote to the churches in Galatia:

*Bear one another's burdens, and so fulfill the law of Christ.*

[pause 8s]

Sometimes God answers our prayers for help through other people's hands and voices. A meal dropped off. A message at just the right moment. Someone who simply sits with us.

[pause 8s]

Bring to mind someone who has helped carry your burdens lately. A partner, a friend, a family member, a nurse, someone at church, someone unexpected. Thank God for them.

[pause 15s]

If support feels thin right now, tell God about that too. Ask him for the help you need. It's okay to ask.

[pause 15s]

If you'd like, rest a hand on your belly.

[pause 6s]

Lord, thank you that you never leave me. Thank you for the people who carry my burdens with me. Where I feel alone, draw near, and bring the help I need. Amen.

[pause 10s]

When you're ready, let your eyes open slowly.

[pause 3s]

He goes with you into the rest of today.

[music 10s]

---

## Week 18 · Grounded

**Title:** Listening / *for* / you.
**Description:** Five minutes of quiet attention inward, wherever you are in getting to know your baby.
**Approach:** turning attention inward like listening to the sea, with no expectation of feeling movement.

[music 8s]

Let's get quiet enough to listen inward.

Find a comfortable position. Lying on your side, or sitting reclined, often makes it easier to notice what's happening inside.

[pause 8s]

Let the sounds of the room fade into the background, like distant waves.

[pause 8s]

Somewhere in these weeks, some people begin to notice tiny movements. Flutters, taps, little bubbles. For others, it takes longer. Every pregnancy has its own timing, and there's no right moment for this.

[pause 6s]

Today isn't about feeling anything in particular. It's simply about paying attention, the way you might sit by the sea and listen.

[pause 8s]

Rest your hands on your belly, if you'd like. Let them be still and soft.

[pause 8s]

Now bring your attention down to where your hands are resting. Notice warmth. Notice the slow rise and fall of your breath.

[pause 12s]

Notice the stillness, too. Stillness is part of listening.

[pause 12s]

Your baby lives surrounded by your rhythms. Your heartbeat. Your breathing. The movement of your body through the day. In their own way, they're getting to know you too.

[pause 10s]

If you feel something, a flutter, a nudge, a little rolling sensation, you can greet it, silently. *Hi. I'm here.*

[pause 10s]

And if you don't feel anything, that's perfectly okay. Your baby is growing in their own quiet way, and you're still getting to know each other.

[pause 12s]

Let yourself simply stay here, listening, with nothing to achieve.

[pause 20s]

Over the coming weeks, quiet moments like this may become some of your favorite times together.

[pause 8s]

When you're ready, let your attention widen again to the room around you, and slowly open your eyes.

[pause 4s]

Whenever you feel it, or don't yet, you're already getting to know each other.

[music 10s]

---

## Week 18 · Faith-centered

**Title:** A greeting / *of* / joy.
**Description:** Five minutes with Mary and Elizabeth, two expectant mothers who shared their joy and their waiting.
**Approach:** imaginative reflection on the visitation, then praying for companionship and joy, with no expectation of feeling movement.
**Scripture:** Luke 1:39–45 (the story retold in Maren's own words); Luke 1:41 (verbatim excerpt: the first part of the verse); Luke 1:44 (verbatim).

[music 8s]

Long ago, two expectant mothers met in a house in the hill country of Judah.

Find a comfortable position as we step into their story.

[pause 6s]

Mary was young, and newly pregnant, carrying news she was still trying to understand. She hurried to visit her relative, Elizabeth, who was also expecting, after years of waiting.

[pause 6s]

Imagine Mary arriving at the door, tired from her journey. Imagine Elizabeth hearing her voice.

Luke tells us:

*When Elizabeth heard Mary's greeting, the baby leaped in her womb.*

[pause 8s]

And Elizabeth said to her:

*For behold, when the voice of your greeting came into my ears, the baby leaped in my womb for joy!*

[pause 10s]

Two women, both carrying new life. Sharing their joy, and their questions, and staying together for months.

[pause 8s]

Imagine the conversations they might have had. Talking about what their bodies were going through. Wondering together about the children they would hold. Laughing, maybe. Praising God, as Mary did.

[pause 10s]

Some people begin to feel small movements around this time, and others not for a while yet. This story isn't about a timeline. It's about joy shared, and about not waiting alone.

[pause 8s]

If you'd like, rest your hands on your belly. Simply be with your baby, whatever you feel or don't feel.

[pause 12s]

Elizabeth's joy began with a greeting. Imagine greeting your baby now, in your heart. A simple hello, full of love.

[pause 12s]

Who is an Elizabeth for you? Someone you can share this season with? Thank God for them. Or, if you're longing for someone like that, ask him for it.

[pause 15s]

Lord, thank you for the joy of new life, and for the people who share it with me. Let joy find its way into my heart, even in the waiting. Amen.

[pause 10s]

When you're ready, let your eyes open slowly.

[pause 3s]

May you find small joys to share today.

[music 10s]

---

## Week 19 · Grounded

**Title:** The pause / *between* / things.
**Description:** Five minutes to learn a one-minute pause you can carry into any busy day.
**Approach:** a short, practical practice, rehearsed twice, for using between tasks.

[music 8s]

Some days feel like one long list. Work, errands, appointments, meals, messages, and somewhere in there, growing a baby.

[pause 6s]

Today, let's practice a small pause you can take anywhere. Between meetings. In a parking lot. While the kettle boils. It takes about a minute.

Let yourself settle first.

[pause 8s]

Here's how it goes. There are just three steps.

First: stop. Let your hands go still, wherever they are.

[pause 6s]

Second: feel your feet. Notice where they touch the floor, or the bed, or each other.

[pause 8s]

Third: let one breath out be a little longer and softer than the rest. Not forced. Just unhurried.

[pause 8s]

That's it. Stop. Feet. One soft breath out.

[pause 10s]

It's small on purpose. Small enough to remember on a hard day. Small enough to do with a phone in your hand, or a toddler on your hip, or in a waiting room before an appointment.

[pause 6s]

Let's practice it once more, slowly.

Stop. Let everything go still.

[pause 6s]

Feet. Feel them, heavy and grounded.

[pause 8s]

One soft breath out.

[pause 10s]

Notice how you feel now. Maybe a little more here. Maybe just the same. Either is fine.

[pause 8s]

Over time, your body may start to remember this pause on its own. Your hands going still. Your feet finding the floor.

[pause 8s]

If you'd like, add a fourth step whenever you have a moment: a hand on your belly, as a small hello to your baby in the middle of your day.

[pause 12s]

These pauses won't make a busy day less busy. But they can give you small places to land, in between all the things.

[pause 15s]

When you're ready, let your eyes open.

[pause 4s]

This pause is yours. It fits into any part of your day.

[music 10s]

---

## Week 19 · Faith-centered

**Title:** The / *one* / thing.
**Description:** Five minutes to sit at Jesus' feet in the middle of a busy season.
**Approach:** imaginative reflection on Mary and Martha, with gentle permission to stop, and quiet time with Jesus.
**Scripture:** Luke 10:38–42 (the story retold in Maren's own words); Luke 10:41–42 (verbatim excerpt: Jesus' words, from "you are anxious" to "one thing is needed").

[music 8s]

Before we begin, notice how full your mind feels right now. Crowded? Quiet? Somewhere in between?

[pause 6s]

Whatever is there, let it wait a few minutes. Settle in, and let your body rest.

[pause 6s]

In Luke's Gospel, Jesus visits the home of two sisters, Martha and Mary. Martha is busy getting everything ready. Mary sits at Jesus' feet, listening.

[pause 6s]

Martha, worn out, asks Jesus to tell her sister to help. And Jesus answers her, gently:

*Martha, Martha, you are anxious and troubled about many things, but one thing is needed.*

[pause 10s]

Notice that he says her name twice. Kindly. He isn't scolding her for caring, or for working hard. He's inviting her to stop for a moment, and be with him.

[pause 8s]

Martha's work mattered. Someone had to make the meal. But in that moment, Jesus himself was sitting in her home, and she was missing time with him.

[pause 8s]

Imagine Jesus saying your name the same way. Kindly. Twice.

[pause 10s]

What are the many things you're anxious and troubled about right now? You can name them to him.

[pause 15s]

Now imagine setting them down, just for these few minutes, and sitting at his feet. There's nothing to prepare. Nothing to prove. Just be with him.

[pause 20s]

If you'd like, rest a hand on your belly. Your baby is here with you, in this quiet place.

[pause 10s]

Jesus, my days are full, and my mind is busier still. Thank you for inviting me to sit with you. Help me find my way back to you, even in the middle of everything. Amen.

[pause 10s]

When you're ready, let your eyes open slowly.

[pause 3s]

Sit at his feet whenever you can, even for a moment in a busy day.

[music 10s]

---

## Week 20 · Grounded

**Title:** Halfway, / *and* / here.
**Description:** Five minutes to look back on how far you've come, and ahead with openness.
**Approach:** a reflective look back over the weeks so far, then looking ahead with curiosity rather than pressure.

[music 8s]

Wherever you are in your pregnancy, you've likely reached somewhere around the middle. A good place to pause, and look around.

Find a comfortable position, and let yourself settle.

[pause 8s]

Let's look back first.

Think of the day you found out you were pregnant. Where were you? What did you feel?

[pause 12s]

Whatever you felt then, joy, shock, fear, all of it, it was a real beginning.

[pause 6s]

Now think of one thing that's been hard since then. Something you've carried, or handled, or simply gotten through.

[pause 12s]

You got through it. Notice that.

[pause 6s]

And think of one moment you'd like to remember from these weeks. A small one is fine.

[pause 12s]

That's part of your story now.

[pause 6s]

Think of someone, or something, that helped you get here. A person who listened. A routine that steadied you. Even your own quiet determination to keep going.

[pause 10s]

Now let's turn, gently, toward what's ahead.

You don't need to plan it all, or know how it will go. Just notice what you feel when you think about the months to come. Curiosity? Nerves? Hope? A mix?

[pause 12s]

Whatever's there, you'll meet the coming weeks the same way you've met these ones. One day at a time, learning as you go.

[pause 8s]

There will be new things to learn. New changes in your body, new decisions, new feelings. You don't have to be ready for all of them today. Only for the next small step.

[pause 10s]

If you'd like, rest a hand on your belly, and let your baby share this moment of looking back and looking ahead.

[pause 15s]

When you're ready, let your eyes open slowly.

[pause 4s]

Wherever the road goes from here, you can meet it as you are.

[music 10s]

---

## Week 20 · Faith-centered

**Title:** Helped / *until* / now.
**Description:** Five minutes to remember God's faithfulness so far, and trust him with the road ahead.
**Approach:** setting up a "stone of help" in remembrance, giving thanks for the past, and entrusting the future to God.
**Scripture:** 1 Samuel 7:12 (verbatim excerpt: Samuel's words at the end of the verse); Deuteronomy 31:8 (verbatim excerpt: the first three sentences).

[music 8s]

In the book of First Samuel, after a hard-won season, the prophet Samuel set up a large stone as a marker. He named it Ebenezer, which means "stone of help," saying:

*the Lord helped us until now.*

[pause 10s]

Samuel's stone wasn't a sign that every hard time was over. It was a way to remember, before the next season began, that God had been faithful.

[pause 8s]

Let's set up a small Ebenezer of your own today.

Find a comfortable position, and let yourself settle.

[pause 8s]

Look back over these weeks of pregnancy. Where have you seen God's help? Maybe in a person. A kind word. A hard day you made it through. Strength you didn't know you had.

[pause 15s]

Thank him for each one, in your own words.

[pause 15s]

Now imagine placing a stone, right here, in this moment. A marker that says: God has helped me until now.

[pause 10s]

Now look ahead. The coming months may hold joy, and challenge, and things you can't yet imagine.

Moses spoke these words to Joshua and the people of Israel, as they faced a new and uncertain land:

*The Lord himself is who goes before you. He will be with you. He will not fail you nor forsake you.*

[pause 10s]

He doesn't promise that the road will be easy. He promises to be with you on it.

[pause 8s]

What feels uncertain about the months ahead? Name it to him. And picture him already there, going before you into each of those places.

[pause 12s]

If you'd like, rest a hand on your belly.

[pause 6s]

Lord, thank you for helping me until now. I trust you with what's ahead. Go before me, and stay with me, every step of the way. Amen.

[pause 10s]

When you're ready, let your eyes open slowly.

[pause 3s]

The God who has helped you until now is with you still.

[music 10s]

---

## Lengths (estimates)

Same method as weeks 6–9: about 120 spoken words a minute, half a second between sentences and a second between paragraphs, plus every pause and music-only section.

| Week | Version | Spoken words | Finished length | Spoken characters |
|---|---|---|---|---|
| 10 | Grounded | 284 | 5:02 | 1,607 |
| 10 | Faith-centered | 298 | 5:00 | 1,615 |
| 11 | Grounded | 278 | 5:05 | 1,511 |
| 11 | Faith-centered | 235 | 4:59 | 1,211 |
| 12 | Grounded | 285 | 5:15 | 1,567 |
| 12 | Faith-centered | 271 | 4:55 | 1,420 |
| 13 | Grounded | 278 | 5:00 | 1,485 |
| 13 | Faith-centered | 267 | 5:02 | 1,443 |
| 14 | Grounded | 269 | 5:11 | 1,480 |
| 14 | Faith-centered | 289 | 4:56 | 1,506 |
| 15 | Grounded | 264 | 4:54 | 1,443 |
| 15 | Faith-centered | 276 | 4:56 | 1,553 |
| 16 | Grounded | 255 | 4:59 | 1,383 |
| 16 | Faith-centered | 254 | 5:10 | 1,335 |
| 17 | Grounded | 301 | 5:01 | 1,627 |
| 17 | Faith-centered | 299 | 5:07 | 1,631 |
| 18 | Grounded | 274 | 5:04 | 1,604 |
| 18 | Faith-centered | 303 | 5:02 | 1,704 |
| 19 | Grounded | 277 | 5:10 | 1,489 |
| 19 | Faith-centered | 276 | 4:52 | 1,488 |
| 20 | Grounded | 277 | 5:03 | 1,503 |
| 20 | Faith-centered | 298 | 5:06 | 1,554 |

Across all 30 scripts so far (weeks 6–20), the average is 1,563 spoken characters. Projected over 74 meditations, that's about 116,000 spoken characters, or about 143,000 ElevenLabs credits once tone tags and a 20% allowance for re-recording are included.
