# Weekly meditations · Weeks 6–9 (approved, with final refinements)

**Narrator at launch:** Maren, for both Grounded and Faith-centered. The scripts don't depend on a particular voice, so more narrators can be added later without rewriting anything.

How to read the scripts:
- `[music 8s]` is music only: Maren hasn't started yet, or has finished, and the soundscape plays on its own.
- `[pause 5s]` is a silence of that many seconds between thoughts, with the soundscape playing underneath.
- A blank line between paragraphs is a short natural breath (about 1 second).
- *Italic lines* in the Faith-centered scripts are Scripture, read word for word from the World English Bible (with "Yahweh" shown as "the Lord", as in the rest of the app). Each Scripture line says whether a passage is verbatim, a verbatim excerpt (part of a verse, words unchanged), or adapted (words changed, which is never shown in italics as a quotation).
- The title has three parts. The middle part shows in italic clay in the app.
- The music markers and pauses are production notes. They aren't spoken and aren't counted toward ElevenLabs characters.

---

## Week 6 · Grounded

**Title:** Simply / *to* / arrive.
**Description:** Five quiet minutes to land in your body, just as it is today, with nothing to figure out.
**Approach:** arriving through the senses, an optional hand on the belly, and stillness.

[music 8s]

Hello. Before anything else, just notice that you've stopped. Whatever came before this moment, and whatever comes after, can wait a few minutes.

Settle into a position that feels easy. Sitting, lying down, leaning back against something soft. There's nothing to get right here.

[pause 4s]

You might let your eyes close, or let your gaze rest somewhere gentle.

[pause 4s]

There's no need to change anything about your breathing. Just notice your next breath as it comes… and as it goes.

[pause 6s]

Now let's arrive, one sense at a time.

Notice the sounds around you. Some near, some farther away. You don't need to name them. Just let them be part of the room.

[pause 7s]

Notice where your body is being held. The weight of your legs. Your back. Your head. Let whatever is beneath you take a little more of you.

[pause 7s]

Notice the air on your skin. Warm or cool. Still, or gently moving.

[pause 6s]

You're here.

[pause 5s]

Something new has begun in you. You might feel it clearly, or hardly at all yet. You might feel happy, unsure, overwhelmed, or simply tired. All of that is welcome. Early on, so much of what's happening is quiet and out of sight.

[pause 6s]

If it feels right, rest one hand low on your belly, and the other over your heart.

[pause 5s]

You don't have to feel anything in particular. Just notice the warmth of your own hands, and the small movement beneath them as you breathe.

[pause 10s]

You don't need to have this figured out. Not the plans, not the feelings, not the months ahead. Right now there is only this breath, and the one after it.

[pause 8s]

Let your shoulders soften as you breathe out.

[pause 6s]

Let your jaw loosen.

[pause 6s]

Let your hands simply rest.

[pause 12s]

For these last moments, there's nothing to do at all. Just be here, as you are.

[pause 15s]

When you're ready, let a little movement come back. Your fingers. Your toes. Notice the light around you.

[pause 4s]

You arrived, and that was enough. You can return to this quiet whenever you need it.

[music 10s]

---

## Week 6 · Faith-centered

**Title:** Known / *before* / the beginning.
**Description:** Five quiet minutes to rest in being known and loved by God, right where you are.
**Approach:** God's call by name, the hidden work he sees, and a moment of personal prayer in the middle.
**Scripture:** Isaiah 43:1 (verbatim excerpt: the words God speaks to Israel, from the second half of the verse); Psalm 139:13 (verbatim).

[music 8s]

Welcome. Let these few minutes be set apart, for you and for God.

Find a position that feels restful. There's nothing you need to prepare, and nothing you need to say yet.

[pause 4s]

Let your breath find a comfortable rhythm. Notice it moving in… and out… without changing a thing.

[pause 6s]

Through the prophet Isaiah, God spoke these words to his people Israel, reminding them that they belonged to him:

*Don't be afraid, for I have redeemed you. I have called you by your name. You are mine.*

[pause 8s]

Those words were first spoken to a whole people, long ago. But they show us the heart of a God who knows his own by name. Not by their to-do lists, or by how well they're coping. By name.

[pause 6s]

Let your own name settle quietly in your mind. Whatever today holds, you are not a stranger to God.

[pause 10s]

Something new has begun in you. You may feel it, or hardly at all yet. You may feel joy, or worry, or a mix you can't quite sort out. Whatever is true for you today, you are already known by God, and you are loved.

[pause 6s]

If it feels right, rest one hand low on your belly.

[pause 4s]

The psalmist prayed:

*For you formed my inmost being. You knit me together in my mother's womb.*

[pause 8s]

The God who saw you before anyone else did sees this little one now. You don't have to understand what's ahead. You don't have to hold all of it by yourself.

[pause 6s]

Take a quiet moment to talk with God about this new beginning. You can use words, or simply rest your heart before him. He already knows what you're feeling.

[pause 20s]

Lord, thank you that you know me by name. Thank you for seeing this little life, hidden from everyone but you. I don't know everything that's ahead, but I know I'm not alone in it. Help me rest in your love today. Amen.

[pause 8s]

Let your shoulders soften as you breathe out. Let your hands rest.

[pause 10s]

When you're ready, gently open your eyes.

[pause 3s]

Go into your day knowing you are known, and you are loved.

[music 10s]

---

## Week 7 · Grounded

**Title:** Rest / *is* / enough.
**Description:** Five minutes of permission to slow down, because growing a new life is real work.
**Approach:** permission to rest, progressive heaviness, and a peaceful resting place.

[music 8s]

Hi. If you can, let yourself lie down for this one. On your side is lovely, with a pillow wherever you need it. If lying down isn't possible right now, simply lean back and let something hold you.

[pause 5s]

You may be more tired than usual right now. The kind of tired that a good night's sleep doesn't quite reach. Pregnancy can ask so much of you, in body and in heart, even on days when it seems like nothing is happening.

[pause 5s]

That tiredness isn't laziness, and it isn't weakness. It's what it can feel like when your body is quietly doing a great deal of work.

[pause 6s]

So here's your permission. For the next few minutes, you don't need to be useful. You don't need to catch up. Rest doesn't need to be earned.

[pause 8s]

Let's let the heaviness come.

Start with your feet. Imagine them growing warm and heavy, sinking a little into whatever is beneath them.

[pause 6s]

That warmth moves into your calves… your knees… your thighs. Heavy. Easy. Held.

[pause 7s]

Your hips and lower back, letting go.

[pause 6s]

Your belly, soft, with nothing to hold in.

[pause 6s]

Your arms, heavy all the way down to your fingertips.

[pause 6s]

And your face. The space between your eyebrows. Your jaw. The soft skin around your eyes.

[pause 8s]

Now picture a place where you could rest completely. Maybe a sunlit room on a slow afternoon, with nowhere to be. A hammock in the shade. Or somewhere only you know.

[pause 8s]

Let yourself be there. Notice the light. The quiet. How nobody needs anything from you.

[pause 15s]

If your mind wanders to the dishes, the emails, the list, that's all right. Notice it, and let your next breath out carry you back to your resting place.

[pause 15s]

You're allowed to stay a little longer.

[pause 12s]

When you're ready, let your body begin to wake. Gently. There's no rush.

[pause 4s]

Be gentle with yourself today, and rest whenever you can. It counts.

[music 10s]

---

## Week 7 · Faith-centered

**Title:** Come / *and* / rest.
**Description:** Five minutes to lay down what feels heavy and receive the rest Jesus offers.
**Approach:** coming to Jesus as you are, setting burdens down in prayer, then resting in his care.
**Scripture:** Matthew 11:28–29 (verbatim); Psalm 23:2 (verbatim).

[music 8s]

Welcome. Let yourself get comfortable. Lie down if you can, perhaps on your side with a pillow. Or simply lean back and let yourself be supported.

[pause 5s]

You may be more tired than usual right now. Pregnancy can ask so much of you, in body and in heart. And it can be hard to slow down when there's so much to carry.

[pause 5s]

Listen to the words of Jesus:

*Come to me, all you who labor and are heavily burdened, and I will give you rest. Take my yoke upon you, and learn from me, for I am gentle and humble in heart; and you will find rest for your souls.*

[pause 10s]

He doesn't say, come once you've finished everything. He doesn't say, come once you've earned it. He simply says, come.

[pause 6s]

Picture yourself coming to him now, just as you are. Tired, perhaps. Unfinished. A little worn.

[pause 6s]

And imagine him making room for you. Gentle. Unhurried. Glad you came.

[pause 10s]

What are you carrying today? Tell him quietly. The tiredness. The worries. The things you haven't gotten to. You can set each one down in front of him.

[pause 20s]

Jesus, I'm tired, and you already know it. Thank you that I don't have to earn your rest, or prove that I deserve it. I'm setting these things down with you. Teach me to rest in you. Amen.

[pause 8s]

Now let your body follow your heart. Let your shoulders sink. Let your hands open. Let your jaw go soft.

[pause 8s]

In Psalm 23, David says of the Lord, his shepherd:

*He makes me lie down in green pastures. He leads me beside still waters.*

[pause 8s]

Rest here a while, beside still waters, in his care.

[pause 18s]

When you're ready, let some movement return, slowly.

[pause 3s]

May you find his rest in the ordinary moments of today.

[music 12s]

---

## Week 8 · Grounded

**Title:** Room for / *every* / feeling.
**Description:** Five minutes to let joy, worry, and everything in between sit side by side.
**Approach:** an honest check-in, making room in the chest, and welcoming mixed feelings.

[music 8s]

Hi. Before we begin, take a moment to check in with yourself. Not how you think you should be feeling. How you actually are.

[pause 8s]

Find a comfortable position, and let your breath settle into whatever rhythm feels natural.

[pause 6s]

Pregnancy can bring so many feelings, sometimes all at once. Excitement. Worry. Tenderness. Doubt. Moments of wonder, and moments of "what have I gotten myself into?" And some days, not much feeling at all.

[pause 6s]

There's no right way to feel right now. Whatever you're feeling is welcome here.

[pause 6s]

Rest a hand over the center of your chest, if you'd like. Feel the warmth there.

[pause 5s]

As you breathe out, imagine the space beneath your hand growing a little wider. A little more room.

[pause 8s]

Now gently ask yourself: *What's here today?*

You don't need words. Just notice. Is there lightness? Heaviness? A flutter? A knot?

[pause 12s]

Whatever you find, you don't need to fix it or explain it. You can simply say to it: *There's room for this feeling, too.*

[pause 8s]

If worry is here, let it sit beside you, like someone on a park bench. It doesn't have to leave for you to feel some peace. You can keep breathing with it there.

[pause 10s]

And if there's joy, even a small spark of it, let yourself feel that too. Joy doesn't need to wait until everything is certain. It's allowed to be here now.

[pause 10s]

Notice how both can be true at once. The hope and the worry. The wonder and the tiredness. You're holding all of it, right now, and you're still here, still breathing.

[pause 12s]

If you'd like, move your hand to your belly. Whatever you're feeling about this pregnancy today, there's room for that too.

[pause 15s]

When you're ready, let your hands rest, and let your eyes slowly open.

[pause 3s]

However today feels, you're not doing it wrong. There's room for all of you.

[music 10s]

---

## Week 8 · Faith-centered

**Title:** Peace / *that* / guards.
**Description:** Five minutes to bring your real worries and hopes to God, and rest in his care.
**Approach:** guided personal prayer, with silence to bring a worry, a hope, and a thanks to God in your own words.
**Scripture:** Philippians 4:6–7 (verbatim); 1 Peter 5:7 (verbatim).

[music 8s]

Welcome. Let this be a quiet place to be honest with God.

Settle in, and let your breath find its own comfortable pace.

[pause 6s]

Pregnancy can stir up so many feelings. Hope and fear. Gratitude and questions. Sometimes they all arrive at once.

[pause 5s]

God isn't asking you to sort them out first. He invites you to bring them to him, just as they are.

[pause 5s]

Listen to these words from Philippians:

*In nothing be anxious, but in everything, by prayer and petition with thanksgiving, let your requests be made known to God. And the peace of God, which surpasses all understanding, will guard your hearts and your thoughts in Christ Jesus.*

[pause 8s]

In everything. Not only the tidy things. Not only the brave ones.

[pause 5s]

Let's do that now, slowly.

Is there a worry you've been carrying? Something you keep turning over? Tell God about it, in your own words. Be as honest as you like.

[pause 20s]

Now, is there a hope in your heart? Something you long for, for yourself, or for your baby? Tell him that too.

[pause 18s]

And is there anything, even something small, you're thankful for today? Offer him that as well.

[pause 15s]

Peter wrote that we can come to God:

*casting all your worries on him, because he cares for you.*

[pause 8s]

Peace doesn't always arrive all at once. Sometimes it comes quietly, like someone sitting down beside you. Whatever you still feel, you're not carrying it alone.

[pause 8s]

Father, thank you for listening. You know every hope and every fear I've named, and the ones I couldn't put into words. I'm leaving them with you. Guard my heart and my thoughts today, and keep me close to you. Amen.

[pause 10s]

When you're ready, let your eyes open gently.

[pause 3s]

Take this peace with you into the rest of your day.

[music 10s]

---

## Week 9 · Grounded

**Title:** Kind / *to your* / body.
**Description:** Five minutes of gentle attention for a body that's changing every day.
**Approach:** gentle movement first, then a kind body scan with no pressure to feel grateful.

[music 8s]

Hello. Let's start by letting your body move a little, before we settle.

If it feels good, roll your shoulders slowly, up, back, and down. Once or twice.

[pause 6s]

Let your head tip gently toward one shoulder… and then the other.

[pause 6s]

Now find a comfortable position and let yourself be still. If you're feeling queasy or unsettled today, sitting a little upright, with something behind your back, might feel better.

[pause 6s]

There's no need to change your breathing. Just notice it, quietly doing its work.

[pause 6s]

Your body is changing in ways you can feel, and in many ways you can't. Some changes might feel welcome. Others might feel uncomfortable, or just unfamiliar. You don't have to love every one of them.

[pause 6s]

Today, let's simply be kind to your body, wherever it is.

[pause 4s]

Bring your attention to your feet, and whatever is beneath them. They've carried you a long way.

[pause 7s]

Your legs. Notice if they feel heavy or tired, and let them rest.

[pause 7s]

Your belly, where a new life is growing. Rest your hand here, if you'd like.

[pause 10s]

Your chest, rising and falling. Your heart, keeping its steady rhythm.

[pause 7s]

Your shoulders, your arms, your hands. Let them grow heavy.

[pause 7s]

Your face. Let the small muscles around your eyes and mouth soften.

[pause 8s]

If there's a place that feels sore, heavy, or uneasy, you don't need to fix it, or feel grateful for it. Just notice it with kindness, the way you might rest a warm hand on someone you love.

[pause 12s]

And if some part of you feels like saying thank you, you can quietly do that too.

[pause 12s]

Whatever your body is asking for today, whether that's rest, water, a little food, or some fresh air, you're allowed to give it.

[pause 6s]

When you're ready, let your eyes open, and come back slowly.

[pause 3s]

Carry a little of this kindness with you today.

[music 10s]

---

## Week 9 · Faith-centered

**Title:** Fearfully, / *wonderfully* / made.
**Description:** Five minutes to bring your changing body to God, with honesty and gratitude.
**Approach:** opens with prayer, God as the gentle shepherd, an honest body prayer, and gratitude offered freely.
**Scripture:** Isaiah 40:11 (verbatim excerpt: the second and third sentences); Psalm 139:14 (verbatim).

[music 8s]

Welcome. Let's begin this time with a short prayer.

Lord, thank you for this moment to slow down. Be near to me as I rest. Amen.

[pause 6s]

Find a comfortable position. If you're feeling unsettled or queasy today, sitting a little upright, with support behind your back, may help.

[pause 5s]

Let your breath be easy. There's nothing you need to change.

[pause 6s]

Your body is changing in ways you can feel, and in many ways you can't. Some days that might feel wonderful. Other days, uncomfortable, or just strange. God sees all of it, and he isn't asking you to pretend.

[pause 6s]

The prophet Isaiah describes God as a shepherd caring for his flock:

*He will gather the lambs in his arm, and carry them in his bosom. He will gently lead those who have their young.*

[pause 8s]

Gently leading those who have their young. Held. Led gently. Not hurried.

[pause 8s]

Let's bring your body before God, one part at a time.

Your feet and legs, carrying you through each day.

[pause 6s]

Your belly, where a new life is growing. Rest your hand here, if you'd like.

[pause 10s]

Your heart, beating steadily. Your breath, coming and going.

[pause 7s]

Your shoulders, your hands, your face. Let them soften.

[pause 7s]

If there's a place that aches or feels uneasy, you don't have to give thanks for the discomfort. You can simply bring it to him, and let it be held. Tell him what's hard.

[pause 12s]

The psalmist prayed:

*I will give thanks to you, for I am fearfully and wonderfully made. Your works are wonderful. My soul knows that very well.*

[pause 8s]

If thankfulness feels true today, offer it to him, in your own words. If it doesn't, simply rest in his care.

[pause 12s]

Creator God, you made me with care, and you're near to me in every change. Thank you for this little one. On the hard days, be my comfort. Lead me gently, the way you lead those with young. Amen.

[pause 8s]

When you're ready, open your eyes and come back slowly.

[pause 3s]

Go gently, knowing you are held.

[music 10s]

---

## Length and budget (estimates)

Lengths assume a slow, natural narration pace of about 120 words a minute, with a half-second between sentences and a second between paragraphs, plus every pause and music-only section.

| Week | Version | Spoken words | Narration | Silence and music | Finished length | Spoken characters |
|---|---|---|---|---|---|---|
| 6 | Grounded | 334 | 3:18 | 2:09 | 5:28 | 1,823 |
| 6 | Faith-centered | 319 | 3:07 | 1:57 | 5:04 | 1,649 |
| 7 | Grounded | 317 | 3:09 | 2:15 | 5:24 | 1,724 |
| 7 | Faith-centered | 294 | 2:54 | 2:07 | 5:01 | 1,552 |
| 8 | Grounded | 304 | 3:00 | 2:07 | 5:07 | 1,672 |
| 8 | Faith-centered | 295 | 2:53 | 2:09 | 5:02 | 1,622 |
| 9 | Grounded | 306 | 3:01 | 2:11 | 5:09 | 1,691 |
| 9 | Faith-centered | 334 | 3:18 | 2:10 | 5:28 | 1,806 |

**Full library, projected from these eight (74 recordings, Maren only):**
- Spoken characters: about 125,000 (average 1,690 per meditation; pause and music markers excluded).
- With v4 tone tags (about 3%) and an allowance of 20% for re-recording lines: about 155,000 ElevenLabs credits (v4 uses 1 credit per character).
- Narration time: about 3.8 hours. Finished audio, including silences: about 6.5 hours.
- Storage: each file is voice only, with the silences included (the app plays the soundscape underneath). As AAC mono at 64–96 kbps, that's about 2.5–3.7 MB per meditation, or 185–275 MB for all 74, which fits within Supabase's free storage. A phone only keeps the weeks it has downloaded.
