# Creating the coach voices with ElevenLabs

Plan: create all five voices, then **generate and test Maren only**, both her Grounded and Faith-Centered libraries. Generate the other four coaches only after you're happy with how Maren sounds in labor mode.

Each coach uses **one voice for both modes**. Lines that work in both modes are generated once and shared (files starting `both-`). That's **269 recordings** in total (about 11,700 characters), not 320.

## 1. Before you start

- **Plan and licence.** Use a paid ElevenLabs plan that includes a commercial licence. The free plan doesn't allow commercial use. If you use a voice from the Voice Library, also read that voice's own terms. Check ElevenLabs' current terms yourself; they change.
- **Script.** The phrases are in `docs/coaching-scripts.md` (for reading, by coach and mode) and `docs/coaching-lines.csv` (one row per recording, with the modes it's used in). Both are generated from `src/data/coaching.ts`. If you change a phrase, edit that file and run `npm run scripts:export`.
- **Cost check.** Running `npm run voices:generate -- --coach maren --dry-run` lists every line and the total character count without spending anything. It’s about 1,800–2,600 characters per coach, 11,712 for all five.

## 2. Create the five voices

In ElevenLabs, use **Voices → Voice Design** (describe a voice) or pick one from the Voice Library. Name them "BirthWell – Maren" and so on. These descriptions are a starting point:

| Coach | Voice description |
|---|---|
| Maren | Woman in her 50s. Warm, calm, mid-low voice. Speaks slowly and plainly, like an experienced midwife on a night shift. Reassuring, never sugary. |
| Jo | Woman in her 30s. Bright, friendly, natural and relaxed, like a close friend sitting beside you. Warm smile in the voice, conversational. |
| Esme | Woman in her 40s. Deep, low, unhurried, very steady. Few words, long pauses, grounding and still. |
| Ines | Woman in her 30s. Soft, gentle, clear and slow. Calm and meditative but plain-spoken, not breathy or theatrical. |
| Della | Woman in her 30s. Confident, bright and warm. Encouraging and direct, never loud, never like a fitness instructor. |

Tips:
- Choose voices that sound good **quietly**. The app will often play at low volume at night.
- Test each voice with four lines before committing: one Grounded and one Faith-Centered encouragement phrase, a short prayer (for example Maren's `faith-encourage-03`, “Lord Jesus, give me strength for this moment.”), and a rest phrase. The voice has to carry both everyday warmth and reverence.
- Copy each voice's **Voice ID** (on the voice's page) into the config in step 3.

## 3. Settings to keep consistent

All of a coach's lines must use the same model and settings, or she'll sound like a different person from line to line.

- **Model:** `eleven_multilingual_v2` is the safest choice for consistency. Newer models may be more expressive but vary more between generations, so test one before switching.
- **Stability:** 0.5–0.7. Higher is calmer and more consistent; Esme suits the high end, Jo and Della the lower end.
- **Similarity:** about 0.75. **Style:** low (0–0.25).
- **Speed:** 1.0 is normal; lower is slower (about 0.7–1.2). Maren is set to 0.9. Change `speed` for a coach in `scripts/elevenlabs.config.json`, test on a few lines, then regenerate with `--force`.
- Ellipses (…) in the script produce natural pauses. Quotation marks are removed automatically before speaking.

These are already filled in, per coach, in `scripts/elevenlabs.config.example.json`.

## 4. Generate Maren (pilot)

On your Mac, in the `birthwell` folder:

```bash
cp scripts/elevenlabs.config.example.json scripts/elevenlabs.config.json
# open scripts/elevenlabs.config.json and paste each voice_id

export ELEVENLABS_API_KEY=your-key-here      # stays on your Mac; never shared
npm run voices:generate -- --coach maren --dry-run
npm run voices:generate -- --coach maren
```

This saves Maren's 54 MP3s to `audio-src/maren/`, covering both libraries, named exactly as the app expects (`grounded-start-01.mp3`, `faith-rest-02.mp3`, `both-breathe-01.mp3`…). It never generates more than one coach per run, and it skips files that already exist. Add `--mode faith` or `--mode grounded` to generate only one library's lines, or `--category ack` for only the end-of-contraction acknowledgments (5 per coach: 3 shared by both modes, 2 Faith-Centered).

**If you'd rather not use the API:** generate each line on the ElevenLabs website, download it, and save it as `audio-src/maren/<id>.mp3` using the IDs in `docs/coaching-lines.csv`.

## 5. Listen and fix

Listen to every file in `audio-src/maren/`. Check:
- Pronunciation, pacing and tone fit the delivery note.
- Nothing is cut off at the start or end.
- Prayers and Scripture sound sincere and reverent, not performed; names (Jesus, Holy Spirit) are pronounced with care.
- None sounds noticeably louder or brighter than the rest.

To redo specific lines:

```bash
npm run voices:generate -- --coach maren --only grounded-breathe-02,faith-rest-01 --force
```

## 6. Prepare and import

```bash
brew install ffmpeg                 # once, if you don't have it
bash scripts/prepare-audio.sh maren # trims silence, evens loudness, saves .m4a into the app
npm run voices                      # tells the app which recordings now exist
npx expo start --tunnel             # restart the app
```

`npm run voices` reports how many of each coach's recordings it found (54 for most coaches, 53 for Jo), and warns about misnamed files. Any phrase without a recording keeps using the iPhone voice, so partial sets are fine.

## 7. Test the experience (before the other four coaches)

- **Coach picker:** tap Maren; you should hear her preview phrase.
- **Settings:** move Coach volume; she plays her volume-test phrase.
- **Labor mode:** set Coaching to Balanced, then time several contractions, some short (~20s) and some long (~70s). Check:
  - One phrase at the start; usually one more, mostly a breathing cue, somewhere between 30 and 42 seconds; and one when it ends. Roughly 1 contraction in 6 gets only the opening phrase, on purpose.
  - End a contraction while she's mid-sentence: if she's nearly done she finishes, then after a short pause gives the resting phrase. If she has more than ~3 seconds left, she stops and the resting phrase follows.
  - Phrases never overlap or cut each other off.
  - Rests stay quiet after the single resting phrase.
  - Ambience dips while she speaks.
- **Switch Settings › Daily encouragement** between Faith-centered and Grounded. Coaching follows that choice: Faith-Centered plays only the faith library, Grounded only the secular one, and shared lines appear in both.
- Then work through `docs/audio-testing.md` on a development build.

When Maren feels right, repeat steps 4–6 for `jo`, `esme`, `ines` and `della`. To process every coach at once: `bash scripts/prepare-audio.sh all`.

## Final ambience loops

1. Export each loop and save it as `audio-src/ambience/desert-dusk.<ext>`, `mountain-rain.<ext>` or `hearth.<ext>` (WAV, MP3 or M4A).
2. Run `bash scripts/prepare-audio.sh ambience`. It levels them quieter than the voices and saves `.m4a` files over the placeholders.
3. Listen for a click or gap where the loop restarts. If you hear one, export a loop with a longer crossfade.
4. To rename or add soundscapes, edit the `AMBIENCE` list in `src/data/content.ts`.

## Using Eleven v4 (audio tags)

Eleven v4 sounds more natural and understands short directions in square brackets, such as `[warmly]` or `[sincere, softly]`. They shape the delivery and aren't spoken.

- `npm run voices:model -- eleven_v4 jo` switches a coach to v4 (`all` for every coach) and adds her suggested tones from the example config. Check v4's exact model name in the ElevenLabs API docs; if it's wrong, the first generate shows an error.
- Each coach has a default `tone`, and `toneFor` sets one per kind of line: `start`, `breathe`, `affirm`, `encourage`, `ack`, `rest`, `ground`, `preview`, `volume`, plus `prayer` for lines that pray. `lineTone` overrides a single line.
- v2's pause settings (`sentencePause`, `endPause`, `speed`) are ignored on v4. It paces sentences itself; use a tone like `[slowly]` instead.
- Always check with `--dry-run`, then test 3–5 lines, before regenerating a coach with `--force`.
