// Switches coaches to another ElevenLabs model (for example Eleven v4) in your local
// scripts/elevenlabs.config.json, and adds the suggested tone directions for each coach
// from the example config (only where you haven't set your own).
//   npm run voices:model -- eleven_v4 jo            one coach
//   npm run voices:model -- eleven_v4 all           every coach
//   npm run voices:model -- eleven_multilingual_v2 jo   back to v2
import { readFileSync, writeFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const [model, ...who] = process.argv.slice(2);
if (!model || !who.length) {
  console.error('Usage: npm run voices:model -- <model_id> <coach|all> [coach…]');
  process.exit(1);
}
const path = join(root, 'scripts/elevenlabs.config.json');
const config = JSON.parse(readFileSync(path, 'utf8'));
const example = JSON.parse(readFileSync(join(root, 'scripts/elevenlabs.config.example.json'), 'utf8'));
const coaches = who[0] === 'all' ? Object.keys(config.voices) : who;
for (const slug of coaches) {
  const v = config.voices[slug];
  if (!v) {
    console.error(`No coach called ${slug}`);
    process.exit(1);
  }
  v.model_id = model;
  const ex = example.voices[slug] ?? {};
  if (!v.tone && ex.tone) v.tone = ex.tone;
  if (!v.toneFor && ex.toneFor) v.toneFor = ex.toneFor;
  console.log(`${slug}: ${model}${/v3|v4/i.test(model) ? `, tone ${v.tone}` : ''}`);
}
writeFileSync(path, JSON.stringify(config, null, 2));
console.log('Saved. Check a few lines with --dry-run before generating.');
