// Uploads finished meditations to Supabase and updates the manifest the app reads.
//
//   read -rs SUPABASE_SECRET_KEY && export SUPABASE_SECRET_KEY   (paste the key, press Return)
//   npm run meditations:upload                       shows what would change, then asks
//   npm run meditations:upload -- --week 7-20        only these weeks
//
// Free weeks (FREE_MEDITATION_WEEKS in src/config/premium.ts) go to the public
// meditations-free bucket; every other week goes to the private meditations bucket. Only new
// or changed recordings are uploaded. The key is never printed or saved.
// The project URL comes from EXPO_PUBLIC_SUPABASE_URL in .env (or --project <url>).

import { createHash } from 'node:crypto';
import { existsSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { createInterface } from 'node:readline/promises';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const NARRATOR = 'maren';
const FREE_BUCKET = 'meditations-free';
const PREMIUM_BUCKET = 'meditations';
const VERSIONS = ['faith', 'secular'];
const pad = (w) => String(w).padStart(2, '0');

const argv = process.argv.slice(2);
const opt = (name) => {
  const i = argv.indexOf(`--${name}`);
  return i < 0 ? undefined : argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[i + 1] : true;
};

function projectUrl() {
  let url = opt('project');
  if (typeof url !== 'string' && existsSync(join(root, '.env'))) {
    url = /^EXPO_PUBLIC_SUPABASE_URL=(.*)$/m.exec(readFileSync(join(root, '.env'), 'utf8'))?.[1];
  }
  url = (url ?? process.env.EXPO_PUBLIC_SUPABASE_URL ?? '').trim().replace(/^["']|["']$/g, '').replace(/^(https?:\/\/[^/]+).*$/, '$1');
  if (!/^https?:\/\/\S+$/.test(url)) {
    console.error('Add your Supabase project URL to .env first, for example:\n  EXPO_PUBLIC_SUPABASE_URL=https://abcd1234.supabase.co');
    process.exit(1);
  }
  return url;
}

function weeksWanted() {
  const w = opt('week');
  if (typeof w !== 'string') return null;
  const [a, b] = w.split('-').map(Number);
  return new Set(Array.from({ length: (b || a) - a + 1 }, (_, i) => a + i));
}

const freeWeeks = () => {
  const src = readFileSync(join(root, 'src/config/premium.ts'), 'utf8');
  return JSON.parse(/FREE_MEDITATION_WEEKS = (\[[^\]]*\])/.exec(src)[1]);
};

const base = projectUrl();
const key = (process.env.SUPABASE_SECRET_KEY ?? '').trim();
function describeKey() {
  const notes = [`${key.length} characters`];
  if (/^sb_secret_\S+$/.test(key)) notes.push('starts with sb_secret_ as expected');
  else if (/^eyJ\S+$/.test(key)) notes.push('a legacy service_role key');
  else if (/^sb_publishable_/.test(key)) notes.push('this is the PUBLISHABLE key: use the SECRET key instead');
  else notes.push('does NOT look like a Supabase secret key (it starts with sb_secret_)');
  if (/\s/.test(key)) notes.push('contains a space or line break');
  return notes.join(', ');
}
if (!key) {
  console.error('No Supabase key. Run this first, paste the secret key and press Return (nothing shows while you paste):\n  read -rs SUPABASE_SECRET_KEY && export SUPABASE_SECRET_KEY');
  process.exit(1);
}
// New-style keys go in the apikey header only; legacy JWT keys also as a bearer token.
const auth = /^eyJ/.test(key) ? { apikey: key, Authorization: `Bearer ${key}` } : { apikey: key };

async function api(method, path, { body, headers = {} } = {}) {
  for (let attempt = 1; ; attempt++) {
    try {
      return await fetch(`${base}/storage/v1${path}`, { method, headers: { ...auth, ...headers }, body });
    } catch (e) {
      if (attempt >= 4) throw e;
      await new Promise(r => setTimeout(r, 2000 * attempt));
    }
  }
}
const why = (status) =>
  status === 401 || status === 403
    ? 'Supabase refused the key. Use the secret key from Project Settings → API Keys.'
    : status === 404
      ? 'Not found. Check the project URL in .env and that the bucket exists.'
      : `Supabase answered ${status}.`;

// ---- Safety checks -------------------------------------------------------------------------
async function checkBucket(id, shouldBePublic) {
  const res = await api('GET', `/bucket/${id}`);
  if (res.status === 404 || res.status === 400) {
    console.error(`\nThe bucket "${id}" doesn't exist yet. Create it in Supabase → Storage (${shouldBePublic ? 'Public' : 'NOT public'}).`);
    process.exit(1);
  }
  if (!res.ok) {
    console.error(`\n${why(res.status)} (key: ${describeKey()})`);
    process.exit(1);
  }
  const b = await res.json();
  if (!!b.public !== shouldBePublic) {
    console.error(
      shouldBePublic
        ? `\nThe bucket "${id}" is private, so free weeks wouldn't play. In Supabase → Storage, edit it and turn on "Public bucket".`
        : `\nStopped: the bucket "${id}" is PUBLIC, so anyone could download Premium meditations. In Supabase → Storage, edit it and turn off "Public bucket". Nothing was uploaded.`,
    );
    process.exit(1);
  }
}

// ---- What to upload ------------------------------------------------------------------------
const free = freeWeeks();
const only = weeksWanted();
const durations = (() => {
  const f = join(root, 'audio-out/meditations', NARRATOR, 'durations.json');
  return existsSync(f) ? JSON.parse(readFileSync(f, 'utf8')) : {};
})();

const current = await fetch(`${base}/storage/v1/object/public/${FREE_BUCKET}/manifest.json?t=${Date.now()}`)
  .then(r => (r.ok ? r.json() : null))
  .catch(() => null);
const manifest = current?.format === 2 ? current : { format: 2, narrator: NARRATOR, files: { faith: {}, secular: {} } };
for (const v of VERSIONS) manifest.files[v] ??= {};

const plan = [];
for (const version of VERSIONS) {
  for (let week = 6; week <= 42; week++) {
    if (only && !only.has(week)) continue;
    const file = join(root, 'audio-out/meditations', NARRATOR, version, `week-${pad(week)}.m4a`);
    if (!existsSync(file)) continue;
    const data = readFileSync(file);
    const rev = createHash('sha256').update(data).digest('hex').slice(0, 12);
    const path = `${NARRATOR}/${version}/week-${pad(week)}.m4a`;
    const isFree = free.includes(week);
    const old = manifest.files[version][String(week)];
    const entry = { path, rev, seconds: durations[`${version}/week-${pad(week)}`], bytes: data.length, ...(isFree ? { free: true } : {}) };
    const state = !old ? 'new' : old.rev !== rev || !!old.free !== isFree ? 'changed' : 'same';
    plan.push({ week, version, data, entry, old, state, isFree });
  }
}

const label = (p) => `Week ${p.week} ${p.version === 'faith' ? 'Faith-centered' : 'Grounded'}`;
const todo = plan.filter(p => p.state !== 'same');
console.log(`\nSupabase project: ${base}`);
console.log(`Key: ${describeKey()}`);
console.log(`Free weeks (public): ${free.join(', ')}. All others are Premium (private).\n`);
if (!plan.length) {
  console.log('No finished meditations found in audio-out/meditations/maren. Nothing to upload.');
  process.exit(0);
}
for (const p of plan) {
  console.log(`  ${label(p).padEnd(28)} ${p.isFree ? 'free   ' : 'Premium'}  ${(p.data.length / 1e6).toFixed(1)} MB  ${p.state === 'same' ? 'already uploaded' : p.state}`);
}
if (!todo.length) {
  console.log('\nEverything is already uploaded. Nothing to do.');
  process.exit(0);
}

await checkBucket(FREE_BUCKET, true);
await checkBucket(PREMIUM_BUCKET, false);

if (!argv.includes('--yes')) {
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  const answer = await rl.question(`\nUpload ${todo.length} meditation${todo.length === 1 ? '' : 's'}? Type yes to upload: `);
  rl.close();
  if (answer.trim().toLowerCase() !== 'yes') {
    console.log('Nothing was uploaded.');
    process.exit(0);
  }
}

// ---- Upload --------------------------------------------------------------------------------
let failed = 0;
for (const p of todo) {
  const bucket = p.isFree ? FREE_BUCKET : PREMIUM_BUCKET;
  process.stdout.write(`  ${label(p)}… `);
  const res = await api('POST', `/object/${bucket}/${p.entry.path}`, {
    body: p.data,
    headers: { 'Content-Type': 'audio/mp4', 'x-upsert': 'true', 'cache-control': 'max-age=3600' },
  });
  if (!res.ok) {
    failed++;
    console.log(`failed. ${why(res.status)}`);
    continue;
  }
  // A week that moved between free and Premium must not stay in its old bucket.
  if (p.old && !!p.old.free !== p.isFree) {
    await api('DELETE', `/object/${p.isFree ? PREMIUM_BUCKET : FREE_BUCKET}`, {
      body: JSON.stringify({ prefixes: [p.entry.path] }),
      headers: { 'Content-Type': 'application/json' },
    });
  }
  manifest.files[p.version][String(p.week)] = p.entry;
  console.log('done');
}

manifest.updated = new Date().toISOString();
const res = await api('POST', `/object/${FREE_BUCKET}/manifest.json`, {
  body: JSON.stringify(manifest, null, 2),
  headers: { 'Content-Type': 'application/json', 'x-upsert': 'true', 'cache-control': 'max-age=60' },
});
if (!res.ok) {
  console.error(`\nThe recordings uploaded, but the manifest didn't (${why(res.status)}). Run this again to retry.`);
  process.exit(1);
}
const listed = VERSIONS.reduce((n, v) => n + Object.keys(manifest.files[v]).length, 0);
console.log(`\n${todo.length - failed} uploaded${failed ? `, ${failed} failed (run again to retry)` : ''}. The app now lists ${listed} meditation${listed === 1 ? '' : 's'}.`);
process.exit(failed ? 1 : 0);
