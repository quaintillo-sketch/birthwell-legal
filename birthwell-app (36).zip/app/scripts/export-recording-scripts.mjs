// Writes clean, recording-ready scripts for one version of the meditations: only what Maren
// says, in order, with her tone directions (shown where they change) and the timed silences.
// The words are exactly what the recorder sends to ElevenLabs.
//   node scripts/export-recording-scripts.mjs faith 7 42 > docs/meditations/recording/faith-weeks-07-42.md
import { buildUnits, estimateSeconds, fmt, loadScripts, MAREN_PACE } from './meditation-scripts.mjs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const [version = 'faith', from = '7', to = '42'] = process.argv.slice(2);
const all = loadScripts(root);
const scripts = all.filter(s => s.version === version && s.week >= Number(from) && s.week <= Number(to));
const out = [];
for (const s of scripts) {
  const grounded = new Set(buildUnits(all.find(x => x.week === s.week && x.version === 'grounded')).map(u => u.sent));
  const units = buildUnits(s);
  const byPara = new Map(units.map(u => [u.paras[0], u]));
  const shared = units.filter(u => grounded.has(u.sent)).length;
  out.push(`## Week ${s.week} · ${s.title}`, '');
  out.push(`*About ${fmt(estimateSeconds(s, 1, MAREN_PACE))} · ${units.length} paragraphs${version === 'faith' ? ` (${shared} identical to Grounded)` : ''} · ${units.reduce((n, u) => n + u.sent.length, 0).toLocaleString()} characters*`, '');
  let tag = '';
  for (const i of s.items) {
    if (i.kind !== 'para') {
      out.push(`\`[${i.kind} ${i.seconds}s]\``, '');
      continue;
    }
    const u = byPara.get(i.n);
    const text = u.sent.replace(/^\[[^\]]+\] /, '');
    out.push(`${i.tag !== tag ? `\`${i.tag}\` ` : ''}${i.scripture ? `*${text}*` : text}`, '');
    tag = i.tag;
  }
}
console.log(out.join('\n'));
