// Records the weekly meditations in Maren's voice with the ElevenLabs API, straight from the
// approved scripts in docs/meditations/. Each paragraph is recorded on its own and saved, so a
// single paragraph can be re-recorded without paying for the rest. Silences are built as exact
// silence, then each meditation is joined, levelled and saved as one .m4a with a review sheet.
//
//   npm run meditations -- --dry-run                         counts for all 74, spends nothing
//   npm run meditations -- --week 6 --check --max-credits 5000   your plan, credits left, the verified rate and whether week 6 fits the cap (free)
//   npm run meditations -- --week 6 --max-credits 5000       record the week 6 pilot, both versions
//   npm run meditations -- --week 6-20 --version faith --max-credits 70000
//   npm run meditations -- --week 12 --version grounded --only 4,9 --force --max-credits 1000   (redo paragraphs 4 and 9)
//   npm run meditations -- --week 6 --assemble               rebuild the files from saved paragraphs (free)
//   … --version faith --reuse-grounded                       also reuse identical paragraphs from that week's Grounded recording
//
// Recordings go to audio-src/meditations/<narrator>/<version>/week-XX/ (one file per paragraph)
// and the finished files to audio-out/meditations/<narrator>/<faith|secular>/week-XX.m4a.
// Settings live in the "meditation" section of scripts/elevenlabs.config.json.
// A real run always needs --max-credits and asks you to type "yes" before spending anything.
// It won't start if the verified credit rate would take it over --max-credits (add --partial to
// record up to the cap instead), and it stops after the first paragraph if the measured rate would.
// Only the weeks Leah has approved for recording can be recorded (UNLOCKED_WEEKS below).
//   npm run meditations -- --week 7 --preview                 mix a finished week with a soundscape to hear it as in the app (free)
// The API key is read from the environment and is never printed or saved.
import { execFileSync, spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { createInterface } from 'node:readline/promises';
import { fileURLToPath } from 'node:url';
import { buildUnits, checkIntegrity, estimateSeconds, fmt, loadScripts, MAREN_PACE, tagChars } from './meditation-scripts.mjs';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const arg = (name) => {
  const i = process.argv.indexOf(`--${name}`);
  return i < 0 ? undefined : process.argv[i + 1] && !process.argv[i + 1].startsWith('--') ? process.argv[i + 1] : true;
};

let fileConfig = {};
try {
  fileConfig = JSON.parse(readFileSync(join(root, 'scripts/elevenlabs.config.json'), 'utf8'));
} catch {}
const med = fileConfig.meditation ?? {};
const narrator = med.narrator ?? 'maren';
const voice = fileConfig.voices?.[narrator] ?? {};
const settings = {
  voice_id: med.voice_id ?? voice.voice_id ?? '',
  // Meditations always use Eleven v4, whatever model Maren's coaching lines use.
  model_id: med.model_id ?? 'eleven_v4',
  stability: med.stability ?? 0.6,
  similarity_boost: med.similarity_boost ?? voice.similarity_boost ?? 0.75,
  seed: med.seed ?? 1234,
  speed: med.speed ?? null,
  context: med.context !== false,
};
const unit = med.unit === 'block' ? 'block' : 'paragraph';
// Rare names get spoken spellings in the text sent to ElevenLabs (the scripts stay as written).
// Names in listenFor are flagged on the review sheet so they can be checked by ear.
const pronounce = med.pronounce ?? { Zephaniah: 'Zeff-uh-NYE-uh', Elihu: 'Ee-LYE-hew' };
const listenFor = med.listenFor ?? ['Ebenezer', 'Hur', 'Lamentations', 'Ecclesiastes', 'Corinthians', 'Philippians', 'Galatia', 'Elizabeth', 'Isaiah'];
const paragraphGap = med.paragraphGap ?? 1.0;
const creditsPerChar = med.creditsPerChar ?? 1;
const outputFormat = fileConfig.output_format ?? 'mp3_44100_128';
// Length targets, set by Leah after the pilot to suit Maren's natural pace: Grounded 4:15–5:30,
// Faith-centered 4:15–6:00 (it carries the Grounded journey plus the faith moments). Small
// exceptions of up to 10 seconds are fine if the pace sounds natural.
const TARGETS = { grounded: { min: 255, max: 330 }, faith: { min: 255, max: 360 } };
const SLACK = 10;
const pace = med.pace ?? MAREN_PACE;
const folder = (version) => (version === 'grounded' ? 'secular' : 'faith'); // the app's folder names
const pad = (n) => String(n).padStart(2, '0');
const srcDir = (s) => join(root, 'audio-src/meditations', narrator, s.version, `week-${pad(s.week)}`);
const outFile = (s) => join(root, 'audio-out/meditations', narrator, folder(s.version), `week-${pad(s.week)}.m4a`);
const hash = (t) => createHash('sha256').update(t).digest('hex').slice(0, 16);

// ---- Which meditations ------------------------------------------------------------------
const all = loadScripts(root);
const weekArg = arg('week');
let weeks = null;
if (typeof weekArg === 'string' && weekArg !== 'all') {
  const [a, b] = weekArg.split('-').map(Number);
  if (!a || (weekArg.includes('-') && !b)) {
    console.error('--week takes a week (6), a range (6-20) or all');
    process.exit(1);
  }
  weeks = [a, b ?? a];
}
const version = arg('version');
if (version !== undefined && version !== 'grounded' && version !== 'faith') {
  console.error('--version must be grounded or faith');
  process.exit(1);
}
const only = typeof arg('only') === 'string' ? new Set(arg('only').split(',').map(x => Number(x.replace(/^[pb]/, '')))) : null;
const scripts = all.filter(s => (!weeks || (s.week >= weeks[0] && s.week <= weeks[1])) && (!version || s.version === version));
if (!scripts.length) {
  console.error('No meditations match that selection.');
  process.exit(1);
}

// ---- What would be sent ------------------------------------------------------------------
// Recordings already made for exactly the same words and tone tag can be reused for free: from
// this meditation's own folder (after a script revision renumbers its paragraphs) and, with
// --reuse-grounded, from the same week's Grounded recording.
function savedRecordings(dirs) {
  const found = new Map();
  for (const dir of dirs) {
    if (!existsSync(dir)) continue;
    for (const name of readdirSync(dir).filter(n => n.endsWith('.json'))) {
      const meta = JSON.parse(readFileSync(join(dir, name), 'utf8'));
      const mp3 = join(dir, name.replace(/\.json$/, '.mp3'));
      if (meta.textHash && existsSync(mp3) && !found.has(meta.textHash)) found.set(meta.textHash, { mp3, meta });
    }
  }
  return found;
}

function plan(s) {
  const units = buildUnits(s, { unit, pronounce });
  const dirs = [srcDir(s)];
  if (arg('reuse-grounded') && s.version === 'faith') dirs.push(srcDir({ ...s, version: 'grounded' }));
  const saved = savedRecordings(dirs);
  return units.map((u, k) => {
    const file = join(srcDir(s), `${u.id}.mp3`);
    const meta = existsSync(file.replace(/\.mp3$/, '.json')) ? JSON.parse(readFileSync(file.replace(/\.mp3$/, '.json'), 'utf8')) : null;
    const recorded = existsSync(file) && meta?.textHash === hash(u.sent);
    const selected = !only || u.paras.some(n => only.has(n));
    const reuse = !recorded && !arg('force') ? saved.get(hash(u.sent)) : undefined;
    return {
      ...u,
      file,
      meta,
      recorded,
      reuse,
      settingsChanged: recorded && JSON.stringify(meta.settings) !== JSON.stringify(settings),
      todo: selected && !reuse && (!recorded || !!arg('force')),
      previous: k > 0 ? units[k - 1].words : '',
      next: k < units.length - 1 ? units[k + 1].words : '',
    };
  });
}

const rows = scripts.map(s => {
  const problems = checkIntegrity(root, s, { unit, pronounce });
  const units = plan(s);
  const todo = units.filter(u => u.todo);
  return {
    s,
    problems,
    units,
    todo,
    spoken: units.reduce((n, u) => n + u.words.length, 0),
    tags: units.reduce((n, u) => n + tagChars(u.sent), 0),
    sent: units.reduce((n, u) => n + u.sent.length, 0),
    todoSent: todo.reduce((n, u) => n + u.sent.length, 0),
    todoContext: todo.reduce((n, u) => n + u.previous.length + u.next.length, 0),
    estimate: estimateSeconds(s, paragraphGap, pace),
  };
});
const broken = rows.filter(r => r.problems.length);
if (broken.length) {
  for (const r of broken) console.error(`Week ${r.s.week} ${r.s.version}: ${r.problems.join('; ')}`);
  console.error('\nStopped: the text to be sent does not match the approved scripts. Nothing was recorded.');
  process.exit(1);
}

function report() {
  console.log(`Meditations · ${narrator} · ${settings.model_id} · one request per ${unit}`);
  console.log('Week  Version    Requests  Spoken  Tags   Sent    Recorded  To send  Est. length (Maren)');
  for (const r of rows) {
    const done = r.units.filter(u => u.recorded).length;
    console.log(`${String(r.s.week).padEnd(5)} ${r.s.version.padEnd(10)} ${String(r.units.length).padStart(8)} ${String(r.spoken).padStart(7)} ${String(r.tags).padStart(5)} ${String(r.sent).padStart(7)} ${`${done}/${r.units.length}`.padStart(9)} ${String(r.todoSent).padStart(8)}  ${fmt(r.estimate)}`);
  }
  const sum = (k) => rows.reduce((n, r) => n + r[k], 0);
  const todoCount = rows.reduce((n, r) => n + r.todo.length, 0);
  console.log(`\n${rows.length} meditations · ${sum('spoken').toLocaleString()} spoken characters + ${sum('tags').toLocaleString()} tag characters = ${sum('sent').toLocaleString()} characters sent`);
  console.log(`To record now: ${todoCount} requests, ${sum('todoSent').toLocaleString()} characters ≈ ${Math.ceil(sum('todoSent') * creditsPerChar).toLocaleString()} credits at ${creditsPerChar} credit per character`);
  if (settings.context) console.log(`Neighbouring text sent for continuity (previous_text / next_text): ${sum('todoContext').toLocaleString()} characters, normally not billed. Confirm with the credit check after the first paragraph.`);
  const reused = rows.reduce((n, r) => n + r.units.filter(u => u.reuse).length, 0);
  if (reused) console.log(`Reused for free: ${reused} paragraph${reused === 1 ? '' : 's'} already recorded with exactly the same words and tone.`);
  const changed = rows.reduce((n, r) => n + r.units.filter(u => u.settingsChanged).length, 0);
  if (changed) console.log(`Note: ${changed} saved recordings were made with different voice settings. They are kept unless you re-record them with --force.`);
  console.log('Every request matches the approved scripts word for word.');
}

// ---- ElevenLabs --------------------------------------------------------------------------
const key = process.env.ELEVENLABS_API_KEY;
const apiBase = process.env.ELEVENLABS_API_URL ?? 'https://api.elevenlabs.io';
// A dropped connection (common after a pause while a meditation is being joined) is retried
// up to 3 times; ElevenLabs only charges for audio it delivers.
async function send(url, options, tries = 3) {
  try {
    return await fetch(url, options);
  } catch (e) {
    if (!tries) throw e;
    await new Promise(res => setTimeout(res, 2000 * 2 ** (3 - tries)));
    return send(url, options, tries - 1);
  }
}
async function api(path) {
  const res = await send(`${apiBase}${path}`, { headers: { 'xi-api-key': key } });
  const body = await res.text();
  return { ok: res.ok, status: res.status, body: res.ok ? JSON.parse(body) : body, reason: res.ok ? '' : why(res.status, body) };
}
// ElevenLabs' own explanation of a refusal, in plain words. (Its replies never contain the key.)
function why(status, body) {
  let detail = {};
  try {
    detail = JSON.parse(body).detail ?? {};
  } catch {}
  const code = typeof detail === 'object' ? detail.status ?? '' : '';
  const message = typeof detail === 'string' ? detail : detail.message ?? '';
  if (/invalid_api_key/i.test(code + message)) return 'ElevenLabs says the key is not valid. It may be incomplete, pasted twice, or deleted.';
  if (/missing_permission/i.test(code + message)) return `ElevenLabs says the key is missing a permission: ${message}`;
  if (/unusual|detected/i.test(code + message)) return `ElevenLabs blocked the request: ${message}`;
  return `ElevenLabs said (${status}): ${message || code || body.slice(0, 200)}`;
}
// Describes the key without revealing it: its length and whether it has the usual shape.
function describeKey() {
  const k = key ?? '';
  const notes = [`${k.length} characters`];
  notes.push(/^sk_[A-Za-z0-9]+$/.test(k) ? 'starts with sk_ as expected' : 'does NOT look like an ElevenLabs key (they start with sk_ and have no spaces)');
  if (/\s/.test(k)) notes.push('contains a space or line break');
  if (k.length > 70) notes.push('longer than usual: was it pasted twice?');
  return notes.join(', ');
}
async function creditsUsed() {
  try {
    const r = await api('/v1/user/subscription');
    return r.ok ? r.body.character_count : null;
  } catch {
    return null;
  }
}

// The model's listed credit rate, if this key may read the model list.
async function listedRate() {
  try {
    const r = await api('/v1/models');
    if (!r.ok) return { status: r.status, reason: r.reason };
    const m = r.body.find(x => x.model_id === settings.model_id);
    return { model: m, rate: m?.model_rates?.character_cost_multiplier ?? null };
  } catch {
    return {};
  }
}
async function balance() {
  try {
    const r = await api('/v1/user/subscription');
    return r.ok ? r.body.character_limit - r.body.character_count : null;
  } catch {
    return null;
  }
}

async function check() {
  if (!key) return console.error('First run:  read -rs ELEVENLABS_API_KEY && export ELEVENLABS_API_KEY');
  console.log(`Key entered: ${describeKey()}`);
  const sub = await api('/v1/user/subscription');
  if (sub.ok) {
    const b = sub.body;
    console.log(`Plan: ${b.tier} · ${b.character_count.toLocaleString()} of ${b.character_limit.toLocaleString()} credits used, ${(b.character_limit - b.character_count).toLocaleString()} left`);
    if (b.next_character_count_reset_unix) console.log(`Credits reset: ${new Date(b.next_character_count_reset_unix * 1000).toLocaleDateString()}`);
  } else console.log(`Couldn't read your plan. ${sub.reason}`);
  const { model: m, rate, status, reason } = await listedRate();
  if (status) console.log(`Couldn't read the model list. ${reason}`);
  else if (!m) console.log(`Model ${settings.model_id} isn't in your account's model list.`);
  else console.log(`Model: ${m.name ?? m.model_id} · credit rate ${rate ?? 'not listed'}${rate ? ' credit(s) per character' : ''}${m.maximum_text_length_per_request ? ` · up to ${m.maximum_text_length_per_request.toLocaleString()} characters per request` : ''}`);
  const v = settings.voice_id ? await api(`/v1/voices/${settings.voice_id}`) : null;
  console.log(v?.ok ? `Voice: ${v.body.name}` : settings.voice_id ? `Couldn't read the voice. ${v.reason}` : 'No voice ID set for the meditations. Add Maren\'s voice_id to scripts/elevenlabs.config.json.');
  // What the selected meditations would cost at the verified rate.
  const chars = rows.reduce((n, r) => n + r.todoSent, 0);
  const useRate = rate ?? creditsPerChar;
  const need = Math.ceil(chars * useRate);
  if (!sub.ok || !rate) console.log('\nThe credit rate or balance is NOT verified yet. Fix the key first; don\'t record until both show above.');
  console.log(`\nThis selection (${rows.length} meditation${rows.length === 1 ? '' : 's'}, ${chars.toLocaleString()} characters to record): about ${need.toLocaleString()} credits at ${useRate} per character${rate ? '' : ' (rate not verified yet)'}`);
  const cap = Number(arg('max-credits'));
  if (cap) console.log(need <= cap ? `Within your cap of ${cap.toLocaleString()} credits.` : `OVER your cap of ${cap.toLocaleString()} credits. Don't record; report this estimate first.`);
  const left = sub.ok ? sub.body.character_limit - sub.body.character_count : null;
  if (left != null) console.log(need <= left ? `Your balance covers it (${left.toLocaleString()} credits left).` : `Your balance (${left.toLocaleString()} credits) is not enough.`);
}

let contextOk = settings.context;
let seedOk = settings.seed != null;
let speedOk = settings.speed != null;
async function record(u) {
  const body = {
    text: u.sent,
    model_id: settings.model_id,
    voice_settings: { stability: settings.stability, similarity_boost: settings.similarity_boost },
  };
  if (speedOk) body.voice_settings.speed = settings.speed;
  if (seedOk) body.seed = settings.seed;
  if (contextOk) {
    if (u.previous) body.previous_text = u.previous;
    if (u.next) body.next_text = u.next;
  }
  const res = await send(`${apiBase}/v1/text-to-speech/${settings.voice_id}?output_format=${outputFormat}`, {
    method: 'POST',
    headers: { 'xi-api-key': key, 'Content-Type': 'application/json', Accept: 'audio/mpeg' },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const text = await res.text();
    // If this model doesn't accept a continuity option, carry on without it (a refused request isn't billed).
    if (res.status === 400 || res.status === 422) {
      if (contextOk && /previous_text|next_text/i.test(text)) {
        contextOk = false;
        console.log('  (this model doesn\'t accept neighbouring text; continuing without it)');
        return record(u);
      }
      if (speedOk && /speed/i.test(text)) {
        speedOk = false;
        console.log('  (this model doesn\'t accept a speed setting; continuing without it)');
        return record(u);
      }
      if (seedOk && /seed/i.test(text)) {
        seedOk = false;
        console.log('  (this model doesn\'t accept a seed; continuing without it)');
        return record(u);
      }
    }
    throw new Error(`ElevenLabs ${res.status}: ${text}`);
  }
  const cost = {};
  res.headers.forEach((value, name) => {
    if (/character|cost|credit/i.test(name)) cost[name] = value;
  });
  mkdirSync(dirname(u.file), { recursive: true });
  writeFileSync(u.file, Buffer.from(await res.arrayBuffer()));
  writeFileSync(u.file.replace(/\.mp3$/, '.json'), JSON.stringify({
    textHash: hash(u.sent), sent: u.sent, settings, usedContext: contextOk, usedSeed: seedOk, usedSpeed: speedOk, headers: cost, recordedAt: new Date().toISOString(),
  }, null, 2));
  const billed = Number(cost['x-character-count'] ?? cost['character-cost'] ?? NaN);
  return Number.isFinite(billed) ? billed : null;
}

// ---- Joining, levelling and the review sheet --------------------------------------------
const ff = (args) => execFileSync('ffmpeg', ['-hide_banner', '-nostdin', '-y', ...args], { stdio: ['ignore', 'pipe', 'pipe'] }).toString();
// ffmpeg prints its measurements to stderr.
const measure = (args) => {
  const r = spawnSync('ffmpeg', ['-hide_banner', '-nostdin', ...args, '-f', 'null', '-'], { encoding: 'utf8' });
  if (r.status !== 0) throw new Error(r.stderr);
  return r.stderr;
};
const loudnormJson = (text) => JSON.parse(text.slice(text.lastIndexOf('{'), text.lastIndexOf('}') + 1));
const duration = (file) => Number(execFileSync('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', file]).toString());
const median = (xs) => {
  const s = [...xs].sort((a, b) => a - b);
  return s.length ? s[Math.floor(s.length / 2)] : 0;
};

function assemble(r) {
  const s = r.s;
  if (r.units.some(u => !existsSync(u.file))) return null;
  const work = join(srcDir(s), '.build');
  mkdirSync(work, { recursive: true });
  const fmtArgs = ['-ar', '44100', '-ac', '1', '-c:a', 'pcm_s16le'];
  // Each recording: trim the silence ElevenLabs leaves at the very start and end, nothing else.
  const trim = 'silenceremove=start_periods=1:start_threshold=-50dB:start_silence=0.05,areverse,silenceremove=start_periods=1:start_threshold=-50dB:start_silence=0.15,areverse';
  const pieces = [];
  const sheet = [];
  const silences = new Map();
  const silence = (sec) => {
    const f = join(work, `silence-${sec}.wav`);
    if (!silences.has(sec)) {
      ff(['-f', 'lavfi', '-i', 'anullsrc=r=44100:cl=mono', '-t', String(sec), ...fmtArgs, f]);
      silences.set(sec, f);
    }
    return f;
  };
  let t = 0;
  let gap = 0;
  let first = true;
  const unitsById = new Map(r.units.map(u => [u.paras[0], u]));
  for (const item of s.items) {
    if (item.kind !== 'para') {
      gap += item.seconds;
      continue;
    }
    const u = unitsById.get(item.n);
    if (!u) continue; // a later paragraph inside a block
    const g = first ? gap : gap + paragraphGap;
    if (g > 0) {
      pieces.push(silence(Number(g.toFixed(2))));
      t += g;
    }
    first = false;
    gap = 0;
    const wav = join(work, `${u.id}.wav`);
    ff(['-i', u.file, '-af', trim, ...fmtArgs, wav]);
    const len = duration(wav);
    const loud = loudnormJson(measure(['-i', wav, '-af', 'loudnorm=print_format=json']));
    const words = (u.words.match(/[A-Za-z’'-]+/g) ?? []).length;
    const meta = JSON.parse(readFileSync(u.file.replace(/\.mp3$/, '.json'), 'utf8'));
    const fromGrounded = s.version === 'faith' && /\/grounded\//.test(meta.reusedFrom ?? '');
    sheet.push({ id: u.id, paras: u.paras, start: t, len, lufs: Number(loud.input_i), wpm: (words / len) * 60, tag: u.sent.match(/^\[[^\]]+\]/)?.[0] ?? '', words: u.words, fromGrounded });
    pieces.push(wav);
    t += len;
  }
  if (gap > 0) {
    pieces.push(silence(gap));
    t += gap;
  }
  const list = join(work, 'list.txt');
  writeFileSync(list, pieces.map(p => `file '${p.replace(/'/g, "'\\''")}'`).join('\n'));
  const joined = join(work, 'joined.wav');
  ff(['-f', 'concat', '-safe', '0', '-i', list, '-c', 'copy', joined]);
  // Two-pass levelling to −16 LUFS (linear, so Maren's own light and shade is kept).
  const m = loudnormJson(measure(['-i', joined, '-af', 'loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json']));
  const out = outFile(s);
  mkdirSync(dirname(out), { recursive: true });
  ff(['-i', joined, '-af', `loudnorm=I=-16:TP=-1.5:LRA=11:measured_I=${m.input_i}:measured_TP=${m.input_tp}:measured_LRA=${m.input_lra}:measured_thresh=${m.input_thresh}:offset=${m.target_offset}:linear=true`,
    '-ar', '44100', '-ac', '1', '-c:a', 'aac', '-b:a', '80k', '-movflags', '+faststart', out]);
  const total = duration(out);
  writeSheet(r, sheet, total, out);
  return total;
}

function verdict(total, version) {
  const t = TARGETS[version];
  const range = `${fmt(t.min)}–${fmt(t.max)}`;
  if (total >= t.min && total <= t.max) return `within ${range}`;
  if (total >= t.min - SLACK && total <= t.max + SLACK) return `a small exception (within 10 seconds of ${range}): fine if the pace sounds natural`;
  return `OUTSIDE ${range}: listen for pace before approving; the fix is a settings change or re-recording, never stretching or padding`;
}

function writeSheet(r, sheet, total, out) {
  const s = r.s;
  const lufs = median(sheet.map(x => x.lufs));
  const wpm = median(sheet.map(x => x.wpm));
  const lines = [
    `# Week ${s.week} · ${s.version === 'grounded' ? 'Grounded' : 'Faith-centered'} · ${s.title}`,
    '',
    `**File:** ${out.replace(root + '/', '')}  `,
    `**Length:** ${fmt(total)}, ${verdict(total, s.version)}  `,
    `**Narrator:** ${narrator} · ${settings.model_id} · stability ${settings.stability} · similarity ${settings.similarity_boost}${settings.seed != null ? ` · seed ${settings.seed}` : ''}  `,
    `**Script check:** every word sent matches the approved script.`,
    '',
    `Flags compare each recording with the rest of this meditation: **louder/quieter** means more than 3 dB from the typical level; **faster/slower** means more than 20% from the typical pace. They are hints for listening, not faults.${s.version === 'faith' ? ' **Grounded recording** marks paragraphs shared with the Grounded version; listen at the joins on either side of them.' : ''}`,
    '',
    `| # | Starts | Length | Tone | Pace (wpm) | Flags | Opening words |`,
    '|---|---|---|---|---|---|---|',
    ...sheet.map(x => {
      const flags = [];
      if (x.lufs - lufs > 3) flags.push('louder');
      if (lufs - x.lufs > 3) flags.push('quieter');
      if (x.wpm > wpm * 1.2) flags.push('faster');
      if (x.wpm < wpm * 0.8) flags.push('slower');
      const watch = Object.keys(pronounce).concat(listenFor).filter(w => x.words.includes(w));
      if (watch.length) flags.push(`check: ${watch.join(', ')}`);
      if (x.fromGrounded) flags.push('Grounded recording');
      return `| ${x.paras.length > 1 ? `${x.paras[0]}–${x.paras[x.paras.length - 1]}` : x.paras[0]} | ${fmt(x.start)} | ${x.len.toFixed(1)}s | ${x.tag} | ${Math.round(x.wpm)} | ${flags.join(', ')} | ${x.words.slice(0, 60)}… |`;
    }),
    '',
    'To redo a paragraph: `npm run meditations -- --week ' + s.week + ' --version ' + s.version + ' --only <numbers> --force --max-credits <limit>`',
    '',
  ];
  writeFileSync(out.replace(/\.m4a$/, '.review.md'), lines.join('\n'));
  const index = join(root, 'audio-out/meditations', narrator, 'durations.json');
  const all = existsSync(index) ? JSON.parse(readFileSync(index, 'utf8')) : {};
  all[`${folder(s.version)}/week-${pad(s.week)}`] = Math.round(total * 10) / 10;
  writeFileSync(index, JSON.stringify(Object.fromEntries(Object.entries(all).sort()), null, 2));
}

// ---- Run ---------------------------------------------------------------------------------
if (arg('check')) {
  await check();
  process.exit(0);
}
report();
if (arg('dry-run')) process.exit(0);

{
  const copies = rows.flatMap(r => r.units.filter(u => u.reuse)).map(u => ({
    u, audio: readFileSync(u.reuse.mp3), meta: u.reuse.meta,
  }));
  for (const { u, audio, meta } of copies) {
    mkdirSync(dirname(u.file), { recursive: true });
    writeFileSync(u.file, audio);
    writeFileSync(u.file.replace(/\.mp3$/, '.json'), JSON.stringify({ ...meta, reusedFrom: u.reuse.mp3.replace(root + '/', '') }, null, 2));
  }
}

// A listening preview: the finished meditation over a soundscape at the app's default levels
// (voice at full volume, the soundscape looped at 40%). Saved beside the file; never uploaded.
if (arg('preview')) {
  const name = typeof arg('ambience') === 'string' ? arg('ambience') : 'desert-dusk';
  const bed = join(root, 'assets/ambience', `${name}.m4a`);
  for (const r of rows) {
    const voice = outFile(r.s);
    if (!existsSync(voice)) {
      console.log(`Week ${r.s.week} ${r.s.version}: not recorded yet`);
      continue;
    }
    const out = voice.replace(/\.m4a$/, `.preview-${name}.m4a`);
    ff(['-i', voice, '-stream_loop', '-1', '-i', bed, '-filter_complex', '[1:a]volume=0.4[b];[0:a][b]amix=inputs=2:duration=first:normalize=0[m]', '-map', '[m]', '-ac', '2', '-c:a', 'aac', '-b:a', '128k', out]);
    console.log(`Week ${r.s.week} ${r.s.version}: ${out.replace(root + '/', '')}`);
  }
  process.exit(0);
}

if (arg('assemble')) {
  for (const r of rows) {
    const total = assemble(r);
    console.log(total == null ? `Week ${r.s.week} ${r.s.version}: not all paragraphs are recorded yet` : `Week ${r.s.week} ${r.s.version}: ${fmt(total)}, ${verdict(total, r.s.version)}`);
  }
  process.exit(0);
}

const toSend = rows.reduce((n, r) => n + r.todoSent, 0);
if (!toSend) {
  for (const r of rows.filter(r => r.units.some(u => u.reuse) && r.units.every(u => existsSync(u.file)))) {
    const total = assemble(r);
    console.log(`→ Week ${r.s.week} ${r.s.version}: ${fmt(total)}, ${verdict(total, r.s.version)}`);
  }
  console.log('\nNothing new to record. Use --assemble to rebuild the files, or --force with --only to redo paragraphs.');
  process.exit(0);
}
const limit = Number(arg('max-credits'));
if (!limit) {
  console.error('\nAdd --max-credits <number> to set the most this run may spend. Nothing was recorded.');
  process.exit(1);
}
if (!key) {
  console.error('\nFirst run:  read -rs ELEVENLABS_API_KEY && export ELEVENLABS_API_KEY   (paste your key, press Return)');
  process.exit(1);
}
if (!settings.voice_id) {
  console.error('\nAdd Maren\'s voice ID to scripts/elevenlabs.config.json first.');
  process.exit(1);
}
if (!/v4/i.test(settings.model_id)) {
  console.error(`\nMeditations are recorded with Eleven v4, but the settings say ${settings.model_id}. Nothing was recorded.`);
  process.exit(1);
}
// Only weeks Leah has approved can be recorded: the week 6 pilot, the week 7 sample, and batch 1
// (weeks 8–20, approved after she listened to the week 7 sample). Batch 2 is unlocked here once
// she approves batch 1.
const UNLOCKED_WEEKS = Array.from({ length: 37 }, (_, i) => i + 6); // weeks 6–42: Leah approved batch 1 and unlocked batch 2 (25 October 2026)
const locked = rows.filter(r => !UNLOCKED_WEEKS.includes(r.s.week) && r.todo.length).map(r => r.s.week);
if (locked.length) {
  console.error(`\nWeek ${[...new Set(locked)].join(', ')} isn't approved for recording yet (approved: weeks ${UNLOCKED_WEEKS[0]}–${UNLOCKED_WEEKS[UNLOCKED_WEEKS.length - 1]}). Nothing was recorded.`);
  process.exit(1);
}
// Use the model's verified rate when the key can read it.
const listed = await listedRate();
let rate = listed.rate ?? creditsPerChar;
const need = Math.ceil(toSend * rate);
console.log(`\nCredit rate: ${rate} per character${listed.rate ? ' (verified from your account)' : ' (not listed for this key; it is measured after the first paragraph)'}`);
if (need > limit && !arg('partial')) {
  console.error(`This needs about ${need.toLocaleString()} credits, more than --max-credits ${limit.toLocaleString()}. Nothing was recorded.`);
  process.exit(1);
}
const left = await balance();
if (left == null) {
  console.error('Couldn\'t read your ElevenLabs balance, so the credit check can\'t run. Nothing was recorded.');
  console.error('Run the free check (--check) to see why, and fix the key first.');
  process.exit(1);
}
if (need > left) {
  console.error(`This needs about ${need.toLocaleString()} credits, but your account has ${left.toLocaleString()} left. Nothing was recorded.`);
  process.exit(1);
}
if (!arg('yes')) {
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  const answer = await rl.question(`\nThis spends about ${Math.min(limit, need).toLocaleString()} ElevenLabs credits (your cap: ${limit.toLocaleString()}). Type yes to record: `);
  rl.close();
  if (answer.trim().toLowerCase() !== 'yes') {
    console.log('Nothing was recorded.');
    process.exit(0);
  }
}

const before = await creditsUsed();
let spent = 0;
let sentChars = 0;
let stopped = false;
for (const r of rows) {
  for (const u of r.todo) {
    const cost = Math.ceil(u.sent.length * rate);
    if (spent + cost > limit) {
      console.log(`\nStopped at the credit limit (${spent.toLocaleString()} of ${limit.toLocaleString()} used). Run the same command again later to continue; finished paragraphs are kept.`);
      stopped = true;
      break;
    }
    process.stdout.write(`Week ${r.s.week} ${r.s.version} ${u.id} (${u.sent.length} characters)… `);
    try {
      const billed = await record(u);
      spent += billed ?? cost;
      sentChars += u.sent.length;
      console.log(billed != null ? `done, ${billed} credits` : 'done');
      // After the first paragraph, confirm with your account that only the paragraph's own
      // characters were charged at the expected rate (not the neighbouring text as well).
      if (sentChars === u.sent.length && before != null) {
        const now = await creditsUsed();
        if (now != null) {
          const used = now - before;
          const measured = used / u.sent.length;
          const projected = Math.ceil(used + (toSend - u.sent.length) * measured);
          console.log(`  Credit check: ${used} credits for ${u.sent.length} characters (${measured.toFixed(2)} per character) → whole run about ${projected.toLocaleString()} credits`);
          if (used > cost * 1.2 + 5 || projected > limit) {
            console.log(`\nStopped after one paragraph: at the measured rate this run would cost about ${projected.toLocaleString()} credits (expected ${need.toLocaleString()}, cap ${limit.toLocaleString()}). Nothing else was recorded.`);
            console.log('The paragraph already recorded is kept and won\'t be charged again.');
            stopped = true;
            break;
          }
          rate = Math.max(rate, measured);
          spent = Math.max(spent, used);
        }
      }
    } catch (e) {
      console.log('failed');
      console.error(e.message);
      stopped = true;
      break;
    }
    await new Promise(res => setTimeout(res, 400));
  }
  if (stopped) break;
  if ((r.todo.length || r.units.some(u => u.reuse) || !existsSync(outFile(r.s))) && r.units.every(u => existsSync(u.file))) {
    const total = assemble(r);
    console.log(`→ Week ${r.s.week} ${r.s.version}: ${fmt(total)}, ${verdict(total, r.s.version)}. Review sheet: ${outFile(r.s).replace(root + '/', '').replace(/\.m4a$/, '.review.md')}`);
  }
}
const after = await creditsUsed();
console.log(`\nCharacters sent this run: ${sentChars.toLocaleString()}`);
if (before != null && after != null) {
  console.log(`Credits used this run (from your ElevenLabs account): ${(after - before).toLocaleString()}${sentChars ? ` → ${((after - before) / sentChars).toFixed(2)} credits per character sent` : ''}`);
} else console.log('To confirm credits used, compare your ElevenLabs usage page with the characters sent above.');
