#!/usr/bin/env bash
# Trims silence, evens out loudness and converts recordings for the app.
# Needs ffmpeg (Mac: brew install ffmpeg).
#
#   bash scripts/prepare-audio.sh maren        audio-src/maren/*  -> assets/voices/maren/*.m4a
#   bash scripts/prepare-audio.sh all          every coach folder in audio-src/
#   bash scripts/prepare-audio.sh ambience     audio-src/ambience/* -> assets/ambience/*.m4a
#
# Voices are levelled to -16 LUFS so every coach sounds equally loud, with a short lead-in
# and tail so phrases don't start or stop abruptly. Ambience is levelled quieter (-26 LUFS)
# and isn't trimmed, so loops stay seamless. Then run: npm run voices
set -euo pipefail
cd "$(dirname "$0")/.."
command -v ffmpeg >/dev/null || { echo "ffmpeg is not installed (Mac: brew install ffmpeg)"; exit 1; }

target="${1:-}"
[ -n "$target" ] || { echo "Usage: bash scripts/prepare-audio.sh <coach|all|ambience>"; exit 1; }

# Silence is trimmed gently so soft word endings and breaths aren't clipped: only near-
# silence (below -60 dB) is removed, 0.25 s of it is kept after the last sound, and the end
# fades out over 0.12 s so a phrase never stops abruptly.
convert_voice() { # in out
  ffmpeg -loglevel error -y -i "$1" -ac 1 -ar 44100 -af \
"silenceremove=start_periods=1:start_threshold=-55dB:start_silence=0.08,areverse,silenceremove=start_periods=1:start_threshold=-60dB:start_silence=0.25,afade=t=in:d=0.12,areverse,loudnorm=I=-16:TP=-1.5:LRA=11,adelay=120,apad=pad_dur=0.35" \
    -c:a aac -b:a 96k "$2"
}
convert_ambience() {
  ffmpeg -loglevel error -y -i "$1" -ac 2 -ar 44100 -af "loudnorm=I=-26:TP=-3:LRA=11" -c:a aac -b:a 128k "$2"
}

process_dir() { # src dest kind
  [ -d "$1" ] || { echo "No folder $1"; return; }
  mkdir -p "$2"
  shopt -s nullglob nocaseglob
  local n=0
  for f in "$1"/*.{mp3,m4a,wav}; do
    name="$(basename "${f%.*}")"
    rm -f "$2/$name.mp3" "$2/$name.m4a"
    if [ "$3" = ambience ]; then convert_ambience "$f" "$2/$name.m4a"; else convert_voice "$f" "$2/$name.m4a"; fi
    echo "  ✓ $2/$name.m4a"; n=$((n+1))
  done
  echo "$n file(s) from $1"
}

case "$target" in
  ambience) process_dir audio-src/ambience assets/ambience ambience ;;
  all) for d in audio-src/*/; do c="$(basename "$d")"; [ "$c" = ambience ] || [ "$c" = meditations ] || process_dir "audio-src/$c" "assets/voices/$c" voice; done ;;
  *) process_dir "audio-src/$target" "assets/voices/$target" voice ;;
esac
echo "Next: npm run voices, then restart the app."
