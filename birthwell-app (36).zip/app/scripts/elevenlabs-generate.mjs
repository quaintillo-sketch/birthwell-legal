// Generates one coach's recordings with the ElevenLabs API, using the exact phrase text
// and filenames from src/data/coaching.ts. A coach has one voice for both libraries;
// lines shared by Grounded and Faith-Centered are generated once. Output goes to audio-src/<coach>/ for review;
// run scripts/prepare-audio.sh afterwards to trim, level and copy into the app.
//
//   cp scripts/elevenlabs.config.example.json scripts/elevenlabs.config.json   (add voice IDs)
//   export ELEVENLABS_API_KEY=...            (your key stays on your computer)
//   npm run voices:generate -- --coach maren --dry-run    (shows lines and character count)
//   npm run voices:generate -- --coach maren              (both libraries; skips existing files)
//   npm run voices:generate -- --coach maren --mode faith (only lines used by one library)
//   npm run voices:generate -- --coach maren --category ack (only the end-of-contraction acknowledgments)
// Per-coach options in the config: "speed" (1.0 normal), "sentencePause" (seconds between
// sentences), "lineSpeed" and "spoken" (per-line fixes).
//   npm run voices:generate -- --coach maren --only grounded-breathe-02,faith-rest-01 --force   (redo some)
//
// This spends ElevenLabs credits, so it only ever does one coach per run.
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { COACHING } from '../src/data/coaching.ts';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const arg = (name) => {
  const i = process.argv.indexOf(`--${name}`);
  return i < 0 ? undefined : process.argv[i + 1] && !process.argv[i + 1].startsWith('--') ? process.argv[i + 1] : true;
};
const slug = arg('coach');
const coach = COACHING.find(c => c.slug === slug);
if (!coach) {
  console.error(`Choose a coach: --coach ${COACHING.map(c => c.slug).join(' | ')}`);
  process.exit(1);
}
const only = typeof arg('only') === 'string' ? new Set(arg('only').split(',')) : null;
const mode = arg('mode');
if (mode && mode !== 'grounded' && mode !== 'faith') {
  console.error('--mode must be grounded or faith');
  process.exit(1);
}
const category = typeof arg('category') === 'string' ? arg('category') : null;
const phrases = coach.phrases.filter(p => (!only || only.has(p.id)) && (!mode || p.modes.includes(mode)) && (!category || p.category === category));
const outDir = join(root, 'audio-src', coach.slug);
const todo = phrases.filter(p => arg('force') || !existsSync(join(outDir, `${p.id}.mp3`)));
// Quotation marks are for the screen; ellipses stay, since they read as pauses.
const strip = (t) => t.replace(/[“”"]/g, '');
// Per-coach options from the config (all optional):
//   "model_id"       this coach's model, e.g. Eleven v4 (otherwise the top-level model_id)
//   "spoken"         { "<id>": "…" } per-line spoken text; the on-screen text stays as written
//   v2 models:  "sentencePause" (seconds between sentences), "endPause" (silence after the
//               last word), "speed", "lineSpeed": { "<id>": 0.85 }
//   v3/v4 models (audio tags in square brackets):
//               "tone"         default direction for every line, e.g. "[warmly]"
//               "toneFor"      per kind of line: { "start", "breathe", "affirm", "encourage",
//                              "ack", "rest", "ground", "prayer", "preview", "volume" }
//               "lineTone"     { "<id>": "[softly]" } for a single line
let fileConfig = {};
try {
  fileConfig = JSON.parse(readFileSync(join(root, 'scripts/elevenlabs.config.json'), 'utf8'));
} catch {}
const v = fileConfig.voices?.[slug] ?? {};
const overrides = v.spoken ?? {};
const modelId = v.model_id ?? fileConfig.model_id ?? 'eleven_multilingual_v2';
// Eleven v3 and v4 understand audio tags but not v2's <break> tags.
const tagModel = /v3|v4/i.test(modelId);
const sentencePause = tagModel ? 0 : Number(v.sentencePause) || 0;
const endPause = tagModel ? 0 : Number(v.endPause) || 0;
const withPauses = (t) => (sentencePause ? t.replace(/([.!?…])\s+(?=\S)/g, `$1 <break time="${sentencePause}s" /> `) : t);
// A prayer addresses God directly ("Lord, …", "Jesus… be my peace", "Thank You, Lord").
const isPrayer = (t) => /\b(Lord( Jesus)?|Jesus|Holy Spirit)(,|…)\s/.test(t) || /\bThank You\b|\bI praise You\b|\bCome, Holy Spirit\b|^Pray with me/.test(t);
const toneFor = (p) => v.lineTone?.[p.id] ?? (isPrayer(p.text) ? v.toneFor?.prayer : undefined) ?? v.toneFor?.[p.category] ?? v.tone ?? '';
const spoken = (p) => {
  const base = strip(overrides[p.id] ?? p.text);
  if (tagModel) {
    const tone = toneFor(p);
    return tone ? `${tone} ${base}` : base;
  }
  const t = withPauses(base);
  return endPause ? `${t} <break time="${endPause}s" />` : t;
};
const chars = todo.reduce((n, p) => n + spoken(p).length, 0);

console.log(`${coach.slug}${mode ? ` (${mode})` : ''} [${modelId}]: ${todo.length} of ${phrases.length} recordings to generate, ${chars} characters.`);
if (arg('dry-run')) {
  todo.forEach(p => console.log(`  ${p.id.padEnd(12)} ${spoken(p)}`));
  process.exit(0);
}

const configPath = join(root, 'scripts/elevenlabs.config.json');
if (!existsSync(configPath)) {
  console.error('Missing scripts/elevenlabs.config.json (copy the .example file and add voice IDs).');
  process.exit(1);
}
const config = JSON.parse(readFileSync(configPath, 'utf8'));
const voice = config.voices?.[coach.slug];
const key = process.env.ELEVENLABS_API_KEY;
if (!voice?.voice_id || !key) {
  console.error(!key ? 'Set ELEVENLABS_API_KEY first.' : `Add a voice_id for ${coach.slug} in scripts/elevenlabs.config.json.`);
  process.exit(1);
}

mkdirSync(outDir, { recursive: true });
for (const p of todo) {
  const res = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voice.voice_id}?output_format=${config.output_format ?? 'mp3_44100_128'}`, {
    method: 'POST',
    headers: { 'xi-api-key': key, 'Content-Type': 'application/json', Accept: 'audio/mpeg' },
    body: JSON.stringify({
      text: spoken(p),
      model_id: modelId,
      voice_settings: tagModel
        ? // v3/v4 take stability and similarity; expression comes from the audio tags.
          { stability: voice.stability, similarity_boost: voice.similarity_boost }
        : {
            stability: voice.stability,
            similarity_boost: voice.similarity_boost,
            style: voice.style,
            use_speaker_boost: true,
            // 1.0 is normal; lower is slower (ElevenLabs allows roughly 0.7–1.2).
            // A line can have its own speed ("lineSpeed": { "<id>": 0.85 }) if it comes out rushed.
            ...(voice.lineSpeed?.[p.id] || voice.speed ? { speed: voice.lineSpeed?.[p.id] ?? voice.speed } : {}),
          },
    }),
  });
  if (!res.ok) {
    console.error(`  ✗ ${p.id}: ${res.status} ${await res.text()}`);
    process.exit(1);
  }
  writeFileSync(join(outDir, `${p.id}.mp3`), Buffer.from(await res.arrayBuffer()));
  console.log(`  ✓ ${p.id}`);
  await new Promise(r => setTimeout(r, 400));
}
console.log(`Done. Listen in audio-src/${coach.slug}/, then run: bash scripts/prepare-audio.sh ${coach.slug}`);
