// Writes src/data/meditationLibrary.ts from the approved scripts: each week's title,
// description and length, for both versions. Run after any script change:
//   node scripts/export-meditation-library.mjs
// tests/meditations.test.ts fails if the app's copy falls out of step with the scripts.

import { readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { estimateSeconds, loadScripts, MAREN_PACE } from './meditation-scripts.mjs';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');

export function buildLibrary(appRoot = root) {
  const library = {};
  for (const s of loadScripts(appRoot)) {
    const section = readFileSync(join(appRoot, 'docs/meditations', s.file), 'utf8')
      .split(`## Week ${s.week} · ${s.version === 'faith' ? 'Faith-centered' : 'Grounded'}`)[1]
      .split('\n---')[0];
    // "**Title:** Known / *before* / the beginning." → display lines, the second in italics.
    // A few titles have two parts ("Open / *hands.*").
    const title = /^\*\*Title:\*\* (.+)$/m.exec(section)[1].split(' / ').map(t => t.replace(/^\*|\*$/g, ''));
    const desc = /^\*\*Description:\*\* (.+)$/m.exec(section)[1].trim();
    if (title.length < 2 || title.length > 3) throw new Error(`Week ${s.week} ${s.version}: the title needs two or three parts`);
    (library[s.week] ??= {})[s.version] = { title, desc, seconds: Math.round(estimateSeconds(s, 1, MAREN_PACE)) };
  }
  return library;
}

export function renderLibrary(library) {
  const rows = Object.entries(library).map(([week, v]) => `  ${week}: ${JSON.stringify(v)},`);
  return [
    '// Generated from docs/meditations by scripts/export-meditation-library.mjs. Do not edit by hand.',
    '// Lengths are estimates at Maren’s pace; the player shows the recording’s real length.',
    '',
    "export type LibraryEntry = { title: string[]; desc: string; seconds: number };",
    'export const MEDITATION_LIBRARY: Record<number, { grounded: LibraryEntry; faith: LibraryEntry }> = {',
    ...rows,
    '};',
    '',
  ].join('\n');
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const out = join(root, 'src/data/meditationLibrary.ts');
  writeFileSync(out, renderLibrary(buildLibrary()));
  console.log(`Wrote ${out.replace(root + '/', '')}`);
}
