// Writes docs/coaching-scripts.md (for review) and docs/coaching-lines.csv (one row per
// recording, for ElevenLabs) from src/data/coaching.ts, so the documents match the app.
//   npm run scripts:export
import { writeFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { CATEGORY_INFO, COACHING, DISTRIBUTION, MODE_LABEL } from '../src/data/coaching.ts';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const NAMES = { maren: 'Maren · the midwife', jo: 'Jo · the best friend', esme: 'Esme · the anchor', ines: 'Ines · the poet', della: 'Della · the champion' };
const ORDER = Object.keys(DISTRIBUTION.faith);
const unique = COACHING.reduce((n, c) => n + c.phrases.length, 0);
const shared = COACHING.reduce((n, c) => n + c.phrases.filter(p => p.modes.length === 2).length, 0);

let md = `# BirthWell coaching scripts\n\nGenerated from \`src/data/coaching.ts\` by \`npm run scripts:export\`; edit that file, not this one.\n\n`;
md += `Two complete libraries per coach, **Grounded** and **Faith-Centered**, 24 phrases each: ${unique + shared} phrases in all. `;
md += `${shared} lines work in both modes and share one recording (marked ↔), so **${unique} unique recordings** are needed. `;
md += `The **ID** is the audio filename (\`assets/voices/<coach>/<id>.m4a\`).\n\n`;
md += `| Coach | Grounded | Faith-Centered | Shared | Unique recordings |\n|---|---|---|---|---|\n`;
for (const c of COACHING) {
  const s = c.phrases.filter(p => p.modes.length === 2).length;
  md += `| ${NAMES[c.slug]} | 24 | 24 | ${s} | ${c.phrases.length} |\n`;
}
md += `\n## Per mode, per coach\n\n| Category | Phrases | When it plays |\n|---|---|---|\n`;
for (const cat of ORDER) md += `| ${CATEGORY_INFO[cat].label}${CATEGORY_INFO[cat].faithLabel ? ` (Faith-Centered: ${CATEGORY_INFO[cat].faithLabel.toLowerCase()})` : ''} | ${DISTRIBUTION.grounded[cat] === DISTRIBUTION.faith[cat] ? DISTRIBUTION.faith[cat] : `${DISTRIBUTION.grounded[cat]} Grounded / ${DISTRIBUTION.faith[cat]} Faith-Centered`} | ${CATEGORY_INFO[cat].plays} |\n`;
for (const c of COACHING) {
  md += `\n---\n\n## ${NAMES[c.slug]}\n\n*Delivery (same voice in both modes):* ${c.delivery}\n`;
  for (const mode of ['grounded', 'faith']) {
    md += `\n### ${MODE_LABEL[mode]}\n`;
    for (const cat of ORDER) {
      const label = mode === 'faith' && CATEGORY_INFO[cat].faithLabel ? CATEGORY_INFO[cat].faithLabel : CATEGORY_INFO[cat].label;
      md += `\n**${label}**\n\n| ID | Phrase |\n|---|---|\n`;
      for (const p of c.phrases.filter(p => p.category === cat && p.modes.includes(mode))) md += `| \`${p.id}\` | ${p.text}${p.modes.length === 2 ? ' ↔' : ''} |\n`;
    }
  }
}
// Scripture used in the Faith-Centered library, with how each verse is applied.
const CONTEXT = {
  'Psalm 28:7': 'David’s psalm of trust: “The Lord is my strength and my shield; my heart trusts in him, and he helps me.” Quoted as a statement of trust, not a promise about outcome.',
  'Proverbs 31:25': 'From the portrait of a woman of strong character. Only the first half is quoted; “she laughs at the days to come” is left out so nothing implies how labor will go.',
  'Psalm 46:10': 'God’s call to stillness amid upheaval: “Be still, and know that I am God.” Used as an invitation to rest in God, the way it is commonly prayed devotionally.',
  'Psalm 23:2': 'The shepherd psalm: “He leads me beside still waters.” Used for rest and comfort.',
  'Psalm 139:14': 'Quoted accurately in the first person, as the psalmist prays it: “I praise You, for I am fearfully and wonderfully made.”',
  'Philippians 4:13': 'Paul writes about being content and sustained in every circumstance, plenty or need. Paraphrased as strength “for whatever this moment holds”, which is closer to Paul’s meaning than the common “achieve anything” reading. Not quoted.',
  '2 Corinthians 12:9': '“My grace is sufficient for you, for my power is made perfect in weakness.” Alluded to (“His grace is enough”) as comfort in hard moments, not a promise of ease.',
};
md += `\n---\n\n## Scripture in the Faith-Centered library\n\nEvery quotation and close paraphrase, checked for wording, attribution and context. Psalm 46:5 (“God is within her; she will not fall”) has been removed: it describes the city of God, not a person.\n\n| Coach | ID | Phrase | Reference | Context and use |\n|---|---|---|---|---|\n`;
for (const c of COACHING)
  for (const p of c.phrases.filter(p => p.scripture)) {
    const ref = p.scripture.replace(/ \((allusion|paraphrase)\)$/, '');
    md += `| ${c.slug} | \`${p.id}\` | ${p.text} | ${p.scripture} | ${CONTEXT[ref] ?? ''} |\n`;
  }
writeFileSync(join(root, 'docs/coaching-scripts.md'), md);

const csv = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
const rows = [['coach', 'filename', 'modes', 'category', 'text', 'delivery'].join(',')];
for (const c of COACHING) for (const p of c.phrases) rows.push([c.slug, `${p.id}.mp3`, p.modes.join('+'), p.category, p.text, c.delivery].map(csv).join(','));
writeFileSync(join(root, 'docs/coaching-lines.csv'), rows.join('\n') + '\n');
console.log(`Wrote docs/coaching-scripts.md and docs/coaching-lines.csv (${unique} recordings).`);
