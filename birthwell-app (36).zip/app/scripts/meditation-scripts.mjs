// Reads the approved meditation scripts (docs/meditations/weeks-*.md) and turns each one into
// the exact paragraphs and silences the meditation recorder sends to ElevenLabs.
// The scripts are the source of truth: nothing here edits them. Pronunciation fixes from the
// config change only the text sent to ElevenLabs, and checkIntegrity() proves the sent words
// still match the approved script exactly.
import { readFileSync } from 'node:fs';
import { join } from 'node:path';

export const SCRIPT_FILES = ['weeks-06-09.md', 'weeks-10-20.md', 'weeks-21-30.md', 'weeks-31-36.md', 'weeks-37-42.md'];

const MARKER = /^\[(pause|music) (\d+(?:\.\d+)?)s\]$/;
const TAG = /^\[(?!pause |music )([a-z][a-z ,-]*)\]\s+/;
// Italics marks and quotation marks are for the page; they aren't spoken.
export const unmark = (t) => t.replace(/[*“”"]/g, '');
// A Scripture line (a whole line in italics) that ends mid-sentence, with "," ";" or ":", is sent
// to ElevenLabs ending in a full stop, so Maren doesn't sound as if she's about to go on.
// Approved by Leah for recording only: the scripts keep their exact wording and punctuation.
const SCRIPTURE_LINE = /^\*[^*].*\*$/;
const endStop = (t) => t.replace(/[,;:](\*?)$/, '.$1');
const squash = (t) => t.replace(/\s+/g, ' ').trim();

// One script → { week, version, title, items }, where items are, in order:
//   { kind: 'para', n, tag, text }       text is the spoken words; tag is the active tone tag
//   { kind: 'pause' | 'music', seconds }
export function parseScript(section) {
  const [heading, ...lines] = section.split('\n');
  const m = /^Week (\d+) · (Grounded|Faith-centered)\s*$/.exec(heading);
  if (!m) return null;
  const script = {
    week: Number(m[1]),
    version: m[2] === 'Grounded' ? 'grounded' : 'faith',
    title: (lines.find(l => l.startsWith('**Title:**')) ?? '').replace('**Title:**', '').replace(/[*/]/g, '').replace(/\s+/g, ' ').trim(),
    items: [],
  };
  const body = lines.filter(l => !/^\*\*(Title|Description|Approach|Scripture):\*\*/.test(l) && l.trim() !== '---');
  let tag = '';
  let n = 0;
  let para = [];
  const flush = () => {
    if (!para.length) return;
    let text = para.join(' ');
    const t = TAG.exec(text);
    if (t) {
      tag = `[${t[1]}]`;
      text = text.slice(t[0].length);
    }
    const scripture = SCRIPTURE_LINE.test(text.trim());
    if (/\[[^\]]*\]/.test(text)) throw new Error(`Week ${script.week} ${script.version}: a bracket inside paragraph ${n + 1} isn't at its start: ${text.slice(0, 60)}…`);
    script.items.push({ kind: 'para', n: ++n, tag, text: squash(unmark(text)), scripture });
    para = [];
  };
  for (const raw of body) {
    const line = raw.trim();
    const marker = MARKER.exec(line);
    if (marker) {
      flush();
      script.items.push({ kind: marker[1], seconds: Number(marker[2]) });
    } else if (!line) flush();
    else para.push(line);
  }
  flush();
  return script;
}

export function loadScripts(root) {
  const scripts = [];
  for (const f of SCRIPT_FILES) {
    const doc = '\n' + readFileSync(join(root, 'docs/meditations', f), 'utf8');
    for (const s of doc.split('\n## ').slice(1)) {
      const script = parseScript(s);
      if (script) scripts.push({ ...script, file: f });
    }
  }
  return scripts;
}

// The approved words of a script, read independently of parseScript: every body line except
// markers and headers, with tone tags, italics and quotation marks removed, and the recording
// full stop applied to Scripture lines that end mid-sentence.
export function approvedWords(root, script) {
  const doc = '\n' + readFileSync(join(root, 'docs/meditations', script.file), 'utf8');
  const label = `Week ${script.week} · ${script.version === 'grounded' ? 'Grounded' : 'Faith-centered'}`;
  const section = doc.split('\n## ').find(s => s.split('\n')[0].trim() === label);
  const lines = section.split('\n').slice(1)
    .filter(l => !/^\*\*(Title|Description|Approach|Scripture):\*\*/.test(l) && l.trim() !== '---' && !MARKER.test(l.trim()))
    .map(l => l.trim().replace(TAG, ''))
    .map(l => (SCRIPTURE_LINE.test(l) ? endStop(l) : l));
  return squash(unmark(lines.join(' ')));
}

// Pronunciation fixes: { "Zephaniah": "Zeff-uh-NYE-uh" }. Whole words only, case-sensitive.
const escape = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const wordRe = (w) => new RegExp(`(?<![\\w’'])${escape(w)}(?![\\w’'])`, 'g');
export function applyPronunciations(text, pronounce = {}) {
  let out = text;
  for (const [word, said] of Object.entries(pronounce)) out = out.replace(wordRe(word), said);
  return out;
}
export function reversePronunciations(text, pronounce = {}) {
  let out = text;
  for (const [word, said] of Object.entries(pronounce)) out = out.replace(wordRe(said), word);
  return out;
}

// The requests sent for one script. unit "paragraph" (the default) sends each paragraph on its
// own, so any paragraph can be re-recorded alone; unit "block" sends the paragraphs between two
// silences together, a fallback if the pilot shows noticeable joins between paragraphs.
// Every request starts with its tone tag; inside a block a tag is repeated only when it changes.
export function buildUnits(script, { unit = 'paragraph', pronounce = {} } = {}) {
  const units = [];
  let current = null;
  for (const i of script.items) {
    if (i.kind !== 'para') {
      current = null;
      continue;
    }
    const words = applyPronunciations(i.scripture ? endStop(i.text) : i.text, pronounce);
    if (unit === 'block' && current) {
      const last = current.paras[current.paras.length - 1];
      current.sent += `\n\n${i.tag && i.tag !== last.tag ? `${i.tag} ` : ''}${words}`;
      current.paras.push(i);
    } else {
      current = { paras: [i], sent: i.tag ? `${i.tag} ${words}` : words };
      units.push(current);
    }
    if (unit !== 'block') current = null;
  }
  return units.map((u, k) => ({
    id: unit === 'block' ? `b${String(k + 1).padStart(2, '0')}` : `p${String(u.paras[0].n).padStart(2, '0')}`,
    paras: u.paras.map(p => p.n),
    words: u.paras.map(p => p.text).join(' '),
    sent: u.sent,
  }));
}

const ALL_TAGS = /\[(?!pause |music )[a-z][a-z ,-]*\]\s*/g;
export const tagChars = (sent) => (sent.match(ALL_TAGS) ?? []).join('').length;

// Proves the words sent to ElevenLabs are the approved words: strip the tags, undo the
// pronunciation fixes, join the requests in order, and compare with the script itself.
export function checkIntegrity(root, script, options = {}) {
  const pronounce = options.pronounce ?? {};
  const units = buildUnits(script, options);
  const back = squash(units.map(u => reversePronunciations(u.sent.replace(ALL_TAGS, ''), pronounce)).join(' '));
  const approved = approvedWords(root, script);
  const problems = [];
  if (back !== approved) {
    let i = 0;
    while (i < back.length && back[i] === approved[i]) i++;
    problems.push(`sent words differ from the approved script near: “${approved.slice(Math.max(0, i - 30), i + 30)}”`);
  }
  for (const p of script.items.filter(i => i.kind === 'para')) {
    if (reversePronunciations(applyPronunciations(p.text, pronounce), pronounce) !== p.text) {
      problems.push(`paragraph ${p.n}: a pronunciation fix can't be undone cleanly (does its spoken spelling also appear as a real word?)`);
    }
  }
  return problems;
}

// Rough length at a slow, natural 120 words a minute, the same estimate used for the scripts.
// speechRate scales the spoken part only (silences are exact): MAREN_PACE is Maren's measured
// pace from the Week 6 pilot, where she read about a fifth faster than 120 words a minute.
// Between two paragraphs there is a natural breath (paragraphGap); a [pause] is silence on top
// of that breath. Music at the start and end is silence of exactly its length.
export const MAREN_PACE = 0.78;
export function estimateSeconds(script, paragraphGap = 1, speechRate = 1) {
  let s = 0;
  let spoke = false;
  let silence = 0;
  for (const i of script.items) {
    if (i.kind === 'para') {
      const words = (i.text.match(/[A-Za-z’'-]+/g) ?? []).length;
      const sentences = (i.text.match(/[.?!…](\s|$)/g) ?? []).length;
      s += silence + (spoke ? paragraphGap : 0) + (words / 2 + 0.5 * Math.max(0, sentences - 1)) * speechRate;
      spoke = true;
      silence = 0;
    } else silence += i.seconds;
  }
  return s + silence;
}

export const fmt = (sec) => {
  const r = Math.round(sec);
  return `${Math.floor(r / 60)}:${String(r % 60).padStart(2, '0')}`;
};
