import AsyncStorage from '@react-native-async-storage/async-storage';
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { useColorScheme } from 'react-native';
import { EMPTY_BIRTH_PLAN, type BirthPlan } from '../data/birthPlan';
import { COACHES, RULES, type AmbienceId, type Faith, type Rule } from '../data/content';
import { EMPTY_ROTATION, type Frequency, type RotationState } from '../lib/coachingEngine';
import type { Contraction, Measure } from '../lib/labor';
import { dark, light, type Theme } from '../theme/tokens';

export type Appearance = 'light' | 'dark' | 'system';

export type Prefs = {
  onboarded: boolean;
  name: string;
  dueDate: string; // ISO date
  faith: Faith;
  coach: number;
  haptics: boolean;
  appearance: Appearance;
  coachVolume: number;
  soundVolume: number;
  coaching: Frequency; // how often the coach speaks in labor mode ('off' = silent)
  rotation: RotationState; // which phrases have played recently, so they don't repeat
  autoDownload: boolean; // download this week's meditation on Wi-Fi
  ambience: AmbienceId;
  musicLink: string; // the person's own playlist, opened in its app when ambience is 'own'
  duckMusic: boolean; // lower other apps' music while the coach speaks
  medVoice: number; // no longer used: Maren narrates every meditation (kept so saved settings still load)
  morning: string;
  checked: Record<string, boolean>;
  customItems: { id: string; label: string }[];
  rule: number; // index into RULES
  custom: Rule;
  measure: Measure;
  alert: boolean;
  provider: string;
  providerPhone: string;
  favorites: number[]; // favourite meditation weeks
  birthPlan: BirthPlan;
  // Labor session
  contractions: Contraction[]; // newest first
  activeStart: number | null;
  sampleSeeded: boolean;
};

const DEFAULTS: Prefs = {
  onboarded: false,
  name: 'Jenna',
  dueDate: '2027-02-03',
  faith: 'sec', // Grounded unless she chooses Faith-centered during onboarding
  coach: 0,
  haptics: true,
  appearance: 'light',
  coachVolume: 0.7,
  soundVolume: 0.4,
  coaching: 'balanced',
  rotation: EMPTY_ROTATION,
  autoDownload: true,
  ambience: 'desert',
  musicLink: '',
  duckMusic: true,
  medVoice: 3,
  morning: '7:00 AM',
  checked: { id: true, prefs: true, robe: true, balm: true, ties: true, outfit: true, seat: true },
  customItems: [],
  rule: 0,
  custom: { a: 5, l: 60, f: 60 },
  measure: 'start',
  alert: true,
  provider: 'Dr. Alvarez',
  providerPhone: '',
  favorites: [],
  birthPlan: EMPTY_BIRTH_PLAN,
  contractions: [],
  activeStart: null,
  sampleSeeded: false,
};

const KEY = 'birthwell.prefs.v1';

type Ctx = {
  ready: boolean;
  prefs: Prefs;
  set: (patch: Partial<Prefs> | ((p: Prefs) => Partial<Prefs>)) => void;
};

const AppContext = createContext<Ctx | null>(null);

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [prefs, setPrefs] = useState<Prefs>(DEFAULTS);
  const [ready, setReady] = useState(false);
  const saveTimer = useRef<ReturnType<typeof setTimeout>>(undefined);

  useEffect(() => {
    AsyncStorage.getItem(KEY)
      .then(raw => {
        if (!raw) return;
        const saved = JSON.parse(raw);
        // Earlier builds had a voice on/off switch instead of a coaching frequency.
        if (!saved.coaching && saved.voiceOn === false) saved.coaching = 'off';
        delete saved.voiceOn;
        delete saved.voicePrompts;
        // "How it's measured" was removed; timing is always start to start.
        delete saved.measure;
        setPrefs({ ...DEFAULTS, ...saved });
      })
      .catch(() => {})
      .finally(() => setReady(true));
  }, []);

  useEffect(() => {
    if (!ready) return;
    clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => AsyncStorage.setItem(KEY, JSON.stringify(prefs)).catch(() => {}), 300);
  }, [prefs, ready]);

  const set = useCallback<Ctx['set']>(patch => {
    setPrefs(p => ({ ...p, ...(typeof patch === 'function' ? patch(p) : patch) }));
  }, []);

  const value = useMemo(() => ({ ready, prefs, set }), [ready, prefs, set]);
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppStateProvider');
  return ctx;
}

// The coach chosen in Settings. Use useActiveCoach() for the one who actually speaks.
export function useCoach() {
  const { prefs } = useApp();
  return COACHES[prefs.coach] ?? COACHES[0];
}

export function useTheme(): Theme {
  const { prefs } = useApp();
  const system = useColorScheme();
  const isDark = prefs.appearance === 'dark' || (prefs.appearance === 'system' && system === 'dark');
  return isDark ? dark : light;
}

export function useRule() {
  const { prefs } = useApp();
  const isCustom = prefs.rule === 3;
  const rule: Rule = isCustom ? prefs.custom : RULES[prefs.rule].rule!;
  const minutes = (s: number) => (s % 60 === 0 ? String(s / 60) : (s / 60).toFixed(1));
  const short = isCustom ? `${rule.a}-${minutes(rule.l)}-${minutes(rule.f)}` : RULES[prefs.rule].short;
  return { rule, short, isCustom, index: prefs.rule };
}
