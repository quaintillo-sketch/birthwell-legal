import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { AppState, Platform } from 'react-native';
import { PREMIUM_PRICE_FALLBACK } from '../config/premium';
import { COACHES } from '../data/content';
import { effectiveCoach, nextEntitlement, type CachedEntitlement, type PurchaseOutcome } from '../lib/access';
import { setMeditationAccess } from '../lib/meditations';
import { createStore, type Store } from '../lib/purchases';
import { useApp } from './AppState';

// BirthWell Premium status for the whole app.
// - The App Store (through RevenueCat) is the source of truth.
// - The last verified answer is kept in the iOS Keychain, so Premium works offline and
//   immediately on launch. Being offline never removes it; only a store check that says
//   "not purchased" does (for example after a refund).

const CACHE_KEY = 'birthwell.premium.v1';
const cache = {
  async read(): Promise<CachedEntitlement | null> {
    try {
      const raw = Platform.OS === 'web' ? await AsyncStorage.getItem(CACHE_KEY) : await SecureStore.getItemAsync(CACHE_KEY);
      return raw ? (JSON.parse(raw) as CachedEntitlement) : null;
    } catch {
      return null;
    }
  },
  async write(v: CachedEntitlement) {
    const raw = JSON.stringify(v);
    try {
      if (Platform.OS === 'web') await AsyncStorage.setItem(CACHE_KEY, raw);
      else await SecureStore.setItemAsync(CACHE_KEY, raw);
    } catch {}
  },
  async clear() {
    try {
      if (Platform.OS === 'web') await AsyncStorage.removeItem(CACHE_KEY);
      else await SecureStore.deleteItemAsync(CACHE_KEY);
    } catch {}
  },
};

type Ctx = {
  ready: boolean;
  premium: boolean;
  price: string;
  storeKind: Store['kind'];
  busy: boolean;
  purchase: () => Promise<PurchaseOutcome>;
  restore: () => Promise<PurchaseOutcome>;
  refresh: () => Promise<void>;
  // Simulated store only: forget the cached status, as a reinstall would.
  forgetForTesting: () => Promise<void>;
};

const PremiumContext = createContext<Ctx | null>(null);

export function PremiumProvider({ children }: { children: ReactNode }) {
  const store = useRef<Store>(createStore()).current;
  const [state, setState] = useState<CachedEntitlement | null>(null);
  const [ready, setReady] = useState(false);
  const [price, setPrice] = useState(PREMIUM_PRICE_FALLBACK);
  const [busy, setBusy] = useState(false);
  const inFlight = useRef(false);
  const current = useRef<CachedEntitlement | null>(null);

  const apply = useCallback(async (next: CachedEntitlement) => {
    current.current = next;
    setState(next);
    await cache.write(next);
  }, []);

  const refresh = useCallback(async () => {
    const check = await store.check();
    await apply(nextEntitlement(current.current, check));
  }, [store, apply]);

  useEffect(() => {
    let alive = true;
    (async () => {
      const cached = await cache.read();
      if (!alive) return;
      current.current = cached;
      setState(cached);
      setReady(true); // the cached answer is good enough to start; the store check follows
      await store.init();
      setMeditationAccess({ storeKind: store.kind, appUserId: () => store.appUserId() });
      await refresh();
      const p = await store.price();
      if (alive && p) setPrice(p);
    })();
    const off = store.onChange(premium => apply({ premium, verifiedAt: Date.now() }));
    const sub = AppState.addEventListener('change', s => s === 'active' && refresh());
    return () => {
      alive = false;
      off();
      sub.remove();
    };
  }, [store, refresh, apply]);

  const run = useCallback(
    async (action: () => Promise<PurchaseOutcome>) => {
      if (inFlight.current) return 'pending' as PurchaseOutcome; // one at a time: no double charges
      inFlight.current = true;
      setBusy(true);
      try {
        const outcome = await action();
        if (outcome === 'purchased' || outcome === 'restored') await apply({ premium: true, verifiedAt: Date.now() });
        return outcome;
      } finally {
        inFlight.current = false;
        setBusy(false);
      }
    },
    [apply],
  );

  const purchase = useCallback(
    () => (current.current?.premium ? Promise.resolve<PurchaseOutcome>('restored') : run(() => store.purchase())),
    [run, store],
  );
  const restore = useCallback(() => run(() => store.restore()), [run, store]);
  const forgetForTesting = useCallback(async () => {
    await cache.clear();
    current.current = null;
    setState(null);
  }, []);

  const value = useMemo<Ctx>(
    () => ({ ready, premium: !!state?.premium, price, storeKind: store.kind, busy, purchase, restore, refresh, forgetForTesting }),
    [ready, state, price, store.kind, busy, purchase, restore, refresh, forgetForTesting],
  );
  return <PremiumContext.Provider value={value}>{children}</PremiumContext.Provider>;
}

export function usePremium() {
  const ctx = useContext(PremiumContext);
  if (!ctx) throw new Error('usePremium must be used inside PremiumProvider');
  return ctx;
}

// The coach who actually speaks (Maren for Free users), with her index.
export function useActiveCoach() {
  const { prefs } = useApp();
  const { premium } = usePremium();
  const index = effectiveCoach(prefs.coach, premium);
  return { index, coach: COACHES[index] ?? COACHES[0] };
}
