import { useState } from 'react';
import { Pressable, View } from 'react-native';
import { simulatedControls, simulator, type SimulatedNext } from '../lib/purchases';
import { usePremium } from '../state/Premium';
import type { Theme } from '../theme/tokens';
import { Kicker, Txt } from './Txt';

// Shown only while the simulated store is in use (Expo Go, web, or no RevenueCat key), so
// every purchase situation can be tried before Apple's sandbox. Never shown in an App Store
// build with RevenueCat configured.
export function SimulatedStorePanel({ t }: { t: Theme }) {
  const { premium, refresh, forgetForTesting } = usePremium();
  const [next, setNext] = useState<SimulatedNext>(simulator.next);
  const [offline, setOffline] = useState(simulator.offline);
  const chip = (label: string, on: boolean, onPress: () => void) => (
    <Pressable
      key={label}
      onPress={onPress}
      accessibilityRole="button"
      accessibilityState={{ selected: on }}
      style={{ paddingHorizontal: 12, height: 34, borderRadius: 17, justifyContent: 'center', borderWidth: 1, borderColor: on ? t.accent : t.rowLine, backgroundColor: on ? t.segActive : 'transparent' }}
    >
      <Txt w={500} size={13} color={t.text}>{label}</Txt>
    </Pressable>
  );
  return (
    <View style={{ marginTop: 40, padding: 16, borderRadius: 18, borderWidth: 1, borderStyle: 'dashed', borderColor: t.rowLine, gap: 12 }}>
      <Kicker color={t.muted}>Testing · simulated store</Kicker>
      <Txt size={12.5} lh={1.45} color={t.muted}>
        {`Real Apple purchases need a development or TestFlight build. Here you can try each case. Status: ${premium ? 'Premium' : 'Free'}.`}
      </Txt>
      <Txt w={500} size={13} color={t.text}>Next purchase will…</Txt>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        {(
          [
            ['success', 'Succeed'],
            ['cancel', 'Be cancelled'],
            ['pending', 'Need approval'],
            ['fail', 'Fail'],
          ] as const
        ).map(([v, label]) =>
          chip(label, next === v, () => {
            simulator.next = v;
            setNext(v);
          }),
        )}
      </View>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        {chip(offline ? 'Offline (on)' : 'Go offline', offline, () => {
          simulator.offline = !simulator.offline;
          setOffline(simulator.offline);
          refresh();
        })}
        {chip('Simulate reinstall', false, () => forgetForTesting())}
        {chip('Reset to Free', false, async () => {
          await simulatedControls.setOwned(false);
          await forgetForTesting();
        })}
      </View>
      <Txt size={11.5} lh={1.45} color={t.faint}>
        Reinstall clears this phone’s saved status but keeps the “Apple ID” purchase, so Restore Purchases brings Premium back.
      </Txt>
    </View>
  );
}
