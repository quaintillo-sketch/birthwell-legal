import { Alert, Modal, Platform, Pressable, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { night, nightSheet } from '../theme/tokens';
import { ShareIcon } from './icons';
import { Em, Txt } from './Txt';

// Leaving labor mode. The safe choices are big and first; clearing the log is a small
// link at the bottom, and asks once more, so it can't be tapped by accident.
export function EndSessionSheet({
  visible,
  count,
  onKeepTiming,
  onClose,
  onShare,
  onClear,
}: {
  visible: boolean;
  count: number;
  onKeepTiming: () => void;
  onClose: () => void;
  onShare: () => void;
  onClear: () => void;
}) {
  const insets = useSafeAreaInsets();
  const confirmClear = () => {
    if (Platform.OS === 'web') return onClear();
    Alert.alert('Clear tonight’s contractions?', 'This deletes the log and can’t be undone.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Clear', style: 'destructive', onPress: onClear },
    ]);
  };
  const button = (label: string, onPress: () => void, filled: boolean, icon?: boolean) => (
    <Pressable
      key={label}
      onPress={onPress}
      accessibilityRole="button"
      style={{
        height: 56,
        borderRadius: 28,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 10,
        backgroundColor: filled ? night.button : 'transparent',
        borderWidth: filled ? 0 : 1,
        borderColor: night.outline,
      }}
    >
      {icon && <ShareIcon color={night.text} size={15} />}
      <Txt w={500} size={16} color={filled ? night.buttonText : night.text}>{label}</Txt>
    </Pressable>
  );

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onKeepTiming}>
      <Pressable style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)' }} onPress={onKeepTiming} accessibilityLabel="Keep timing" />
      <View style={{ backgroundColor: nightSheet.bg, borderTopLeftRadius: 28, borderTopRightRadius: 28, paddingHorizontal: 28, paddingBottom: insets.bottom + 16 }}>
        <View style={{ alignItems: 'center', paddingTop: 10 }}>
          <View style={{ width: 40, height: 5, borderRadius: 3, backgroundColor: nightSheet.grabber }} />
        </View>
        <Txt serif size={34} lh={1.1} color={night.text} style={{ marginTop: 18 }}>
          Leave <Em color={night.accent}>labor mode?</Em>
        </Txt>
        <Txt size={14} lh={1.45} color={night.muted} style={{ marginTop: 8 }}>
          Your contractions stay saved unless you clear them.
        </Txt>
        <View style={{ gap: 10, marginTop: 22 }}>
          {button('Keep timing', onKeepTiming, false)}
          {button('Close, keep session', onClose, true)}
          {count > 0 && button('Share log', onShare, false, true)}
        </View>
        <Pressable onPress={confirmClear} hitSlop={10} accessibilityRole="button" style={{ alignSelf: 'center', marginTop: 20, paddingVertical: 6 }}>
          <Txt w={500} size={13.5} color={night.muted} style={{ textDecorationLine: 'underline' }}>End and clear the log</Txt>
        </Pressable>
      </View>
    </Modal>
  );
}
