import { View } from 'react-native';
import Svg, { Circle, Line, Path, Rect } from 'react-native-svg';

// Thin line-art stopwatch for the labor mode button (no filled backing).
export function Stopwatch({ color, size = 32 }: { color: string; size?: number }) {
  return (
    <Svg width={size} height={size * 1.125} viewBox="0 0 32 36">
      <Rect x={12.75} y={0.75} width={6.5} height={1.5} rx={0.75} stroke={color} strokeWidth={1.5} fill="none" />
      <Line x1={16} y1={3} x2={16} y2={7} stroke={color} strokeWidth={1.5} />
      <Circle cx={16} cy={21.5} r={13.25} stroke={color} strokeWidth={1.5} fill="none" />
      <Line x1={16} y1={13} x2={16} y2={21.5} stroke={color} strokeWidth={1.5} strokeLinecap="round" />
    </Svg>
  );
}

export function CloseX({ color, size = 12 }: { color: string; size?: number }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 12 12">
      <Line x1={1} y1={1} x2={11} y2={11} stroke={color} strokeWidth={1.5} strokeLinecap="round" />
      <Line x1={11} y1={1} x2={1} y2={11} stroke={color} strokeWidth={1.5} strokeLinecap="round" />
    </Svg>
  );
}

// Play triangle; `w` is the triangle width, height is 4/3 of it as in the design.
export function PlayGlyph({ color, w = 12 }: { color: string; w?: number }) {
  const h = (w * 4) / 3;
  return (
    <Svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{ marginLeft: w / 3 }}>
      <Path d={`M0 0 L${w} ${h / 2} L0 ${h} Z`} fill={color} />
    </Svg>
  );
}

export function PauseGlyph({ color }: { color: string }) {
  return (
    <View style={{ flexDirection: 'row', gap: 7 }}>
      <View style={{ width: 5, height: 24, borderRadius: 2, backgroundColor: color }} />
      <View style={{ width: 5, height: 24, borderRadius: 2, backgroundColor: color }} />
    </View>
  );
}

// Line-art gear for Settings (outline after Feather's "settings" icon, MIT).
export function Gear({ color, size = 18 }: { color: string; size?: number }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Circle cx={12} cy={12} r={3} stroke={color} strokeWidth={1.5} />
      <Path
        d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"
        stroke={color}
        strokeWidth={1.5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </Svg>
  );
}

export function ChevronLeft({ color, size = 12 }: { color: string; size?: number }) {
  return (
    <Svg width={size * 0.6} height={size} viewBox="0 0 7.2 12">
      <Path d="M6.2 1 L1.2 6 L6.2 11" stroke={color} strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round" fill="none" />
    </Svg>
  );
}

export function Check({ color, size = 12 }: { color: string; size?: number }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 12 12">
      <Path d="M1.5 6.5 L4.6 9.5 L10.5 2.5" stroke={color} strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round" fill="none" />
    </Svg>
  );
}

// Share: a box with an arrow leaving it, as on iOS.
export function ShareIcon({ color, size = 16 }: { color: string; size?: number }) {
  return (
    <Svg width={size * 0.8} height={size} viewBox="0 0 16 20">
      <Path d="M8 1 V12 M4.5 4.5 L8 1 L11.5 4.5" stroke={color} strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round" fill="none" />
      <Path d="M5 8 H2.5 A1.5 1.5 0 0 0 1 9.5 V17.5 A1.5 1.5 0 0 0 2.5 19 H13.5 A1.5 1.5 0 0 0 15 17.5 V9.5 A1.5 1.5 0 0 0 13.5 8 H11" stroke={color} strokeWidth={1.5} strokeLinecap="round" fill="none" />
    </Svg>
  );
}

export function Heart({ color, filled, size = 20 }: { color: string; filled?: boolean; size?: number }) {
  return (
    <Svg width={size} height={size * 0.9} viewBox="0 0 20 18">
      <Path
        d="M10 16.8 C4.2 12.6 1 9.6 1 5.9 C1 3.2 3.1 1.2 5.6 1.2 C7.4 1.2 9 2.2 10 3.8 C11 2.2 12.6 1.2 14.4 1.2 C16.9 1.2 19 3.2 19 5.9 C19 9.6 15.8 12.6 10 16.8 Z"
        stroke={color}
        strokeWidth={1.5}
        strokeLinejoin="round"
        fill={filled ? color : 'none'}
      />
    </Svg>
  );
}
