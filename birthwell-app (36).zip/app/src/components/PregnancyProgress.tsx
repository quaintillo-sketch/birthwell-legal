import { View } from 'react-native';
import type { Theme } from '../theme/tokens';
import { Kicker, Txt } from './Txt';

// Home · the trimester progress bar under the week number: weeks 1–40, with the trimester
// labels above (the current one in clay) and ticks at weeks 1, 20 and 40 below.
const TRIMESTERS = ['1st trimester', '2nd trimester', '3rd trimester'];
const pos = (week: number) => Math.min(1, Math.max(0, (week - 1) / 39));
// Trimester boundaries fall between weeks 13–14 and 27–28.
const EDGES = [0, pos(13.5), pos(27.5), 1];

// '#A96A4E' + 0.2 → 'rgba(169,106,78,0.2)'
function alpha(hex: string, a: number) {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}

export function PregnancyProgress({ week, t }: { week: number; t: Theme }) {
  const x = pos(week);
  const current = week <= 13 ? 0 : week <= 27 ? 1 : 2;
  return (
    <View
      accessible
      accessibilityRole="progressbar"
      accessibilityLabel={`Week ${week} of 40, ${TRIMESTERS[current]}`}
      accessibilityValue={{ min: 1, max: 40, now: Math.min(week, 40) }}
    >
      <View style={{ flexDirection: 'row', height: 22, alignItems: 'center' }}>
        {TRIMESTERS.map((label, i) => (
          <View
            key={label}
            style={{
              width: `${(EDGES[i + 1] - EDGES[i]) * 100}%`,
              alignItems: 'center',
            }}
          >
            {/* A dotted divider between trimesters (single-side dashed borders don't render on iOS). */}
            {i > 0 && (
              <View style={{ position: 'absolute', left: 0, top: 0, bottom: 0, justifyContent: 'space-between' }}>
                {[0, 1, 2, 3, 4, 5].map(d => <View key={d} style={{ width: 1, height: 2, backgroundColor: t.faint }} />)}
              </View>
            )}
            <Kicker size={10} color={i === current ? t.accent : t.faint}>{label}</Kicker>
          </View>
        ))}
      </View>

      <View style={{ height: 5, borderRadius: 2.5, backgroundColor: alpha(t.accent, 0.14), marginTop: 16 }}>
        <View style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: `${x * 100}%`, borderRadius: 2.5, backgroundColor: alpha(t.accent, 0.32) }} />
        <View
          style={{
            position: 'absolute',
            left: `${x * 100}%`,
            top: -6.5,
            width: 18,
            height: 18,
            marginLeft: -9,
            borderRadius: 9,
            backgroundColor: t.accent,
            borderWidth: 2,
            borderColor: t.bg,
            shadowColor: '#2E2420',
            shadowOpacity: 0.14,
            shadowRadius: 4,
            shadowOffset: { width: 0, height: 2 },
            elevation: 3,
          }}
        />
      </View>

      <View style={{ height: 30, marginTop: 12 }}>
        {[1, 20, 40].map(w => (
          <View key={w} style={{ position: 'absolute', left: `${pos(w) * 100}%`, width: 30, marginLeft: -15, alignItems: 'center' }}>
            <View style={{ width: 1, height: 7, backgroundColor: t.faint }} />
            <Txt size={12} color={t.muted} style={{ marginTop: 5 }}>{String(w)}</Txt>
          </View>
        ))}
      </View>
    </View>
  );
}
