import type { ReactNode } from 'react';
import { Pressable, View } from 'react-native';
import { Radio } from './controls';
import { PremiumTag } from './PremiumTag';
import { Txt } from './Txt';

export type ChoiceColors = { text: string; muted: string; accent: string; line: string; ring: string };

// A list of radio options with an optional sub-line, in the timer-settings style.
export function ChoiceList<T extends string | number>({
  options,
  value,
  onChange,
  c,
  indent = 0,
}: {
  options: { value: T; label: string; sub?: string; thumb?: ReactNode; locked?: boolean }[];
  value: T;
  onChange: (v: T) => void;
  c: ChoiceColors;
  indent?: number;
}) {
  return (
    <View style={{ paddingLeft: indent }}>
      {options.map(o => {
        const on = o.value === value;
        return (
          <Pressable
            key={String(o.value)}
            onPress={() => onChange(o.value)}
            accessibilityRole="radio"
            accessibilityState={{ selected: on }}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 14, paddingVertical: 12, borderTopWidth: 1, borderTopColor: c.line }}
          >
            <Radio selected={on} ring={on ? c.accent : c.ring} dot={c.accent} />
            {o.thumb}
            <View style={{ flex: 1, gap: 3 }}>
              <Txt size={15.5} color={c.text}>{o.label}</Txt>
              {!!o.sub && <Txt size={12.5} lh={1.4} color={c.muted}>{o.sub}</Txt>}
            </View>
            {o.locked && <PremiumTag color={c.accent} />}
          </Pressable>
        );
      })}
    </View>
  );
}

// Settings row that shows its current value and opens its options in place.
export function ChoiceRow<T extends string | number>({
  label,
  desc,
  options,
  value,
  onChange,
  open,
  onToggle,
  c,
}: {
  label: string;
  desc?: string;
  options: { value: T; label: string; sub?: string; thumb?: ReactNode; locked?: boolean }[];
  value: T;
  onChange: (v: T) => void;
  open: boolean;
  onToggle: () => void;
  c: ChoiceColors;
}) {
  const current = options.find(o => o.value === value)?.label ?? '';
  return (
    <View style={{ borderBottomWidth: 1, borderBottomColor: c.line }}>
      <Pressable
        onPress={onToggle}
        accessibilityRole="button"
        accessibilityState={{ expanded: open }}
        style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 16, minHeight: 54, paddingVertical: desc ? 14 : 0 }}
      >
        <View style={{ flex: 1, gap: 4 }}>
          <Txt size={17} color={c.text}>{label}</Txt>
          {!!desc && <Txt size={12.5} lh={1.4} color={c.muted}>{desc}</Txt>}
        </View>
        <Txt size={15} color={c.muted}>{`${current} ${open ? '⌃' : '›'}`}</Txt>
      </Pressable>
      {open && (
        <View style={{ paddingBottom: 8 }}>
          <ChoiceList options={options} value={value} onChange={onChange} c={c} indent={8} />
        </View>
      )}
    </View>
  );
}
