import { Modal, Pressable, ScrollView, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { firstPhrase, modeFor } from '../data/coaching';
import { AMBIENCE, COACHES } from '../data/content';
import { FREQUENCIES } from '../lib/coachingEngine';
import { hasRecording, playPhrase } from '../lib/coachVoice';
import { router } from 'expo-router';
import { useState } from 'react';
import { isAmbienceFree, isCoachFree } from '../lib/access';
import { useApp } from '../state/AppState';
import { usePremium } from '../state/Premium';
import { PremiumTag } from './PremiumTag';
import { ChoiceList, type ChoiceColors } from './ChoiceRow';
import { CoachPortrait } from './Coach';
import { SoundThumb } from './SoundThumb';
import { OwnMusic } from './OwnMusic';
import { Radio, Slider } from './controls';
import { Em, Kicker, Txt } from './Txt';

export type SheetColors = ChoiceColors & {
  bg: string;
  grabber: string;
  sliderTrack: string;
  sliderFill: string;
  thumb: string;
  thumbBorder: string;
  toggleOn: string;
  toggleOff: string;
  knob: string;
};

// Silent-switch behaviour, shown wherever coaching volume can be changed.
export const SILENT_SWITCH_NOTE =
  'Coaching and ambience play even when your iPhone is set to silent, so guidance isn’t lost at night, and the coach speaks over any music you’re playing rather than pausing it. To quiet her, choose Silent or lower the volume here.';

function Volume({ c, label, value, onChange }: { c: SheetColors; label: string; value: number; onChange: (v: number) => void }) {
  return (
    <View style={{ gap: 8, paddingTop: 12, paddingBottom: 10, borderTopWidth: 1, borderTopColor: c.line }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <Txt size={15.5} color={c.text}>{label}</Txt>
        <Txt size={15} color={c.muted}>{`${Math.round(value * 100)}%`}</Txt>
      </View>
      <Slider value={value} onChange={onChange} track={c.sliderTrack} fill={c.sliderFill} thumb={c.thumb} thumbBorder={c.thumbBorder} shadow="#000" />
    </View>
  );
}

// "Voice & sound" sheet. In labor mode it picks the labor coach and how often she speaks; in the
// meditation player it shows the narrator (Maren narrates every meditation). Both adjust
// volumes and ambience.
export function AudioSheet({ visible, onClose, mode, c }: { visible: boolean; onClose: () => void; mode: 'labor' | 'meditation'; c: SheetColors }) {
  const { prefs, set } = useApp();
  const insets = useSafeAreaInsets();
  const { premium } = usePremium();
  const [note, setNote] = useState<string | null>(null);
  // Labor coaches beyond Maren are Premium; the meditation voice isn't gated.
  const coachLocked = (i: number) => mode === 'labor' && !premium && !isCoachFree(i);
  const voiceIndex = coachLocked(prefs.coach) ? 0 : prefs.coach;

  // A Premium coach can always be previewed. Choosing one, or a Premium soundscape, shows a
  // short note instead; during labor it never opens the purchase screen.
  const pickVoice = (i: number) => {
    playPhrase(i, firstPhrase(i, modeFor(prefs.faith), 'preview'), prefs.coachVolume, { interrupt: true });
    if (coachLocked(i)) return setNote(`${COACHES[i].name} is part of BirthWell Premium. You’re hearing her preview.`);
    setNote(null);
    set({ coach: i });
  };
  const pickAmbience = (id: (typeof AMBIENCE)[number]['id']) => {
    if (!premium && !isAmbienceFree(id)) return setNote(`${AMBIENCE.find(a => a.id === id)?.name} is part of BirthWell Premium.`);
    setNote(null);
    set({ ambience: id });
  };
  const Note = () =>
    note ? (
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: 10 }}>
        <Txt size={12.5} lh={1.4} color={c.muted} style={{ flex: 1 }}>{note}</Txt>
        {mode !== 'labor' && (
          <Pressable
            onPress={() => {
              onClose();
              router.push('/premium');
            }}
            hitSlop={8}
            accessibilityRole="button"
          >
            <Txt w={500} size={13} color={c.accent}>See Premium</Txt>
          </Pressable>
        )}
      </View>
    ) : null;

  const Section = ({ children }: { children: string }) => <Kicker color={c.muted} style={{ marginTop: 26, marginBottom: 6 }}>{children}</Kicker>;
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <Pressable style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.45)' }} onPress={onClose} accessibilityLabel="Close" />
      <View style={{ maxHeight: '86%', backgroundColor: c.bg, borderTopLeftRadius: 28, borderTopRightRadius: 28, paddingBottom: insets.bottom + 12 }}>
        <View style={{ alignItems: 'center', paddingTop: 10 }}>
          <View style={{ width: 40, height: 5, borderRadius: 3, backgroundColor: c.grabber }} />
        </View>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline', paddingHorizontal: 28, paddingTop: 14 }}>
          <Txt serif size={34} lh={1} color={c.text}>
            Voice <Em color={c.accent}>&amp; sound</Em>
          </Txt>
          <Pressable onPress={onClose} hitSlop={12} accessibilityRole="button">
            <Txt w={500} size={15} color={c.accent}>Done</Txt>
          </Pressable>
        </View>
        <ScrollView contentContainerStyle={{ paddingHorizontal: 28, paddingBottom: 12 }} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled" automaticallyAdjustKeyboardInsets>
          {mode === 'meditation' && (
            <>
              <Section>Narrator</Section>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14, paddingVertical: 10, borderTopWidth: 1, borderTopColor: c.line }}>
                <CoachPortrait coach={COACHES[0]} bg={c.bg} />
                <Txt serif size={22} lh={1.1} color={c.text} style={{ flex: 1 }}>
                  {COACHES[0].name} <Em color={c.muted}>narrates every meditation</Em>
                </Txt>
              </View>
            </>
          )}
          {mode === 'labor' && <Section>Your coach</Section>}
          {mode === 'labor' &&
            COACHES.map((coach, i) => (
            <Pressable
              key={coach.name}
              onPress={() => pickVoice(i)}
              accessibilityRole="radio"
              accessibilityState={{ selected: i === voiceIndex }}
              style={{ flexDirection: 'row', alignItems: 'center', gap: 14, paddingVertical: 10, borderTopWidth: 1, borderTopColor: c.line }}
            >
              <CoachPortrait coach={coach} bg={c.bg} />
              <View style={{ flex: 1 }}>
                <Txt serif size={22} lh={1.1} color={c.text}>
                  {coach.name} <Em color={c.muted}>{coach.role}</Em>
                </Txt>
              </View>
              {coachLocked(i) && <PremiumTag color={c.accent} />}
              <Radio selected={i === voiceIndex} ring={i === voiceIndex ? c.accent : c.ring} dot={c.accent} />
            </Pressable>
          ))}
          <Note />
          {mode === 'labor' && (
            <Txt size={12.5} lh={1.4} color={c.muted} style={{ marginTop: 6 }}>
              {hasRecording(voiceIndex, firstPhrase(voiceIndex, modeFor(prefs.faith), 'preview').id)
                ? 'Tap a voice to hear it.'
                : 'Tap a voice to hear it. Until recordings are added, your iPhone’s built-in voice reads the words.'}
            </Txt>
          )}

          {mode === 'labor' && (
            <>
              <Section>Coaching</Section>
              <ChoiceList options={FREQUENCIES} value={prefs.coaching} onChange={coaching => set({ coaching })} c={c} />
            </>
          )}
          <View style={{ marginTop: mode === 'labor' ? 8 : 14 }}>
            <Volume c={c} label={mode === 'labor' ? 'Coach volume' : 'Voice volume'} value={prefs.coachVolume} onChange={coachVolume => set({ coachVolume })} />
          </View>

          <Section>Ambience</Section>
          <ChoiceList
            options={AMBIENCE.map(a => ({ value: a.id, label: a.name, sub: a.sub, thumb: <SoundThumb id={a.id} ring={c.ring} />, locked: !premium && !isAmbienceFree(a.id) }))}
            value={!premium && !isAmbienceFree(prefs.ambience) ? 'desert' : prefs.ambience}
            onChange={pickAmbience}
            c={c}
          />
          <Note />
          {prefs.ambience === 'own' && <OwnMusic c={c} />}
          {prefs.ambience !== 'off' && prefs.ambience !== 'own' && <Volume c={c} label="Sound volume" value={prefs.soundVolume} onChange={soundVolume => set({ soundVolume })} />}
          <Txt size={12.5} lh={1.4} color={c.muted} style={{ marginTop: 14 }}>{SILENT_SWITCH_NOTE}</Txt>
        </ScrollView>
      </View>
    </Modal>
  );
}
