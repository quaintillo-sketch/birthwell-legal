import { useEffect, useRef } from 'react';
import { Animated, View, type NativeScrollEvent, type NativeSyntheticEvent } from 'react-native';
import { fonts } from '../theme/tokens';

const ITEM = 52;
const VISIBLE = 5;

// One column of the editorial date wheel: the centred row is 36pt, neighbours shrink to
// 26pt / 22pt and fade to .45 / .2, matching the onboarding due-date design (1c).
export function WheelColumn({
  items,
  index,
  onChange,
  align,
  color,
  flex,
}: {
  items: string[];
  index: number;
  onChange: (i: number) => void;
  align: 'left' | 'center' | 'right';
  color: string;
  flex: number;
}) {
  const y = useRef(new Animated.Value(index * ITEM)).current;
  const ref = useRef<any>(null);
  const current = useRef(index);

  useEffect(() => {
    if (index !== current.current) {
      current.current = index;
      ref.current?.scrollTo({ y: index * ITEM, animated: true });
    }
  }, [index]);

  const settle = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    const i = Math.min(items.length - 1, Math.max(0, Math.round(e.nativeEvent.contentOffset.y / ITEM)));
    if (i !== current.current) {
      current.current = i;
      onChange(i);
    }
  };

  const origin = align === 'left' ? 'left' : align === 'right' ? 'right' : 'center';
  return (
    <View style={{ flex, height: ITEM * VISIBLE }}>
      <Animated.ScrollView
        ref={ref}
        showsVerticalScrollIndicator={false}
        nestedScrollEnabled
        snapToInterval={ITEM}
        decelerationRate="fast"
        contentOffset={{ x: 0, y: index * ITEM }}
        // contentOffset is ignored on web and Android; position the wheel once laid out.
        onLayout={() => ref.current?.scrollTo({ y: current.current * ITEM, animated: false })}
        contentContainerStyle={{ paddingVertical: ITEM * 2 }}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y } } }], { useNativeDriver: true })}
        scrollEventThrottle={16}
        onMomentumScrollEnd={settle}
        onScrollEndDrag={e => {
          // Without momentum (a slow drag) only this event fires.
          if (!e.nativeEvent.velocity || Math.abs(e.nativeEvent.velocity.y) < 0.05) settle(e);
        }}
      >
        {items.map((label, i) => {
          const range = [(i - 2) * ITEM, (i - 1) * ITEM, i * ITEM, (i + 1) * ITEM, (i + 2) * ITEM];
          const scale = y.interpolate({ inputRange: range, outputRange: [22 / 36, 26 / 36, 1, 26 / 36, 22 / 36], extrapolate: 'clamp' });
          const opacity = y.interpolate({ inputRange: range, outputRange: [0.2, 0.45, 1, 0.45, 0.2], extrapolate: 'clamp' });
          return (
            <Animated.Text
              key={label + i}
              onPress={() => {
                current.current = i;
                ref.current?.scrollTo({ y: i * ITEM, animated: true });
                onChange(i);
              }}
              style={{
                height: ITEM,
                lineHeight: ITEM,
                fontFamily: fonts.serif,
                fontSize: 36,
                color,
                textAlign: align,
                opacity,
                transform: [{ scale }],
                transformOrigin: origin,
              }}
            >
              {label}
            </Animated.Text>
          );
        })}
      </Animated.ScrollView>
    </View>
  );
}

export const WHEEL_ITEM = ITEM;
