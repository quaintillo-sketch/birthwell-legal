import { Platform, StyleSheet, Text, type TextProps, type TextStyle } from 'react-native';
import { fonts } from '../theme/tokens';

type Props = TextProps & {
  serif?: boolean;
  italic?: boolean;
  w?: 400 | 500 | 600;
  size: number;
  lh?: number; // line-height as a multiple of size, like CSS `font: 16px/1.4`
  ls?: number; // letter-spacing in em
  color?: string;
  upper?: boolean;
  align?: TextStyle['textAlign'];
  tabular?: boolean;
};

// Instrument Serif needs ~1.3em of vertical room (ascent .99 + descent .31). On iOS a tighter
// line box keeps the descent at the bottom and pushes ascenders out of the top, where they are
// clipped. Below this line height, serif text gets invisible padding instead.
const SERIF_SAFE_LH = 1.12;

// Distance from the bottom of a serif text box to its baseline, for lining up smaller text
// with the foot of a big number. iOS keeps the whole descent (.31em) at the bottom of a tight
// line box; the web centres the glyphs in it.
export function serifBaselineFromBottom(size: number, lh: number) {
  if (Platform.OS === 'ios') return 0.31 * size;
  const box = lh * size;
  return box - ((box - 1.3 * size) / 2 + 0.99 * size);
}

type Side = 'Top' | 'Bottom' | 'Left' | 'Right';

// The caller's own margin or padding on one side, so the extra room adds to it.
function own(flat: TextStyle, kind: 'margin' | 'padding', side: Side) {
  const axis = side === 'Top' || side === 'Bottom' ? flat[`${kind}Vertical`] : flat[`${kind}Horizontal`];
  return flat[`${kind}${side}`] ?? axis ?? flat[kind] ?? 0;
}

// Adds `pad` padding on each side and cancels it with negative margin. A side whose caller
// value isn't a number (such as `marginTop: 'auto'`) keeps the caller's value.
function compensate(flat: TextStyle, pads: Record<Side, number>): TextStyle {
  const out: Record<string, number> = {};
  for (const side of Object.keys(pads) as Side[]) {
    if (!pads[side]) continue;
    const p = own(flat, 'padding', side), m = own(flat, 'margin', side);
    if (typeof p !== 'number' || typeof m !== 'number') continue;
    out[`padding${side}`] = p + pads[side];
    out[`margin${side}`] = m - pads[side];
  }
  return out;
}

export function Txt({ serif, italic, w = 400, size, lh, ls, color, upper, align, tabular, style, ...rest }: Props) {
  const fontFamily = serif ? (italic ? fonts.serifItalic : fonts.serif) : w === 600 ? fonts.sans600 : w === 500 ? fonts.sans500 : fonts.sans400;

  // Room for glyph ink that falls outside the measured box: tight serif leading (top),
  // negative tracking, which iOS also applies after the last glyph (right), and italic
  // overhang on either side. Each pad is cancelled by an equal negative margin, so layout
  // matches the design exactly.
  const padTop = serif && lh !== undefined && lh < SERIF_SAFE_LH ? Math.ceil((SERIF_SAFE_LH - lh) * size) : 0;
  const padBottom = Math.ceil(padTop / 2);
  const padRight = Math.ceil(((ls && ls < 0 ? -ls : 0) + (serif ? 0.06 : 0)) * size);
  const padLeft = serif && italic ? Math.ceil(0.05 * size) : 0;
  const flat = (StyleSheet.flatten(style) ?? {}) as TextStyle;

  return (
    <Text
      {...rest}
      style={[
        {
          fontFamily,
          fontSize: size,
          lineHeight: lh ? Math.round(size * lh) : undefined,
          letterSpacing: ls ? ls * size : undefined,
          color,
          textTransform: upper ? 'uppercase' : undefined,
          textAlign: align,
          fontVariant: tabular ? ['tabular-nums'] : undefined,
        },
        style,
        compensate(flat, { Top: padTop, Bottom: padBottom, Right: padRight, Left: padLeft }),
      ]}
    />
  );
}

// Tracked-out small caps label used across the app (600 10.5px, .16em).
export function Kicker({ size = 10.5, ...props }: Omit<Props, 'size' | 'upper' | 'w'> & { size?: number }) {
  return <Txt w={600} size={size} lh={1} ls={props.ls ?? 0.16} upper {...props} />;
}

// Nested italic span; inherits size from the parent Txt.
export function Em({ color, children }: { color?: string; children: React.ReactNode }) {
  return <Text style={{ fontFamily: fonts.serifItalic, color }}>{children}</Text>;
}
