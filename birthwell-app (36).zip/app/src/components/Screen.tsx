import { StatusBar } from 'expo-status-bar';
import type { ReactNode } from 'react';
import { ScrollView, View, type ViewStyle } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

// Full-bleed screen: background colour, status bar style and safe-area padding.
// `scroll` keeps `marginTop: 'auto'` footers pinned when content is short.
export function Screen({
  bg,
  darkContent,
  children,
  scroll,
  padding,
  bottom = 44,
}: {
  bg: string;
  darkContent: boolean;
  children: ReactNode;
  scroll?: boolean;
  padding: ViewStyle;
  bottom?: number; // bottom padding including the home indicator area, as in the 852pt mockups
}) {
  const insets = useSafeAreaInsets();
  const inner: ViewStyle = { ...padding, paddingBottom: Math.max(bottom, insets.bottom + 10) };
  return (
    <View style={{ flex: 1, backgroundColor: bg, paddingTop: insets.top }}>
      <StatusBar style={darkContent ? 'dark' : 'light'} />
      {scroll ? (
        <ScrollView style={{ flex: 1 }} contentContainerStyle={[{ flexGrow: 1 }, inner]} showsVerticalScrollIndicator={false}>
          {children}
        </ScrollView>
      ) : (
        <View style={[{ flex: 1 }, inner]}>{children}</View>
      )}
    </View>
  );
}
