import { Animated, Pressable, type ViewStyle } from 'react-native';
import { palette } from '../theme/tokens';
import { useFade } from './controls';
import { Txt } from './Txt';

// 58pt espresso pill used for Begin / Continue.
export function PrimaryButton({ label, onPress, style }: { label: string; onPress: () => void; style?: ViewStyle }) {
  const fade = useFade();
  return (
    <Pressable onPress={onPress} onPressIn={fade.onPressIn} onPressOut={fade.onPressOut} accessibilityRole="button" style={style}>
      <Animated.View style={[{ height: 58, borderRadius: 29, backgroundColor: palette.espresso, alignItems: 'center', justifyContent: 'center' }, fade.style]}>
        <Txt w={500} size={16} ls={0.02} color={palette.ivory}>{label}</Txt>
      </Animated.View>
    </Pressable>
  );
}
