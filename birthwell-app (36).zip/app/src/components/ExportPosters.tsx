import type { Ref } from 'react';
import { View } from 'react-native';
import type { PosterRef } from '../lib/exportDoc';
import { PLAN_DETAILS, PLAN_NOTE, PLAN_SECTIONS, type BirthPlan } from '../data/birthPlan';
import { light, palette } from '../theme/tokens';
import { Em, Kicker, Txt } from './Txt';

// Image versions of the Bag and Birth plan, always in the light paper style so they look
// the same in Photos or Messages whatever the app's theme. They're rendered off-screen and
// captured with react-native-view-shot when "Save as image" is chosen.

const t = light;
const WIDTH = 420;

function Frame({ ref, title, kicker, children }: { ref: Ref<PosterRef>; title: [string, string]; kicker: string; children: React.ReactNode }) {
  return (
    <View
      ref={ref}
      collapsable={false}
      pointerEvents="none"
      style={{ position: 'absolute', left: -10000, top: 0, width: WIDTH, backgroundColor: t.bg, paddingHorizontal: 32, paddingTop: 40, paddingBottom: 32 }}
    >
      <Txt serif size={54} lh={1} ls={-0.01} color={t.text}>
        {title[0]} <Em color={t.accent}>{title[1]}</Em>
      </Txt>
      <Kicker color={t.muted} style={{ marginTop: 14 }}>{kicker}</Kicker>
      {children}
      <Kicker color={t.accent} style={{ marginTop: 26 }}>Made with BirthWell</Kicker>
    </View>
  );
}

function Check({ label, on, note }: { label: string; on: boolean; note?: string }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 9, borderTopWidth: 1, borderTopColor: t.rowLine }}>
      <View
        style={{
          width: 18,
          height: 18,
          borderRadius: 9,
          borderWidth: 1.2,
          borderColor: on ? t.check.fill : t.check.box,
          backgroundColor: on ? t.check.fill : 'transparent',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        {on && <Txt w={600} size={9} color={t.check.mark}>✓</Txt>}
      </View>
      <Txt size={14} lh={1.35} color={on && note !== undefined ? t.check.doneText : t.text} style={{ flex: 1 }}>{label}</Txt>
      {!!note && <Txt size={12} color={t.faint}>{note}</Txt>}
    </View>
  );
}

const Heading = ({ children }: { children: string }) => (
  <Txt serif italic size={22} color={t.text} style={{ marginTop: 22, paddingBottom: 4 }}>{children}</Txt>
);

export function BagPoster({
  ref,
  groups,
  checked,
  packed,
  total,
}: {
  ref: Ref<PosterRef>;
  groups: { name: string; items: { id: string; label: string; note: string }[] }[];
  checked: Record<string, boolean>;
  packed: number;
  total: number;
}) {
  return (
    <Frame ref={ref} title={['The', 'bag']} kicker={`Hospital bag · ${packed} of ${total} packed`}>
      {groups.map(g => (
        <View key={g.name}>
          <Heading>{g.name}</Heading>
          {g.items.map(it => <Check key={it.id} label={it.label} on={!!checked[it.id]} note={it.note} />)}
        </View>
      ))}
    </Frame>
  );
}

export function PlanPoster({ ref, plan, name, due, provider }: { ref: Ref<PosterRef>; plan: BirthPlan; name: string; due: string; provider: string }) {
  const details = [{ label: 'Provider', value: provider }, ...PLAN_DETAILS.map(d => ({ label: d.label, value: plan.details[d.id]?.trim() ?? '' }))].filter(d => d.value);
  return (
    <Frame ref={ref} title={['Birth', 'plan']} kicker={`${name} · Due ${due}`}>
      <View style={{ marginTop: 18 }}>
        {details.map(d => (
          <View key={d.label} style={{ flexDirection: 'row', gap: 12, paddingVertical: 8, borderTopWidth: 1, borderTopColor: t.rowLine }}>
            <Txt size={12} color={t.muted} style={{ width: 120 }}>{d.label}</Txt>
            <Txt size={14} color={t.text} style={{ flex: 1 }}>{d.value}</Txt>
          </View>
        ))}
      </View>
      {PLAN_SECTIONS.map(s => {
        const picked = s.options.filter(o => plan.picks[o.id]);
        const note = plan.notes[s.id]?.trim();
        if (!picked.length && !note) return null;
        return (
          <View key={s.id}>
            <Heading>{s.title}</Heading>
            {picked.map(o => <Check key={o.id} label={o.label} on />)}
            {!!note && (
              <Txt serif italic size={16} lh={1.35} color={palette.espresso} style={{ paddingTop: 8, borderTopWidth: 1, borderTopColor: t.rowLine }}>{note}</Txt>
            )}
          </View>
        );
      })}
      <Txt serif italic size={14.5} lh={1.4} color={t.muted} style={{ marginTop: 24 }}>{PLAN_NOTE}</Txt>
    </Frame>
  );
}
