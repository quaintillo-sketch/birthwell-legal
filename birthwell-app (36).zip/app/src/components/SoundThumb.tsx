import Svg, { Circle, ClipPath, Defs, G, Line, LinearGradient, Path, RadialGradient, Stop } from 'react-native-svg';
import type { AmbienceId } from '../data/content';
import { palette } from '../theme/tokens';

// Small round illustrations for the soundscapes, drawn only in the BirthWell palette
// (clay, dusk rose, sand, sage, plum, espresso, ivory, and tints of them) so they sit
// naturally beside the coach portraits in light and dark themes.

const S = 40;

function Grad({ id, from, to, radial }: { id: string; from: string; to: string; radial?: boolean }) {
  return (
    <Defs>
      {radial ? (
        <RadialGradient id={id} cx="50%" cy="60%" r="60%">
          <Stop offset="0" stopColor={from} />
          <Stop offset="1" stopColor={to} />
        </RadialGradient>
      ) : (
        <LinearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <Stop offset="0" stopColor={from} />
          <Stop offset="1" stopColor={to} />
        </LinearGradient>
      )}
    </Defs>
  );
}

export function SoundThumb({ id, size = S, ring }: { id: AmbienceId; size?: number; ring: string }) {
  const art = (() => {
    switch (id) {
      case 'desert': // sun setting behind a dune
        return (
          <>
            <Grad id="g-desert" from={palette.duskRose} to={palette.clay} />
            <Circle cx={20} cy={20} r={20} fill="url(#g-desert)" />
            <Circle cx={24} cy={22} r={6} fill={palette.cream} opacity={0.9} />
            <Path d="M0 27 Q 12 20 24 26 T 40 25 V40 H0 Z" fill={palette.clayDeep} />
            <Path d="M0 32 Q 14 27 40 33 V40 H0 Z" fill="#6B4030" />
          </>
        );
      case 'rain': // rain over pines
        return (
          <>
            <Grad id="g-rain" from={palette.sand} to={palette.sage} />
            <Circle cx={20} cy={20} r={20} fill="url(#g-rain)" />
            {[6, 12, 18, 24, 30, 36].map((x, i) => (
              <Line key={x} x1={x} y1={4 + (i % 2) * 4} x2={x - 3} y2={14 + (i % 2) * 4} stroke={palette.paper} strokeWidth={1} strokeLinecap="round" opacity={0.85} />
            ))}
            <Path d="M8 34 L14 20 L20 34 Z M18 36 L25 18 L32 36 Z" fill="#4A4832" />
            <Path d="M0 34 H40 V40 H0 Z" fill="#4A4832" />
          </>
        );
      case 'hearth': // a small flame
        return (
          <>
            <Grad id="g-hearth" from="#7A5546" to="#3E2E27" radial />
            <Circle cx={20} cy={20} r={20} fill="url(#g-hearth)" />
            <Path d="M20 9 C 25 15 28 19 27 25 C 26.5 30 23.5 32 20 32 C 16.5 32 13.5 30 13 25 C 12.5 21 15 18 17 15 C 17.5 18 18.5 20 20 21 C 20.5 17 20 13 20 9 Z" fill={palette.clay} />
            <Path d="M20 19 C 23 22 24 25 23 28 C 22.4 30 21.3 31 20 31 C 18.7 31 17.6 30 17 28 C 16.5 25.5 18 23 20 19 Z" fill="#E8C3A4" />
          </>
        );
      case 'golden': // a warm glow
        return (
          <>
            <Grad id="g-golden" from={palette.sand} to="#D9A587" radial />
            <Circle cx={20} cy={20} r={20} fill="url(#g-golden)" />
            <Circle cx={20} cy={22} r={9} fill={palette.cream} opacity={0.9} />
            <Circle cx={20} cy={22} r={13} fill="none" stroke={palette.cream} strokeWidth={1} opacity={0.6} />
          </>
        );
      case 'spirit': // a melody drifting over dusk
        return (
          <>
            <Grad id="g-spirit" from="#895D70" to={palette.plum} />
            <Circle cx={20} cy={20} r={20} fill="url(#g-spirit)" />
            <Path d="M5 22 C 11 14 16 26 22 18 S 32 12 36 17" stroke={palette.duskRose} strokeWidth={1.4} fill="none" strokeLinecap="round" />
            <Path d="M7 27 C 13 21 18 31 24 24 S 32 20 35 23" stroke={palette.duskRose} strokeWidth={1} fill="none" strokeLinecap="round" opacity={0.6} />
            <Path d="M0 32 Q 20 27 40 32 V40 H0 Z" fill="#43303A" />
          </>
        );
      case 'grace': // flowing water
        return (
          <>
            <Grad id="g-grace" from="#A9A68A" to={palette.sage} />
            <Circle cx={20} cy={20} r={20} fill="url(#g-grace)" />
            {[14, 21, 28].map((y, i) => (
              <Path key={y} d={`M2 ${y} Q 8 ${y - 3} 14 ${y} T 26 ${y} T 38 ${y}`} stroke={palette.paper} strokeWidth={1.4 - i * 0.2} fill="none" strokeLinecap="round" opacity={0.9 - i * 0.2} />
            ))}
          </>
        );
      case 'own': // a music note
        return (
          <>
            <Grad id="g-own" from={palette.clay} to={palette.clayDeep} />
            <Circle cx={20} cy={20} r={20} fill="url(#g-own)" />
            <G fill={palette.cream}>
              <Circle cx={15.5} cy={27} r={3.4} />
              <Circle cx={26.5} cy={24.5} r={3.4} />
            </G>
            <Path d="M18.6 27 V13.5 L29.6 11 V24.5" stroke={palette.cream} strokeWidth={1.8} fill="none" strokeLinejoin="round" />
          </>
        );
      case 'off': // silence
        return (
          <>
            <Circle cx={20} cy={20} r={19.25} fill="none" stroke={ring} strokeWidth={1.5} />
            <Line x1={12} y1={28} x2={28} y2={12} stroke={ring} strokeWidth={1.5} strokeLinecap="round" />
          </>
        );
    }
  })();
  return (
    <Svg width={size} height={size} viewBox="0 0 40 40">
      <Defs>
        <ClipPath id={`clip-${id}`}>
          <Circle cx={20} cy={20} r={20} />
        </ClipPath>
      </Defs>
      <G clipPath={`url(#clip-${id})`}>{art}</G>
    </Svg>
  );
}
