import { Image } from 'expo-image';
import { View } from 'react-native';
import type { Coach } from '../data/content';
import { Txt } from './Txt';

// Small initial disc used on the timer and Settings.
export function CoachInitial({ coach, letterColor, size = 30 }: { coach: Coach; letterColor: string; size?: number }) {
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: coach.color, alignItems: 'center', justifyContent: 'center' }}>
      <Txt serif size={16} color={letterColor}>{coach.name[0]}</Txt>
    </View>
  );
}

// Portrait inside the coach's colour ring, with a colour dot at the lower right.
export function CoachPortrait({ coach, bg }: { coach: Coach; bg: string }) {
  return (
    <View style={{ width: 52, height: 52, borderRadius: 26, borderWidth: 2, borderColor: coach.color, padding: 2 }}>
      <View style={{ width: 44, height: 44, borderRadius: 22, overflow: 'hidden', backgroundColor: coach.color }}>
        <Image source={coach.photo} style={{ width: 44, height: 44 }} contentFit="cover" contentPosition={{ left: '50%', top: '30%' }} accessibilityLabel={coach.name} />
      </View>
      <View style={{ position: 'absolute', right: -1, bottom: -1, width: 14, height: 14, borderRadius: 7, backgroundColor: coach.color, borderWidth: 2, borderColor: bg }} />
    </View>
  );
}
