import { useEffect, useRef, type ReactNode } from 'react';
import { Animated, Easing, View } from 'react-native';
import { night } from '../theme/tokens';

const SIZE = 300;
export const BREATH_SECONDS = 10; // 4s in, 6s out — the long exhale
const IN = 0.4;

// Concentric hairline rings with a soft disc that swells on the in-breath (bwBreathe).
export function BreathingRing({ breathing, startedAt, children }: { breathing: boolean; startedAt: number | null; children: ReactNode }) {
  const scale = useRef(new Animated.Value(0.72)).current;

  useEffect(() => {
    if (!breathing || startedAt === null) return;
    // Align the animation phase with the "Breathe in / out" label, which counts from startedAt.
    const into = ((Date.now() - startedAt) / 1000) % BREATH_SECONDS;
    const cycle = Animated.loop(
      Animated.sequence([
        Animated.timing(scale, { toValue: 1, duration: BREATH_SECONDS * IN * 1000, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
        Animated.timing(scale, { toValue: 0.72, duration: BREATH_SECONDS * (1 - IN) * 1000, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
      ]),
    );
    let first: Animated.CompositeAnimation;
    if (into < BREATH_SECONDS * IN) {
      scale.setValue(0.72 + 0.28 * (into / (BREATH_SECONDS * IN)));
      first = Animated.timing(scale, { toValue: 1, duration: (BREATH_SECONDS * IN - into) * 1000, easing: Easing.out(Easing.ease), useNativeDriver: true });
      first.start(({ finished }) => finished && startOut());
    } else {
      scale.setValue(1 - 0.28 * ((into - BREATH_SECONDS * IN) / (BREATH_SECONDS * (1 - IN))));
      first = Animated.timing(scale, { toValue: 0.72, duration: (BREATH_SECONDS - into) * 1000, easing: Easing.out(Easing.ease), useNativeDriver: true });
      first.start(({ finished }) => finished && cycle.start());
    }
    function startOut() {
      Animated.timing(scale, { toValue: 0.72, duration: BREATH_SECONDS * (1 - IN) * 1000, easing: Easing.inOut(Easing.ease), useNativeDriver: true }).start(
        ({ finished }) => finished && cycle.start(),
      );
    }
    return () => {
      first.stop();
      cycle.stop();
      scale.stopAnimation();
    };
  }, [breathing, startedAt, scale]);

  return (
    <View style={{ width: SIZE, height: SIZE, alignSelf: 'center', alignItems: 'center', justifyContent: 'center' }}>
      <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, borderRadius: SIZE / 2, borderWidth: 1, borderColor: night.ring }} />
      <View style={{ position: 'absolute', top: 26, left: 26, right: 26, bottom: 26, borderRadius: SIZE / 2, borderWidth: 1, borderColor: night.ringInner }} />
      {breathing && (
        <Animated.View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, borderRadius: SIZE / 2, backgroundColor: night.breath, transform: [{ scale }] }} />
      )}
      {children}
    </View>
  );
}
