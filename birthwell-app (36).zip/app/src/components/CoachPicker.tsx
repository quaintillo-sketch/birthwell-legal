import { useEffect, useState } from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import { firstPhrase, modeFor } from '../data/coaching';
import { COACHES } from '../data/content';
import { onSpeakingChange, playPhrase, stopVoice } from '../lib/coachVoice';
import { router } from 'expo-router';
import { isCoachFree } from '../lib/access';
import { useApp } from '../state/AppState';
import { usePremium } from '../state/Premium';
import { PremiumTag } from './PremiumTag';
import type { Theme } from '../theme/tokens';
import { CoachPortrait } from './Coach';
import { PlayGlyph } from './icons';
import { Txt } from './Txt';

const WAVE = [6, 10, 16, 12, 20, 26, 18, 22, 14, 24, 26, 16, 10, 18, 22, 12, 8, 14, 20, 24, 18, 12, 16, 10, 6, 12, 8, 5, 4, 3];
const PREVIEW_MS = 3500;

// Coach list from 1e. Tapping a coach plays her preview phrase (her recording once added,
// the phone's voice until then) while the waveform fills.
export function CoachPicker({ t }: { t: Theme }) {
  const { prefs, set } = useApp();
  const [previewing, setPreviewing] = useState<number | null>(null);
  const [progress, setProgress] = useState(11);
  const { premium } = usePremium();
  // The coach whose details are open: the chosen one, or a Premium coach being previewed.
  const [focused, setFocused] = useState(prefs.coach);

  useEffect(() => {
    if (previewing === null) return;
    const started = Date.now();
    setProgress(0);
    const id = setInterval(() => {
      const p = Math.min(WAVE.length, Math.round(((Date.now() - started) / PREVIEW_MS) * WAVE.length));
      setProgress(p);
      if (p >= WAVE.length) clearInterval(id);
    }, 100);
    return () => clearInterval(id);
  }, [previewing]);
  useEffect(() => {
    const off = onSpeakingChange(speaking => !speaking && setPreviewing(null));
    return () => {
      off();
      stopVoice();
    };
  }, []);

  // Premium coaches can be previewed by anyone, but only chosen with Premium.
  const preview = (i: number) => {
    setFocused(i);
    if (premium || isCoachFree(i)) set({ coach: i });
    if (previewing === i) return stopVoice();
    if (playPhrase(i, firstPhrase(i, modeFor(prefs.faith), 'preview'), prefs.coachVolume, { interrupt: true })) setPreviewing(i);
  };

  return (
    <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
      {COACHES.map((c, i) => {
        const locked = !premium && !isCoachFree(i);
        const selected = !locked && i === prefs.coach;
        const open = i === focused || selected;
        return (
          <Pressable key={c.name} onPress={() => preview(i)} accessibilityRole="radio" accessibilityState={{ selected }} accessibilityLabel={`${c.name}, ${c.role}`}>
            <View style={{ borderTopWidth: 1, borderTopColor: t.dark ? 'rgba(239,228,214,0.12)' : 'rgba(46,36,32,0.12)', paddingVertical: 14, gap: 12 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
                <CoachPortrait coach={c} bg={t.bg} />
                <View style={{ flex: 1, minWidth: 0, gap: 3 }}>
                  <View style={{ flexDirection: 'row', alignItems: 'baseline', gap: 8 }}>
                    <Txt serif size={26} lh={1} color={t.text}>{c.name}</Txt>
                    <Txt serif italic size={16} lh={1} color={t.muted}>{c.role}</Txt>
                  </View>
                  <Txt size={12.5} lh={1.35} color={t.muted}>{c.desc}</Txt>
                </View>
                {locked && <PremiumTag color={t.accent} />}
                <Pressable
                  onPress={() => preview(i)}
                  hitSlop={8}
                  accessibilityRole="button"
                  accessibilityLabel={`Preview ${c.name}’s voice`}
                  style={{
                    width: 38,
                    height: 38,
                    borderRadius: 19,
                    borderWidth: 1,
                    borderColor: selected ? c.color : t.avatarRing,
                    backgroundColor: selected ? c.color : 'transparent',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  {previewing === i ? (
                    <View style={{ flexDirection: 'row', gap: 3 }}>
                      <View style={{ width: 3, height: 12, borderRadius: 1, backgroundColor: '#F4EFE7' }} />
                      <View style={{ width: 3, height: 12, borderRadius: 1, backgroundColor: '#F4EFE7' }} />
                    </View>
                  ) : (
                    <PlayGlyph w={9} color={selected ? '#F4EFE7' : t.text} />
                  )}
                </Pressable>
              </View>
              {open && (
                <View style={{ gap: 12, paddingLeft: 60 }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 3, height: 26 }}>
                    {WAVE.map((h, k) => (
                      <View key={k} style={{ width: 3, height: h, borderRadius: 2, backgroundColor: k < progress ? c.color : t.avatarRing }} />
                    ))}
                  </View>
                  <Txt serif italic size={19} lh={1.3} color={t.text}>{c.line}</Txt>
                  {locked && (
                    <Pressable
                      onPress={() => router.push('/premium')}
                      accessibilityRole="button"
                      style={{ alignSelf: 'flex-start', height: 38, paddingHorizontal: 16, borderRadius: 19, backgroundColor: t.laborButton.bg, justifyContent: 'center' }}
                    >
                      <Txt w={500} size={13.5} color={t.laborButton.text}>{`Choose ${c.name} with Premium`}</Txt>
                    </Pressable>
                  )}
                </View>
              )}
            </View>
          </Pressable>
        );
      })}
    </ScrollView>
  );
}
