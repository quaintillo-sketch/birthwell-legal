import { useRef, useState } from 'react';
import { Animated, PanResponder, Pressable, View, type ViewStyle } from 'react-native';
import { Txt } from './Txt';

export function Segmented<T extends string | number>({
  options,
  value,
  onChange,
  track,
  active,
  color,
}: {
  options: { label: string; value: T }[];
  value: T;
  onChange: (v: T) => void;
  track: string;
  active: string;
  color: string;
}) {
  return (
    <View style={{ flexDirection: 'row', backgroundColor: track, borderRadius: 16, padding: 3 }}>
      {options.map(o => (
        <Pressable
          key={String(o.value)}
          onPress={() => onChange(o.value)}
          accessibilityRole="button"
          accessibilityState={{ selected: o.value === value }}
          style={{ flex: 1, height: 40, borderRadius: 13, alignItems: 'center', justifyContent: 'center', backgroundColor: o.value === value ? active : 'transparent' }}
        >
          <Txt w={500} size={14} color={color}>{o.label}</Txt>
        </Pressable>
      ))}
    </View>
  );
}

export function Toggle({ on, onColor, offColor, knob }: { on: boolean; onColor: string; offColor: string; knob: string }) {
  return (
    <View style={{ width: 50, height: 30, borderRadius: 15, backgroundColor: on ? onColor : offColor }}>
      <View style={{ position: 'absolute', top: 3, left: on ? 23 : 3, width: 24, height: 24, borderRadius: 12, backgroundColor: knob }} />
    </View>
  );
}

// 2px hairline slider with a round thumb, as on the Settings audio rows.
export function Slider({
  value,
  onChange,
  track,
  fill,
  thumb,
  thumbBorder,
  shadow,
}: {
  value: number;
  onChange: (v: number) => void;
  track: string;
  fill: string;
  thumb: string;
  thumbBorder: string;
  shadow: string;
}) {
  const [width, setWidth] = useState(0);
  const start = useRef(0);
  const latest = useRef({ value, width, onChange });
  latest.current = { value, width, onChange };
  const clamp = (v: number) => Math.min(1, Math.max(0, v));

  const pan = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderTerminationRequest: () => false,
      onPanResponderGrant: e => {
        const { width: w, onChange: cb } = latest.current;
        if (!w) return;
        const v = clamp(e.nativeEvent.locationX / w);
        start.current = v;
        cb(Math.round(v * 100) / 100);
      },
      onPanResponderMove: (_, g) => {
        const { width: w, onChange: cb } = latest.current;
        if (!w) return;
        cb(Math.round(clamp(start.current + g.dx / w) * 100) / 100);
      },
    }),
  ).current;

  return (
    <View
      {...pan.panHandlers}
      onLayout={e => setWidth(e.nativeEvent.layout.width)}
      style={{ height: 24, justifyContent: 'center' }}
      accessibilityRole="adjustable"
      accessibilityValue={{ min: 0, max: 100, now: Math.round(value * 100) }}
      accessibilityActions={[{ name: 'increment' }, { name: 'decrement' }]}
      onAccessibilityAction={e => onChange(clamp(value + (e.nativeEvent.actionName === 'increment' ? 0.1 : -0.1)))}
    >
      <View pointerEvents="none" style={{ height: 2, backgroundColor: track }}>
        <View style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: `${value * 100}%`, backgroundColor: fill }} />
        <View
          style={{
            position: 'absolute',
            left: `${value * 100}%`,
            top: -10,
            width: 22,
            height: 22,
            marginLeft: -11,
            borderRadius: 11,
            backgroundColor: thumb,
            borderWidth: 1,
            borderColor: thumbBorder,
            shadowColor: shadow,
            shadowOpacity: 0.12,
            shadowRadius: 6,
            shadowOffset: { width: 0, height: 2 },
            elevation: 2,
          }}
        />
      </View>
    </View>
  );
}

// Radio ring used on onboarding and timer settings.
export function Radio({ selected, ring, dot, style }: { selected: boolean; ring: string; dot: string; style?: ViewStyle }) {
  return (
    <View style={[{ width: 22, height: 22, borderRadius: 11, borderWidth: 1.5, borderColor: ring, alignItems: 'center', justifyContent: 'center' }, style]}>
      <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: selected ? dot : 'transparent' }} />
    </View>
  );
}

export function Hairline({ color, style }: { color: string; style?: ViewStyle }) {
  return <View style={[{ height: 1, backgroundColor: color }, style]} />;
}

// Gentle press feedback without bubbly scaling.
export function useFade() {
  const o = useRef(new Animated.Value(1)).current;
  return {
    style: { opacity: o },
    onPressIn: () => Animated.timing(o, { toValue: 0.7, duration: 80, useNativeDriver: true }).start(),
    onPressOut: () => Animated.timing(o, { toValue: 1, duration: 160, useNativeDriver: true }).start(),
  };
}
