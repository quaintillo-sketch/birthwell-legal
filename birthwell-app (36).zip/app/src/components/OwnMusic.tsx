import { Linking, Pressable, TextInput, View } from 'react-native';
import { useApp } from '../state/AppState';
import { fonts } from '../theme/tokens';
import { Toggle } from './controls';
import { Txt } from './Txt';

export type OwnMusicColors = { text: string; muted: string; accent: string; line: string; toggleOn: string; toggleOff: string; knob: string };

const open = (url: string) => Linking.openURL(url).catch(() => {});

// Shown under the ambience choices when "My own music" is picked. BirthWell doesn't play
// the music itself: she plays it in Spotify, Apple Music or any app, and the coach speaks
// over it (never pausing it).
export function OwnMusic({ c }: { c: OwnMusicColors }) {
  const { prefs, set } = useApp();
  const link = prefs.musicLink.trim();
  const pill = (label: string, onPress: () => void, filled?: boolean) => (
    <Pressable
      key={label}
      onPress={onPress}
      accessibilityRole="button"
      style={{
        flex: 1,
        height: 44,
        borderRadius: 22,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: filled ? c.accent : 'transparent',
        borderWidth: filled ? 0 : 1,
        borderColor: c.line,
      }}
    >
      <Txt w={500} size={14} color={filled ? '#FAF5EF' : c.text}>{label}</Txt>
    </Pressable>
  );
  return (
    <View style={{ paddingTop: 12, paddingBottom: 6, gap: 12 }}>
      <Txt size={12.5} lh={1.45} color={c.muted}>
        Start your playlist in your music app. Your coach speaks over it and never pauses it.
      </Txt>
      <View style={{ borderTopWidth: 1, borderTopColor: c.line, paddingTop: 8 }}>
        <Txt size={12} color={c.muted}>Playlist link (optional)</Txt>
        <TextInput
          value={prefs.musicLink}
          onChangeText={musicLink => set({ musicLink })}
          placeholder="Paste a Spotify or Apple Music link"
          placeholderTextColor={c.muted}
          autoCapitalize="none"
          autoCorrect={false}
          keyboardType="url"
          returnKeyType="done"
          accessibilityLabel="Playlist link"
          style={{ fontFamily: fonts.sans400, fontSize: 15, color: c.text, paddingVertical: 8 }}
        />
      </View>
      <View style={{ flexDirection: 'row', gap: 10 }}>
        {link
          ? pill('Open my playlist', () => open(link), true)
          : [pill('Open Spotify', () => open('spotify:')), pill('Open Apple Music', () => open('music:'))]}
      </View>
      <Pressable
        onPress={() => set({ duckMusic: !prefs.duckMusic })}
        accessibilityRole="switch"
        accessibilityState={{ checked: prefs.duckMusic }}
        style={{ flexDirection: 'row', alignItems: 'center', gap: 16, paddingTop: 6 }}
      >
        <View style={{ flex: 1, gap: 3 }}>
          <Txt size={15.5} color={c.text}>Lower music while coach speaks</Txt>
          <Txt size={12.5} lh={1.4} color={c.muted}>Your music dips under her voice, then comes back up.</Txt>
        </View>
        <Toggle on={prefs.duckMusic} onColor={c.toggleOn} offColor={c.toggleOff} knob={c.knob} />
      </Pressable>
    </View>
  );
}
