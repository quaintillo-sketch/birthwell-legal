import { View } from 'react-native';
import { Kicker } from './Txt';

// Small "Premium" label for locked coaches, soundscapes and meditations.
export function PremiumTag({ color }: { color: string }) {
  return (
    <View style={{ borderWidth: 1, borderColor: color, borderRadius: 10, paddingHorizontal: 7, paddingVertical: 4 }}>
      <Kicker size={8.5} ls={0.12} color={color}>Premium</Kicker>
    </View>
  );
}
