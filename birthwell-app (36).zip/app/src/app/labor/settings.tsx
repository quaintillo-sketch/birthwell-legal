import { router } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { Pressable, ScrollView, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useState } from 'react';
import { Radio, Toggle } from '../../components/controls';
import { Check, ChevronLeft } from '../../components/icons';
import { Em, Kicker, Txt } from '../../components/Txt';
import { RULES, type Rule } from '../../data/content';
import { useApp, useRule } from '../../state/AppState';
import { fonts, night } from '../../theme/tokens';

// 1l · Timer settings, opened from the ⓘ on the contraction timer.
export default function TimerSettings() {
  const { prefs, set } = useApp();
  const { rule, isCustom, index } = useRule();
  const insets = useSafeAreaInsets();
  const [editing, setEditing] = useState(false);

  const step = (k: keyof Rule, d: number, min: number, max: number) => () =>
    set(p => ({ custom: { ...p.custom, [k]: Math.min(max, Math.max(min, p.custom[k] + d)) } }));

  const tag = index === 0 ? 'Recommended default' : isCustom ? 'Your provider’s pattern' : 'Your guideline';
  const big = isCustom ? `${rule.a} · ${rule.l}s · ${rule.f}m` : RULES[index].short.split('-').join(' · ');
  const desc =
    index === 0
      ? 'Contractions 5 minutes apart, each lasting about 1 minute, steady for 1 hour. The guideline most OBs and midwives give for when to call.'
      : `Contractions ${rule.a} minutes apart, lasting ${rule.l} seconds, steady for ${rule.f} minutes. BirthWell will let you know when you reach it.`;

  const Stepper = ({ label, value, onDown, onUp }: { label: string; value: string; onDown: () => void; onUp: () => void }) => (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 10, borderTopWidth: 1, borderTopColor: night.lineFaint }}>
      <Txt size={15} color={night.body} style={{ flex: 1 }}>{label}</Txt>
      {[
        ['−', onDown, `Decrease ${label}`],
        ['+', onUp, `Increase ${label}`],
      ].map(([g, fn, a], i) => (
        <View key={g as string} style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          {i === 1 && <Txt serif size={24} align="center" color={night.text} style={{ width: 74 }}>{value}</Txt>}
          <Pressable
            onPress={fn as () => void}
            accessibilityRole="button"
            accessibilityLabel={a as string}
            style={{ width: 40, height: 40, borderRadius: 20, borderWidth: 1, borderColor: night.stepper, alignItems: 'center', justifyContent: 'center' }}
          >
            <Txt size={20} color={night.text}>{g as string}</Txt>
          </Pressable>
        </View>
      ))}
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: night.bg, paddingTop: insets.top }}>
      <StatusBar style="light" />
      <ScrollView keyboardShouldPersistTaps="handled" automaticallyAdjustKeyboardInsets contentContainerStyle={{ paddingTop: 10, paddingHorizontal: 28, paddingBottom: Math.max(40, insets.bottom + 10) }} showsVerticalScrollIndicator={false}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <Pressable onPress={() => router.back()} hitSlop={12} accessibilityRole="button" style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <ChevronLeft color={night.muted} />
            <Txt w={500} size={14} color={night.muted}>Back to timer</Txt>
          </Pressable>
          <Pressable onPress={() => router.back()} hitSlop={12} accessibilityRole="button" style={{ flexDirection: 'row', alignItems: 'center', gap: 7 }}>
            <Check color={night.accent} size={12} />
            <Txt w={500} size={14} color={night.accent}>Done</Txt>
          </Pressable>
        </View>
        <Txt serif size={48} lh={1} ls={-0.01} color={night.text} style={{ marginTop: 22 }}>
          Timer <Em color={night.accent}>settings</Em>
        </Txt>

        <View style={{ marginTop: 22, backgroundColor: night.card, borderRadius: 24, paddingTop: 22, paddingHorizontal: 22, paddingBottom: 20, gap: 10 }}>
          <Kicker size={10} color={night.accent}>{tag}</Kicker>
          <Txt serif size={64} lh={0.95} ls={-0.01} color={night.text} adjustsFontSizeToFit numberOfLines={1}>{big}</Txt>
          <Txt size={14} lh={1.5} color={night.body}>{desc}</Txt>
        </View>

        <Kicker color={night.muted} style={{ marginTop: 28, marginBottom: 6 }}>Your guideline</Kicker>
        {RULES.map((r, i) => (
          <Pressable
            key={r.name}
            onPress={() => set({ rule: i })}
            accessibilityRole="radio"
            accessibilityState={{ selected: i === index }}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 14, paddingVertical: 14, borderTopWidth: 1, borderTopColor: night.rowLine }}
          >
            <Radio selected={i === index} ring={i === index ? night.accent : 'rgba(239,228,214,0.35)'} dot={night.accent} />
            <View style={{ flex: 1, gap: 3 }}>
              <Txt size={16} color={night.text}>{r.name}</Txt>
              <Txt size={12.5} lh={1.4} color={night.muted}>{r.sub}</Txt>
            </View>
            {!!r.badge && <Kicker size={9.5} ls={0.14} color={night.accent}>{r.badge}</Kicker>}
          </Pressable>
        ))}
        {isCustom && (
          <View style={{ paddingTop: 4, paddingBottom: 8, paddingLeft: 36 }}>
            <Stepper label="Apart" value={`${prefs.custom.a} min`} onDown={step('a', -1, 2, 10)} onUp={step('a', 1, 2, 10)} />
            <Stepper label="Lasting" value={`${prefs.custom.l} sec`} onDown={step('l', -15, 30, 120)} onUp={step('l', 15, 30, 120)} />
            <Stepper label="For" value={`${prefs.custom.f} min`} onDown={step('f', -15, 15, 120)} onUp={step('f', 15, 15, 120)} />
          </View>
        )}

        <Kicker color={night.muted} style={{ marginTop: 28, marginBottom: 2 }}>When your pattern is reached</Kicker>
        <Pressable
          onPress={() => set({ alert: !prefs.alert })}
          accessibilityRole="switch"
          accessibilityState={{ checked: prefs.alert }}
          style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 16, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: night.rowLine }}
        >
          <View style={{ flex: 1, gap: 4 }}>
            <Txt size={16} color={night.text}>Gentle alert</Txt>
            <Txt size={12.5} lh={1.4} color={night.muted}>A soft chime and a prompt to call your provider.</Txt>
          </View>
          <Toggle on={prefs.alert} onColor={night.toggleOn} offColor={night.toggleOff} knob={night.text} />
        </Pressable>
        <View style={{ borderBottomWidth: 1, borderBottomColor: night.rowLine }}>
          <Pressable
            onPress={() => setEditing(e => !e)}
            accessibilityRole="button"
            accessibilityState={{ expanded: editing }}
            style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 14, gap: 12 }}
          >
            <Txt size={16} color={night.text}>Provider</Txt>
            <Txt size={15} color={editing ? night.accent : night.muted} numberOfLines={1} style={{ flexShrink: 1 }}>
              {editing ? 'Done' : `${prefs.provider || 'Add'}${prefs.providerPhone ? ` · ${prefs.providerPhone}` : ''} ›`}
            </Txt>
          </Pressable>
          {editing && (
            <View style={{ paddingBottom: 14, gap: 10 }}>
              {[
                { label: 'Name', value: prefs.provider, key: 'provider' as const, placeholder: 'Dr. Alvarez, or your midwife', keyboard: 'default' as const },
                { label: 'Phone', value: prefs.providerPhone, key: 'providerPhone' as const, placeholder: 'Number for the “Call” button', keyboard: 'phone-pad' as const },
              ].map(f => (
                <View key={f.key} style={{ borderRadius: 14, backgroundColor: night.card, paddingHorizontal: 14, paddingTop: 8, paddingBottom: 2 }}>
                  <Txt size={11.5} color={night.muted}>{f.label}</Txt>
                  <TextInput
                    value={f.value}
                    onChangeText={v => set({ [f.key]: v })}
                    placeholder={f.placeholder}
                    placeholderTextColor={night.columnHead}
                    keyboardType={f.keyboard}
                    returnKeyType="done"
                    accessibilityLabel={`Provider ${f.label.toLowerCase()}`}
                    style={{ fontFamily: fonts.sans400, fontSize: 16, color: night.text, paddingVertical: 8 }}
                  />
                </View>
              ))}
            </View>
          )}
        </View>
        <Txt serif italic size={17} lh={1.4} color={night.body} style={{ marginTop: 22 }}>
          Always follow your provider’s advice. Call right away if your water breaks, you notice bleeding, or baby is moving less.
        </Txt>
      </ScrollView>
    </View>
  );
}
