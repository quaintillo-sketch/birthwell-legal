import * as Haptics from 'expo-haptics';
import { useKeepAwake } from 'expo-keep-awake';
import { router } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useEffect, useRef, useState } from 'react';
import { Animated, Easing, Linking, Pressable, ScrollView, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AudioSheet } from '../../components/AudioSheet';
import { EndSessionSheet } from '../../components/EndSessionSheet';
import { BREATH_SECONDS, BreathingRing } from '../../components/BreathingRing';
import { CoachInitial } from '../../components/Coach';
import { useFade } from '../../components/controls';
import { CloseX, ShareIcon } from '../../components/icons';
import { Kicker, serifBaselineFromBottom, Txt } from '../../components/Txt';
import { firstPhrase, modeFor } from '../../data/coaching';
import { AMBIENCE } from '../../data/content';
import { useAmbience, useOwnMusicDucking } from '../../lib/ambience';
import { gaps, logText, patternReached, sampleSession, stats } from '../../lib/labor';
import { shareText } from '../../lib/share';
import { fmtClock, fmtDuration } from '../../lib/time';
import { useLaborCoaching } from '../../lib/useLaborCoaching';
import { useApp, useRule } from '../../state/AppState';
import { useActiveCoach, usePremium } from '../../state/Premium';
import { effectiveAmbience } from '../../lib/access';
import { night, nightSheet } from '../../theme/tokens';

function useNow(intervalMs: number) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(id);
  }, [intervalMs]);
  return now;
}

function PulseDot() {
  const o = useRef(new Animated.Value(0.35)).current;
  useEffect(() => {
    const a = Animated.loop(
      Animated.sequence([
        Animated.timing(o, { toValue: 1, duration: 1000, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
        Animated.timing(o, { toValue: 0.35, duration: 1000, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
      ]),
    );
    a.start();
    return () => a.stop();
  }, [o]);
  return <Animated.View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: night.accent, opacity: o }} />;
}

// 1h (during a contraction) and 1i (between contractions) · Contraction timer
export default function LaborMode() {
  useKeepAwake();
  const { prefs, set } = useApp();
  const { coach, index: coachIndex } = useActiveCoach(); // Maren for Free users
  const { premium } = usePremium();
  const ambienceId = effectiveAmbience(prefs.ambience, premium);
  const { rule, short } = useRule();
  const insets = useSafeAreaInsets();
  const now = useNow(500);
  const fade = useFade();
  const [sheet, setSheet] = useState(false);
  useAmbience(true);
  // Playing her own music in another app: dip it while the coach speaks.
  useOwnMusicDucking(ambienceId === 'own' && prefs.duckMusic && prefs.coaching !== 'off');

  useEffect(() => {
    if (!prefs.sampleSeeded) set({ ...sampleSession(), sampleSeeded: true });
  }, [prefs.sampleSeeded, set]);

  const active = prefs.activeStart !== null;
  const elapsed = active ? Math.floor((now - prefs.activeStart!) / 1000) : 0;
  const breathingIn = elapsed % BREATH_SECONDS < 4;
  const list = prefs.contractions;
  const last = list[0];
  const { avgLength, avgApart } = stats(list, prefs.measure);
  const pattern = patternReached(list, rule, prefs.measure, now);

  // Breathing haptics pace the breath: taps that build through the 4s in-breath, then slow,
  // soft taps through the 6s out-breath, so it can be followed with eyes closed.
  useEffect(() => {
    if (!active || !prefs.haptics) return;
    const start = prefs.activeStart!;
    let lastSlot = -1;
    const id = setInterval(() => {
      const ms = (Date.now() - start) % (BREATH_SECONDS * 1000);
      const cycle = Math.floor((Date.now() - start) / (BREATH_SECONDS * 1000));
      let slot: number, style: Haptics.ImpactFeedbackStyle;
      if (ms < 4000) {
        slot = Math.floor(ms / 500); // 8 taps in
        style = slot < 3 ? Haptics.ImpactFeedbackStyle.Light : slot < 6 ? Haptics.ImpactFeedbackStyle.Medium : Haptics.ImpactFeedbackStyle.Heavy;
      } else {
        slot = 8 + Math.floor((ms - 4000) / 1500); // 4 taps out
        style = Haptics.ImpactFeedbackStyle.Soft;
      }
      const key = cycle * 100 + slot;
      if (key !== lastSlot) {
        lastSlot = key;
        Haptics.impactAsync(style).catch(() => {});
      }
    }, 100);
    return () => clearInterval(id);
  }, [active, prefs.haptics, prefs.activeStart]);

  // Spoken coaching (see useLaborCoaching). The words on screen follow what was last said,
  // or a default line for the moment when the coach is silent or hasn't spoken yet.
  const coaching = useLaborCoaching();
  const fallback = (category: 'breathe' | 'rest') => firstPhrase(coachIndex, modeFor(prefs.faith), category).text;
  const shownPrompt =
    active
      ? coaching.shown && (coaching.shown.moment === 'start' || coaching.shown.moment === 'mid') ? coaching.shown.phrase.text : fallback('breathe')
      : coaching.shown?.moment === 'end' ? coaching.shown.phrase.text : fallback('rest');
  const voiceOn = prefs.coaching !== 'off';

  // Gentle alert when the pattern is first reached.
  const hadPattern = useRef(!!pattern);
  useEffect(() => {
    if (pattern && !hadPattern.current && prefs.alert) Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
    hadPattern.current = !!pattern;
  }, [pattern, prefs.alert]);

  const toggle = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy).catch(() => {});
    if (active) coaching.onContractionEnd((Date.now() - prefs.activeStart!) / 1000);
    else coaching.onContractionStart();
    const t = Date.now();
    set(p =>
      p.activeStart !== null
        ? { activeStart: null, contractions: [{ start: p.activeStart, end: t }, ...p.contractions].slice(0, 200) }
        : { activeStart: t },
    );
  };

  const [ending, setEnding] = useState(false);
  const endSession = () => setEnding(true);

  const shareLog = () => shareText('Contraction log', logText(list, prefs.measure, short, fmtClock, fmtDuration));

  const rows = list.slice(0, 6);
  const rowGaps = gaps(list.slice(0, 7), prefs.measure);

  return (
    <View style={{ flex: 1, backgroundColor: night.bg, paddingTop: insets.top }}>
      <StatusBar style="light" />
      <View style={{ flex: 1, paddingTop: 14, paddingHorizontal: 28, paddingBottom: Math.max(44, insets.bottom + 10) }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <Pressable
            onPress={endSession}
            accessibilityRole="button"
            style={{ flexDirection: 'row', alignItems: 'center', gap: 8, height: 36, paddingHorizontal: 14, borderRadius: 18, borderWidth: 1, borderColor: night.outline }}
          >
            <CloseX color={night.text} size={11} />
            <Txt w={500} size={14} color={night.text}>End session</Txt>
          </Pressable>
          <View style={{ flexDirection: 'row', gap: 10 }}>
          {list.length > 0 && (
            <Pressable
              onPress={shareLog}
              accessibilityRole="button"
              accessibilityLabel="Share contraction log"
              style={{ width: 36, height: 36, borderRadius: 18, borderWidth: 1, borderColor: night.outline, alignItems: 'center', justifyContent: 'center' }}
            >
              <ShareIcon color={night.text} size={15} />
            </Pressable>
          )}
          <Pressable
            onPress={() => router.push('/labor/settings')}
            accessibilityRole="button"
            accessibilityLabel="Timer settings"
            style={{ width: 36, height: 36, borderRadius: 18, borderWidth: 1, borderColor: night.outline, alignItems: 'center', justifyContent: 'center' }}
          >
            <Txt serif italic size={20} lh={1} color={night.text}>i</Txt>
          </Pressable>
          </View>
        </View>
        <Kicker color={night.accent} style={{ marginTop: 22 }}>{`Labor mode · ${short}`}</Kicker>

        <Pressable
          onPress={() => setSheet(true)}
          accessibilityRole="button"
          accessibilityLabel="Voice and sound settings"
          style={{ flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 14 }}
        >
          <CoachInitial coach={coach} letterColor="#F4EFE7" />
          <View style={{ flex: 1, gap: 2 }}>
            <Txt w={500} size={14} color={night.text}>{`${coach.name} is with you`}</Txt>
            <Txt size={12} color={night.muted}>{ambienceId === 'off' ? 'No ambience' : `Ambience · ${AMBIENCE.find(a => a.id === ambienceId)?.name}`}</Txt>
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, height: 32, paddingHorizontal: 12, borderRadius: 16, borderWidth: 1, borderColor: night.outline }}>
            {voiceOn && <PulseDot />}
            <Txt w={500} size={12} color={night.text}>{voiceOn ? 'Voice on ›' : 'Voice off ›'}</Txt>
          </View>
        </Pressable>

        {active ? (
          <>
            <View style={{ marginTop: 22 }}>
              <BreathingRing breathing startedAt={prefs.activeStart}>
                <View style={{ alignItems: 'center', gap: 8 }}>
                  <Kicker color={night.accent}>Contraction</Kicker>
                  <Txt serif size={92} lh={1.05} ls={-0.02} tabular color={night.text} accessibilityLiveRegion="polite">{fmtDuration(elapsed)}</Txt>
                  <Txt serif italic size={26} lh={1} color={night.soft}>{breathingIn ? 'Breathe in' : 'Breathe out…'}</Txt>
                </View>
              </BreathingRing>
            </View>
            <Txt serif italic size={22} lh={1.3} align="center" color={night.text} style={{ marginTop: 30, maxWidth: 300, alignSelf: 'center' }}>
              {shownPrompt}
            </Txt>
            <View style={{ flexDirection: 'row', marginTop: 'auto', paddingVertical: 18, borderTopWidth: 1, borderTopColor: night.line }}>
              {[
                [list.length ? fmtDuration(avgLength) : '—', 'Avg length'],
                [list.length > 1 ? fmtDuration(avgApart) : '—', 'Avg apart'],
                [String(list.length + 1), 'Tonight'],
              ].map(([value, label], i) => (
                <View key={label} style={{ flex: 1, alignItems: 'center', gap: 6, borderLeftWidth: i === 1 ? 1 : 0, borderRightWidth: i === 1 ? 1 : 0, borderColor: night.line }}>
                  <Txt serif size={28} lh={1} color={night.text}>{value}</Txt>
                  <Kicker size={9.5} ls={0.14} color={night.muted}>{label}</Kicker>
                </View>
              ))}
            </View>
          </>
        ) : (
          <ScrollView style={{ flex: 1 }} contentContainerStyle={{ paddingBottom: 20 }} showsVerticalScrollIndicator={false}>
            {last ? (
              <>
                <Kicker color={night.muted} style={{ marginTop: 22 }}>Resting</Kicker>
                {/* Tall digits on a tight line height draw above their box on iOS; leave room under the label. */}
                <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 12, marginTop: 28 }}>
                  <Txt serif size={104} lh={0.85} ls={-0.02} tabular color={night.text}>{fmtDuration((now - last.end) / 1000)}</Txt>
                  <Txt serif italic size={22} lh={1.1} color={night.soft} style={{ paddingBottom: Math.max(0, Math.round(serifBaselineFromBottom(104, 0.85) - serifBaselineFromBottom(22, 1.1))) }}>{'since the\nlast one'}</Txt>
                </View>
              </>
            ) : (
              <>
                <Kicker color={night.muted} style={{ marginTop: 28 }}>Ready when you are</Kicker>
                <Txt serif size={44} lh={1.05} color={night.text} style={{ marginTop: 14 }}>
                  Tap below when a contraction begins.
                </Txt>
              </>
            )}

            <View style={{ marginTop: 28, paddingVertical: 20, borderTopWidth: 1, borderBottomWidth: 1, borderColor: night.line, gap: 10 }}>
              {pattern ? (
                <>
                  <Kicker size={10} color={night.accent}>{`Your pattern · ${short} reached`}</Kicker>
                  <Txt serif size={23} lh={1.2} color={night.text}>{pattern}</Txt>
                  <Txt size={13.5} lh={1.45} color={night.muted}>This may be a good time to call your provider.</Txt>
                  <Pressable
                    onPress={() => {
                      if (prefs.providerPhone.trim()) return Linking.openURL(`tel:${prefs.providerPhone.replace(/[^\d+]/g, '')}`).catch(() => {});
                      router.push('/labor/settings');
                    }}
                    accessibilityRole="button"
                    style={{ marginTop: 6, height: 48, borderRadius: 24, borderWidth: 1, borderColor: night.outline, alignItems: 'center', justifyContent: 'center' }}
                  >
                    <Txt w={500} size={15} color={night.text}>{prefs.providerPhone.trim() ? `Call ${prefs.provider}` : 'Add your provider’s number'}</Txt>
                  </Pressable>
                </>
              ) : (
                <View style={{ gap: 8 }}>
                  <Kicker size={10} color={night.accent}>{`${coach.name} says`}</Kicker>
                  <Txt serif italic size={22} lh={1.25} color={night.text}>{shownPrompt}</Txt>
                </View>
              )}
            </View>

            {rows.length > 0 && (
              <>
                <View style={{ flexDirection: 'row', marginTop: 20, paddingBottom: 10 }}>
                  {['Started', 'Length', 'Apart'].map((h, i) => (
                    <Kicker key={h} size={9.5} ls={0.14} color={night.columnHead} align={i === 2 ? 'right' : 'left'} style={{ flex: 1 }}>{h}</Kicker>
                  ))}
                </View>
                {rows.map((c, i) => (
                  <View key={c.start} style={{ flexDirection: 'row', paddingVertical: 11, borderTopWidth: 1, borderTopColor: night.lineFaint }}>
                    {[fmtClock(c.start), fmtDuration((c.end - c.start) / 1000), rowGaps[i] !== undefined ? fmtDuration(rowGaps[i]) : '—'].map((v, k) => (
                      <Txt key={k} size={15} tabular color={i === 0 ? night.text : night.muted} align={k === 2 ? 'right' : 'left'} style={{ flex: 1 }}>{v}</Txt>
                    ))}
                  </View>
                ))}
              </>
            )}
          </ScrollView>
        )}

        <Pressable onPress={toggle} onPressIn={fade.onPressIn} onPressOut={fade.onPressOut} accessibilityRole="button">
          <Animated.View
            style={[
              { height: active ? 85 : 75, borderRadius: 46, backgroundColor: night.button, alignItems: 'center', justifyContent: 'center', marginTop: active ? 0 : 12 },
              fade.style,
            ]}
          >
            <Txt w={500} size={20} ls={0.01} color={night.buttonText}>{active ? 'Contraction ended' : 'Contraction started'}</Txt>
          </Animated.View>
        </Pressable>
      </View>
      <AudioSheet visible={sheet} onClose={() => setSheet(false)} mode="labor" c={nightSheet} />
      <EndSessionSheet
        visible={ending}
        count={list.length}
        onKeepTiming={() => setEnding(false)}
        onClose={() => {
          setEnding(false);
          router.back();
        }}
        onShare={() => {
          setEnding(false);
          shareLog();
        }}
        onClear={() => {
          setEnding(false);
          set({ contractions: [], activeStart: null });
          router.back();
        }}
      />
    </View>
  );
}
