import { Stack } from 'expo-router';
import { night } from '../../theme/tokens';

// Labor mode is always the warm night palette, whatever the app appearance.
export default function LaborLayout() {
  return <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: night.bg } }} />;
}
