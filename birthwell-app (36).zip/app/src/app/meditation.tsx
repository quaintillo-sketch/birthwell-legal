import { useAudioPlayer, useAudioPlayerStatus } from 'expo-audio';
import { Image } from 'expo-image';
import { Redirect, router, useLocalSearchParams } from 'expo-router';
import { useEffect, useRef, useState } from 'react';
import { Pressable, useWindowDimensions, View } from 'react-native';
import { AudioSheet } from '../components/AudioSheet';
import { CloseX, Heart, PauseGlyph, PlayGlyph } from '../components/icons';
import { Screen } from '../components/Screen';
import { Kicker, Txt } from '../components/Txt';
import { AMBIENCE, MEDITATION_CUES, meditationForWeek, versionFor } from '../data/content';
import { useAmbience } from '../lib/ambience';
import { meditationSource } from '../lib/meditations';
import { fmtDuration, pregnancy } from '../lib/time';
import { speakText, stopSpeaking } from '../lib/voice';
import { useApp, useTheme } from '../state/AppState';
import { usePremium } from '../state/Premium';
import { isMeditationFree } from '../lib/access';

// Flower art for the player, one per week in rotation (assets/meditation).
const FLOWERS = [
  require('../../assets/meditation/flowers-1.png'),
  require('../../assets/meditation/flowers-2.png'),
  require('../../assets/meditation/flowers-3.png'),
];
import { themeSheet } from '../theme/tokens';

type Playback = { playing: boolean; pos: number; duration: number; toggle: () => void; seek: (d: number) => void; loaded?: boolean };

const cuesBefore = (pos: number) => MEDITATION_CUES.filter(c => c.at <= pos).length;

// Until a week's recording is hosted: a simulated timeline with spoken cues in the
// chosen meditation voice.
function usePlaceholder(active: boolean, seconds: number, voice: number, volume: number): Playback {
  const [playing, setPlaying] = useState(true);
  const [pos, setPos] = useState(0);
  const spoken = useRef(0);

  useEffect(() => {
    const due = cuesBefore(pos);
    if (active && playing && due > spoken.current) speakText(MEDITATION_CUES[due - 1].text, voice, volume);
    spoken.current = due;
  }, [active, pos, playing, voice, volume]);
  useEffect(() => {
    if (!playing || !active) stopSpeaking();
  }, [playing, active]);
  useEffect(() => stopSpeaking, []);

  useEffect(() => {
    if (!playing || !active) return;
    const id = setInterval(() => {
      setPos(p => {
        if (p + 1 >= seconds) {
          setPlaying(false);
          return seconds;
        }
        return p + 1;
      });
    }, 1000);
    return () => clearInterval(id);
  }, [playing, active, seconds]);

  return {
    playing,
    pos,
    duration: seconds,
    toggle: () => {
      if (!playing && pos >= seconds) {
        spoken.current = 0;
        setPos(0);
      }
      setPlaying(p => !p);
    },
    seek: d => {
      const next = Math.min(seconds, Math.max(0, pos + d));
      spoken.current = cuesBefore(next);
      stopSpeaking();
      setPos(next);
    },
  };
}

// A real recording, downloaded (offline) or streamed.
function useRecording(uri: string | null, fallbackSeconds: number): Playback {
  const player = useAudioPlayer(uri);
  const status = useAudioPlayerStatus(player);
  const started = useRef(false);

  useEffect(() => {
    started.current = false;
  }, [uri]);
  useEffect(() => {
    // Start once, as soon as it's ready, matching the design's playing state on open.
    if (uri && status.isLoaded && !started.current) {
      started.current = true;
      player.play();
    }
  }, [uri, status.isLoaded, player]);

  const duration = status.duration > 0 ? status.duration : fallbackSeconds;
  return {
    loaded: status.isLoaded,
    playing: status.playing,
    pos: Math.min(status.currentTime, duration),
    duration,
    toggle: () => {
      if (status.playing) return player.pause();
      if (status.didJustFinish || status.currentTime >= duration - 0.5) player.seekTo(0);
      player.play();
    },
    seek: d => player.seekTo(Math.min(duration, Math.max(0, status.currentTime + d))),
  };
}

// 1g / 2b · Weekly meditation. Plays the week's recording in the chosen version
// (Faith-centered or Grounded): the downloaded copy if there is one, otherwise streamed.
// Until recordings are hosted, it falls back to the placeholder above.
export default function MeditationPlayer() {
  const { prefs } = useApp();
  const { premium, ready } = usePremium();
  const params = useLocalSearchParams<{ week?: string }>();
  const thisWeek = pregnancy(prefs.dueDate).week;
  const week = params.week ? Number(params.week) || thisWeek : thisWeek;
  if (ready && !premium && !isMeditationFree(week)) return <Redirect href="/premium" />;
  // A new key for each week starts its player fresh.
  return <Player key={week} week={week} />;
}

function Player({ week }: { week: number }) {
  const { prefs, set } = useApp();
  const t = useTheme();
  const m = t.meditation;
  const fav = prefs.favorites.includes(week);
  const toggleFav = () =>
    set(p => ({ favorites: p.favorites.includes(week) ? p.favorites.filter(x => x !== week) : [...p.favorites, week].sort((a, b) => a - b) }));
  const version = versionFor(prefs.faith);
  const med = meditationForWeek(week, version);
  const { width } = useWindowDimensions();
  // The large title: as big as the design (84) while its longest line still fits the screen.
  const titleSize = Math.min(84, Math.floor((width - 64) / (Math.max(...med.title.map(l => l.length)) * 0.34)));
  const [sheet, setSheet] = useState(false);
  const [source, setSource] = useState<{ uri: string; offline: boolean } | null | undefined>(undefined);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let alive = true;
    meditationSource(week, version).then(s => alive && setSource(s));
    return () => {
      alive = false;
    };
  }, [week, version]);

  const useFile = !!source && !failed;
  const recording = useRecording(useFile ? source!.uri : null, med.seconds);
  // Maren (coach 0) narrates every meditation; the stand-in uses her built-in iPhone voice.
  const placeholder = usePlaceholder(source === null || failed, med.seconds, 0, prefs.coachVolume);
  const { playing, pos, duration, toggle, seek } = useFile ? recording : placeholder;
  useAmbience(playing);

  // A stream that never loads (offline, or the file isn't uploaded yet) falls back. The
  // timer reads the latest status through a ref, not the status from when it was set.
  const loaded = useRef(false);
  loaded.current = !!recording.loaded;
  useEffect(() => {
    if (!useFile || source?.offline) return;
    const id = setTimeout(() => !loaded.current && setFailed(true), 10000);
    return () => clearTimeout(id);
  }, [useFile, source?.offline]);

  const pct = `${duration ? (pos / duration) * 100 : 0}%` as const;

  return (
    <Screen bg={m.bg} darkContent={!t.dark} scroll padding={{ paddingTop: 14, paddingHorizontal: 32 }} bottom={46}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <Pressable onPress={() => router.back()} hitSlop={12} accessibilityRole="button" style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <CloseX color={m.text} />
          <Txt w={500} size={14} color={m.text}>Close</Txt>
        </Pressable>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
          <WeekStepper week={week} color={m.sub} />
          <Pressable
            onPress={toggleFav}
            hitSlop={12}
            accessibilityRole="button"
            accessibilityState={{ selected: fav }}
            accessibilityLabel={fav ? 'Remove from favorites' : 'Add to favorites'}
          >
            <Heart color={m.text} filled={fav} size={18} />
          </Pressable>
        </View>
      </View>

      {!t.dark && (
        <Image
          source={FLOWERS[week % FLOWERS.length]}
          style={{ position: 'absolute', top: 40, right: -32, width: 140, height: 330 }}
          contentFit="contain"
          contentPosition="right"
          pointerEvents="none"
        />
      )}
      <Kicker color={m.kicker} style={{ marginTop: 68 }}>{med.kicker}</Kicker>
      <View style={{ marginTop: 20 }} accessible accessibilityRole="header" accessibilityLabel={med.title.join(' ')}>
        {med.title.map((line, i) => (
          <Txt key={i} serif italic={i === 1} size={titleSize} lh={0.9} ls={-0.02} color={m.title} numberOfLines={1} adjustsFontSizeToFit>
            {line}
          </Txt>
        ))}
      </View>
      <Txt serif italic size={20} lh={1.35} color={m.body} style={{ marginTop: 28, maxWidth: 300 }}>{med.desc}</Txt>

      <View style={{ marginTop: 'auto', paddingTop: 32, gap: 10 }}>
        <View style={{ height: 2, borderRadius: 1, backgroundColor: m.track }}>
          <View style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: pct, borderRadius: 1, backgroundColor: m.fill }} />
          <View style={{ position: 'absolute', top: -5, left: pct, width: 12, height: 12, marginLeft: -6, borderRadius: 6, backgroundColor: m.fill }} />
        </View>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <Txt w={500} size={12} tabular color={m.sub}>{fmtDuration(pos)}</Txt>
          <Txt w={500} size={12} tabular color={m.sub}>{fmtDuration(duration)}</Txt>
        </View>
      </View>

      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 30, paddingHorizontal: 18 }}>
        <Pressable onPress={() => seek(-15)} hitSlop={16} accessibilityRole="button" accessibilityLabel="Back 15 seconds">
          <Txt w={500} size={15} color={m.text}>−15s</Txt>
        </Pressable>
        <Pressable
          onPress={toggle}
          accessibilityRole="button"
          accessibilityLabel={playing ? 'Pause' : 'Play'}
          style={{ width: 88, height: 88, borderRadius: 44, backgroundColor: m.playBg, alignItems: 'center', justifyContent: 'center' }}
        >
          {playing ? <PauseGlyph color={m.playIcon} /> : <PlayGlyph w={20} color={m.playIcon} />}
        </Pressable>
        <Pressable onPress={() => seek(15)} hitSlop={16} accessibilityRole="button" accessibilityLabel="Forward 15 seconds">
          <Txt w={500} size={15} color={m.text}>+15s</Txt>
        </Pressable>
      </View>

      <WeekNav week={week} color={m.text} />

      <View style={{ flexDirection: 'row', gap: 10, marginTop: 22 }}>
        {[
          `Voice · ${med.narrator}`,
          `Ambience · ${AMBIENCE.find(a => a.id === prefs.ambience)?.name ?? 'Off'}`,
        ].map(label => (
          <Pressable
            key={label}
            onPress={() => {
              // Pause first, so previews in the sheet never play over the meditation.
              if (playing) toggle();
              setSheet(true);
            }}
            accessibilityRole="button"
            accessibilityHint="Opens voice and sound settings"
            style={{ flexGrow: 1, flexShrink: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', height: 36, paddingHorizontal: 10, paddingTop: 3, borderRadius: 18, borderWidth: 1, borderColor: m.track }}
          >
            {/* Capital letters sit high in their line, so paddingTop nudges them to the middle; the negative margin cancels the letter spacing after the last character. */}
            <Kicker size={10.5} ls={0.12} color={m.sub} numberOfLines={1} style={{ textAlign: 'center', marginRight: -1.2 }}>{`${label} ›`}</Kicker>
          </Pressable>
        ))}
      </View>
      <AudioSheet visible={sheet} onClose={() => setSheet(false)} mode="meditation" c={themeSheet(t)} />
    </Screen>
  );
}


// "‹ Week 8 of 42 ›": the previous and next week. A Premium week opens the Premium screen
// for a Free user, as in the library.
function useWeekNav() {
  const { premium } = usePremium();
  return (w: number) => (!premium && !isMeditationFree(w) ? router.push('/premium') : router.setParams({ week: String(w) }));
}

function WeekStepper({ week, color }: { week: number; color: string }) {
  const go = useWeekNav();
  const arrow = (w: number, label: string, glyph: string) => (
    <Pressable onPress={() => go(w)} disabled={w < 6 || w > 42} hitSlop={10} accessibilityRole="button" accessibilityLabel={label} style={{ opacity: w < 6 || w > 42 ? 0.3 : 1 }}>
      <Txt w={500} size={18} lh={1} color={color}>{glyph}</Txt>
    </Pressable>
  );
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
      {arrow(week - 1, 'Previous week', '‹')}
      <Kicker color={color}>{`Week ${week} of 42`}</Kicker>
      {arrow(week + 1, 'Next week', '›')}
    </View>
  );
}

// "‹ Week 7 · Week 9 ›" under the player controls, easy to reach with a thumb.
function WeekNav({ week, color }: { week: number; color: string }) {
  const go = useWeekNav();
  const link = (w: number, label: string) =>
    w < 6 || w > 42 ? (
      <View />
    ) : (
      <Pressable onPress={() => go(w)} hitSlop={12} accessibilityRole="button" accessibilityLabel={`Week ${w} meditation`}>
        <Txt w={500} size={15} color={color}>{label}</Txt>
      </Pressable>
    );
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 28, paddingHorizontal: 18 }}>
      {link(week - 1, `‹  Week ${week - 1}`)}
      {link(week + 1, `Week ${week + 1}  ›`)}
    </View>
  );
}
