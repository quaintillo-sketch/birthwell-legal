import { HankenGrotesk_400Regular } from '@expo-google-fonts/hanken-grotesk/400Regular';
import { HankenGrotesk_500Medium } from '@expo-google-fonts/hanken-grotesk/500Medium';
import { HankenGrotesk_600SemiBold } from '@expo-google-fonts/hanken-grotesk/600SemiBold';
import { InstrumentSerif_400Regular } from '@expo-google-fonts/instrument-serif/400Regular';
import { InstrumentSerif_400Regular_Italic } from '@expo-google-fonts/instrument-serif/400Regular_Italic';
import { useFonts } from 'expo-font';
import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { useEffect } from 'react';
import { AppState } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { configureAudio } from '../lib/ambience';
import { syncMorningReminders } from '../lib/morningReminders';
import { AppStateProvider, useApp, useTheme } from '../state/AppState';
import { PremiumProvider } from '../state/Premium';
import { fonts } from '../theme/tokens';

SplashScreen.preventAutoHideAsync().catch(() => {});
configureAudio();

function Navigator() {
  const { ready, prefs } = useApp();
  const theme = useTheme();
  const [fontsLoaded] = useFonts({
    [fonts.serif]: InstrumentSerif_400Regular,
    [fonts.serifItalic]: InstrumentSerif_400Regular_Italic,
    [fonts.sans400]: HankenGrotesk_400Regular,
    [fonts.sans500]: HankenGrotesk_500Medium,
    [fonts.sans600]: HankenGrotesk_600SemiBold,
  });
  const loaded = ready && fontsLoaded;

  useEffect(() => {
    if (loaded) SplashScreen.hideAsync().catch(() => {});
  }, [loaded]);

  // Keep the next few weeks of morning messages scheduled: on launch, whenever the app comes
  // back to the foreground, and when the time, encouragement style or due date changes.
  const { morning, faith, dueDate, onboarded } = prefs;
  useEffect(() => {
    if (!ready || !onboarded) return;
    const sync = () => syncMorningReminders({ morning, faith, dueDate });
    sync();
    const sub = AppState.addEventListener('change', s => s === 'active' && sync());
    return () => sub.remove();
  }, [ready, onboarded, morning, faith, dueDate]);

  if (!loaded) return null;
  return (
    <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: theme.bg } }}>
      <Stack.Screen name="index" />
      <Stack.Screen name="welcome" options={{ animation: 'fade' }} />
      <Stack.Screen name="onboarding" />
      <Stack.Screen name="(tabs)" options={{ animation: 'fade', gestureEnabled: false }} />
      <Stack.Screen name="meditation" options={{ presentation: 'fullScreenModal', contentStyle: { backgroundColor: theme.meditation.bg } }} />
      <Stack.Screen name="labor" options={{ presentation: 'fullScreenModal', contentStyle: { backgroundColor: '#1C1512' } }} />
      <Stack.Screen name="settings" options={{ presentation: 'modal' }} />
      <Stack.Screen name="birth-plan" options={{ presentation: 'modal' }} />
      <Stack.Screen name="premium" options={{ presentation: 'modal' }} />
      <Stack.Screen name="coach" />
    </Stack>
  );
}

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <AppStateProvider>
        <PremiumProvider>
          <Navigator />
        </PremiumProvider>
      </AppStateProvider>
    </SafeAreaProvider>
  );
}
