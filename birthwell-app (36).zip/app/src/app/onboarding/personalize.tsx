import { router } from 'expo-router';
import { useState } from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import { CoachPicker } from '../../components/CoachPicker';
import { PremiumTag } from '../../components/PremiumTag';
import { PrimaryButton } from '../../components/PrimaryButton';
import { Screen } from '../../components/Screen';
import { SoundThumb } from '../../components/SoundThumb';
import { Em, Kicker, Txt } from '../../components/Txt';
import { AMBIENCE, type Faith } from '../../data/content';
import { isAmbienceFree } from '../../lib/access';
import { syncMorningReminders } from '../../lib/morningReminders';
import { useApp } from '../../state/AppState';
import { usePremium } from '../../state/Premium';
import { light, palette } from '../../theme/tokens';

// Onboarding 6 · Make BirthWell yours: the three choices that matter most, saved straight to
// the same settings the rest of the app uses. Finishing (or skipping) completes onboarding.
const MODES: { value: Faith; label: string; sub: string }[] = [
  { value: 'sec', label: 'Grounded', sub: 'Calming, gentle encouragement.' },
  { value: 'faith', label: 'Faith-centered', sub: 'Gentle encouragement woven with faith.' },
];

export default function Personalize() {
  const { prefs, set } = useApp();
  const { premium } = usePremium();
  const t = light;
  const [note, setNote] = useState<string | null>(null);

  const finish = () => {
    set({ onboarded: true });
    // The iPhone asks once whether BirthWell may send the morning word.
    syncMorningReminders(prefs, true).finally(() => router.replace('/(tabs)'));
  };
  const pickSound = (id: (typeof AMBIENCE)[number]['id'], name: string) => {
    if (!premium && !isAmbienceFree(id)) return setNote(`${name} is part of BirthWell Premium.`);
    setNote(null);
    set({ ambience: id });
  };

  return (
    <Screen bg={t.bg} darkContent padding={{ paddingTop: 14, paddingHorizontal: 28 }} bottom={30}>
      <View style={{ flexDirection: 'row', justifyContent: 'flex-end' }}>
        <Pressable onPress={finish} hitSlop={12} accessibilityRole="button">
          <Txt w={500} size={14} color={t.muted}>I’ll choose later</Txt>
        </Pressable>
      </View>
      <Txt serif size={40} lh={1.02} ls={-0.01} color={t.text} style={{ marginTop: 14 }} accessibilityRole="header">
        Make BirthWell <Em color={t.accent}>yours.</Em>
      </Txt>
      <Txt size={14.5} lh={1.5} color={t.muted} style={{ marginTop: 8 }}>A few little choices to make your experience feel just right.</Txt>

      <Kicker color={t.muted} style={{ marginTop: 20, marginBottom: 8 }}>Your experience</Kicker>
      <View style={{ flexDirection: 'row', gap: 10 }}>
        {MODES.map(m => {
          const on = prefs.faith === m.value;
          return (
            <Pressable
              key={m.value}
              onPress={() => set({ faith: m.value })}
              accessibilityRole="radio"
              accessibilityState={{ selected: on }}
              style={{ flex: 1, padding: 14, borderRadius: 18, borderWidth: on ? 1.5 : 1, borderColor: on ? palette.espresso : 'rgba(46,36,32,0.15)', backgroundColor: on ? palette.paper : 'transparent', gap: 4 }}
            >
              <Txt serif size={21} lh={1.05} color={t.text}>{m.label}</Txt>
              <Txt size={12} lh={1.35} color={t.muted}>{m.sub}</Txt>
            </Pressable>
          );
        })}
      </View>

      <Kicker color={t.muted} style={{ marginTop: 20, marginBottom: 8 }}>Your soundscape</Kicker>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flexGrow: 0, flexShrink: 0, marginHorizontal: -28 }} contentContainerStyle={{ paddingHorizontal: 28, gap: 12 }}>
        {AMBIENCE.filter(a => a.id !== 'own').map(a => {
          const locked = !premium && !isAmbienceFree(a.id);
          const on = prefs.ambience === a.id;
          return (
            <Pressable key={a.id} onPress={() => pickSound(a.id, a.name)} accessibilityRole="radio" accessibilityState={{ selected: on }} accessibilityLabel={`${a.name}${locked ? ', Premium' : ''}`} style={{ alignItems: 'center', gap: 6, width: 74 }}>
              <SoundThumb id={a.id} ring={on ? palette.espresso : t.hairline} />
              <Txt size={11.5} color={on ? t.text : t.muted} numberOfLines={1}>{a.id === 'off' ? 'None' : a.name}</Txt>
              {locked && <PremiumTag color={t.accent} />}
            </Pressable>
          );
        })}
      </ScrollView>
      {!!note && (
        <Txt size={12.5} color={t.muted} style={{ marginTop: 6 }} accessibilityLiveRegion="polite">{note}</Txt>
      )}

      <Kicker color={t.muted} style={{ marginTop: 18, marginBottom: 4 }}>Your coaching voice</Kicker>
      <View style={{ flex: 1, minHeight: 160 }}>
        <CoachPicker t={t} />
      </View>

      <PrimaryButton label="Continue to BirthWell" onPress={finish} style={{ marginTop: 12 }} />
      <Txt size={12} color={t.muted} style={{ textAlign: 'center', marginTop: 10 }}>You can always change these in Settings later.</Txt>
    </Screen>
  );
}
