import { Stack } from 'expo-router';
import { light } from '../../theme/tokens';

export default function OnboardingLayout() {
  return <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: light.bg } }} />;
}
