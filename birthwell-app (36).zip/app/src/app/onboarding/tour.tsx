import { router, useLocalSearchParams } from 'expo-router';
import type { ReactNode } from 'react';
import { Pressable, View } from 'react-native';
import { CoachPortrait } from '../../components/Coach';
import { PrimaryButton } from '../../components/PrimaryButton';
import { Screen } from '../../components/Screen';
import { SoundThumb } from '../../components/SoundThumb';
import { Em, Kicker, Txt } from '../../components/Txt';
import { AMBIENCE, COACHES, meditationForWeek, titleParts, versionFor } from '../../data/content';
import { pregnancy } from '../../lib/time';
import { useApp } from '../../state/AppState';
import { light, palette } from '../../theme/tokens';

// Onboarding 2–4 · Three feature slides between the due date and BirthWell Premium.
const t = light;
const WAVE = [8, 14, 22, 30, 38, 44, 40, 34, 26, 30, 36, 28, 20, 14, 10, 16, 22, 18, 12, 8];
const card = { backgroundColor: palette.paper, borderRadius: 24, padding: 20, borderWidth: 1, borderColor: 'rgba(46,36,32,0.08)' } as const;

// Slide 1: a contraction in progress, with the coach speaking.
function TimerPreview() {
  const maren = COACHES[0];
  return (
    <View style={[card, { gap: 16 }]} accessible accessibilityLabel="Preview: a contraction being timed while Maren coaches your breathing">
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <Kicker size={10} color={t.accent}>Contraction 6 · in progress</Kicker>
        <Kicker size={10} color={t.muted}>Every 4 min</Kicker>
      </View>
      <Txt serif size={64} lh={1} tabular color={t.text}>0:42</Txt>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, height: 46 }}>
        {WAVE.map((h, i) => (
          <View key={i} style={{ flex: 1, height: h, borderRadius: 3, backgroundColor: i < 12 ? maren.color : t.hairline }} />
        ))}
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <CoachPortrait coach={maren} bg={palette.paper} />
        <Txt serif italic size={18} lh={1.3} color="#4F423B" style={{ flex: 1 }}>“Let your breath out be long and slow. You’re doing well.”</Txt>
      </View>
    </View>
  );
}

// Slide 2: five coaches, soundscapes and the two modes.
function ChoicePreview() {
  return (
    <View style={[card, { gap: 18 }]} accessible accessibilityLabel="Preview: five coaching voices, soundscapes, and Grounded or Faith-centered encouragement">
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        {COACHES.map(c => (
          <View key={c.name} style={{ alignItems: 'center', gap: 6 }}>
            <CoachPortrait coach={c} bg={palette.paper} />
            <Txt w={500} size={12} color={t.text}>{c.name}</Txt>
          </View>
        ))}
      </View>
      <View style={{ height: 1, backgroundColor: t.hairline }} />
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        {AMBIENCE.filter(a => ['desert', 'rain', 'hearth', 'golden'].includes(a.id)).map(a => (
          <View key={a.id} style={{ alignItems: 'center', gap: 6, width: 70 }}>
            <SoundThumb id={a.id} ring={t.hairline} />
            <Txt size={11} color={t.muted} numberOfLines={1}>{a.name}</Txt>
          </View>
        ))}
      </View>
      <View style={{ flexDirection: 'row', gap: 10 }}>
        {['Grounded', 'Faith-centered'].map(m => (
          <View key={m} style={{ flex: 1, height: 38, borderRadius: 19, borderWidth: 1, borderColor: t.hairline, alignItems: 'center', justifyContent: 'center' }}>
            <Txt w={500} size={13.5} color={t.text}>{m}</Txt>
          </View>
        ))}
      </View>
    </View>
  );
}

// Slide 3: pregnancy, labor and everyday support, using her own week.
function JourneyPreview() {
  const { prefs } = useApp();
  const week = Math.min(42, Math.max(6, pregnancy(prefs.dueDate).week));
  const med = titleParts(meditationForWeek(week, versionFor(prefs.faith)).title);
  const stage = (kicker: string, body: ReactNode) => (
    <View style={[card, { paddingVertical: 16, gap: 6 }]}>
      <Kicker size={10} color={t.accent}>{kicker}</Kicker>
      {body}
    </View>
  );
  return (
    <View style={{ gap: 10 }}>
      {stage(
        `Pregnancy · Week ${week}`,
        <Txt serif size={22} lh={1.15} color={t.text}>
          {med.lead} <Em color={t.accent}>{med.rest}</Em>
        </Txt>,
      )}
      {stage('Labor', <Txt size={14.5} lh={1.4} color="#4F423B">Contraction timing, a coach in your ear, and soothing sounds.</Txt>)}
      {stage('Every day', <Txt size={14.5} lh={1.4} color="#4F423B">A morning word, your birth plan and a hospital bag checklist.</Txt>)}
    </View>
  );
}

const SLIDES = [
  {
    title: ['More than a', 'contraction timer.'],
    body: 'Feel guided and supported through every contraction with real-time coaching, calming voices, and soothing sounds.',
    Visual: TimerPreview,
  },
  {
    title: ['Your birth.', 'Your kind of support.'],
    body: 'Choose from five comforting coaching voices, relaxing soundscapes, and Grounded or Faith-centered encouragement. Make every moment feel more like you.',
    Visual: ChoicePreview,
  },
  {
    title: ['Support for the', 'whole journey.'],
    // Postpartum meditations aren't part of the library yet, so they aren't promised here.
    body: 'Unwind with weekly pregnancy meditations, feel supported through labor, and keep everything for the big day in one peaceful place.',
    Visual: JourneyPreview,
  },
];

const toPremium = () => router.push({ pathname: '/premium', params: { from: 'onboarding' } });

export default function Tour() {
  const page = Math.min(SLIDES.length - 1, Math.max(0, Number(useLocalSearchParams<{ page?: string }>().page ?? 0) || 0));
  const s = SLIDES[page];
  const last = page === SLIDES.length - 1;
  const next = () => (last ? toPremium() : router.push({ pathname: '/onboarding/tour', params: { page: String(page + 1) } }));

  return (
    <Screen bg={t.bg} darkContent scroll padding={{ paddingTop: 14, paddingHorizontal: 28 }} bottom={36}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <Pressable onPress={() => router.back()} hitSlop={12} accessibilityRole="button">
          <Txt w={500} size={14} color={t.muted}>Back</Txt>
        </Pressable>
        <Pressable onPress={toPremium} hitSlop={12} accessibilityRole="button">
          <Txt w={500} size={14} color={t.muted}>Skip</Txt>
        </Pressable>
      </View>

      <Txt serif size={44} lh={1.02} ls={-0.01} color={t.text} style={{ marginTop: 28 }} accessibilityRole="header">
        {s.title[0]} <Em color={t.accent}>{s.title[1]}</Em>
      </Txt>
      <Txt size={16} lh={1.5} color="#4F423B" style={{ marginTop: 14 }}>{s.body}</Txt>
      <View style={{ marginTop: 26 }}>
        <s.Visual />
      </View>

      <View style={{ marginTop: 'auto', paddingTop: 26 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 8, marginBottom: 18 }} accessible accessibilityLabel={`Page ${page + 1} of ${SLIDES.length}`}>
          {SLIDES.map((_, i) => (
            <View key={i} style={{ width: i === page ? 18 : 6, height: 6, borderRadius: 3, backgroundColor: i === page ? t.text : t.hairline }} />
          ))}
        </View>
        <PrimaryButton label="Continue" onPress={next} />
      </View>
    </Screen>
  );
}
