import { router } from 'expo-router';
import { useMemo, useState } from 'react';
import { Pressable, View } from 'react-native';
import { PrimaryButton } from '../../components/PrimaryButton';
import { Screen } from '../../components/Screen';
import { Em, Txt } from '../../components/Txt';
import { WHEEL_ITEM, WheelColumn } from '../../components/WheelPicker';
import { pregnancy } from '../../lib/time';
import { useApp } from '../../state/AppState';
import { light } from '../../theme/tokens';

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const DAY = 86400000;
const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

function summary(week: number) {
  if (week < 1 || week > 42) return 'Check the date — that’s outside the forty weeks.';
  if (week < 6) return `That makes you ${week} weeks along. Your first meditations begin at week six.`;
  if (week <= 20) return `That makes you ${week} weeks along — a season for rest and connection.`;
  return `That makes you ${week} weeks along — the gentle turn toward preparing for labor.`;
}

// 1c · Onboarding · Due date
export default function DueDate() {
  const { prefs, set } = useApp();
  const t = light;
  const [mode, setMode] = useState<'due' | 'lmp'>('due');
  const [date, setDate] = useState(() => new Date(prefs.dueDate + 'T00:00:00'));

  const thisYear = new Date().getFullYear();
  const years = mode === 'due' ? [thisYear, thisYear + 1] : [thisYear - 1, thisYear];
  const daysInMonth = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  const update = (y: number, m: number, d: number) => setDate(new Date(y, m, Math.min(d, new Date(y, m + 1, 0).getDate())));

  const due = mode === 'due' ? date : new Date(date.getTime() + 280 * DAY);
  const { week } = useMemo(() => pregnancy(iso(due)), [due.getTime()]);
  const yearIndex = Math.max(0, years.indexOf(date.getFullYear()));

  const switchMode = () => {
    const next = mode === 'due' ? 'lmp' : 'due';
    setDate(new Date(due.getTime() + (next === 'lmp' ? -280 : 0) * DAY));
    setMode(next);
  };

  return (
    <Screen bg={t.bg} darkContent scroll padding={{ paddingTop: 14, paddingHorizontal: 32 }}>
      <Pressable onPress={() => router.back()} hitSlop={12} accessibilityRole="button" style={{ alignSelf: 'flex-start' }}>
        <Txt w={500} size={14} color={t.muted}>Back</Txt>
      </Pressable>
      <Txt serif size={48} lh={1} ls={-0.01} color={t.text} style={{ marginTop: 32 }} accessibilityRole="header">
        Let’s make this journey <Em color={t.accent}>yours.</Em>
      </Txt>
      <Txt size={16} lh={1.5} color={t.muted} style={{ marginTop: 14 }}>
        {mode === 'due' ? 'When is your little one expected to arrive?' : 'When did your last period begin?'}
      </Txt>

      <View style={{ marginTop: 38 - WHEEL_ITEM / 4, flexDirection: 'row' }}>
        <View pointerEvents="none" style={{ position: 'absolute', left: 0, right: 0, top: WHEEL_ITEM * 2, height: WHEEL_ITEM, borderTopWidth: 1, borderBottomWidth: 1, borderColor: 'rgba(46,36,32,0.2)' }} />
        <WheelColumn flex={1.6} align="left" color={t.text} items={MONTHS} index={date.getMonth()} onChange={m => update(date.getFullYear(), m, date.getDate())} />
        <WheelColumn
          flex={0.7}
          align="center"
          color={t.text}
          items={Array.from({ length: daysInMonth }, (_, i) => String(i + 1))}
          index={date.getDate() - 1}
          onChange={d => update(date.getFullYear(), date.getMonth(), d + 1)}
        />
        <WheelColumn flex={1} align="right" color={t.text} items={years.map(String)} index={yearIndex} onChange={y => update(years[y], date.getMonth(), date.getDate())} />
      </View>

      <Txt serif italic size={22} lh={1.3} color="#4F423B" style={{ marginTop: 30, marginBottom: 5 }}>{summary(week)}</Txt>

      <View style={{ marginTop: 'auto', gap: 14, paddingTop: 20 }}>
        <PrimaryButton
          label="Continue"
          onPress={() => {
            set({ dueDate: iso(due) });
            router.push('/onboarding/tour');
          }}
        />
        <Pressable onPress={switchMode} accessibilityRole="button" style={{ alignItems: 'center' }}>
          <Txt size={15} color="#8E4E27">{mode === 'due' ? 'Use my last period instead' : 'Use my due date instead'}</Txt>
        </Pressable>
      </View>
    </Screen>
  );
}
