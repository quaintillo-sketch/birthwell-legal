import { router } from 'expo-router';
import { Logo } from '../components/Logo';
import { PrimaryButton } from '../components/PrimaryButton';
import { Screen } from '../components/Screen';
import { Kicker, Txt } from '../components/Txt';
import { LINKS } from '../config/links';
import { DISCLAIMER } from '../data/content';
import { Linking, useWindowDimensions, View } from 'react-native';
import { light, palette } from '../theme/tokens';

// 1b · Welcome
export default function Welcome() {
  const t = light;
  const { width } = useWindowDimensions();
  return (
    <Screen bg={t.bg} darkContent padding={{ paddingTop: 40, paddingHorizontal: 32 }} bottom={44}>
      <View style={{ flex: 1, justifyContent: 'space-between' }}>
        <Kicker color={t.muted}>For the forty weeks — and the night it begins</Kicker>
        <View style={{ gap: 30 }}>
          <Logo height={Math.min(80, ((width - 64) * 149.6) / 794.36)} />
          <View style={{ width: 36, height: 1, backgroundColor: palette.espresso }} />
          <Txt size={17} lh={1.55} color="#4F423B" style={{ maxWidth: 300 }}>
            A quiet companion for pregnancy and labor. A daily word, a weekly meditation, and a coach beside you when it’s time.
          </Txt>
        </View>
        <View style={{ gap: 18, alignItems: 'stretch' }}>
          <PrimaryButton label="Begin" onPress={() => router.push('/onboarding/due-date')} />
          <Txt size={11.5} lh={1.5} color="#8A7B70" style={{ textAlign: 'center' }}>
            {DISCLAIMER}
            {!!LINKS.terms && ' By continuing you agree to the '}
            {!!LINKS.terms && (
              <Txt size={11.5} color="#8A7B70" style={{ textDecorationLine: 'underline' }} onPress={() => Linking.openURL(LINKS.terms)}>Terms of Use</Txt>
            )}
            {!!LINKS.terms && !!LINKS.privacy && ' and '}
            {!!LINKS.terms && !!LINKS.privacy && (
              <Txt size={11.5} color="#8A7B70" style={{ textDecorationLine: 'underline' }} onPress={() => Linking.openURL(LINKS.privacy)}>Privacy Policy</Txt>
            )}
            {!!LINKS.terms && '.'}
          </Txt>
        </View>
      </View>
    </Screen>
  );
}
