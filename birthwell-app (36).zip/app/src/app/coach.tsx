import { router } from 'expo-router';
import { Pressable, View } from 'react-native';
import { CoachPicker } from '../components/CoachPicker';
import { Check, ChevronLeft } from '../components/icons';
import { Screen } from '../components/Screen';
import { Em, Txt } from '../components/Txt';
import { useTheme } from '../state/AppState';

// Choose your coach, opened from Settings › Labor coach.
export default function CoachSettings() {
  const t = useTheme();
  return (
    <Screen bg={t.bg} darkContent={!t.dark} padding={{ paddingTop: 14, paddingHorizontal: 32 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <Pressable onPress={() => router.back()} hitSlop={12} accessibilityRole="button" style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <ChevronLeft color={t.muted} />
          <Txt w={500} size={14} color={t.muted}>Back</Txt>
        </Pressable>
        <Pressable onPress={() => router.back()} hitSlop={12} accessibilityRole="button" style={{ flexDirection: 'row', alignItems: 'center', gap: 7 }}>
          <Check color={t.accent} size={12} />
          <Txt w={500} size={14} color={t.accent}>Done</Txt>
        </Pressable>
      </View>
      <Txt serif size={44} lh={1} ls={-0.01} color={t.text} style={{ marginTop: 30 }}>
        Choose the voice <Em color={t.accent}>beside you.</Em>
      </Txt>
      <Txt size={14} lh={1.5} color={t.muted} style={{ marginTop: 12, marginBottom: 18 }}>Your coach guides each breath during labor. Tap to hear them.</Txt>
      <CoachPicker t={t} />
    </Screen>
  );
}
