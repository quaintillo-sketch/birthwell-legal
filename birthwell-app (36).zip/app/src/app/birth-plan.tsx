import { router } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useRef } from 'react';
import { Pressable, ScrollView, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { CloseX, ShareIcon } from '../components/icons';
import { Em, Kicker, Txt } from '../components/Txt';
import { PLAN_DETAILS, PLAN_NOTE, PLAN_SECTIONS, birthPlanText } from '../data/birthPlan';
import { PlanPoster } from '../components/ExportPosters';
import { type PosterRef, chooseExport, docHtml, exportImage, exportPdf, html } from '../lib/exportDoc';
import { useApp, useTheme } from '../state/AppState';
import { fonts, type Theme } from '../theme/tokens';

// Rows live at module level so text fields keep focus while typing (a component defined
// inside the screen would be recreated on every keystroke).

function CheckRow({ t, label, on, onPress }: { t: Theme; label: string; on: boolean; onPress: () => void }) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="checkbox"
      accessibilityState={{ checked: on }}
      style={{ flexDirection: 'row', alignItems: 'center', gap: 14, minHeight: 48, paddingVertical: 10, borderTopWidth: 1, borderTopColor: t.rowLine }}
    >
      <View
        style={{
          width: 22,
          height: 22,
          borderRadius: 11,
          borderWidth: 1.3,
          borderColor: on ? t.check.fill : t.check.box,
          backgroundColor: on ? t.check.fill : 'transparent',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        {on && <Txt w={600} size={11} color={t.check.mark}>✓</Txt>}
      </View>
      <Txt size={15.5} lh={1.35} color={t.text} style={{ flex: 1 }}>{label}</Txt>
    </Pressable>
  );
}

function Field({
  t,
  label,
  value,
  placeholder,
  multiline,
  onChange,
}: {
  t: Theme;
  label?: string;
  value: string;
  placeholder: string;
  multiline?: boolean;
  onChange: (v: string) => void;
}) {
  return (
    <View style={{ borderTopWidth: 1, borderTopColor: t.rowLine, paddingTop: 10, paddingBottom: 4 }}>
      {!!label && <Txt size={12.5} color={t.muted}>{label}</Txt>}
      <TextInput
        value={value}
        onChangeText={onChange}
        placeholder={placeholder}
        placeholderTextColor={t.faint}
        multiline={multiline}
        accessibilityLabel={label ?? placeholder}
        style={{ fontFamily: fonts.sans400, fontSize: 15.5, color: t.text, paddingVertical: 8, minHeight: multiline ? 56 : undefined, textAlignVertical: 'top' }}
      />
    </View>
  );
}

// Birth plan: preferences to share with the care team, saved on the phone.
export default function BirthPlanScreen() {
  const { prefs, set } = useApp();
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const plan = prefs.birthPlan;
  const chosen = Object.values(plan.picks).filter(Boolean).length;

  const update = (patch: (p: typeof plan) => Partial<typeof plan>) => set(p => ({ birthPlan: { ...p.birthPlan, ...patch(p.birthPlan) } }));
  const poster = useRef<PosterRef>(null);
  const due = new Date(prefs.dueDate).toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' });
  const share = () =>
    chooseExport('Birth plan', {
      text: birthPlanText(plan, prefs.name, prefs.dueDate, prefs.provider),
      pdf: () => {
        const details = [['Provider', prefs.provider], ...PLAN_DETAILS.map(d => [d.label, plan.details[d.id]?.trim() ?? ''])].filter(([, v]) => v);
        const sections = PLAN_SECTIONS.map(s => {
          const picked = s.options.filter(o => plan.picks[o.id]);
          const note = plan.notes[s.id]?.trim();
          if (!picked.length && !note) return '';
          return `<h2>${html.esc(s.title)}</h2>${picked.map(o => html.bullet(o.label)).join('')}${note ? `<div class="notes">${html.esc(note)}</div>` : ''}`;
        }).join('');
        exportPdf(
          docHtml(['Birth', 'plan'], `${prefs.name} · Due ${due}`, `<div style="margin-top:18px">${details.map(([l, v]) => html.field(l, v)).join('')}</div>${sections}<div class="foot">${html.esc(PLAN_NOTE)}</div>`),
          'BirthWell Birth Plan',
        );
      },
      image: () => exportImage(poster, 'BirthWell Birth Plan'),
    });

  return (
    <View style={{ flex: 1, backgroundColor: t.bg, paddingTop: insets.top }}>
      <StatusBar style={t.dark ? 'light' : 'dark'} />
      <PlanPoster ref={poster} plan={plan} name={prefs.name} due={due} provider={prefs.provider} />
      <ScrollView
        contentContainerStyle={{ paddingTop: 10, paddingHorizontal: 28, paddingBottom: Math.max(40, insets.bottom + 10) }}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        automaticallyAdjustKeyboardInsets
      >
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <Pressable onPress={() => router.back()} hitSlop={12} accessibilityRole="button" style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <CloseX color={t.muted} size={11} />
            <Txt w={500} size={14} color={t.muted}>Close</Txt>
          </Pressable>
          <Pressable onPress={share} hitSlop={12} accessibilityRole="button" accessibilityLabel="Save or share birth plan" style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <ShareIcon color={t.accent} size={15} />
            <Txt w={500} size={14} color={t.accent}>Share</Txt>
          </Pressable>
        </View>

        <Txt serif size={52} lh={1} ls={-0.01} color={t.text} style={{ marginTop: 14 }}>
          Birth <Em color={t.accent}>plan</Em>
        </Txt>
        <Txt size={13.5} lh={1.5} color={t.muted} style={{ marginTop: 12 }}>
          {chosen ? `${chosen} preferences chosen. Share it with your provider, or print it for your bag.` : 'Tap what matters to you. Everything is optional, and you can change it any time.'}
        </Txt>

        <Kicker color={t.muted} style={{ marginTop: 30, marginBottom: 4 }}>About you</Kicker>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 12, borderTopWidth: 1, borderTopColor: t.rowLine }}>
          <Txt size={15.5} color={t.text}>{prefs.name}</Txt>
          <Txt size={14} color={t.muted}>{`Provider · ${prefs.provider}`}</Txt>
        </View>
        {PLAN_DETAILS.map(d => (
          <Field
            key={d.id}
            t={t}
            label={d.label}
            value={plan.details[d.id] ?? ''}
            placeholder={d.placeholder}
            onChange={v => update(p => ({ details: { ...p.details, [d.id]: v } }))}
          />
        ))}

        {PLAN_SECTIONS.map(s => (
          <View key={s.id}>
            <Txt serif italic size={24} color={t.text} style={{ marginTop: 30, paddingBottom: 6 }}>{s.title}</Txt>
            {s.options.map(o => (
              <CheckRow
                key={o.id}
                t={t}
                label={o.label}
                on={!!plan.picks[o.id]}
                onPress={() => update(p => ({ picks: { ...p.picks, [o.id]: !p.picks[o.id] } }))}
              />
            ))}
            <Field
              t={t}
              value={plan.notes[s.id] ?? ''}
              placeholder={s.notePlaceholder}
              multiline
              onChange={v => update(p => ({ notes: { ...p.notes, [s.id]: v } }))}
            />
          </View>
        ))}

        <Txt serif italic size={17} lh={1.4} color={t.muted} style={{ marginTop: 28 }}>{PLAN_NOTE}</Txt>
        <Pressable
          onPress={share}
          accessibilityRole="button"
          style={{ marginTop: 24, height: 52, borderRadius: 26, backgroundColor: t.playBg, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10 }}
        >
          <ShareIcon color={t.playIcon} size={15} />
          <Txt w={500} size={15} color={t.playIcon}>Save as PDF, image or text</Txt>
        </Pressable>
      </ScrollView>
    </View>
  );
}
