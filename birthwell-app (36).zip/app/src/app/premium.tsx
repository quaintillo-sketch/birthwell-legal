import { router, useLocalSearchParams } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Linking, Pressable, ScrollView, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Check, CloseX } from '../components/icons';
import { Em, Kicker, Txt } from '../components/Txt';
import { LINKS } from '../config/links';
import type { PurchaseOutcome } from '../lib/access';
import { useTheme } from '../state/AppState';
import { usePremium } from '../state/Premium';

// Everything here is included in the premium entitlement. Postpartum meditations aren't in
// the library yet, so they aren't listed.
const FEATURES = [
  'All 5 personalized coaching voices',
  'Full guided coaching through every contraction',
  'The full library of calming soundscapes',
  'Weekly pregnancy meditations, weeks 6 to 42',
  'Grounded & Faith-centered experiences',
];

const MESSAGES: Partial<Record<PurchaseOutcome, string>> = {
  pending: 'Waiting for approval. Premium unlocks as soon as the purchase is approved, and you can keep using BirthWell in the meantime.',
  failed: 'The purchase didn’t go through, and you haven’t been charged. Please check your connection and try again.',
  'not-found': 'We couldn’t find a previous BirthWell Premium purchase for this Apple ID.',
};

// BirthWell Premium: one-time purchase, opened from onboarding, Settings, or a locked item.
// Never opened during labor.
export default function PremiumScreen() {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const { ready, premium, price, busy, purchase, restore } = usePremium();
  const { from } = useLocalSearchParams<{ from?: string }>();
  const onboarding = from === 'onboarding';
  const [message, setMessage] = useState<string | null>(null);
  const [thanks, setThanks] = useState(false);

  // During onboarding, purchase or Free both lead on to personalization, which finishes
  // onboarding. Someone who already owns Premium is never asked to buy it again.
  const purchasedHere = useRef(false);
  useEffect(() => {
    if (onboarding && ready && premium && !purchasedHere.current) router.replace('/onboarding/personalize');
  }, [onboarding, ready, premium]);
  const finish = () => {
    if (onboarding) router.replace('/onboarding/personalize');
    else if (router.canGoBack()) router.back();
    else router.replace('/(tabs)');
  };
  const handle = (outcome: PurchaseOutcome) => {
    if (outcome === 'purchased' || outcome === 'restored') {
      setMessage(null);
      setThanks(true);
    } else setMessage(MESSAGES[outcome] ?? null); // cancelled: say nothing
  };

  const owned = premium || thanks;
  return (
    <View style={{ flex: 1, backgroundColor: t.bg, paddingTop: insets.top }}>
      <StatusBar style={t.dark ? 'light' : 'dark'} />
      <ScrollView contentContainerStyle={{ paddingTop: 10, paddingHorizontal: 28, paddingBottom: Math.max(36, insets.bottom + 12) }} showsVerticalScrollIndicator={false}>
        {!onboarding && (
          <Pressable onPress={finish} hitSlop={12} accessibilityRole="button" style={{ alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <CloseX color={t.muted} size={11} />
            <Txt w={500} size={14} color={t.muted}>Close</Txt>
          </Pressable>
        )}

        <Kicker color={t.accent} style={{ marginTop: onboarding ? 20 : 28 }}>BirthWell Premium</Kicker>
        {owned ? (
          <>
            <Txt serif size={46} lh={1.02} ls={-0.01} color={t.text} style={{ marginTop: 14 }}>
              Thank you. <Em color={t.accent}>It’s yours to keep.</Em>
            </Txt>
            <Txt size={15} lh={1.55} color={t.muted} style={{ marginTop: 14 }}>
              All five coaches, every soundscape and every guided meditation are unlocked, for this pregnancy and any after it.
            </Txt>
          </>
        ) : (
          <>
            <Txt serif size={44} lh={1.02} ls={-0.01} color={t.text} style={{ marginTop: 14 }}>
              A little more peace, <Em color={t.accent}>for the whole journey.</Em>
            </Txt>
            <Txt size={15} lh={1.55} color={t.muted} style={{ marginTop: 14 }}>Unlock the complete BirthWell experience.</Txt>
          </>
        )}

        <View style={{ marginTop: 24 }}>
          {FEATURES.map(f => (
            <View key={f} style={{ flexDirection: 'row', alignItems: 'center', gap: 14, paddingVertical: 11, borderTopWidth: 1, borderTopColor: t.rowLine }}>
              <View style={{ width: 22, height: 22, borderRadius: 11, backgroundColor: t.check.fill, alignItems: 'center', justifyContent: 'center' }}>
                <Check color={t.check.mark} size={10} />
              </View>
              <Txt size={15.5} color={t.text} style={{ flex: 1 }}>{f}</Txt>
            </View>
          ))}
        </View>

        {!owned && (
          <View style={{ marginTop: 22, borderRadius: 24, backgroundColor: t.meditation.bg, padding: 22, gap: 4 }} accessible accessibilityLabel={`${price}. One purchase, yours for life. One-time payment, lifetime Premium access. No subscription, no recurring charges, ever.`}>
            <Txt serif size={48} lh={1.05} color={t.meditation.title}>{price}</Txt>
            <Txt serif italic size={22} lh={1.2} color={t.meditation.title}>One purchase. Yours for life.</Txt>
            <Txt w={500} size={13.5} lh={1.45} color={t.meditation.body} style={{ marginTop: 8 }}>One-time payment · Lifetime Premium access</Txt>
            <Txt size={13.5} lh={1.45} color={t.meditation.sub}>No subscription. No recurring charges. Ever.</Txt>
          </View>
        )}

        {!!message && !owned && (
          <Txt size={13.5} lh={1.5} color={t.text} style={{ marginTop: 16 }} accessibilityLiveRegion="polite">{message}</Txt>
        )}

        <Pressable
          onPress={
            owned
              ? finish
              : async () => {
                  purchasedHere.current = true;
                  handle(await purchase());
                }
          }
          disabled={busy}
          accessibilityRole="button"
          accessibilityState={{ busy }}
          style={{ marginTop: 22, height: 58, borderRadius: 29, backgroundColor: t.laborButton.bg, alignItems: 'center', justifyContent: 'center', opacity: busy ? 0.7 : 1 }}
        >
          {busy ? (
            <ActivityIndicator color={t.laborButton.text} />
          ) : (
            <Txt w={500} size={16.5} color={t.laborButton.text}>{owned ? 'Continue' : `Unlock Lifetime Access — ${price}`}</Txt>
          )}
        </Pressable>

        {!owned && (
          <>
            <Pressable onPress={finish} accessibilityRole="button" style={{ marginTop: 10, height: 50, borderRadius: 25, borderWidth: 1, borderColor: t.avatarRing, alignItems: 'center', justifyContent: 'center' }}>
              <Txt w={500} size={15.5} color={t.text}>Continue with Free</Txt>
            </Pressable>
            <Pressable
              onPress={async () => {
                purchasedHere.current = true;
                handle(await restore());
              }} disabled={busy} accessibilityRole="button" hitSlop={8} style={{ alignSelf: 'center', marginTop: 16, paddingVertical: 4 }}>
              <Txt w={500} size={14} color={t.accent}>Restore Purchases</Txt>
            </Pressable>

            <Txt size={12.5} lh={1.5} color={t.muted} style={{ marginTop: 22 }}>
              Free always includes unlimited contraction timing and history, Maren’s coaching in both modes, two soundscapes, three meditations, daily encouragement, the hospital bag and your birth plan.
            </Txt>
            <Txt size={11.5} lh={1.5} color={t.faint} style={{ marginTop: 10 }}>
              A single payment charged to your Apple ID. It doesn’t renew, and you can restore it on any device signed in with the same Apple ID.
              {(LINKS.terms || LINKS.privacy) && ' '}
              {!!LINKS.terms && (
                <Txt size={11.5} color={t.faint} style={{ textDecorationLine: 'underline' }} onPress={() => Linking.openURL(LINKS.terms)}>Terms</Txt>
              )}
              {!!LINKS.terms && !!LINKS.privacy && ' · '}
              {!!LINKS.privacy && (
                <Txt size={11.5} color={t.faint} style={{ textDecorationLine: 'underline' }} onPress={() => Linking.openURL(LINKS.privacy)}>Privacy</Txt>
              )}
            </Txt>
          </>
        )}
      </ScrollView>
    </View>
  );
}
