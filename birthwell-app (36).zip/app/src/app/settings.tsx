import * as Haptics from 'expo-haptics';
import { router } from 'expo-router';
import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Alert, Linking, Pressable, View } from 'react-native';
import { ChoiceRow } from '../components/ChoiceRow';
import { CoachInitial } from '../components/Coach';
import { CloseX } from '../components/icons';
import { SoundThumb } from '../components/SoundThumb';
import { OwnMusic } from '../components/OwnMusic';
import { Segmented, Slider, Toggle } from '../components/controls';
import { Screen } from '../components/Screen';
import { Em, Kicker, Txt } from '../components/Txt';
import { SILENT_SWITCH_NOTE } from '../components/AudioSheet';
import { firstPhrase, modeFor } from '../data/coaching';
import { AMBIENCE, DISCLAIMER, FAITH, MORNING_OPTIONS } from '../data/content';
import { useAmbience } from '../lib/ambience';
import { FREQUENCIES } from '../lib/coachingEngine';
import { playPhrase, stopVoice } from '../lib/coachVoice';
import { notificationsBlocked, syncMorningReminders } from '../lib/morningReminders';
import { formatBytes, meditationsConfigured, removeAllDownloads, removeDownload, useDownloads } from '../lib/meditations';
import { LINKS } from '../config/links';
import { useApp, useTheme, type Appearance } from '../state/AppState';
import { useActiveCoach, usePremium } from '../state/Premium';
import { effectiveAmbience, isAmbienceFree } from '../lib/access';
import { SimulatedStorePanel } from '../components/SimulatedStorePanel';
import type { Theme } from '../theme/tokens';

function Volume({ t, label, value, onChange }: { t: Theme; label: string; value: number; onChange: (v: number) => void }) {
  return (
    <View style={{ gap: 8, paddingTop: 14, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: t.rowLine }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <Txt size={17} color={t.text}>{label}</Txt>
        <Txt size={15} color={t.muted}>{`${Math.round(value * 100)}%`}</Txt>
      </View>
      <Slider
        value={value}
        onChange={onChange}
        track={t.sliderTrack}
        fill={t.sliderFill}
        thumb={t.sliderThumb}
        thumbBorder={t.sliderThumbBorder}
        shadow={t.dark ? '#EFE4D6' : '#2E2420'}
      />
    </View>
  );
}

// 1k / 2d · Settings
export default function Settings() {
  const { prefs, set } = useApp();
  const { coach, index: coachIndex } = useActiveCoach();
  const { premium, price, restore, busy, storeKind } = usePremium();
  const t = useTheme();
  const [open, setOpen] = useState<'coaching' | 'morning' | 'ambience' | 'downloads' | null>(null);
  const [blocked, setBlocked] = useState(false);
  useEffect(() => {
    notificationsBlocked().then(setBlocked);
  }, []);
  const downloads = useDownloads();
  const totalBytes = downloads.reduce((n, d) => n + d.bytes, 0);
  const toggle = (k: NonNullable<typeof open>) => setOpen(o => (o === k ? null : k));
  const c = { text: t.text, muted: t.muted, accent: t.accent, line: t.rowLine, ring: t.check.box };

  // Preview sounds while adjusting them: ambience plays while its list is open, and the
  // coach says her volume-test phrase shortly after the coach volume changes.
  useAmbience(open === 'ambience');
  const firstVolume = useRef(true);
  useEffect(() => {
    if (firstVolume.current) {
      firstVolume.current = false;
      return;
    }
    const id = setTimeout(() => {
      playPhrase(coachIndex, firstPhrase(coachIndex, modeFor(prefs.faith), 'volume'), prefs.coachVolume, { interrupt: true });
    }, 450);
    return () => clearTimeout(id);
  }, [prefs.coachVolume]);
  useEffect(() => stopVoice, []);

  const Section = ({ children, mb = 12 }: { children: string; mb?: number }) => (
    <Kicker size={11.5} color={t.muted} style={{ marginTop: 44, marginBottom: mb }}>{children}</Kicker>
  );
  const Described = ({ title, desc, right, onPress }: { title: string; desc: string; right: ReactNode; onPress?: () => void }) => (
    <Pressable
      onPress={onPress}
      disabled={!onPress}
      accessibilityRole={onPress ? 'switch' : undefined}
      style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 16, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: t.rowLine }}
    >
      <View style={{ flex: 1, gap: 4 }}>
        <Txt size={17} color={t.text}>{title}</Txt>
        <Txt size={12.5} lh={1.4} color={t.muted}>{desc}</Txt>
      </View>
      {right}
    </Pressable>
  );
  return (
    <Screen bg={t.bg} darkContent={!t.dark} scroll padding={{ paddingTop: 10, paddingHorizontal: 28 }} bottom={40}>
      <Pressable
        onPress={() => router.back()}
        hitSlop={12}
        accessibilityRole="button"
        style={{ alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 8 }}
      >
        <CloseX color={t.muted} size={11} />
        <Txt w={500} size={14} color={t.muted}>Done</Txt>
      </Pressable>
      <Txt serif size={52} lh={1} ls={-0.01} color={t.text} style={{ marginTop: 14 }}>Settings</Txt>

      <Pressable
        onPress={() => router.push('/premium')}
        accessibilityRole="button"
        style={{ marginTop: 22, borderRadius: 22, backgroundColor: t.meditation.bg, padding: 18, flexDirection: 'row', alignItems: 'center', gap: 14 }}
      >
        <View style={{ flex: 1, gap: 4 }}>
          <Kicker size={10} color={t.meditation.kicker}>{premium ? 'BirthWell Premium' : 'Upgrade to Premium'}</Kicker>
          <Txt serif size={22} lh={1.15} color={t.meditation.title}>
            {premium ? <>Yours to keep. <Em color={t.meditation.body}>Thank you.</Em></> : <>All coaches, sounds & <Em color={t.meditation.body}>meditations</Em></>}
          </Txt>
          {!premium && <Txt size={12.5} color={t.meditation.sub}>{`${price} · one-time purchase · no subscription`}</Txt>}
        </View>
        <Txt size={18} color={t.meditation.sub}>›</Txt>
      </Pressable>

      <Section mb={8}>Labor coach</Section>
      <Pressable
        onPress={() => router.push('/coach')}
        accessibilityRole="button"
        accessibilityLabel={`Choose your coach. Currently ${coach.name}, ${coach.role}`}
        style={{ paddingTop: 12, paddingBottom: 14, gap: 12, borderBottomWidth: 1, borderBottomColor: t.rowLine }}
      >
        <View style={{ gap: 4 }}>
          <Txt size={17} color={t.text}>Choose your coach</Txt>
          <Txt size={12.5} lh={1.4} color={t.muted}>The voice that guides your breathing and encourages you through labor. You can listen to each one before choosing.</Txt>
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <CoachInitial coach={coach} letterColor={t.coachLetter} />
          <Txt size={16} color={t.text} style={{ flex: 1 }}>
            {coach.name} <Em color={t.muted}>{coach.role}</Em>
          </Txt>
          <Txt w={500} size={14} color={t.accent}>Change ›</Txt>
        </View>
      </Pressable>
      <Volume t={t} label="Coach volume" value={prefs.coachVolume} onChange={coachVolume => set({ coachVolume })} />
      <ChoiceRow
        label="Coaching"
        desc="How often your coach speaks during a contraction. She always speaks once when one ends, then stays quiet."
        options={FREQUENCIES}
        value={prefs.coaching}
        onChange={coaching => set({ coaching })}
        open={open === 'coaching'}
        onToggle={() => toggle('coaching')}
        c={c}
      />

      <Section>Daily encouragement</Section>
      <Segmented
        options={[
          { label: FAITH.faith.label, value: 'faith' as const },
          { label: FAITH.sec.label, value: 'sec' as const },
        ]}
        value={prefs.faith}
        onChange={faith => set({ faith })}
        track={t.segTrack}
        active={t.segActive}
        color={t.text}
      />
      <Txt size={12.5} lh={1.45} color={t.muted} style={{ marginTop: 10, marginBottom: 4 }}>{FAITH[prefs.faith].desc}</Txt>
      <ChoiceRow
        label="Morning delivery"
        desc={blocked && prefs.morning !== 'Off' ? 'Notifications are turned off for BirthWell in iPhone Settings.' : undefined}
        options={MORNING_OPTIONS.map(m => ({ value: m, label: m }))}
        value={prefs.morning}
        onChange={morning => {
          set({ morning });
          syncMorningReminders({ ...prefs, morning }, true).then(r => setBlocked(r === 'denied'));
        }}
        open={open === 'morning'}
        onToggle={() => toggle('morning')}
        c={c}
      />
      {blocked && prefs.morning !== 'Off' ? (
        <Pressable onPress={() => Linking.openSettings()} accessibilityRole="link" hitSlop={6} style={{ paddingVertical: 12 }}>
          <Txt size={14} color={t.accent}>Open iPhone Settings</Txt>
        </Pressable>
      ) : null}

      <Section mb={4}>Audio</Section>
      <ChoiceRow
        label="Ambience / Sound"
        desc={open === 'ambience' ? 'Playing a preview while this list is open.' : 'Soft nature soundscapes beneath meditations and labor mode.'}
        options={AMBIENCE.map(a => ({ value: a.id, label: a.name, sub: a.sub, thumb: <SoundThumb id={a.id} ring={t.check.box} />, locked: !premium && !isAmbienceFree(a.id) }))}
        value={effectiveAmbience(prefs.ambience, premium)}
        onChange={ambience => (premium || isAmbienceFree(ambience) ? set({ ambience }) : router.push('/premium'))}
        open={open === 'ambience'}
        onToggle={() => toggle('ambience')}
        c={c}
      />
      {prefs.ambience === 'own' ? (
        <View style={{ borderBottomWidth: 1, borderBottomColor: t.rowLine }}>
          <OwnMusic c={{ text: t.text, muted: t.muted, accent: t.accent, line: t.rowLine, toggleOn: t.toggleOn, toggleOff: t.toggleOff, knob: t.knob }} />
        </View>
      ) : (
        <Volume t={t} label="Sound volume" value={prefs.soundVolume} onChange={soundVolume => set({ soundVolume })} />
      )}
      <Txt size={12.5} lh={1.45} color={t.muted} style={{ paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: t.rowLine }}>{SILENT_SWITCH_NOTE}</Txt>
      <Described
        title="Breathing haptics"
        desc="Taps build as you breathe in and slow as you breathe out, so you can follow without looking. If you feel nothing, check iPhone Settings › Sounds & Haptics › System Haptics."
        onPress={() => {
          if (!prefs.haptics) Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy).catch(() => {});
          set({ haptics: !prefs.haptics });
        }}
        right={<Toggle on={prefs.haptics} onColor={t.toggleOn} offColor={t.toggleOff} knob={t.knob} />}
      />

      <Section mb={4}>Meditations</Section>
      <Described
        title="Download on Wi‑Fi"
        desc={`Saves this week’s meditation in your chosen version (${FAITH[prefs.faith].label}) so it plays offline.`}
        onPress={() => set({ autoDownload: !prefs.autoDownload })}
        right={<Toggle on={prefs.autoDownload} onColor={t.toggleOn} offColor={t.toggleOff} knob={t.knob} />}
      />
      <View style={{ borderBottomWidth: 1, borderBottomColor: t.rowLine }}>
        <Pressable
          onPress={() => toggle('downloads')}
          accessibilityRole="button"
          accessibilityState={{ expanded: open === 'downloads' }}
          style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 54 }}
        >
          <Txt size={17} color={t.text}>Downloaded</Txt>
          <Txt size={15} color={t.muted}>{`${downloads.length ? `${downloads.length} · ${formatBytes(totalBytes)}` : 'None'} ${open === 'downloads' ? '⌃' : '›'}`}</Txt>
        </Pressable>
        {open === 'downloads' && (
          <View style={{ paddingBottom: 10 }}>
            {!meditationsConfigured() && (
              <Txt size={12.5} lh={1.45} color={t.muted} style={{ paddingBottom: 8 }}>Meditation hosting isn’t connected yet, so there’s nothing to download.</Txt>
            )}
            {downloads.map(d => (
              <View key={`${d.version}-${d.week}`} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 12, borderTopWidth: 1, borderTopColor: t.rowLine }}>
                <View style={{ flex: 1, gap: 2 }}>
                  <Txt size={15.5} color={t.text}>{`Week ${d.week}`}</Txt>
                  <Txt size={12.5} color={t.muted}>{`${d.version === 'faith' ? FAITH.faith.label : FAITH.sec.label} · ${formatBytes(d.bytes)}`}</Txt>
                </View>
                <Pressable onPress={() => removeDownload(d)} hitSlop={10} accessibilityRole="button" accessibilityLabel={`Remove week ${d.week}`}>
                  <Txt w={500} size={14} color={t.accent}>Remove</Txt>
                </Pressable>
              </View>
            ))}
            {downloads.length > 1 && (
              <Pressable onPress={removeAllDownloads} accessibilityRole="button" style={{ paddingVertical: 12, borderTopWidth: 1, borderTopColor: t.rowLine }}>
                <Txt w={500} size={14} color={t.accent}>Remove all downloads</Txt>
              </Pressable>
            )}
          </View>
        )}
      </View>

      <Section>Appearance</Section>
      <Segmented<Appearance>
        options={[
          { label: 'Light', value: 'light' },
          { label: 'Dark', value: 'dark' },
          { label: 'Follow device', value: 'system' },
        ]}
        value={prefs.appearance}
        onChange={appearance => set({ appearance })}
        track={t.segTrack}
        active={t.segActive}
        color={t.text}
      />
      <Txt size={12.5} lh={1.45} color={t.muted} style={{ marginTop: 10 }}>Follow device matches your iPhone’s setting. Labor mode always opens dark.</Txt>

      <Section mb={4}>About</Section>
      <Pressable
        onPress={async () => {
          const outcome = await restore();
          Alert.alert(
            'Restore purchases',
            outcome === 'restored'
              ? 'BirthWell Premium is restored. Thank you!'
              : outcome === 'not-found'
                ? 'We couldn’t find a previous BirthWell Premium purchase for this Apple ID.'
                : 'We couldn’t reach the App Store. Please check your connection and try again.',
          );
        }}
        disabled={busy}
        accessibilityRole="button"
        style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', minHeight: 54, borderBottomWidth: 1, borderBottomColor: t.rowLine }}
      >
        <Txt size={17} color={t.text}>Restore purchases</Txt>
        <Txt size={16} color={t.faint}>›</Txt>
      </Pressable>
      <Pressable
        onPress={() => router.push('/welcome')}
        accessibilityRole="button"
        style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', minHeight: 54, borderBottomWidth: 1, borderBottomColor: t.rowLine }}
      >
        <Txt size={17} color={t.text}>Replay introduction</Txt>
        <Txt size={16} color={t.faint}>›</Txt>
      </Pressable>
      {[
        { label: 'Privacy policy', url: LINKS.privacy },
        { label: 'Terms of use', url: LINKS.terms },
        { label: 'Contact support', url: LINKS.support },
      ].map(l => (
        <Pressable
          key={l.label}
          onPress={() => (l.url ? Linking.openURL(l.url).catch(() => {}) : Alert.alert(l.label, 'Coming soon.'))}
          accessibilityRole="link"
          style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', minHeight: 54, borderBottomWidth: 1, borderBottomColor: t.rowLine }}
        >
          <Txt size={17} color={t.text}>{l.label}</Txt>
          <Txt size={16} color={t.faint}>›</Txt>
        </Pressable>
      ))}
      <Txt size={12.5} lh={1.45} color={t.muted} style={{ marginTop: 14 }}>
        {DISCLAIMER}
      </Txt>

      {storeKind === 'simulated' && <SimulatedStorePanel t={t} />}
    </Screen>
  );
}
