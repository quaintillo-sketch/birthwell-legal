import { Redirect } from 'expo-router';
import { useApp } from '../state/AppState';

export default function Index() {
  const { prefs } = useApp();
  return <Redirect href={prefs.onboarded ? '/(tabs)' : '/welcome'} />;
}
