import { router } from 'expo-router';
import { useEffect } from 'react';
import { Image } from 'expo-image';
import { Animated, Pressable, View } from 'react-native';
import { useFade } from '../../components/controls';
import { Gear, PlayGlyph, Stopwatch } from '../../components/icons';
import { Logo } from '../../components/Logo';
import { PregnancyProgress } from '../../components/PregnancyProgress';
import { Screen } from '../../components/Screen';
import { Em, Kicker, serifBaselineFromBottom, Txt } from '../../components/Txt';
import { meditationForWeek, titleParts, versionFor } from '../../data/content';
import { reflectionForDay } from '../../data/reflections';
import { autoDownload } from '../../lib/meditations';
import { greeting, pregnancy } from '../../lib/time';
import { useApp, useTheme } from '../../state/AppState';
import { usePremium } from '../../state/Premium';
import { isMeditationFree } from '../../lib/access';

// 1f / 2a · Home · Today
export default function Home() {
  const { prefs } = useApp();
  const t = useTheme();
  const { week, weeksToGo, day } = pregnancy(prefs.dueDate);
  const word = reflectionForDay(prefs.faith, day);
  const med = meditationForWeek(week, versionFor(prefs.faith));
  const { premium } = usePremium();
  const medLocked = !premium && !isMeditationFree(week);
  const labor = useFade();
  const planCount = Object.values(prefs.birthPlan.picks).filter(Boolean).length;

  // Fetch this week's meditation in the chosen version, on Wi-Fi, when Home opens.
  useEffect(() => {
    if (prefs.autoDownload && !medLocked) autoDownload(week, versionFor(prefs.faith)).catch(() => {});
  }, [week, prefs.faith, prefs.autoDownload, medLocked]);

  return (
    <Screen bg={t.bg} darkContent={!t.dark} scroll padding={{ paddingTop: 10, paddingHorizontal: 28 }} bottom={12}>
      {/* Painted flowers behind the greeting and week number, flush to the right edge. Their cream
          backdrop matches the light background exactly, so they're shown in light mode only. */}
      {!t.dark && (
        <Image
          source={require('../../../assets/brand/home-flowers.png')}
          style={{ position: 'absolute', top: 48, right: 0, width: 181, height: 276 }}
          contentFit="contain"
          pointerEvents="none"
          accessibilityElementsHidden
          importantForAccessibility="no-hide-descendants"
        />
      )}
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 6 }}>
        <Logo height={30} />
        <Pressable
          onPress={() => router.push('/settings')}
          accessibilityRole="button"
          accessibilityLabel="Settings"
          hitSlop={8}
          style={{ width: 34, height: 34, borderRadius: 17, borderWidth: 1, borderColor: t.avatarRing, alignItems: 'center', justifyContent: 'center' }}
        >
          <Gear color={t.text} size={18} />
        </Pressable>
      </View>
      <Txt serif size={34} lh={1.05} color={t.text} numberOfLines={1} adjustsFontSizeToFit style={{ marginTop: 40 }}>
        {greeting()}, <Em color={t.accent}>{prefs.name}</Em>
      </Txt>

      <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 14, marginTop: 68 }}>
        <Txt serif size={160} lh={0.76} ls={-0.04} color={t.weekNumber}>{String(week)}</Txt>
        {/* "weeks to go" sits on the number's baseline (13px text has ~3px below its own). */}
        <View style={{ gap: 6, paddingBottom: Math.max(0, Math.round(serifBaselineFromBottom(160, 0.76)) - 3) }}>
          <Kicker color={t.muted}>Week</Kicker>
          <Txt serif italic size={28} lh={1} color={t.accent}>of forty</Txt>
          <Txt size={13} color={t.muted}>{weeksToGo === 1 ? '1 week to go' : `${weeksToGo} weeks to go`}</Txt>
        </View>
      </View>

      <View style={{ marginTop: 32 }}>
        <PregnancyProgress week={week} t={t} />
      </View>

      <View style={{ height: 1, backgroundColor: t.hairline, marginTop: 22, marginBottom: 24 }} />
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <Kicker color={t.muted}>{prefs.faith === 'faith' ? 'Today’s word' : 'Today’s reflection'}</Kicker>
        <Kicker color={t.accent}>{word.ref ?? `Day ${day}`}</Kicker>
      </View>
      <Txt serif size={28} lh={1.14} color={t.quote} style={{ marginTop: 16 }}>{word.text}</Txt>

      <View style={{ height: 1, backgroundColor: t.hairline, marginTop: 28, marginBottom: 20 }} />
      <Pressable onPress={() => router.push(medLocked ? '/premium' : '/meditation')} accessibilityRole="button" style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
        <View style={{ flex: 1, gap: 7 }}>
          <Kicker color={t.muted}>{`Week ${week} guided meditation · ${medLocked ? 'Premium' : `${Math.round(med.seconds / 60)} min`}`}</Kicker>
          <Txt serif size={25} lh={1.05} color={t.text}>
            {titleParts(med.title).lead} <Em color={t.dark ? t.quote : undefined}>{titleParts(med.title).rest}</Em>
          </Txt>
        </View>
        <View style={{ width: 52, height: 52, borderRadius: 26, backgroundColor: t.playBg, alignItems: 'center', justifyContent: 'center' }}>
          <PlayGlyph color={t.playIcon} />
        </View>
      </Pressable>

      <View style={{ height: 1, backgroundColor: t.hairline, marginTop: 20 }} />
      <Pressable
        onPress={() => router.push('/birth-plan')}
        accessibilityRole="button"
        style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 16 }}
      >
        <View style={{ gap: 7 }}>
          <Kicker color={t.muted}>Birth plan</Kicker>
          <Txt serif size={22} lh={1.05} color={t.text}>
            {planCount ? <>{`${planCount} preferences `}<Em color={t.accent}>chosen</Em></> : <>Your <Em color={t.accent}>preferences</Em></>}
          </Txt>
        </View>
        <Txt size={18} color={t.faint}>›</Txt>
      </Pressable>

      <Pressable
        onPress={() => router.push('/labor')}
        onPressIn={labor.onPressIn}
        onPressOut={labor.onPressOut}
        accessibilityRole="button"
        style={{ marginTop: 'auto', paddingTop: 24 }}
      >
        <Animated.View style={[{ backgroundColor: t.laborButton.bg, borderRadius: 28, paddingVertical: 18, paddingHorizontal: 20, flexDirection: 'row', alignItems: 'center', gap: 16 }, labor.style]}>
          <Stopwatch color={t.laborButton.text} />
          <View style={{ flex: 1, gap: 6 }}>
            <Kicker size={10} color={t.laborButton.kicker}>Labor mode</Kicker>
            <Txt serif size={26} lh={1} color={t.laborButton.text}>Time a contraction</Txt>
          </View>
          <Txt size={20} color={t.laborButton.text}>→</Txt>
        </Animated.View>
      </Pressable>
    </Screen>
  );
}
