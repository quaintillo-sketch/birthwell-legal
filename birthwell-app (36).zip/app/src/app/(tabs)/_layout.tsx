import { router } from 'expo-router';
import { Tabs } from 'expo-router/js-tabs';
import { Pressable, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Txt } from '../../components/Txt';
import { useTheme } from '../../state/AppState';

// Home, Meditate (the library) and Bag are tabs; Labor opens its full-screen experience.
const ITEMS = [
  { label: 'Home', route: 'index' },
  { label: 'Meditate', route: 'meditations' },
  { label: 'Labor', href: '/labor' },
  { label: 'Bag', route: 'bag' },
] as const;

export default function TabsLayout() {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  return (
    <Tabs
      screenOptions={{ headerShown: false, sceneStyle: { backgroundColor: t.bg } }}
      tabBar={({ state, navigateToTab }) => {
        const current = state.routes[state.index].name;
        return (
          <View
            style={{
              flexDirection: 'row',
              borderTopWidth: 1,
              borderTopColor: t.rowLine,
              backgroundColor: t.bg,
              paddingHorizontal: 12,
              paddingTop: 22,
              paddingBottom: Math.max(insets.bottom, 18) + 4,
            }}
          >
            {ITEMS.map(item => {
              const active = 'route' in item && item.route === current;
              return (
                <Pressable
                  key={item.label}
                  accessibilityRole="tab"
                  accessibilityState={{ selected: active }}
                  onPress={() => {
                    if ('href' in item) return router.push(item.href);
                    const route = state.routes.find(r => r.name === item.route);
                    if (route) navigateToTab(route.key);
                  }}
                  style={{ flex: 1, alignItems: 'center', gap: 7 }}
                >
                  <View style={{ width: 4, height: 4, borderRadius: 2, backgroundColor: active ? t.accent : 'transparent' }} />
                  <Txt w={600} size={11.5} lh={1} ls={0.12} upper color={active ? t.text : t.faint}>{item.label}</Txt>
                </Pressable>
              );
            })}
          </View>
        );
      }}
    >
      <Tabs.Screen name="index" />
      <Tabs.Screen name="meditations" />
      <Tabs.Screen name="bag" />
    </Tabs>
  );
}
