import { useNavigation } from 'expo-router';
import { useRef, useState } from 'react';
import { Pressable, ScrollView, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { ChevronLeft, ShareIcon } from '../../components/icons';
import { Em, Kicker, Txt } from '../../components/Txt';
import { BagPoster } from '../../components/ExportPosters';
import { type PosterRef, chooseExport, docHtml, exportImage, exportPdf, html } from '../../lib/exportDoc';
import { BAG_GROUPS, type BagItem } from '../../data/content';
import { useApp, useTheme } from '../../state/AppState';
import { fonts } from '../../theme/tokens';

// 1j / 2c · Hospital bag
export default function Bag() {
  const { prefs, set } = useApp();
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const [adding, setAdding] = useState(false);
  const [draft, setDraft] = useState('');
  const navigation = useNavigation();

  const groups = BAG_GROUPS.map((g, i) =>
    i === 0 ? { ...g, items: [...g.items, ...prefs.customItems.map(c => ({ ...c, note: '' }))] } : g,
  );
  const all = groups.flatMap(g => g.items);
  const packed = all.filter(i => prefs.checked[i.id]).length;
  const poster = useRef<PosterRef>(null);
  const share = () => {
    const lines = ['Hospital bag', `${packed} of ${all.length} packed`];
    for (const g of groups) {
      lines.push('', g.name.toUpperCase());
      for (const it of g.items) lines.push(`${prefs.checked[it.id] ? '☑' : '☐'} ${it.label}${it.note ? ` (${it.note})` : ''}`);
    }
    lines.push('', 'Made with BirthWell');
    chooseExport('Hospital bag', {
      text: lines.join('\n'),
      pdf: () =>
        exportPdf(
          docHtml(
            ['The', 'bag'],
            `Hospital bag · ${packed} of ${all.length} packed`,
            groups.map(g => `<h2>${html.esc(g.name)}</h2>${g.items.map(it => html.check(it.label, !!prefs.checked[it.id], it.note)).join('')}`).join(''),
          ),
          'BirthWell Hospital Bag',
        ),
      image: () => exportImage(poster, 'BirthWell Hospital Bag'),
    });
  };
  const toggle = (id: string) => set(p => ({ checked: { ...p.checked, [id]: !p.checked[id] } }));

  const add = () => {
    const label = draft.trim();
    if (label) set(p => ({ customItems: [...p.customItems, { id: 'c' + Date.now(), label }] }));
    setDraft('');
    setAdding(false);
  };

  const Row = ({ it }: { it: BagItem }) => {
    const on = !!prefs.checked[it.id];
    return (
      <Pressable
        onPress={() => toggle(it.id)}
        accessibilityRole="checkbox"
        accessibilityState={{ checked: on }}
        style={{ flexDirection: 'row', alignItems: 'center', gap: 14, minHeight: 48, borderTopWidth: 1, borderTopColor: t.rowLine }}
      >
        <View
          style={{
            width: 22,
            height: 22,
            borderRadius: 11,
            borderWidth: 1.3,
            borderColor: on ? t.check.fill : t.check.box,
            backgroundColor: on ? t.check.fill : 'transparent',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          {on && <Txt w={600} size={11} color={t.check.mark}>✓</Txt>}
        </View>
        <Txt size={15.5} color={on ? t.check.doneText : t.text} style={{ flex: 1 }}>{it.label}</Txt>
        {!!it.note && <Txt size={12.5} color={t.faint}>{it.note}</Txt>}
      </Pressable>
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: t.bg, paddingTop: insets.top + 10, paddingHorizontal: 28 }}>
      <StatusBar style={t.dark ? 'light' : 'dark'} />
      <BagPoster ref={poster} groups={groups} checked={prefs.checked} packed={packed} total={all.length} />
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <Pressable
          onPress={() => navigation.navigate('index' as never)}
          hitSlop={12}
          accessibilityRole="button"
          accessibilityLabel="Back to Home"
          style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}
        >
          <ChevronLeft color={t.muted} />
          <Txt w={500} size={14} color={t.muted}>Home</Txt>
        </Pressable>
        <Pressable onPress={share} hitSlop={12} accessibilityRole="button" accessibilityLabel="Save or share packing list" style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <ShareIcon color={t.accent} size={15} />
          <Txt w={500} size={14} color={t.accent}>Share</Txt>
        </Pressable>
      </View>
      <Txt serif size={60} lh={0.92} ls={-0.01} color={t.text}>
        The <Em color={t.accent}>bag</Em>
      </Txt>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline', marginTop: 20 }}>
        <Kicker color={t.muted}>Packed</Kicker>
        <Txt serif size={20} color={t.text}>
          {packed} <Em color={t.muted}>of {all.length}</Em>
        </Txt>
      </View>
      <View style={{ height: 2, backgroundColor: t.dark ? 'rgba(239,228,214,0.12)' : 'rgba(46,36,32,0.12)', marginTop: 10 }}>
        <View style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: `${(packed / all.length) * 100}%`, backgroundColor: t.text }} />
      </View>
      <ScrollView style={{ flex: 1, marginTop: 8 }} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        {groups.map(g => (
          <View key={g.name}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline', marginTop: 22, paddingBottom: 6 }}>
              <Txt serif italic size={22} color={t.text}>{g.name}</Txt>
              <Txt w={500} size={12} color={t.muted}>{`${g.items.filter(i => prefs.checked[i.id]).length} / ${g.items.length}`}</Txt>
            </View>
            {g.items.map(it => <Row key={it.id} it={it} />)}
          </View>
        ))}
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14, minHeight: 52, borderTopWidth: 1, borderTopColor: t.rowLine, marginBottom: 24 }}>
          <Txt size={20} color={t.accent} style={{ width: 22, textAlign: 'center' }}>+</Txt>
          {adding ? (
            <TextInput
              autoFocus
              value={draft}
              onChangeText={setDraft}
              onSubmitEditing={add}
              onBlur={add}
              returnKeyType="done"
              placeholder="Something of your own"
              placeholderTextColor={t.faint}
              style={{ flex: 1, fontFamily: fonts.sans400, fontSize: 15.5, color: t.text, paddingVertical: 12 }}
            />
          ) : (
            <Pressable onPress={() => setAdding(true)} accessibilityRole="button" style={{ flex: 1, paddingVertical: 16 }}>
              <Txt w={500} size={15} color={t.accent}>Add something of your own</Txt>
            </Pressable>
          )}
        </View>
      </ScrollView>
    </View>
  );
}
