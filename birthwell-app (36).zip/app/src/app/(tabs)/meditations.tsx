import { router } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Segmented } from '../../components/controls';
import { Heart, PlayGlyph } from '../../components/icons';
import { Em, Kicker, Txt } from '../../components/Txt';
import { meditationForWeek, titleParts, versionFor } from '../../data/content';
import { pregnancy } from '../../lib/time';
import { useApp, useTheme } from '../../state/AppState';
import { usePremium } from '../../state/Premium';
import { isMeditationFree } from '../../lib/access';
import { PremiumTag } from '../../components/PremiumTag';
import type { Theme } from '../../theme/tokens';

const MEDITATION_WEEKS = Array.from({ length: 37 }, (_, i) => i + 6); // weeks 6–42

// Every guided meditation, by week, with favourites.
export default function Meditations() {
  const { prefs, set } = useApp();
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const { week: thisWeek } = pregnancy(prefs.dueDate);
  const { premium } = usePremium();
  const locked = (w: number) => !premium && !isMeditationFree(w);
  const open = (w: number, current = false) =>
    locked(w) ? router.push('/premium') : current ? router.push('/meditation') : router.push({ pathname: '/meditation', params: { week: String(w) } });
  const [show, setShow] = useState<'all' | 'fav'>('all');
  const favs = new Set(prefs.favorites);
  // Every week is listed, this week included (marked "This week"), even though it's also featured above.
  const weeks = show === 'fav' ? MEDITATION_WEEKS.filter(w => favs.has(w)) : MEDITATION_WEEKS;
  const toggleFav = (w: number) =>
    set(p => ({ favorites: p.favorites.includes(w) ? p.favorites.filter(x => x !== w) : [...p.favorites, w].sort((a, b) => a - b) }));

  return (
    <View style={{ flex: 1, backgroundColor: t.bg, paddingTop: insets.top + 16, paddingHorizontal: 28 }}>
      <StatusBar style={t.dark ? 'light' : 'dark'} />
      <Txt serif size={56} lh={0.95} ls={-0.01} color={t.text}>Guided</Txt>
      <Txt serif italic size={56} lh={0.95} ls={-0.01} color={t.accent}>meditations</Txt>
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ paddingBottom: 24 }} showsVerticalScrollIndicator={false}>
      <FeaturedCard week={thisWeek} fav={favs.has(thisWeek)} onFav={() => toggleFav(thisWeek)} t={t} locked={locked(thisWeek)} onOpen={() => open(thisWeek, true)} />
      <View style={{ marginTop: 26 }}>
        <Segmented
          options={[
            { label: 'All weeks', value: 'all' as const },
            { label: `Favorites${favs.size ? ` · ${favs.size}` : ''}`, value: 'fav' as const },
          ]}
          value={show}
          onChange={setShow}
          track={t.segTrack}
          active={t.segActive}
          color={t.text}
        />
      </View>
      <View style={{ marginTop: 12 }}>
        {weeks.length === 0 && (
          <Txt serif italic size={20} lh={1.35} color={t.muted} style={{ marginTop: 28 }}>
            Tap the heart on any meditation to keep it here.
          </Txt>
        )}
        {weeks.map(w => {
          const m = meditationForWeek(w, versionFor(prefs.faith));
          const current = w === thisWeek;
          const fav = favs.has(w);
          return (
            <View key={w} style={{ flexDirection: 'row', alignItems: 'center', gap: 14, paddingVertical: 14, borderTopWidth: 1, borderTopColor: t.rowLine }}>
              <Pressable
                onPress={() => open(w)}
                accessibilityRole="button"
                accessibilityLabel={`Week ${w}, ${m.title.join(' ')}, ${Math.round(m.seconds / 60)} minutes`}
                style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 14 }}
              >
                <View
                  style={{
                    width: 40,
                    height: 40,
                    borderRadius: 20,
                    alignItems: 'center',
                    justifyContent: 'center',
                    backgroundColor: current ? t.playBg : 'transparent',
                    borderWidth: current ? 0 : 1,
                    borderColor: t.avatarRing,
                  }}
                >
                  <PlayGlyph w={10} color={current ? t.playIcon : t.text} />
                </View>
                <View style={{ flex: 1, gap: 5 }}>
                  <Kicker size={9.5} color={current ? t.accent : t.muted}>
                    {`Week ${w}${current ? ' · This week' : ''} · ${Math.round(m.seconds / 60)} min`}
                  </Kicker>
                  <Txt serif size={21} lh={1.1} color={t.text}>
                    {titleParts(m.title).lead} <Em color={t.dark ? t.quote : undefined}>{titleParts(m.title).rest}</Em>
                  </Txt>
                </View>
              </Pressable>
              {locked(w) && <PremiumTag color={t.accent} />}
              <Pressable
                onPress={() => toggleFav(w)}
                hitSlop={12}
                accessibilityRole="button"
                accessibilityState={{ selected: fav }}
                accessibilityLabel={fav ? `Remove week ${w} from favorites` : `Add week ${w} to favorites`}
              >
                <Heart color={fav ? t.accent : t.faint} filled={fav} />
              </Pressable>
            </View>
          );
        })}
      </View>
      </ScrollView>
    </View>
  );
}

// This week's meditation, large and first.
function FeaturedCard({ week, fav, onFav, t, locked, onOpen }: { week: number; fav: boolean; onFav: () => void; t: Theme; locked: boolean; onOpen: () => void }) {
  const { prefs } = useApp();
  const m = meditationForWeek(week, versionFor(prefs.faith));
  const c = t.meditation;
  return (
    <Pressable
      onPress={onOpen}
      accessibilityRole="button"
      accessibilityLabel={`This week's meditation: ${m.title.join(' ')}, ${Math.round(m.seconds / 60)} minutes`}
      style={{ marginTop: 22, backgroundColor: c.bg, borderRadius: 28, padding: 24 }}
    >
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <Kicker size={10} color={c.kicker}>{`This week · Week ${week} · ${Math.round(m.seconds / 60)} min`}</Kicker>
          {locked && <PremiumTag color={c.kicker} />}
        </View>
        <Pressable onPress={onFav} hitSlop={12} accessibilityRole="button" accessibilityLabel={fav ? 'Remove from favorites' : 'Add to favorites'}>
          <Heart color={c.text} filled={fav} size={18} />
        </Pressable>
      </View>
      <View style={{ marginTop: 18 }}>
        <Txt serif size={52} lh={0.95} ls={-0.02} color={c.title}>{m.title[0]}</Txt>
        <Txt serif italic size={52} lh={0.95} ls={-0.02} color={c.title}>{m.title.slice(1).join(' ')}</Txt>
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 16, marginTop: 18 }}>
        <Txt serif italic size={16.5} lh={1.35} color={c.body} style={{ flex: 1 }}>{m.desc}</Txt>
        <View style={{ width: 64, height: 64, borderRadius: 32, backgroundColor: c.playBg, alignItems: 'center', justifyContent: 'center' }}>
          <PlayGlyph w={15} color={c.playIcon} />
        </View>
      </View>
    </Pressable>
  );
}
