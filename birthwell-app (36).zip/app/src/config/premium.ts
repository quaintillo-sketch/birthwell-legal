// BirthWell Free and Premium. Premium is a single non-consumable in-app purchase
// ($11.99, one time, never expires). Everything here is plain data so it can be tested.

import type { AmbienceId } from '../data/content';

// App Store Connect product ID and RevenueCat entitlement ID. They must match what's set up
// in App Store Connect and RevenueCat exactly (see docs/premium-setup.md).
export const PREMIUM_PRODUCT_ID = 'birthwell_premium';
export const PREMIUM_ENTITLEMENT = 'premium';
export const PREMIUM_PRICE_FALLBACK = '$11.99'; // shown until the App Store returns the local price

// RevenueCat's public iOS SDK key (starts with "appl_"). Safe to ship in the app. Set it in
// .env as EXPO_PUBLIC_REVENUECAT_IOS_KEY; without it the app uses the simulated store.
export const REVENUECAT_IOS_KEY = process.env.EXPO_PUBLIC_REVENUECAT_IOS_KEY ?? '';

// ---- What's free ----------------------------------------------------------------------

// Maren (coach 0) is the free coach. Other coaches can be previewed but not chosen.
export const FREE_COACH = 0;

// Maren's free coaching library, chosen from her approved, already-recorded lines, so free
// users hear real recordings and nothing new is generated. Per mode this is 2 openers,
// 2 breathing cues, 2 encouragements, 2 resting phrases and 2 acknowledgments, plus her
// preview and volume-test lines. Lines starting "both-" serve both modes.
export const FREE_MAREN_PHRASES = [
  // Opening
  'both-start-01', // Okay. Breathe in slowly… and let it out long.
  'grounded-start-01', // I’m here. Soften your shoulders, and breathe.
  'faith-start-01', // I’m here, and so is Jesus. Soften your shoulders, and breathe.
  // Breathing
  'both-breathe-01', // If it helps, let your out-breath be a little longer.
  'both-breathe-02', // Unclench your hands. Let your fingers go loose.
  // Encouragement
  'both-affirm-01', // You’re doing well.
  'grounded-encourage-04', // For now, just focus on your next breath.
  'faith-encourage-03', // Lord Jesus, give me strength for this moment.
  // Resting
  'grounded-rest-01', // That wave has passed. Let your whole body go heavy.
  'grounded-rest-02', // Rest now. Have a sip of water if you’d like.
  'faith-rest-01', // That wave has passed. Let your body go heavy, and rest in Him.
  'faith-rest-02', // Thank You, Lord, for carrying me through that one.
  // End-of-contraction acknowledgments
  'both-ack-01', // You did wonderfully.
  'both-ack-02', // There you go. Beautifully done.
  // Preview and volume test
  'grounded-preview-01',
  'faith-preview-01',
  'both-volume-01',
];

// Recommended free soundscapes (pending approval): the two pure nature sounds. The musical
// tracks (Golden hour, Desert spirit, Flowing grace) and Hearth are Premium. "My own music"
// and "Off" are always available.
export const FREE_AMBIENCE: AmbienceId[] = ['desert', 'rain', 'own', 'off'];

// Recommended free meditations (pending approval): one from each part of pregnancy, so
// everyone has something relevant: early pregnancy, the start of labor preparation, and
// the final weeks.
export const FREE_MEDITATION_WEEKS = [6, 21, 36];
