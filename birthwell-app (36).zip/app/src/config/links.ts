// Public pages the app links to. Fill these in before submitting to the App Store; Apple
// requires a privacy policy, and subscriptions need terms of use (EULA) as well.
export const LINKS = {
  privacy: '', // e.g. https://birthwell.app/privacy
  terms: '', // e.g. https://birthwell.app/terms
  support: '', // e.g. mailto:hello@birthwell.app or https://birthwell.app/support
};
