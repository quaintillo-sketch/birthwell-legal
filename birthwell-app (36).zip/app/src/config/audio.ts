// Where weekly meditation audio is hosted: the BirthWell Supabase project. Set
// EXPO_PUBLIC_SUPABASE_URL in .env to the project URL, for example
//   https://abcd1234.supabase.co
// The buckets, file layout and Premium check are described in src/lib/meditationHosting.ts
// and docs/meditation-hosting.md.

export const SUPABASE_URL = (process.env.EXPO_PUBLIC_SUPABASE_URL ?? '').trim().replace(/\/+$/, '');

// Development only: lets Expo Go (which can't make real purchases) play Premium weeks while
// testing. It works only while the same code is saved in Supabase as MEDITATION_PREVIEW_CODE;
// delete that secret before launch and it stops working everywhere.
export const MEDITATION_PREVIEW_CODE = process.env.EXPO_PUBLIC_MEDITATION_PREVIEW_CODE ?? '';

export type { MeditationVersion } from '../lib/meditationHosting';
