// BirthWell coaching script library: two complete libraries per coach, Grounded
// (secular, 31 phrases) and Faith-Centered (Christian, 33 phrases). A phrase that works in
// both is written once and recorded once.
//
// Each phrase's id is also its audio filename:
//   assets/voices/<coach>/<id>.m4a  (or .mp3)
//   ids start with grounded-, faith- or both-, e.g. faith-rest-02, both-breathe-01
// Until a recording exists, the phone's text-to-speech reads `text` instead.
//
// Writing rules for every phrase:
// - No assumptions about labor stage or progress ("almost there", "halfway", "peaking").
// - No medical instructions, no "push", nothing that minimises pain.
// - Faith-Centered: never promise a painless, easy or safe birth because of faith; never
//   suggest prayer replaces medical care, or that a hard birth means too little faith.
// - Scripture is quoted accurately, in context, with its reference, and never as a promise
//   of a particular labor or outcome.
// - Breathing cues invite rather than prescribe; nothing implies she must be strong, brave
//   or in control.
// - Short enough to hear in the middle of a contraction; plain, spoken language.
// - Each coach sounds like herself in both modes.

export type CoachSlug = 'maren' | 'jo' | 'esme' | 'ines' | 'della';
export type Mode = 'grounded' | 'faith';
export type Category = 'start' | 'breathe' | 'affirm' | 'encourage' | 'rest' | 'ack' | 'ground' | 'preview' | 'volume';

export type Phrase = {
  id: string; // also the audio filename
  category: Category;
  text: string;
  modes: Mode[]; // ['grounded'], ['faith'] or both (one shared recording)
  scripture?: string; // reference for any quoted or closely paraphrased verse
};

export type CoachScript = {
  slug: CoachSlug;
  // Direction for whoever generates or records the voice (same voice in both modes).
  delivery: string;
  phrases: Phrase[]; // every unique recording for this coach
};

export const MODE_LABEL: Record<Mode, string> = { grounded: 'Grounded', faith: 'Faith-Centered' };

export const CATEGORY_INFO: Record<Category, { label: string; faithLabel?: string; plays: string }> = {
  start: { label: 'Beginning of a contraction', plays: 'When “Contraction started” is tapped' },
  breathe: { label: 'Breathing & relaxing', plays: 'Most of what the coach says during a contraction' },
  affirm: { label: 'Small encouragements', plays: 'Sprinkled through a contraction, between breathing cues' },
  encourage: { label: 'Encouragement for hard moments', plays: 'Now and then during a contraction, a little more often after ~30 seconds' },
  ack: { label: 'End-of-contraction acknowledgment', plays: 'Most of the time when “Contraction ended” is tapped (on its own, never followed by another phrase)' },
  rest: { label: 'Resting between contractions', plays: 'Sometimes when “Contraction ended” is tapped, in place of the acknowledgment' },
  ground: { label: 'Grounding & reassurance', faithLabel: 'Reassurance & prayer', plays: 'Occasionally, during a contraction or when it ends' },
  preview: { label: 'Voice preview', plays: 'Coach picker and the Voice & sound panel' },
  volume: { label: 'Volume test', plays: 'When the coach volume is adjusted in Settings' },
};

// Per mode, per coach. Acknowledgments: the 3 Grounded ones are shared by both modes
// (one recording each), and Faith-Centered adds 2 of its own.
const BASE = { start: 5, breathe: 5, affirm: 4, encourage: 4, rest: 4, ground: 4, preview: 1, volume: 1 };
export const DISTRIBUTION: Record<Mode, Record<Category, number>> = {
  grounded: { ...BASE, ack: 3 },
  faith: { ...BASE, ack: 5 },
};

type Row = [Category, string, string?]; // category, text, Scripture reference

function script(slug: CoachSlug, delivery: string, rows: { both: Row[]; grounded: Row[]; faith: Row[] }): CoachScript {
  const phrases: Phrase[] = [];
  const add = (prefix: 'both' | Mode, modes: Mode[], list: Row[]) => {
    const counts: Partial<Record<Category, number>> = {};
    for (const [category, text, scripture] of list) {
      counts[category] = (counts[category] ?? 0) + 1;
      phrases.push({ id: `${prefix}-${category}-${String(counts[category]).padStart(2, '0')}`, category, text, modes, ...(scripture ? { scripture } : {}) });
    }
  };
  add('both', ['grounded', 'faith'], rows.both);
  add('grounded', ['grounded'], rows.grounded);
  add('faith', ['faith'], rows.faith);
  return { slug, delivery, phrases };
}

export const COACHING: CoachScript[] = [
  script('maren', 'Calm, practical, quietly certain. An experienced midwife: plain words, unhurried, warm but never sugary. In prayer, simple and sincere, never performed.', {
    both: [
      ['start', 'Okay. Breathe in slowly… and let it out long.'],
      ['breathe', 'If it helps, let your out-breath be a little longer.'],
      ['breathe', 'Unclench your hands. Let your fingers go loose.'],
      ['volume', 'This is how loud I’ll be. Adjust me until I feel comfortable.'],
      ['affirm', 'You’re doing well.'],
      ['affirm', 'That’s it. Just like that.'],
      ['affirm', 'Good. Stay with it.'],
      ['ack', 'You did wonderfully.'],
      ['ack', 'There you go. Beautifully done.'],
      ['ack', 'You made it through that one.'],
    ],
    grounded: [
      ['start', 'I’m here. Soften your shoulders, and breathe.'],
      ['start', 'Let’s meet this one together. Slow breath in.'],
      ['start', 'Here’s a wave. Unclench your jaw, and breathe.'],
      ['start', 'Easy now. Find a comfortable breath, and stay with it.'],
      ['breathe', 'Soften your jaw. Let your lips part.'],
      ['breathe', 'Let your breath find whatever rhythm feels right.'],
      ['breathe', 'Let your shoulders drop away from your ears.'],
      ['encourage', 'If it feels hard, that’s okay. You’re meeting it one breath at a time.'],
      ['encourage', 'Stay with your breath. Just this wave.'],
      ['encourage', 'Make whatever sound helps. Low and open.'],
      ['encourage', 'For now, just focus on your next breath.'],
      ['rest', 'That wave has passed. Let your whole body go heavy.'],
      ['rest', 'Rest now. Have a sip of water if you’d like.'],
      ['rest', 'Change position if you need to, then let yourself rest.'],
      ['rest', 'Let your breathing find its own pace again.'],
      ['ground', 'Feel where your body is supported, and let it hold you.'],
      ['ground', 'Whatever you’re feeling right now is allowed.'],
      ['ground', 'You don’t have to do this perfectly. There isn’t a perfect way.'],
      ['ground', 'The people caring for you are here to help. Lean on them.'],
      ['preview', 'I’m Maren. I’ll keep things calm and simple, one breath at a time.'],
      ['affirm', 'You’re doing exactly what you need to.'],
    ],
    faith: [
      ['start', 'I’m here, and so is Jesus. Soften your shoulders, and breathe.'],
      ['start', 'Let’s bring this one to God together. Slow breath in.'],
      ['start', 'Here’s a wave. Unclench your jaw, and breathe. Lord, be near.'],
      ['start', 'Lord Jesus, walk with me through this one. Slow breath in.'],
      ['breathe', 'Soften your jaw, and breathe in His peace.'],
      ['breathe', 'Breathe at your own pace. Holy Spirit, steady me.'],
      ['breathe', 'Let your shoulders soften. Rest in His peace.'],
      ['encourage', 'You don’t have to find all the strength yourself. Lean on Jesus.'],
      ['encourage', 'Stay with your breath. His grace is enough for this wave.', '2 Corinthians 12:9 (allusion)'],
      ['encourage', 'Lord Jesus, give me strength for this moment.'],
      ['encourage', 'Make whatever sound helps. God hears every one.'],
      ['rest', 'That wave has passed. Let your body go heavy, and rest in Him.'],
      ['rest', 'Thank You, Lord, for carrying me through that one.'],
      ['rest', 'Have a sip of water. Jesus is with you in the quiet, too.'],
      ['rest', 'Let your breathing settle. Jesus, stay with me in this rest.'],
      ['ground', 'Whatever you’re feeling is allowed. God understands all of it.'],
      ['ground', 'Lord, I give You this moment. Help me trust You with it.'],
      ['ground', 'You are His beloved, right now, exactly as you are.'],
      ['ground', '“The Lord is my strength and my shield.” Let that be enough for now.', 'Psalm 28:7'],
      ['preview', 'I’m Maren. I’ll keep things calm and simple, and I’ll pray with you as we go.'],
      ['affirm', 'You’re doing well, and you’re not alone in this.'],
      ['ack', 'There you go. God is with you.'],
      ['ack', 'You did beautifully. Thank You, Jesus.'],
    ],
  }),

  script('jo', 'Warm, casual, gently funny. A best friend holding your hand: relaxed and affectionate, never jokey when things are hard. With Jesus, warm and sincere, never flippant.', {
    both: [
      ['start', 'Okay, here we go. I’m right here with you.'],
      ['breathe', 'Breathe in… and let it all out.'],
      ['breathe', 'Breathe with me. Slow in… slower out.'],
      ['rest', 'Have a sip of water. Seriously, I’ll wait.'],
      ['volume', 'Can you hear me okay? This is how loud I’ll be.'],
      ['affirm', 'You’re doing so good.'],
      ['affirm', 'Yes. That’s it.'],
      ['affirm', 'Look at you go.'],
      ['ack', 'You did it!'],
      ['ack', 'There you go. That was wonderful.'],
      ['ack', 'Another one behind you!'],
    ],
    grounded: [
      ['start', 'Big breath with me. You and me, okay?'],
      ['start', 'Alright, this one’s ours. Breathe with me.'],
      ['start', 'Here comes a wave. Squeeze something if it helps, and breathe with me.'],
      ['start', 'Okay, love. Find your breath. I’m with you.'],
      ['breathe', 'Shoulders down, love. There you go.'],
      ['breathe', 'Loosen your grip a little. You don’t have to hold on so tight.'],
      ['breathe', 'Let your face go soft. Yep, even your forehead.'],
      ['encourage', 'Breathe through this wave with me. I’ve got you.'],
      ['encourage', 'You’re doing this. You’re really doing it.'],
      ['encourage', 'It’s okay if this feels hard. Just take the next breath. I’m right here.'],
      ['encourage', 'Breathe it out. You don’t have to be quiet about it.'],
      ['rest', 'Phew. That wave’s behind you. Shake it out.'],
      ['rest', 'Okay, breathe however feels good. This bit is yours.'],
      ['rest', 'Get comfy. Pillow, blanket, whatever you need.'],
      ['ground', 'You can ask for anything. Ice chips, quiet, a hand to squeeze.'],
      ['ground', 'There’s no wrong way to do this. Do whatever helps.'],
      ['ground', 'However this goes, you’re doing something incredible.'],
      ['ground', 'I’m right here with you, every step of the way.'],
      ['preview', 'Hi, I’m Jo. Think of me as your best friend in the room.'],
      ['affirm', 'You’ve so got this.'],
    ],
    faith: [
      ['start', 'Big breath with me. Jesus is right here, and so am I.'],
      ['start', 'Alright, let’s give this one to God. Breathe with me.'],
      ['start', 'Here comes a wave. Jesus, be near. Breathe with me.'],
      ['start', 'Okay, love. Find your breath. You’re held in God’s love.'],
      ['breathe', 'Shoulders down, love. Let His peace in.'],
      ['breathe', 'Loosen your grip. You don’t have to hold on so tight. He’s holding you.'],
      ['breathe', 'Let your face go soft, and breathe in God’s peace.'],
      ['encourage', 'Lean on Jesus, and lean on me. You don’t have to carry this alone.'],
      ['encourage', 'Pray with me: Jesus, stay close. Give me peace and courage.'],
      ['encourage', 'It’s okay if this feels really hard. Jesus is right here with you.'],
      ['encourage', 'One wave at a time, friend. His grace is enough for this one.', '2 Corinthians 12:9 (allusion)'],
      ['rest', 'Phew. Thank You, Jesus, for getting us through that wave.'],
      ['rest', 'Get comfy. Jesus, carry some of this for me for a while.'],
      ['rest', 'Breathe however feels good. He’s in this quiet bit, too.'],
      ['ground', 'You can ask for anything. Ice chips, quiet, a hand to squeeze, a prayer.'],
      ['ground', '“She is clothed with strength and dignity.” That’s you, friend.', 'Proverbs 31:25'],
      ['ground', 'However this goes, you are so loved by God. And by me.'],
      ['ground', 'Holy Spirit, fill this room with Your peace.'],
      ['preview', 'Hi, I’m Jo. Think of me as your best friend in the room, praying right alongside you.'],
      ['affirm', 'You’re doing amazing, friend. God’s got you.'],
      ['ack', 'You did it! Praise God.'],
      ['ack', 'There you go. Jesus is with you.'],
    ],
  }),

  script('esme', 'Deep, slow, grounded. Very few words with long, comfortable pauses. Steady as stone; never rushed, never bright. Prayer is quiet and still, almost whispered.', {
    both: [
      ['start', 'Breathe in… and down.'],
      ['breathe', 'Long breath out… all the way.'],
      ['breathe', 'Slow… slower still.'],
      ['volume', 'This is my voice. Make it as soft as you need.'],
      ['affirm', 'Good.'],
      ['affirm', 'Yes… like that.'],
      ['affirm', 'Steady. You’re doing it.'],
      ['ack', 'Beautifully done.'],
      ['ack', 'There you go. Now rest.'],
      ['ack', 'You made it through.'],
    ],
    grounded: [
      ['start', 'I’m here. Heavy, and slow.'],
      ['start', 'Find your support. Take a gentle breath.'],
      ['start', 'A wave. Let it come… and breathe.'],
      ['start', 'Still. Soft. Breathe.'],
      ['breathe', 'Let your breath sink low.'],
      ['breathe', 'Heavy shoulders. Heavy arms.'],
      ['breathe', 'Let the floor take your weight.'],
      ['encourage', 'Stay. Breathe. I’m here.'],
      ['encourage', 'Nothing to fix. Just breathe.'],
      ['encourage', 'Underneath all this, you are steady.'],
      ['encourage', 'Let this wave be what it is. You can be still inside it.'],
      ['rest', 'The wave has passed. Be still now.'],
      ['rest', 'Rest. Let the ground hold you.'],
      ['rest', 'Quiet now. Breathe however you like.'],
      ['rest', 'Soft hands. Soft face. Rest.'],
      ['ground', 'Feel the weight of your body. You are here.'],
      ['ground', 'Notice one thing you can touch. Stay with it.'],
      ['ground', 'This moment is the only one you need to meet.'],
      ['ground', 'Rooted. Present. Here.'],
      ['preview', 'I’m Esme. I’ll speak slowly, and I won’t fill the quiet.'],
      ['affirm', 'Soft. Steady. Good.'],
    ],
    faith: [
      ['start', 'I’m here. God is here. Slow.'],
      ['start', 'Find your support. Rest in Him.'],
      ['start', 'A wave. Jesus… stay near.'],
      ['start', 'Still. Soft. You are held.'],
      ['breathe', 'Let your breath sink low… into His peace.'],
      ['breathe', 'Heavy shoulders. You are held.'],
      ['breathe', 'Let the floor take your weight. Lord, carry what I can’t.'],
      ['encourage', 'Stay. Breathe. Christ is near.'],
      ['encourage', 'Jesus… be my peace.'],
      ['encourage', 'Underneath all this, His love holds steady.'],
      ['encourage', 'Be still inside this wave. You are not alone in it.'],
      ['rest', 'The wave has passed. Be still, and rest in Him.'],
      ['rest', 'Thank You, Lord… for this quiet.'],
      ['rest', 'Rest. Holy Spirit… settle over me.'],
      ['rest', 'Soft hands. Soft face. Breathe in grace.'],
      ['ground', '“Be still, and know that I am God.” Rest in that.', 'Psalm 46:10'],
      ['ground', 'Lord, I am here. You are here. That is enough.'],
      ['ground', 'Feel the weight of your body. Let God hold all of it.'],
      ['ground', 'Come, Holy Spirit. Fill this room with stillness.'],
      ['preview', 'I’m Esme. I’ll speak slowly, leave room for quiet, and rest in God with you.'],
      ['affirm', 'Good. You are held.'],
      ['ack', 'Beautifully done. Rest in Him.'],
      ['ack', 'There you go. Thank You, Lord.'],
    ],
  }),

  script('ines', 'Gentle and unhurried, with simple imagery of water and air. Soft-spoken, clear and concrete, never flowery. Contemplative in prayer, like speaking in a quiet chapel.', {
    both: [
      ['start', 'Open your hands, and breathe.'],
      ['breathe', 'Soften your belly, and let your breath be easy.'],
      ['breathe', 'With each breath out, let a little more go.'],
      ['volume', 'This is how I’ll sound. Let my voice sit just above the quiet.'],
      ['affirm', 'That’s it, gently.'],
      ['affirm', 'You’re doing beautifully.'],
      ['affirm', 'Just like that… easy.'],
      ['ack', 'You did beautifully.'],
      ['ack', 'There you go. The wave has passed.'],
      ['ack', 'Beautiful. Now take your rest.'],
    ],
    grounded: [
      ['start', 'Here’s a wave. Breathe with it.'],
      ['start', 'Let it come. Your breath goes with it.'],
      ['start', 'Breathe gently through this wave.'],
      ['start', 'Let your breath be soft, like air through an open window.'],
      ['breathe', 'Breathe out slowly, like a tide going out.'],
      ['breathe', 'Let your breath move like water. Nothing held.'],
      ['breathe', 'Just follow your breath, wherever it goes.'],
      ['encourage', 'You can rest inside this breath, even now.'],
      ['encourage', 'You don’t need to hold back the wave. Let it move through you.'],
      ['encourage', 'Soft shoulders, soft hands. Nothing to hold on to.'],
      ['encourage', 'Let the sound of your breath carry you.'],
      ['rest', 'That wave has passed. Let yourself float for a while.'],
      ['rest', 'Breathe into the quiet.'],
      ['rest', 'Let the stillness settle over you.'],
      ['rest', 'Let your body be heavy, like warm sand.'],
      ['ground', 'Notice the air on your skin, and the light in the room.'],
      ['ground', 'Nothing to hurry toward. Just this breath.'],
      ['ground', 'Let anything you’re carrying wait outside the door for now.'],
      ['ground', 'You don’t need to figure anything out right now.'],
      ['preview', 'I’m Ines. I’ll guide you with gentle pictures and slow, steady breath.'],
      ['affirm', 'You’re moving with it so well.'],
    ],
    faith: [
      ['start', 'Here’s a wave. Breathe with it, and let God hold you.'],
      ['start', 'Let it come. Holy Spirit, be near me now.'],
      ['start', 'Jesus, hold me gently through this wave.'],
      ['start', 'Let your breath be soft. The Lord is near.'],
      ['breathe', 'Breathe out slowly, like a tide going out. Let it carry anything heavy to Him.'],
      ['breathe', 'Let your breath move like water. His peace is flowing in.'],
      ['breathe', 'Breathe in grace. Let the rest go.'],
      ['encourage', 'You can rest in Jesus, even inside this breath.'],
      ['encourage', 'Lord, be my calm in the middle of this wave.'],
      ['encourage', 'You don’t need to hold it back. Let it move through you, held by love.'],
      ['encourage', 'His grace is wide enough to hold this moment.', '2 Corinthians 12:9 (allusion)'],
      ['rest', 'It’s eased. Let His peace wash over you, slow and quiet.'],
      ['rest', 'Thank You, Jesus, for every breath that brought me here.'],
      ['rest', 'Let the stillness settle. The Holy Spirit is near.'],
      ['rest', 'Let your body be heavy, held in His hands.'],
      ['ground', '“He leads me beside still waters.” Rest there a moment.', 'Psalm 23:2'],
      ['ground', 'Jesus, I give You whatever I’m carrying. Hold it for me.'],
      ['ground', '“I praise You, for I am fearfully and wonderfully made.”', 'Psalm 139:14'],
      ['ground', 'Holy Spirit, breathe Your peace into me.'],
      ['preview', 'I’m Ines. I’ll guide you with gentle pictures, slow breath, and quiet prayer.'],
      ['affirm', 'Gently now. You are held in love.'],
      ['ack', 'There you go. Rest in His love.'],
      ['ack', 'You did beautifully. God is near.'],
    ],
  }),

  script('della', 'Bright, confident and direct, with real warmth. Believes in you completely; encouraging, never loud or pushy, and never treats labor as a battle. Speaks of faith with joyful conviction, not preaching.', {
    both: [
      ['start', 'Let’s breathe through this one together.'],
      ['breathe', 'Lips loose, shoulders down. Good.'],
      ['breathe', 'Find your rhythm, and stay with it.'],
      ['volume', 'Here’s how loud I’ll be. Turn me up or down until it feels right.'],
      ['affirm', 'You’re doing great.'],
      ['affirm', 'That’s it. Nice and steady.'],
      ['affirm', 'Look at you. You’re doing it.'],
      ['ack', 'Yes! You did it!'],
      ['ack', 'Look at you. Beautifully done!'],
      ['ack', 'There you go! You did wonderfully.'],
    ],
    grounded: [
      ['start', 'Here we go. Breathe with me.'],
      ['start', 'I’m with you. Find your breath.'],
      ['start', 'Here comes a wave. Shoulders down, and breathe.'],
      ['start', 'I’m right beside you. Easy breath in.'],
      ['breathe', 'Big breath in… and let it all go.'],
      ['breathe', 'Keep your breath steady. That’s it.'],
      ['breathe', 'Breathe out slow and full.'],
      ['encourage', 'One breath, then the next. I’m with you.'],
      ['encourage', 'That’s it. Keep going. I’m right here.'],
      ['encourage', 'You don’t have to be brave. Just breathe.'],
      ['encourage', 'Breathe into this wave. You’re meeting it one breath at a time.'],
      ['rest', 'That wave’s behind you. Breathe easy.'],
      ['rest', 'Nicely done. Let your body rest.'],
      ['rest', 'Take a moment for you. Water, a stretch, whatever helps.'],
      ['rest', 'Reset. Roll your shoulders, and soften.'],
      ['ground', 'Notice what you need right now, and let yourself have it.'],
      ['ground', 'You can ask for what you need. No apologies.'],
      ['ground', 'You’re surrounded by support, and I’m part of it.'],
      ['ground', 'However today unfolds, you are doing something powerful.'],
      ['preview', 'I’m Della. I’ll bring steady, upbeat encouragement and stay right beside you.'],
      ['affirm', 'You’ve got this. I believe in you.'],
    ],
    faith: [
      ['start', 'Here we go. Breathe with me. The Lord is your strength.', 'Psalm 28:7 (allusion)'],
      ['start', 'I’m with you, and so is Jesus. Find your breath.'],
      ['start', 'Here comes a wave. Lord, fill me with Your peace.'],
      ['start', 'Shoulders down. Breathe in His strength.'],
      ['breathe', 'Big breath in… and give it all to God.'],
      ['breathe', 'Keep your breath steady. He’s steady too.'],
      ['breathe', 'Breathe out slow and full. Rest in His power.'],
      ['encourage', 'Christ strengthens you for whatever this moment holds.', 'Philippians 4:13 (paraphrase)'],
      ['encourage', 'You don’t have to be brave. Just breathe, and let Him be your strength.'],
      ['encourage', 'Lord Jesus, give me courage for this moment.'],
      ['encourage', 'That’s it. Breathe through this wave. God is right here in it with you.'],
      ['rest', 'That wave’s behind you. Thank You, Lord, for Your strength.'],
      ['rest', 'Nicely done. Rest now, and receive His peace.'],
      ['rest', 'Take a moment for you. Water, a stretch, a quiet prayer.'],
      ['rest', 'Reset. Holy Spirit, renew me.'],
      ['ground', 'Lord, You are my strength. I’m leaning on You right now.'],
      ['ground', 'You can ask for what you need. No apologies. God sees you.'],
      ['ground', 'However today unfolds, you and your baby are surrounded by God’s love.'],
      ['ground', 'Holy Spirit, fill me with courage and calm.'],
      ['preview', 'I’m Della. I’ll bring steady, faith-filled encouragement and stay right beside you.'],
      ['affirm', 'You’re doing great. The Lord is your strength.'],
      ['ack', 'You did it! Thank You, Jesus!'],
      ['ack', 'Yes! God’s right here with you!'],
    ],
  }),
];

export const COACH_SLUGS: CoachSlug[] = ['maren', 'jo', 'esme', 'ines', 'della'];

export function scriptFor(coachIndex: number) {
  return COACHING[coachIndex] ?? COACHING[0];
}

export function libraryFor(coachIndex: number, mode: Mode) {
  return scriptFor(coachIndex).phrases.filter(p => p.modes.includes(mode));
}

// The first phrase of a category in a mode: the preview, the volume test, or a default
// line to show on screen.
export function firstPhrase(coachIndex: number, mode: Mode, category: Category) {
  return libraryFor(coachIndex, mode).find(p => p.category === category)!;
}

export const modeFor = (faith: 'faith' | 'sec'): Mode => (faith === 'faith' ? 'faith' : 'grounded');
