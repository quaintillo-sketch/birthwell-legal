// Birth plan: a starting point for a conversation with the care team, not medical advice.
// Options are common preferences people list; every section also has free-text notes.

export type BirthPlan = {
  details: Record<string, string>;
  picks: Record<string, boolean>;
  notes: Record<string, string>;
};

export const EMPTY_BIRTH_PLAN: BirthPlan = { details: {}, picks: {}, notes: {} };

export const PLAN_DETAILS: { id: string; label: string; placeholder: string }[] = [
  { id: 'place', label: 'Planned birthplace', placeholder: 'Hospital or birth center' },
  { id: 'support', label: 'Support people', placeholder: 'Partner, doula, family' },
  { id: 'contact', label: 'Emergency contact', placeholder: 'Name and phone' },
];

export type PlanSection = { id: string; title: string; options: { id: string; label: string }[]; notePlaceholder: string };

export const PLAN_SECTIONS: PlanSection[] = [
  {
    id: 'room',
    title: 'The room',
    options: [
      { id: 'room-dim', label: 'Dim lights' },
      { id: 'room-quiet', label: 'Quiet, calm voices' },
      { id: 'room-music', label: 'My own music or ambience' },
      { id: 'room-visitors', label: 'Visitors only when I ask' },
      { id: 'room-photos', label: 'Photos or video welcome' },
    ],
    notePlaceholder: 'Anything else about the space',
  },
  {
    id: 'labor',
    title: 'During labor',
    options: [
      { id: 'labor-move', label: 'Free to walk and change position' },
      { id: 'labor-eat', label: 'Light food and drinks, if allowed' },
      { id: 'labor-monitor', label: 'Intermittent monitoring, if possible' },
      { id: 'labor-water', label: 'Shower or tub' },
      { id: 'labor-ball', label: 'Birth ball or peanut ball' },
      { id: 'labor-explain', label: 'Explain options before any intervention' },
    ],
    notePlaceholder: 'Anything else for labor',
  },
  {
    id: 'comfort',
    title: 'Comfort & pain relief',
    options: [
      { id: 'comfort-breath', label: 'Breathing and my BirthWell coach' },
      { id: 'comfort-touch', label: 'Massage or counter-pressure' },
      { id: 'comfort-heat', label: 'Warm compress or heat' },
      { id: 'comfort-nitrous', label: 'Open to nitrous oxide' },
      { id: 'comfort-epidural', label: 'Open to an epidural' },
      { id: 'comfort-ask', label: 'Please let me ask for medication' },
      { id: 'comfort-undecided', label: 'Undecided — I’ll see how I feel' },
    ],
    notePlaceholder: 'Your thoughts on comfort and pain relief',
  },
  {
    id: 'birth',
    title: 'Birth',
    options: [
      { id: 'birth-positions', label: 'Choose my own positions' },
      { id: 'birth-guided', label: 'Gentle guidance on when to push' },
      { id: 'birth-mirror', label: 'A mirror to see baby arrive' },
      { id: 'birth-announce', label: 'Partner announces the sex' },
    ],
    notePlaceholder: 'Anything else for the birth',
  },
  {
    id: 'after',
    title: 'Right after birth',
    options: [
      { id: 'after-skin', label: 'Immediate skin-to-skin' },
      { id: 'after-cord', label: 'Delayed cord clamping' },
      { id: 'after-cut', label: 'Partner cuts the cord' },
      { id: 'after-hour', label: 'An undisturbed first hour' },
      { id: 'after-placenta', label: 'Keep the placenta' },
    ],
    notePlaceholder: 'Anything else for the first hour',
  },
  {
    id: 'feeding',
    title: 'Feeding',
    options: [
      { id: 'feed-breast', label: 'Breastfeeding' },
      { id: 'feed-formula', label: 'Formula' },
      { id: 'feed-both', label: 'Both' },
      { id: 'feed-lactation', label: 'Visit from a lactation consultant' },
      { id: 'feed-unsure', label: 'Not sure yet' },
    ],
    notePlaceholder: 'Feeding notes',
  },
  {
    id: 'baby',
    title: 'Baby’s care',
    options: [
      { id: 'baby-procedures', label: 'Newborn procedures done with me present' },
      { id: 'baby-bath', label: 'Delay the first bath' },
      { id: 'baby-room', label: 'Baby rooms in with me' },
      { id: 'baby-discuss', label: 'Discuss vitamin K, eye ointment and vaccines with me first' },
    ],
    notePlaceholder: 'Anything else for baby',
  },
  {
    id: 'cesarean',
    title: 'If plans change',
    options: [
      { id: 'c-support', label: 'My support person stays with me' },
      { id: 'c-explain', label: 'Talk me through each step' },
      { id: 'c-drape', label: 'Clear drape, or lowered to see baby' },
      { id: 'c-skin', label: 'Skin-to-skin in the operating room' },
      { id: 'c-music', label: 'My music in the operating room' },
    ],
    notePlaceholder: 'Wishes if a cesarean or other change is needed',
  },
];

export const PLAN_NOTE =
  'A birth plan is a starting point for conversations with your care team. Births don’t always go as planned, and your provider will guide what’s safe for you and your baby.';

export function birthPlanText(plan: BirthPlan, name: string, dueISO: string, provider: string) {
  const due = new Date(dueISO).toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' });
  const lines = [`Birth plan · ${name}`, `Due ${due}`, `Provider: ${provider}`];
  for (const d of PLAN_DETAILS) if (plan.details[d.id]?.trim()) lines.push(`${d.label}: ${plan.details[d.id].trim()}`);
  for (const s of PLAN_SECTIONS) {
    const picked = s.options.filter(o => plan.picks[o.id]).map(o => `• ${o.label}`);
    const note = plan.notes[s.id]?.trim();
    if (!picked.length && !note) continue;
    lines.push('', s.title.toUpperCase(), ...picked);
    if (note) lines.push(`Notes: ${note}`);
  }
  lines.push('', PLAN_NOTE, '', 'Made with BirthWell');
  return lines.join('\n');
}
