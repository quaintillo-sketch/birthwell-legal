// Daily encouragement on Home: "Today's reflection" (Grounded) and "Today's word"
// (Faith-Centered, Scripture). One per day, chosen by reflectionForDay().
//
// Stages follow the pregnancy: early (weeks 1–13), middle (14–27), late (28–36) and birth
// (37–42). "any" fits every stage.
//
// Scripture is the World English Bible (public domain), quoted exactly, with God's name
// shown as "the Lord", as in most English Bibles. Tests check every quote
// against the WEB text. Quotes may be part of a verse; "…" joins two parts of a passage.
// Writing rules, as for coaching: no promises about how a birth will go, no pressure to be
// strong or brave, nothing that minimises pain or replaces medical care.

export type Stage = 'early' | 'middle' | 'late' | 'birth' | 'any';
export type Reflection = { text: string; stage: Stage; ref?: string };

export const GROUNDED: Reflection[] = [
  // Early
  { stage: 'early', text: 'Something new is beginning, quietly. You don’t have to understand all of it today.' },
  { stage: 'early', text: 'Tiredness isn’t laziness. Your body is doing invisible, important work. Rest counts.' },
  { stage: 'early', text: 'It’s okay to feel more than one thing at once: wonder and worry, joy and nerves.' },
  { stage: 'early', text: 'You don’t need to have it all figured out. Today, just take good care of yourself.' },
  { stage: 'early', text: 'Small and steady is how all growing things begin.' },
  { stage: 'early', text: 'Be gentle with yourself on the queasy days. Getting through them is enough.' },
  { stage: 'early', text: 'You are already someone’s whole world, and they are no bigger than a seed.' },
  { stage: 'early', text: 'There’s no right way to feel about early pregnancy. Whatever you feel is allowed.' },
  { stage: 'early', text: 'Drink some water, take a breath, and let today be simple.' },
  { stage: 'early', text: 'Even on the days you feel nothing at all, growth is happening.' },
  { stage: 'early', text: 'You can share your news when you’re ready, and not a moment before.' },
  { stage: 'early', text: 'Your body knows how to begin this. You’re allowed to simply follow along.' },
  { stage: 'early', text: 'Some days the best thing you can do is lie down early. That’s a good choice, not a lost day.' },
  { stage: 'early', text: 'Notice one small good thing today, and let it be enough.' },
  { stage: 'early', text: 'Everything is changing, and you are still you.' },
  // Middle
  { stage: 'middle', text: 'Your body is making room, a little more each day. Give yourself room too.' },
  { stage: 'middle', text: 'If you feel a flutter today, pause and say hello. Those small moments are worth noticing.' },
  { stage: 'middle', text: 'Growing a person is real work. It’s okay to say no to things this week.' },
  { stage: 'middle', text: 'Your shape is changing because something wonderful is happening inside it.' },
  { stage: 'middle', text: 'Put a hand where your baby is growing, and take three slow breaths together.' },
  { stage: 'middle', text: 'Energy comes and goes. Use the good days gently and rest on the others.' },
  { stage: 'middle', text: 'You’re allowed to enjoy this part. Not every day needs to be about preparing.' },
  { stage: 'middle', text: 'Your baby already knows the sound of your heartbeat. You are home to them.' },
  { stage: 'middle', text: 'Questions are welcome. Write them down and bring them to your next appointment.' },
  { stage: 'middle', text: 'Halfway is a good place to stop for a moment and notice how far you’ve come.' },
  { stage: 'middle', text: 'A short walk, some fresh air, a slow breath. Small things add up.' },
  { stage: 'middle', text: 'Your baby can hear more of the world now. Talk to them, or simply hum.' },
  { stage: 'middle', text: 'Comparing your pregnancy to anyone else’s helps no one. Yours is yours.' },
  { stage: 'middle', text: 'You don’t need to buy everything or read everything. You’re doing plenty.' },
  { stage: 'middle', text: 'Let someone take care of you today, even in a small way.' },
  // Late
  { stage: 'late', text: 'Heavier days call for slower steps. There’s no rush in you right now.' },
  { stage: 'late', text: 'You can prepare without needing to control every detail. Some things will unfold on their own.' },
  { stage: 'late', text: 'Sleep may be harder now. Rest whenever you can, however you can.' },
  { stage: 'late', text: 'Practice your long, slow breath out today. It will be there for you when you need it.' },
  { stage: 'late', text: 'Your body is getting ready in ways you can’t see. You don’t have to do it all on purpose.' },
  { stage: 'late', text: 'Nesting, worrying, waiting: all of it is part of getting ready.' },
  { stage: 'late', text: 'Ask for help with the heavy things. Literally, and otherwise.' },
  { stage: 'late', text: 'It’s okay to feel ready and not ready at the same time.' },
  { stage: 'late', text: 'Talk with your provider about anything on your mind. No question is too small.' },
  { stage: 'late', text: 'Every kick is a little conversation. Notice the patterns, and tell your provider if they change.' },
  { stage: 'late', text: 'Let your shoulders drop. Let your jaw soften. Let the day be a little slower.' },
  { stage: 'late', text: 'Your bag can wait an hour. Rest first.' },
  { stage: 'late', text: 'You’ve carried so much these months. You can set some of it down today.' },
  { stage: 'late', text: 'Plans are a starting point, not a test. Whatever happens, you can meet it as it comes.' },
  { stage: 'late', text: 'Someone is going to be very glad to meet you.' },
  // Birth
  { stage: 'birth', text: 'You don’t have to be ready for all of it. Only for the next breath.' },
  { stage: 'birth', text: 'Waiting is its own kind of work. Be patient with yourself, and with your baby.' },
  { stage: 'birth', text: 'There’s no schedule your body has to keep. Babies come in their own time.' },
  { stage: 'birth', text: 'Labor comes one wave at a time. You only ever need to meet the one in front of you.' },
  { stage: 'birth', text: 'You are surrounded by people who want to help you. Let them.' },
  { stage: 'birth', text: 'However your baby arrives, you are their mother, and that is everything.' },
  { stage: 'birth', text: 'Rest today if you can. Eat something you love. Let the waiting be gentle.' },
  { stage: 'birth', text: 'Trust your instincts, and call your provider whenever something feels off.' },
  { stage: 'birth', text: 'It’s okay to be nervous. Nerves and courage often arrive together.' },
  { stage: 'birth', text: 'You’ve practiced your breathing. It will be there when you reach for it.' },
  { stage: 'birth', text: 'You don’t have to do this perfectly. There is no perfect way.' },
  { stage: 'birth', text: 'Soon there will be someone new to hold. Until then, hold yourself kindly.' },
  { stage: 'birth', text: 'Each day of waiting is still a day of growing. Nothing is wasted.' },
  { stage: 'birth', text: 'You can ask for what you need, change your mind, and take your time.' },
  { stage: 'birth', text: 'Whatever today brings, you won’t face it alone.' },
  // Any time
  { stage: 'any', text: 'Your body has been quietly preparing for this all along. Today, you only need to listen.' },
  { stage: 'any', text: 'You are not waiting for strength to arrive. It is already here, growing with you.' },
  { stage: 'any', text: 'Breathe in slowly. Breathe out longer. That’s all for now.' },
  { stage: 'any', text: 'You are allowed to rest before you are exhausted.' },
  { stage: 'any', text: 'Today doesn’t need to be productive to be good.' },
  { stage: 'any', text: 'Notice where you’re holding tension, and let a little of it go.' },
  { stage: 'any', text: 'You can be grateful and tired at the same time.' },
  { stage: 'any', text: 'Some days are for doing. Some days are for being. Both matter.' },
  { stage: 'any', text: 'You don’t have to earn rest. You only have to take it.' },
  { stage: 'any', text: 'Speak to yourself today the way you’ll speak to your child.' },
  { stage: 'any', text: 'Change is happening slowly, beautifully, whether you notice it or not.' },
  { stage: 'any', text: 'A slow breath is always within reach.' },
  { stage: 'any', text: 'It’s okay to ask for help. It’s okay to need it.' },
  { stage: 'any', text: 'You are doing something extraordinary in an ordinary week.' },
  { stage: 'any', text: 'Feelings come and go like weather. You don’t have to hold on to any of them.' },
  { stage: 'any', text: 'Let today be a little softer than yesterday.' },
  { stage: 'any', text: 'You are learning as you go. So is everyone.' },
  { stage: 'any', text: 'Small kindnesses to yourself are never wasted.' },
  { stage: 'any', text: 'You don’t need to know how everything will go to take the next step.' },
  { stage: 'any', text: 'Drink some water. Stretch a little. Step outside if you can.' },
  { stage: 'any', text: 'There is no one way to be a mother. You will find yours.' },
  { stage: 'any', text: 'Love is already here, even before you’ve met.' },
  { stage: 'any', text: 'You can hold hope and worry in the same hand.' },
  { stage: 'any', text: 'This season is asking you to slow down. It’s okay to answer.' },
  { stage: 'any', text: 'Pause for a moment and feel your feet on the ground.' },
  { stage: 'any', text: 'You don’t have to be calm all the time. You can always come back to your breath.' },
  { stage: 'any', text: 'Today, notice what your body is asking for, and give it a little of that.' },
  { stage: 'any', text: 'Growth rarely feels like growth while it’s happening.' },
  { stage: 'any', text: 'Your worth isn’t measured by how much you get done.' },
  { stage: 'any', text: 'Let the people who love you show it. Say yes to the meal, the help, the hug.' },
  { stage: 'any', text: 'You are allowed to protect your peace.' },
  { stage: 'any', text: 'Every day brings you a little closer to meeting them.' },
  { stage: 'any', text: 'Quiet is a gift you can give yourself, even for five minutes.' },
  { stage: 'any', text: 'There will be easy days and hard days. Neither one is the whole story.' },
  { stage: 'any', text: 'Trust the slow work. It’s happening.' },
  { stage: 'any', text: 'Your body is wise. Listen to it kindly.' },
  { stage: 'any', text: 'You get to decide what this experience means to you.' },
  { stage: 'any', text: 'Unclench your jaw. Drop your shoulders. Breathe.' },
  { stage: 'any', text: 'You don’t need to be anyone other than who you are today.' },
  { stage: 'any', text: 'It’s okay if today was hard. Tomorrow is a fresh start.' },
  { stage: 'any', text: 'Write down one thing you want to remember about this week.' },
  { stage: 'any', text: 'Patience with yourself is a form of love.' },
  { stage: 'any', text: 'You are making room in your life and in your heart. That takes time.' },
  { stage: 'any', text: 'A good cry can be a kind of rest too.' },
  { stage: 'any', text: 'Whatever you’re carrying today, you don’t have to carry it alone.' },
  { stage: 'any', text: 'Let something make you laugh today.' },
  { stage: 'any', text: 'Gentleness is strength, too.' },
  { stage: 'any', text: 'You are building a bond with every thought you send their way.' },
  { stage: 'any', text: 'Trust that you will know more when you need to know it.' },
  { stage: 'any', text: 'Your pace is the right pace.' },
  { stage: 'any', text: 'Rest is part of the work, not a break from it.' },
  { stage: 'any', text: 'Notice the light today: through a window, on a wall, in someone’s face.' },
  { stage: 'any', text: 'You are already a source of comfort, warmth and home.' },
  { stage: 'any', text: 'Breathe in calm. Breathe out whatever you don’t need.' },
  { stage: 'any', text: 'You can say no to advice that doesn’t fit you.' },
  { stage: 'any', text: 'Some of the most important work happens in the quiet.' },
  { stage: 'any', text: 'Take one thing off your list today, and don’t replace it.' },
  { stage: 'any', text: 'You are allowed to enjoy the waiting.' },
  { stage: 'any', text: 'Be as kind to your body as it has been to your baby.' },
  { stage: 'any', text: 'You are becoming, and that is enough for today.' },
];

export const FAITH: Reflection[] = [
  // Early
  { stage: 'early', ref: 'Psalm 139:13', text: 'For you formed my inmost being. You knit me together in my mother’s womb.' },
  { stage: 'early', ref: 'Psalm 139:14', text: 'I will give thanks to you, for I am fearfully and wonderfully made. Your works are wonderful.' },
  { stage: 'early', ref: 'Jeremiah 1:5', text: 'Before I formed you in the womb, I knew you.' },
  { stage: 'early', ref: 'Psalm 139:16', text: 'Your eyes saw my body. In your book they were all written, the days that were ordained for me, when as yet there were none of them.' },
  { stage: 'early', ref: 'Ecclesiastes 11:5', text: 'As you don’t know what is the way of the wind, nor how the bones grow in the womb of her who is with child; even so you don’t know the work of God who does all.' },
  { stage: 'early', ref: 'Job 10:11-12', text: 'You have clothed me with skin and flesh, and knit me together with bones and sinews. You have granted me life and loving kindness.' },
  { stage: 'early', ref: 'Lamentations 3:22-23', text: 'His compassion doesn’t fail. They are new every morning. Great is your faithfulness.' },
  { stage: 'early', ref: 'Matthew 11:28', text: 'Come to me, all you who labor and are heavily burdened, and I will give you rest.' },
  { stage: 'early', ref: 'Isaiah 40:29', text: 'He gives power to the weak. He increases the strength of him who has no might.' },
  { stage: 'early', ref: 'Psalm 94:19', text: 'In the multitude of my thoughts within me, your comforts delight my soul.' },
  { stage: 'early', ref: 'Psalm 127:3', text: 'Behold, children are a heritage of the Lord. The fruit of the womb is his reward.' },
  { stage: 'early', ref: 'Isaiah 43:1', text: 'I have called you by your name. You are mine.' },
  { stage: 'early', ref: 'Psalm 139:1', text: 'Lord, you have searched me, and you know me.' },
  { stage: 'early', ref: 'Psalm 100:3', text: 'It is he who has made us, and we are his.' },
  { stage: 'early', ref: 'Psalm 139:17', text: 'How precious to me are your thoughts, God! How vast is their sum!' },
  { stage: 'early', ref: '1 Samuel 1:27', text: 'I prayed for this child, and the Lord has given me my petition which I asked of him.' },
  // Middle
  { stage: 'middle', ref: 'Luke 1:41', text: 'When Elizabeth heard Mary’s greeting, the baby leaped in her womb.' },
  { stage: 'middle', ref: 'Luke 1:44', text: 'The baby leaped in my womb for joy!' },
  { stage: 'middle', ref: 'Luke 2:19', text: 'But Mary kept all these sayings, pondering them in her heart.' },
  { stage: 'middle', ref: 'Isaiah 49:15-16', text: 'I will not forget you! Behold, I have engraved you on the palms of my hands.' },
  { stage: 'middle', ref: 'Psalm 71:6', text: 'I have relied on you from the womb. You are he who took me out of my mother’s womb. I will always praise you.' },
  { stage: 'middle', ref: 'Galatians 5:22-23', text: 'But the fruit of the Spirit is love, joy, peace, patience, kindness, goodness, faith, gentleness, and self-control.' },
  { stage: 'middle', ref: 'Ecclesiastes 3:1', text: 'For everything there is a season, and a time for every purpose under heaven.' },
  { stage: 'middle', ref: 'Colossians 3:12', text: 'Put on therefore, as God’s chosen ones, holy and beloved, a heart of compassion, kindness, lowliness, humility, and perseverance.' },
  { stage: 'middle', ref: 'Psalm 104:33', text: 'I will sing to the Lord as long as I live.' },
  { stage: 'middle', ref: 'Song of Solomon 2:12', text: 'The flowers appear on the earth. The time of the singing has come.' },
  { stage: 'middle', ref: 'Genesis 21:6', text: 'God has made me laugh. Everyone who hears will laugh with me.' },
  { stage: 'middle', ref: 'Psalm 90:14', text: 'Satisfy us in the morning with your loving kindness, that we may rejoice and be glad all our days.' },
  { stage: 'middle', ref: 'Psalm 118:24', text: 'This is the day that the Lord has made. We will rejoice and be glad in it!' },
  { stage: 'middle', ref: 'Psalm 126:3', text: 'The Lord has done great things for us, and we are glad.' },
  { stage: 'middle', ref: 'Psalm 139:5', text: 'You hem me in behind and before. You laid your hand on me.' },
  { stage: 'middle', ref: '1 Corinthians 13:4', text: 'Love is patient and is kind.' },
  // Late
  { stage: 'late', ref: 'Isaiah 40:11', text: 'He will gather the lambs in his arm, and carry them in his bosom. He will gently lead those who have their young.' },
  { stage: 'late', ref: 'Isaiah 40:31', text: 'But those who wait for the Lord will renew their strength. They will mount up with wings like eagles. They will run, and not be weary. They will walk, and not faint.' },
  { stage: 'late', ref: 'Isaiah 26:3', text: 'You will keep whoever’s mind is steadfast in perfect peace, because he trusts in you.' },
  { stage: 'late', ref: 'Isaiah 30:15', text: 'Your strength will be in quietness and in confidence.' },
  { stage: 'late', ref: 'Philippians 4:6-7', text: 'In nothing be anxious, but in everything, by prayer and petition with thanksgiving, let your requests be made known to God. And the peace of God, which surpasses all understanding, will guard your hearts and your thoughts in Christ Jesus.' },
  { stage: 'late', ref: '1 Peter 5:7', text: 'Casting all your worries on him, because he cares for you.' },
  { stage: 'late', ref: 'Psalm 55:22', text: 'Cast your burden on the Lord and he will sustain you.' },
  { stage: 'late', ref: 'Matthew 6:34', text: 'Therefore don’t be anxious for tomorrow, for tomorrow will be anxious for itself.' },
  { stage: 'late', ref: 'Psalm 62:1', text: 'My soul rests in God alone.' },
  { stage: 'late', ref: 'Psalm 131:2', text: 'Surely I have stilled and quieted my soul, like a weaned child with his mother.' },
  { stage: 'late', ref: 'Psalm 37:7', text: 'Rest in the Lord, and wait patiently for him.' },
  { stage: 'late', ref: 'Exodus 33:14', text: 'My presence will go with you, and I will give you rest.' },
  { stage: 'late', ref: 'Deuteronomy 33:27', text: 'The eternal God is your dwelling place. Underneath are the everlasting arms.' },
  { stage: 'late', ref: 'Isaiah 46:4', text: 'I have made, and I will bear. Yes, I will carry.' },
  { stage: 'late', ref: 'Proverbs 31:25', text: 'Strength and dignity are her clothing. She laughs at the time to come.' },
  { stage: 'late', ref: 'Psalm 130:5', text: 'I wait for the Lord. My soul waits. I hope in his word.' },
  // Birth
  { stage: 'birth', ref: 'Isaiah 41:10', text: 'Don’t you be afraid, for I am with you. Don’t be dismayed, for I am your God. I will strengthen you. Yes, I will help you.' },
  { stage: 'birth', ref: 'Isaiah 43:2', text: 'When you pass through the waters, I will be with you.' },
  { stage: 'birth', ref: 'Deuteronomy 31:8', text: 'The Lord himself is who goes before you. He will be with you. He will not fail you nor forsake you.' },
  { stage: 'birth', ref: 'Zephaniah 3:17', text: 'He will calm you in his love. He will rejoice over you with singing.' },
  { stage: 'birth', ref: '2 Corinthians 12:9', text: 'My grace is sufficient for you, for my power is made perfect in weakness.' },
  { stage: 'birth', ref: 'Psalm 121:1-2', text: 'I will lift up my eyes to the hills. Where does my help come from? My help comes from the Lord, who made heaven and earth.' },
  { stage: 'birth', ref: 'Psalm 46:1', text: 'God is our refuge and strength, a very present help in trouble.' },
  { stage: 'birth', ref: 'Psalm 28:7', text: 'The Lord is my strength and my shield. My heart has trusted in him, and I am helped.' },
  { stage: 'birth', ref: 'John 14:27', text: 'Peace I leave with you. My peace I give to you; not as the world gives, I give to you. Don’t let your heart be troubled, neither let it be fearful.' },
  { stage: 'birth', ref: 'Psalm 56:3', text: 'When I am afraid, I will put my trust in you.' },
  { stage: 'birth', ref: 'Psalm 61:2', text: 'I will call to you when my heart is overwhelmed. Lead me to the rock that is higher than I.' },
  { stage: 'birth', ref: 'Isaiah 66:13', text: 'As one whom his mother comforts, so I will comfort you.' },
  { stage: 'birth', ref: 'Psalm 73:26', text: 'My flesh and my heart fails, but God is the strength of my heart and my portion forever.' },
  { stage: 'birth', ref: 'Psalm 63:7', text: 'For you have been my help. I will rejoice in the shadow of your wings.' },
  { stage: 'birth', ref: 'Isaiah 41:13', text: 'For I, the Lord your God, will hold your right hand, saying to you, ‘Don’t be afraid. I will help you.’' },
  { stage: 'birth', ref: 'Psalm 16:8', text: 'I have set the Lord always before me. Because he is at my right hand, I shall not be moved.' },
  // Any time
  { stage: 'any', ref: 'Numbers 6:24-26', text: 'The Lord bless you, and keep you. The Lord make his face to shine on you, and be gracious to you. The Lord lift up his face toward you, and give you peace.' },
  { stage: 'any', ref: 'Romans 15:13', text: 'Now may the God of hope fill you with all joy and peace in believing, that you may abound in hope, in the power of the Holy Spirit.' },
  { stage: 'any', ref: 'Psalm 23:1-3', text: 'The Lord is my shepherd: I shall lack nothing. He makes me lie down in green pastures. He leads me beside still waters. He restores my soul.' },
  { stage: 'any', ref: 'Psalm 46:10', text: 'Be still, and know that I am God.' },
  { stage: 'any', ref: 'Psalm 34:4', text: 'I sought the Lord, and he answered me, and delivered me from all my fears.' },
  { stage: 'any', ref: 'Psalm 34:18', text: 'The Lord is near to those who have a broken heart, and saves those who have a crushed spirit.' },
  { stage: 'any', ref: 'Psalm 30:5', text: 'Weeping may stay for the night, but joy comes in the morning.' },
  { stage: 'any', ref: 'Psalm 37:5', text: 'Commit your way to the Lord. Trust also in him.' },
  { stage: 'any', ref: 'Psalm 42:11', text: 'Hope in God! For I shall still praise him.' },
  { stage: 'any', ref: 'Psalm 86:15', text: 'But you, Lord, are a merciful and gracious God, slow to anger, and abundant in loving kindness and truth.' },
  { stage: 'any', ref: 'Psalm 103:13', text: 'Like a father has compassion on his children, so the Lord has compassion on those who fear him.' },
  { stage: 'any', ref: 'Psalm 145:18', text: 'The Lord is near to all those who call on him, to all who call on him in truth.' },
  { stage: 'any', ref: 'Psalm 147:3', text: 'He heals the broken in heart, and binds up their wounds.' },
  { stage: 'any', ref: 'Proverbs 3:5-6', text: 'Trust in the Lord with all your heart, and don’t lean on your own understanding. In all your ways acknowledge him, and he will make your paths straight.' },
  { stage: 'any', ref: 'Isaiah 54:10', text: 'For the mountains may depart, and the hills be removed; but my loving kindness will not depart from you.' },
  { stage: 'any', ref: 'Jeremiah 31:3', text: 'Yes, I have loved you with an everlasting love. Therefore I have drawn you with loving kindness.' },
  { stage: 'any', ref: 'Micah 7:7', text: 'But as for me, I will look to the Lord. I will wait for the God of my salvation. My God will hear me.' },
  { stage: 'any', ref: 'Romans 8:38-39', text: 'For I am persuaded that neither death, nor life, nor angels, nor principalities, nor things present, nor things to come, nor powers, nor height, nor depth, nor any other created thing will be able to separate us from God’s love which is in Christ Jesus our Lord.' },
  { stage: 'any', ref: 'Ephesians 3:20', text: 'Now to him who is able to do exceedingly abundantly above all that we ask or think.' },
  { stage: 'any', ref: 'Colossians 3:15', text: 'And let the peace of God rule in your hearts… and be thankful.' },
  { stage: 'any', ref: '2 Thessalonians 3:16', text: 'Now may the Lord of peace himself give you peace at all times in all ways.' },
  { stage: 'any', ref: '2 Timothy 1:7', text: 'For God didn’t give us a spirit of fear, but of power, love, and self-control.' },
  { stage: 'any', ref: 'Hebrews 13:5', text: 'I will in no way leave you, neither will I in any way forsake you.' },
  { stage: 'any', ref: 'James 1:5', text: 'If any of you lacks wisdom, let him ask of God, who gives to all liberally and without reproach.' },
  { stage: 'any', ref: '1 John 4:18', text: 'There is no fear in love; but perfect love casts out fear.' },
  { stage: 'any', ref: 'Psalm 116:1', text: 'I love the Lord, because he listens to my voice, and my cries for mercy.' },
  { stage: 'any', ref: 'Psalm 119:105', text: 'Your word is a lamp to my feet, and a light for my path.' },
  { stage: 'any', ref: 'Lamentations 3:25', text: 'The Lord is good to those who wait for him, to the soul who seeks him.' },
  { stage: 'any', ref: 'Psalm 5:3', text: 'Lord, in the morning you will hear my voice. In the morning I will lay my requests before you, and will watch expectantly.' },
  { stage: 'any', ref: 'Psalm 143:8', text: 'Cause me to hear your loving kindness in the morning, for I trust in you.' },
  { stage: 'any', ref: '1 Thessalonians 5:16-18', text: 'Always rejoice. Pray without ceasing. In everything give thanks.' },
  { stage: 'any', ref: 'Psalm 32:8', text: 'I will instruct you and teach you in the way which you shall go.' },
  { stage: 'any', ref: 'Psalm 36:7', text: 'How precious is your loving kindness, God! The children of men take refuge under the shadow of your wings.' },
  { stage: 'any', ref: 'Psalm 40:1', text: 'I waited patiently for the Lord. He turned to me, and heard my cry.' },
  { stage: 'any', ref: 'Psalm 68:19', text: 'Blessed be the Lord, who daily bears our burdens.' },
  { stage: 'any', ref: 'Psalm 136:1', text: 'Give thanks to the Lord, for he is good; for his loving kindness endures forever.' },
  { stage: 'any', ref: 'Isaiah 42:3', text: 'He won’t break a bruised reed. He won’t quench a dimly burning wick.' },
  { stage: 'any', ref: 'Isaiah 43:19', text: 'Behold, I will do a new thing. It springs out now. Don’t you know it?' },
  { stage: 'any', ref: 'Isaiah 55:12', text: 'For you shall go out with joy, and be led out with peace.' },
  { stage: 'any', ref: 'Isaiah 65:24', text: 'Before they call, I will answer; and while they are yet speaking, I will hear.' },
  { stage: 'any', ref: 'Jeremiah 17:7-8', text: 'Blessed is the man who trusts in the Lord… For he will be as a tree planted by the waters, who spreads out its roots by the river.' },
  { stage: 'any', ref: 'Matthew 28:20', text: 'Behold, I am with you always, even to the end of the age.' },
  { stage: 'any', ref: 'Luke 12:6-7', text: 'Not one of them is forgotten by God. But the very hairs of your head are all counted.' },
  { stage: 'any', ref: 'John 15:9', text: 'Even as the Father has loved me, I also have loved you. Remain in my love.' },
  { stage: 'any', ref: 'Romans 5:5', text: 'Hope doesn’t disappoint us, because God’s love has been poured into our hearts through the Holy Spirit who was given to us.' },
  { stage: 'any', ref: 'Romans 12:12', text: 'Rejoicing in hope; enduring in troubles; continuing steadfastly in prayer.' },
  { stage: 'any', ref: 'Ephesians 2:10', text: 'For we are his workmanship, created in Christ Jesus for good works.' },
  { stage: 'any', ref: 'Philippians 4:4-5', text: 'Rejoice in the Lord always! … The Lord is at hand.' },
  { stage: 'any', ref: 'Hebrews 10:23', text: 'He who promised is faithful.' },
  { stage: 'any', ref: 'James 1:17', text: 'Every good gift and every perfect gift is from above, coming down from the Father of lights.' },
  { stage: 'any', ref: '1 Peter 3:4', text: 'A gentle and quiet spirit, which is very precious in the sight of God.' },
  { stage: 'any', ref: '1 John 3:1', text: 'See how great a love the Father has given to us, that we should be called children of God!' },
  { stage: 'any', ref: 'Psalm 3:3', text: 'But you, Lord, are a shield around me, my glory, and the one who lifts up my head.' },
  { stage: 'any', ref: 'Psalm 13:5', text: 'But I trust in your loving kindness. My heart rejoices in your salvation.' },
  { stage: 'any', ref: 'Psalm 25:5', text: 'Guide me in your truth, and teach me, For you are the God of my salvation, I wait for you all day long.' },
  { stage: 'any', ref: 'Psalm 62:5', text: 'My soul, wait in silence for God alone, for my expectation is from him.' },
  { stage: 'any', ref: 'Psalm 27:1', text: 'The Lord is my light and my salvation. Whom shall I fear?' },
  { stage: 'any', ref: 'Nehemiah 8:10', text: 'The joy of the Lord is your strength.' },
  { stage: 'any', ref: 'Psalm 139:9-10', text: 'Even there your hand will lead me, and your right hand will hold me.' },
  { stage: 'any', ref: 'Psalm 145:9', text: 'The Lord is good to all. His tender mercies are over all his works.' },
  { stage: 'any', ref: 'Psalm 62:8', text: 'Pour out your heart before him. God is a refuge for us.' },
  { stage: 'any', ref: 'Psalm 92:1-2', text: 'It is a good thing to give thanks to the Lord… to proclaim your loving kindness in the morning, and your faithfulness every night.' },
  { stage: 'any', ref: 'Psalm 119:76', text: 'Please let your loving kindness be for my comfort.' },
  { stage: 'any', ref: 'Psalm 138:3', text: 'In the day that I called, you answered me. You encouraged me with strength in my soul.' },
  { stage: 'any', ref: 'John 1:16', text: 'From his fullness we all received grace upon grace.' },
  { stage: 'any', ref: 'Romans 8:26', text: 'The Spirit also helps our weaknesses.' },
  { stage: 'any', ref: '2 Corinthians 1:3-4', text: 'The Father of mercies and God of all comfort; who comforts us in all our affliction.' },
  { stage: 'any', ref: 'Colossians 1:17', text: 'He is before all things, and in him all things are held together.' },
  { stage: 'any', ref: 'Hebrews 6:19', text: 'This hope we have as an anchor of the soul, a hope both sure and steadfast.' },
  { stage: 'any', ref: 'Psalm 91:1', text: 'He who dwells in the secret place of the Most High will rest in the shadow of the Almighty.' },
];

// ---- Choosing today's entry -------------------------------------------------------------

export function stageForWeek(week: number): Exclude<Stage, 'any'> {
  return week <= 13 ? 'early' : week <= 27 ? 'middle' : week <= 36 ? 'late' : 'birth';
}

function shuffled<T>(xs: T[], seed: number) {
  const a = [...xs];
  let s = seed;
  const rand = () => ((s = (s * 16807) % 2147483647) / 2147483647);
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// A fixed schedule for every day of pregnancy (day 0 to 300): about one day in three
// draws from the current stage, the rest from "any time". Nothing repeats until its pool
// has been used up, and the schedule is the same every time the app opens.
const LAST_DAY = 300;
const schedules = new Map<string, Reflection[]>();
function scheduleFor(list: Reflection[], key: string) {
  const cached = schedules.get(key);
  if (cached) return cached;
  const general = shuffled(list.filter(r => r.stage === 'any'), 11);
  const byStage = (s: Stage) => shuffled(list.filter(r => r.stage === s), 29 + s.length);
  const stagePools = { early: byStage('early'), middle: byStage('middle'), late: byStage('late'), birth: byStage('birth') };
  const shownOn = new Map<Reflection, number>();
  const out: Reflection[] = [];
  // Prefer an unseen entry from the first pool, then an unseen one from the second. Once both
  // are used up, repeat whichever was shown longest ago.
  const take = (first: Reflection[], second: Reflection[]) => {
    const r =
      first.find(x => !shownOn.has(x)) ??
      second.find(x => !shownOn.has(x)) ??
      [...first, ...second].reduce((a, b) => (shownOn.get(b)! < shownOn.get(a)! ? b : a));
    shownOn.set(r, out.length);
    return r;
  };
  for (let day = 0; day <= LAST_DAY; day++) {
    const stage = stagePools[stageForWeek(Math.floor(day / 7))];
    out.push(day % 3 === 0 ? take(stage, general) : take(general, stage));
  }
  schedules.set(key, out);
  return out;
}

// `day` is the day of pregnancy (0 at the start of the 280 days, from the due date).
export function reflectionForDay(mode: 'faith' | 'sec', day: number): Reflection {
  const list = mode === 'faith' ? FAITH : GROUNDED;
  const schedule = scheduleFor(list, mode);
  return schedule[Math.min(LAST_DAY, Math.max(0, Math.floor(day)))];
}
