// All coach names, personalities and copy are placeholders from the design handoff.

import type { MeditationVersion } from '../lib/meditationHosting';
import { MEDITATION_LIBRARY } from './meditationLibrary.ts';

export type Coach = {
  name: string;
  role: string;
  desc: string;
  line: string;
  color: string;
  photo: number; // require()d asset
};

export const COACHES: Coach[] = [
  {
    name: 'Maren',
    role: 'the midwife',
    desc: 'Calm, practical, quietly certain.',
    line: '“Low and slow. Let this one move through you.”',
    color: '#A96A4E',
    photo: require('../../assets/coaches/maren.jpg'),
  },
  {
    name: 'Jo',
    role: 'the best friend',
    desc: 'Warm, funny, endlessly in your corner.',
    line: '“Look at you. You are actually doing this.”',
    color: '#B98C82',
    photo: require('../../assets/coaches/jo.jpg'),
  },
  {
    name: 'Esme',
    role: 'the anchor',
    desc: 'Deep, unhurried, steady as stone.',
    line: '“Feet heavy. Jaw soft. I’m right here.”',
    color: '#6E6B4A',
    photo: require('../../assets/coaches/esme.jpg'),
  },
  {
    name: 'Ines',
    role: 'the poet',
    desc: 'Meditative; breath as landscape.',
    line: '“Let each wave come, and let it go.”',
    color: '#5E4450',
    photo: require('../../assets/coaches/ines.jpg'),
  },
  {
    name: 'Della',
    role: 'the champion',
    desc: 'Bold, bright energy for the hard push.',
    line: '“Strong. Stronger. That’s it — keep going.”',
    color: '#7A4E36',
    photo: require('../../assets/coaches/della.jpg'),
  },
];

export type Faith = 'faith' | 'sec';

export const FAITH = {
  faith: {
    label: 'Faith-centered',
    kicker: 'Scripture & prayer',
    sample: '“She is clothed with strength and dignity; she laughs at the days to come.”',
    desc: 'Scripture, prayer, and reflections rooted in Christian faith, in your daily word and your labor coaching.',
    quote: 'Those who hope in the Lord will renew their strength. They will soar on wings like eagles.',
    ref: 'Isaiah 40:31',
  },
  sec: {
    label: 'Grounded',
    kicker: 'Reflection & affirmation',
    sample: '“You are not waiting for strength to arrive. It is already here, growing with you.”',
    desc: 'Reflections and affirmations drawn from mindfulness and nature, with no religious content, in your daily word and your labor coaching.',
    quote: 'Your body has been quietly preparing for this all along. Today, you only need to listen.',
    ref: '', // filled with "Day N" at runtime
  },
} as const;

export type Meditation = { kicker: string; title: string[]; desc: string; seconds: number; narrator: string };

// Titles, descriptions and lengths come from the approved scripts (meditationLibrary.ts).
// Each version has its own. Weeks 6–20 focus on pregnancy and connection; 21–42 turn
// toward labor.
export function meditationForWeek(week: number, version: MeditationVersion = 'secular'): Meditation {
  const w = Math.min(42, Math.max(6, week));
  const entry = MEDITATION_LIBRARY[w][version === 'faith' ? 'faith' : 'grounded'];
  const kicker = w >= 21 ? `Preparing for labor · No. ${w - 20}` : `Pregnancy & connection · No. ${w - 5}`;
  return { kicker, ...entry, narrator: 'Maren' };
}

// The meditation version for the person's Faith setting.
export const versionFor = (faith: string): MeditationVersion => (faith === 'faith' ? 'faith' : 'secular');

// A title on one line, as in lists: "Known" + "before the beginning", the rest in italics.
export const titleParts = (title: string[]) => ({ lead: title[0], rest: title.slice(1).join(' ').replace(/\.$/, '') });

export type BagItem = { id: string; label: string; note: string };
export const BAG_GROUPS: { name: string; items: BagItem[] }[] = [
  {
    name: 'For you',
    items: [
      { id: 'id', label: 'Photo ID & insurance card', note: '' },
      { id: 'prefs', label: 'Birth preferences', note: '3 copies' },
      { id: 'robe', label: 'Robe or nursing gown', note: '' },
      { id: 'socks', label: 'Non-slip socks', note: '2 pairs' },
      { id: 'balm', label: 'Lip balm', note: '' },
      { id: 'charger', label: 'Long phone charger', note: '10 ft' },
      { id: 'ties', label: 'Hair ties', note: '' },
    ],
  },
  {
    name: 'For baby',
    items: [
      { id: 'outfit', label: 'Going-home outfit', note: 'two sizes' },
      { id: 'seat', label: 'Car seat, installed', note: '' },
      { id: 'swaddle', label: 'Swaddle blanket', note: '' },
      { id: 'hat', label: 'Soft hat & mittens', note: '' },
    ],
  },
  {
    name: 'For your partner',
    items: [
      { id: 'clothes', label: 'Change of clothes', note: '' },
      { id: 'snacks', label: 'Snacks for the night', note: '' },
      { id: 'pillow', label: 'Pillow from home', note: '' },
    ],
  },
];

// 4-1-1 and 3-1-1 are placeholders from the design; confirm with a clinician.
export type Rule = { a: number; l: number; f: number }; // minutes apart, seconds long, minutes sustained
export const RULES: { name: string; short: string; sub: string; badge: string; rule?: Rule }[] = [
  { name: 'Standard · 5-1-1', short: '5-1-1', sub: 'Every 5 min, lasting 1 min, for 1 hour', badge: 'Most OBs', rule: { a: 5, l: 60, f: 60 } },
  { name: 'Earlier · 4-1-1', short: '4-1-1', sub: 'Every 4 min, lasting 1 min, for 1 hour', badge: '', rule: { a: 4, l: 60, f: 60 } },
  { name: 'Sooner · 3-1-1', short: '3-1-1', sub: 'Every 3 min, lasting 1 min, for 1 hour', badge: '', rule: { a: 3, l: 60, f: 60 } },
  { name: 'Custom', short: 'Custom', sub: 'Set the pattern your provider gave you', badge: '' },
];

// Text-to-speech fallback until recordings exist: preferred iOS voice names (the first one
// installed is used), plus pitch and pace so each coach still sounds distinct.
export const COACH_VOICES: { voices: string[]; pitch: number; rate: number }[] = [
  { voices: ['Moira', 'Karen', 'Samantha'], pitch: 1.0, rate: 0.88 },
  { voices: ['Samantha', 'Nicky', 'Ava'], pitch: 1.12, rate: 0.98 },
  { voices: ['Karen', 'Serena', 'Allison'], pitch: 0.88, rate: 0.82 },
  { voices: ['Tessa', 'Fiona', 'Victoria'], pitch: 1.0, rate: 0.8 },
  { voices: ['Ava', 'Allison', 'Susan'], pitch: 1.05, rate: 1.04 },
];

export type AmbienceId = 'desert' | 'rain' | 'hearth' | 'golden' | 'spirit' | 'grace' | 'own' | 'off';
export const AMBIENCE: { id: AmbienceId; name: string; sub: string; file?: number }[] = [
  { id: 'desert', name: 'Desert dusk', sub: 'Low wind at sunset', file: require('../../assets/ambience/desert-dusk.m4a') },
  { id: 'rain', name: 'Mountain rain', sub: 'Soft rain on pines', file: require('../../assets/ambience/mountain-rain.m4a') },
  { id: 'hearth', name: 'Hearth', sub: 'A quiet fire crackling', file: require('../../assets/ambience/hearth.m4a') },
  { id: 'golden', name: 'Golden hour', sub: 'Warm ambient tones', file: require('../../assets/ambience/golden-hour.m4a') },
  { id: 'spirit', name: 'Desert spirit', sub: 'Gentle flute melodies', file: require('../../assets/ambience/desert-spirit.m4a') },
  { id: 'grace', name: 'Flowing grace', sub: 'Flowing water and soft music', file: require('../../assets/ambience/flowing-grace.m4a') },
  { id: 'own', name: 'My own music', sub: 'Your playlist in Spotify, Apple Music or any app' },
  { id: 'off', name: 'Off', sub: 'Silence beneath the voice' },
];

export const MORNING_OPTIONS = ['6:00 AM', '7:00 AM', '8:00 AM', '9:00 AM', 'Off'];

// Spoken cues for the placeholder meditation, by second.
export const MEDITATION_CUES: { at: number; text: string }[] = [
  { at: 2, text: 'Welcome. Find a comfortable seat, and let your eyes close.' },
  { at: 20, text: 'Notice your jaw. Let it soften, and let your tongue rest.' },
  { at: 45, text: 'Breathe in through your nose for four… and out slowly for six.' },
  { at: 80, text: 'Let your shoulders fall away from your ears.' },
  { at: 120, text: 'With each exhale, let a little more tension go.' },
  { at: 170, text: 'This long, slow breath is the one you’ll return to in labor.' },
  { at: 230, text: 'Place a hand where your baby is growing. Breathe toward them.' },
  { at: 300, text: 'Keep breathing at your own pace. There’s nowhere else to be.' },
  { at: 370, text: 'Begin to notice the room around you again.' },
  { at: 405, text: 'When you’re ready, open your eyes. Take your time.' },
];

// Shown on Welcome, in Settings and in the terms of use.
export const DISCLAIMER =
  'BirthWell offers comfort and encouragement. It is not medical or psychological advice, and it doesn’t replace your doctor, midwife or mental health professional. Always follow your provider’s guidance. If something feels wrong, call them or emergency services.';
