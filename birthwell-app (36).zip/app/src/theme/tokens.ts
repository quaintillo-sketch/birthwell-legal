// Palette and per-mode tokens taken from BirthWell.dc.html (screens 1a–1l, 2a–2d).

export const palette = {
  ivory: '#F4EFE7',
  paper: '#FAF7F2',
  sand: '#E6DACA',
  duskRose: '#DCC3B2',
  clay: '#A96A4E',
  clayDeep: '#9C5F44',
  sage: '#6E6B4A',
  plum: '#5E4450',
  espresso: '#2E2420',
  night: '#1C1512',
  cream: '#FAF5EF',
};

export type Theme = {
  dark: boolean;
  bg: string;
  text: string;
  muted: string; // secondary labels, descriptions
  faint: string; // inactive tab labels, notes
  accent: string; // clay / italic emphasis
  weekNumber: string; // the big "24" on Home
  quote: string; // Today's word
  hairline: string; // section rules (.14)
  rowLine: string; // list row borders (.1)
  avatarRing: string;
  segTrack: string;
  segActive: string;
  toggleOn: string;
  toggleOff: string;
  knob: string;
  sliderTrack: string;
  sliderFill: string;
  sliderThumb: string;
  sliderThumbBorder: string;
  playBg: string;
  playIcon: string;
  coachLetter: string;
  laborButton: { bg: string; text: string; kicker: string }; // "Time a contraction" on Home
  check: { fill: string; box: string; mark: string; doneText: string };
  meditation: {
    bg: string;
    text: string;
    title: string;
    sub: string;
    body: string;
    kicker: string;
    track: string;
    fill: string;
    playBg: string;
    playIcon: string;
  };
};

export const light: Theme = {
  dark: false,
  bg: palette.ivory,
  text: palette.espresso,
  muted: '#6F5F55',
  faint: '#8E7E73',
  accent: palette.clay,
  weekNumber: palette.plum,
  quote: palette.espresso,
  hairline: 'rgba(46,36,32,0.14)',
  rowLine: 'rgba(46,36,32,0.1)',
  avatarRing: 'rgba(46,36,32,0.2)',
  segTrack: palette.sand,
  segActive: palette.paper,
  toggleOn: palette.espresso,
  toggleOff: 'rgba(46,36,32,0.18)',
  knob: palette.paper,
  sliderTrack: 'rgba(46,36,32,0.14)',
  sliderFill: palette.espresso,
  sliderThumb: palette.paper,
  sliderThumbBorder: 'rgba(46,36,32,0.2)',
  playBg: palette.espresso,
  playIcon: palette.ivory,
  coachLetter: palette.ivory,
  laborButton: { bg: palette.clayDeep, text: palette.cream, kicker: '#F6E2D4' },
  check: { fill: palette.plum, box: 'rgba(46,36,32,0.35)', mark: palette.ivory, doneText: '#8E7E73' },
  meditation: {
    bg: palette.duskRose,
    text: palette.espresso,
    title: palette.espresso,
    sub: '#4F423B',
    body: '#4F3E36',
    kicker: '#A25A27',
    track: 'rgba(46,36,32,0.18)',
    fill: palette.espresso,
    playBg: palette.espresso,
    playIcon: palette.ivory,
  },
};

export const dark: Theme = {
  dark: true,
  bg: palette.night,
  text: '#EFE4D6',
  muted: '#B3A293',
  faint: '#968679',
  accent: '#D9A587',
  weekNumber: '#7C5555',
  quote: '#B3A592',
  hairline: 'rgba(239,228,214,0.14)',
  rowLine: 'rgba(239,228,214,0.1)',
  avatarRing: 'rgba(239,228,214,0.2)',
  segTrack: '#2E241F',
  segActive: '#4A3B33',
  toggleOn: '#D9A587',
  toggleOff: 'rgba(239,228,214,0.2)',
  knob: '#2A201B',
  sliderTrack: 'rgba(239,228,214,0.14)',
  sliderFill: '#EFE4D6',
  sliderThumb: '#2A201B',
  sliderThumbBorder: 'rgba(239,228,214,0.2)',
  playBg: '#7C5555',
  playIcon: palette.night,
  coachLetter: palette.night,
  // Deeper and softer than the light-mode clay, so it doesn't glare on the night background.
  laborButton: { bg: '#6F4434', text: '#EADBCB', kicker: '#D9B9A4' },
  check: { fill: '#895D70', box: 'rgba(239,228,214,0.4)', mark: '#EADFCC', doneText: '#968679' },
  meditation: {
    bg: '#2B201D',
    text: '#EFE4D6',
    title: '#B3A592',
    sub: '#D3C3B3',
    body: '#D3C3B3',
    kicker: '#C78F8F',
    track: 'rgba(239,228,214,0.18)',
    fill: '#EFE4D6',
    playBg: '#895D70',
    playIcon: palette.night,
  },
};

// Labor mode is always this warm night palette, in either theme.
export const night = {
  bg: palette.night,
  text: '#EFE4D6',
  accent: '#D9A587',
  muted: '#B3A293',
  soft: '#E3CDBB',
  body: '#D3C3B3',
  columnHead: '#8F7F72',
  card: '#2A201B',
  segTrack: '#2E241F',
  segActive: '#4A3B33',
  line: 'rgba(239,228,214,0.12)',
  lineFaint: 'rgba(239,228,214,0.08)',
  rowLine: 'rgba(239,228,214,0.1)',
  ring: 'rgba(217,165,135,0.18)',
  ringInner: 'rgba(217,165,135,0.12)',
  breath: 'rgba(201,138,107,0.16)',
  outline: 'rgba(239,228,214,0.3)',
  stepper: 'rgba(239,228,214,0.25)',
  toggleOn: '#C98A6B',
  toggleOff: 'rgba(239,228,214,0.2)',
  button: '#8A5440',
  buttonText: '#F3E6D9',
};

export const fonts = {
  serif: 'InstrumentSerif',
  serifItalic: 'InstrumentSerif-Italic',
  sans400: 'HankenGrotesk',
  sans500: 'HankenGrotesk-Medium',
  sans600: 'HankenGrotesk-SemiBold',
};

// Colours for the "Voice & sound" sheet and option lists.
export const nightSheet = {
  bg: '#2A201B',
  grabber: 'rgba(239,228,214,0.25)',
  text: night.text,
  muted: night.muted,
  accent: night.accent,
  line: night.rowLine,
  ring: 'rgba(239,228,214,0.35)',
  sliderTrack: 'rgba(239,228,214,0.14)',
  sliderFill: night.text,
  thumb: '#3A2E27',
  thumbBorder: 'rgba(239,228,214,0.25)',
  toggleOn: night.toggleOn,
  toggleOff: night.toggleOff,
  knob: night.text,
};

export function themeSheet(t: Theme) {
  return {
    bg: t.dark ? '#2A201B' : palette.paper,
    grabber: t.avatarRing,
    text: t.text,
    muted: t.muted,
    accent: t.accent,
    line: t.rowLine,
    ring: t.check.box,
    sliderTrack: t.sliderTrack,
    sliderFill: t.sliderFill,
    thumb: t.dark ? '#3A2E27' : palette.ivory,
    thumbBorder: t.sliderThumbBorder,
    toggleOn: t.toggleOn,
    toggleOff: t.toggleOff,
    knob: t.dark ? '#3A2E27' : palette.paper,
  };
}
