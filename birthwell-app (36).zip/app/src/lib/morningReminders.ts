// Morning delivery: each day's reflection arrives as a quiet local notification at the chosen
// time. Notifications are scheduled on the phone (no server, no account) for the next few
// weeks, and refreshed whenever the app opens or the settings change.

import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { reflectionForDay } from '../data/reflections';
import { pregnancy } from './time';

const DAYS_AHEAD = 30; // iOS keeps at most 64 pending notifications per app

// Shown as a banner if the app happens to be open when it arrives.
if (Platform.OS !== 'web') {
  Notifications.setNotificationHandler({
    handleNotification: async () => ({ shouldShowBanner: true, shouldShowList: true, shouldPlaySound: false, shouldSetBadge: false }),
  });
}

// '7:00 AM' → { h: 7, m: 0 }; anything else ('Off') → null.
export function parseMorning(value: string) {
  const m = value.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
  if (!m) return null;
  const h = (Number(m[1]) % 12) + (m[3].toUpperCase() === 'PM' ? 12 : 0);
  return { h, m: Number(m[2]) };
}

// True when the person has turned BirthWell's notifications off in iPhone Settings.
export async function notificationsBlocked() {
  if (Platform.OS === 'web') return false;
  try {
    const p = await Notifications.getPermissionsAsync();
    return !p.granted && !p.canAskAgain;
  } catch {
    return false;
  }
}

export type ReminderResult = 'scheduled' | 'off' | 'denied' | 'unsupported';

type Settings = { morning: string; faith: 'faith' | 'sec'; dueDate: string };

// `ask` shows the iPhone permission prompt if it hasn't been answered yet. Only pass it when
// the person has just chosen this (onboarding or Settings), never on a plain app launch.
// Runs one at a time, so two quick changes can't leave a doubled set of messages.
let queue: Promise<unknown> = Promise.resolve();
export function syncMorningReminders(s: Settings, ask = false): Promise<ReminderResult> {
  const run = queue.then(() => reschedule(s, ask));
  queue = run;
  return run;
}

async function reschedule(s: Settings, ask: boolean): Promise<ReminderResult> {
  if (Platform.OS === 'web') return 'unsupported';
  try {
    await Notifications.cancelAllScheduledNotificationsAsync();
    const time = parseMorning(s.morning);
    if (!time) return 'off';

    let perm = await Notifications.getPermissionsAsync();
    if (!perm.granted && perm.canAskAgain && ask) perm = await Notifications.requestPermissionsAsync();
    if (!perm.granted) return 'denied';

    const now = new Date();
    for (let i = 0; i <= DAYS_AHEAD; i++) {
      const at = new Date(now.getFullYear(), now.getMonth(), now.getDate() + i, time.h, time.m);
      if (at <= now) continue;
      const { day } = pregnancy(s.dueDate, at);
      if (day > 300) break; // well past the due date
      const r = reflectionForDay(s.faith, day);
      await Notifications.scheduleNotificationAsync({
        content: {
          title: s.faith === 'faith' ? `Today’s word · ${r.ref}` : 'Today’s reflection',
          body: r.text,
        },
        trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: at },
      });
    }
    return 'scheduled';
  } catch {
    return 'unsupported';
  }
}
