// What a Free or Premium user can use. Pure functions, no React Native, so they're tested.

import { FREE_AMBIENCE, FREE_COACH, FREE_MAREN_PHRASES, FREE_MEDITATION_WEEKS } from '../config/premium.ts';
import type { CoachScript } from '../data/coaching';
import type { AmbienceId } from '../data/content';

export const isCoachFree = (coach: number) => coach === FREE_COACH;
export const isAmbienceFree = (id: AmbienceId) => FREE_AMBIENCE.includes(id);
export const isMeditationFree = (week: number) => FREE_MEDITATION_WEEKS.includes(week);

// The coach who actually speaks. A free user always hears Maren, even if another coach was
// chosen earlier (for example while testing Premium, or after a refund).
export const effectiveCoach = (chosen: number, premium: boolean) => (premium || isCoachFree(chosen) ? chosen : FREE_COACH);

// The soundscape that actually plays; a Premium soundscape falls back to the first free one.
export const effectiveAmbience = (chosen: AmbienceId, premium: boolean): AmbienceId => (premium || isAmbienceFree(chosen) ? chosen : FREE_AMBIENCE[0]);

// A coach's library for this user: everything for Premium, Maren's free selection otherwise.
// The same recordings are used either way; nothing is duplicated.
export function scriptForTier(script: CoachScript, premium: boolean): CoachScript {
  if (premium) return script;
  const free = new Set(FREE_MAREN_PHRASES);
  return { ...script, phrases: script.phrases.filter(p => free.has(p.id)) };
}

// ---- Entitlement --------------------------------------------------------------------------

// The last purchase status confirmed by the store, cached securely on the device.
export type CachedEntitlement = { premium: boolean; verifiedAt: number };

// What the store said this time. 'unavailable' means we couldn't reach it (offline, store
// down), which must never take Premium away.
export type StoreCheck = { kind: 'verified'; premium: boolean } | { kind: 'unavailable' };

export function nextEntitlement(cached: CachedEntitlement | null, check: StoreCheck, now = Date.now()): CachedEntitlement {
  if (check.kind === 'unavailable') return cached ?? { premium: false, verifiedAt: 0 };
  return { premium: check.premium, verifiedAt: now };
}

// Outcome of tapping "Unlock".
export type PurchaseOutcome = 'purchased' | 'restored' | 'cancelled' | 'pending' | 'failed' | 'not-found';
