import { setAudioModeAsync, setIsAudioActiveAsync, useAudioPlayer } from 'expo-audio';
import { useEffect, useState } from 'react';
import { AMBIENCE } from '../data/content';
import { useApp } from '../state/AppState';
import { usePremium } from '../state/Premium';
import { effectiveAmbience } from './access';
import { onSpeakingChange } from './coachVoice';

// - Plays with the silent switch on: coaching only speaks when the person has chosen a
//   coaching level, and the in-app volume and Silent option still apply.
// - Keeps playing in the background / with the screen locked (needs a development build;
//   Expo Go ignores the background setting).
// - Mixes with other apps' audio instead of stopping it, so the coach always speaks over
//   the person's own music rather than pausing it.
const BASE_MODE = { playsInSilentMode: true, shouldPlayInBackground: true } as const;
export function configureAudio() {
  setAudioModeAsync({ ...BASE_MODE, interruptionMode: 'mixWithOthers' }).catch(() => {});
}

// With "My own music": while the coach speaks, ask iOS to lower other apps' audio (as Maps
// does for directions), then hand full volume back. iOS only restores the other app's volume
// when our audio session is deactivated, so it's briefly switched off and on again.
export function useOwnMusicDucking(enabled: boolean) {
  useEffect(() => {
    if (!enabled) return;
    let ducking = false;
    const off = onSpeakingChange(speaking => {
      if (speaking && !ducking) {
        ducking = true;
        setAudioModeAsync({ ...BASE_MODE, interruptionMode: 'duckOthers' }).catch(() => {});
      } else if (!speaking && ducking) {
        ducking = false;
        (async () => {
          await setAudioModeAsync({ ...BASE_MODE, interruptionMode: 'mixWithOthers' });
          await setIsAudioActiveAsync(false);
          await setIsAudioActiveAsync(true);
        })().catch(() => {});
      }
    });
    return () => {
      off();
      if (ducking) configureAudio();
    };
  }, [enabled]);
}

// Loops the chosen soundscape at the sound volume while `playing` is true.
export function useAmbience(playing: boolean) {
  const { prefs } = useApp();
  const { premium } = usePremium();
  const track = AMBIENCE.find(a => a.id === effectiveAmbience(prefs.ambience, premium));
  const player = useAudioPlayer(track?.file ?? null);
  const [ducked, setDucked] = useState(false);
  useEffect(() => onSpeakingChange(setDucked), []);

  // Dip the soundscape while the coach is speaking.
  useEffect(() => {
    player.loop = true;
    player.volume = prefs.soundVolume * (ducked ? 0.45 : 1);
  }, [player, prefs.soundVolume, ducked]);

  useEffect(() => {
    if (playing && track?.file) player.play();
    else player.pause();
  }, [player, playing, track?.file]);
}
