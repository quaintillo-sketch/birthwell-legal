// The purchase "store": the real App Store through RevenueCat in a development or App Store
// build, or a simulated store in Expo Go and on the web, where Apple purchases can't run.
// Both behave the same from the app's point of view.

import AsyncStorage from '@react-native-async-storage/async-storage';
import { NativeModules, Platform } from 'react-native';
import { PREMIUM_ENTITLEMENT, PREMIUM_PRODUCT_ID, REVENUECAT_IOS_KEY } from '../config/premium';
import type { PurchaseOutcome, StoreCheck } from './access';

export type Store = {
  kind: 'revenuecat' | 'simulated' | 'unavailable';
  init(): Promise<void>;
  check(): Promise<StoreCheck>;
  price(): Promise<string | null>;
  purchase(): Promise<PurchaseOutcome>;
  restore(): Promise<PurchaseOutcome>;
  onChange(fn: (premium: boolean) => void): () => void;
  // RevenueCat's ID for this customer, which the meditation server checks for Premium.
  // Null where there's no real store (Expo Go, the web).
  appUserId(): Promise<string | null>;
};

// ---- RevenueCat (real purchases) ----------------------------------------------------------

function revenueCatStore(): Store {
  // Loaded only when the native module exists, so Expo Go never touches it.
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const Purchases = require('react-native-purchases').default as typeof import('react-native-purchases').default;
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const { PURCHASES_ERROR_CODE, PRODUCT_CATEGORY } = require('react-native-purchases') as typeof import('react-native-purchases');
  type Info = import('react-native-purchases').CustomerInfo;
  const hasPremium = (info: Info) => info.entitlements.active[PREMIUM_ENTITLEMENT] !== undefined;
  let product: import('react-native-purchases').PurchasesStoreProduct | null = null;
  const loadProduct = async () => {
    if (product) return product;
    const [p] = await Purchases.getProducts([PREMIUM_PRODUCT_ID], PRODUCT_CATEGORY.NON_SUBSCRIPTION);
    product = p ?? null;
    return product;
  };

  return {
    kind: 'revenuecat',
    async init() {
      Purchases.configure({ apiKey: REVENUECAT_IOS_KEY });
    },
    async check() {
      try {
        return { kind: 'verified', premium: hasPremium(await Purchases.getCustomerInfo()) };
      } catch {
        return { kind: 'unavailable' };
      }
    },
    async price() {
      try {
        return (await loadProduct())?.priceString ?? null;
      } catch {
        return null;
      }
    },
    async purchase() {
      try {
        const p = await loadProduct();
        if (!p) return 'failed';
        const { customerInfo } = await Purchases.purchaseStoreProduct(p);
        return hasPremium(customerInfo) ? 'purchased' : 'pending';
      } catch (e) {
        const err = e as { userCancelled?: boolean; code?: string };
        if (err.userCancelled || err.code === PURCHASES_ERROR_CODE.PURCHASE_CANCELLED_ERROR) return 'cancelled';
        if (err.code === PURCHASES_ERROR_CODE.PAYMENT_PENDING_ERROR) return 'pending';
        if (err.code === PURCHASES_ERROR_CODE.PRODUCT_ALREADY_PURCHASED_ERROR) {
          // Already owned on this Apple ID: unlock it rather than charging again.
          return hasPremium(await Purchases.restorePurchases()) ? 'restored' : 'failed';
        }
        return 'failed';
      }
    },
    async restore() {
      try {
        return hasPremium(await Purchases.restorePurchases()) ? 'restored' : 'not-found';
      } catch {
        return 'failed';
      }
    },
    onChange(fn) {
      const listener = (info: Info) => fn(hasPremium(info));
      Purchases.addCustomerInfoUpdateListener(listener);
      return () => {
        Purchases.removeCustomerInfoUpdateListener(listener);
      };
    },
    async appUserId() {
      try {
        return await Purchases.getAppUserID();
      } catch {
        return null;
      }
    },
  };
}

// ---- Simulated store (Expo Go, web, automated tests) -----------------------------------------

// Lets every purchase situation be tried without Apple: success, cancel, waiting for approval
// (Ask to Buy), failure, being offline, and reinstalling. "Owned" stands in for the Apple ID's
// purchase history, which survives a reinstall.
export type SimulatedNext = 'success' | 'cancel' | 'pending' | 'fail';
export const simulator = {
  next: 'success' as SimulatedNext,
  offline: false,
};
const OWNED_KEY = 'birthwell.simulated.owned';
const listeners = new Set<(premium: boolean) => void>();

function simulatedStore(): Store {
  const owned = async () => (await AsyncStorage.getItem(OWNED_KEY)) === '1';
  const setOwned = async (v: boolean) => {
    await AsyncStorage.setItem(OWNED_KEY, v ? '1' : '0');
    listeners.forEach(l => l(v));
  };
  const wait = (ms: number) => new Promise(r => setTimeout(r, ms));
  return {
    kind: 'simulated',
    async init() {},
    async check() {
      if (simulator.offline) return { kind: 'unavailable' };
      return { kind: 'verified', premium: await owned() };
    },
    async price() {
      return null;
    },
    async purchase() {
      await wait(900);
      if (simulator.offline) return 'failed';
      switch (simulator.next) {
        case 'cancel':
          return 'cancelled';
        case 'fail':
          return 'failed';
        case 'pending':
          // Approved a little later, as with Ask to Buy.
          setTimeout(() => setOwned(true), 6000);
          return 'pending';
        default:
          if (await owned()) return 'restored'; // never charge twice
          await setOwned(true);
          return 'purchased';
      }
    },
    async restore() {
      await wait(700);
      if (simulator.offline) return 'failed';
      return (await owned()) ? 'restored' : 'not-found';
    },
    onChange(fn) {
      listeners.add(fn);
      return () => {
        listeners.delete(fn);
      };
    },
    async appUserId() {
      return null;
    },
  };
}

// Simulator controls for the developer panel in Settings.
export const simulatedControls = {
  async setOwned(v: boolean) {
    await AsyncStorage.setItem(OWNED_KEY, v ? '1' : '0');
    listeners.forEach(l => l(v));
  },
};

// A release build without RevenueCat configured must never hand out Premium for free:
// purchases simply report that the App Store isn't available.
function unavailableStore(): Store {
  return {
    kind: 'unavailable',
    async init() {},
    async check() {
      return { kind: 'unavailable' };
    },
    async price() {
      return null;
    },
    async purchase() {
      return 'failed';
    },
    async restore() {
      return 'failed';
    },
    onChange() {
      return () => {};
    },
    async appUserId() {
      return null;
    },
  };
}

export function createStore(): Store {
  const native = Platform.OS === 'ios' && !!NativeModules.RNPurchases && REVENUECAT_IOS_KEY.length > 0;
  if (native) return revenueCatStore();
  // Simulated purchases: development builds, or a test build made with
  // EXPO_PUBLIC_SIMULATED_STORE=1. Never set that for an App Store build.
  const simulate = __DEV__ || process.env.EXPO_PUBLIC_SIMULATED_STORE === '1';
  return simulate ? simulatedStore() : unavailableStore();
}
