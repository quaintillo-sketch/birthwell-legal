// Where each week's meditation lives in Supabase, as plain functions so they're tested.
// See docs/meditation-hosting.md for the setup.
//
//   meditations-free (public bucket)    manifest.json, and the free weeks (6, 21 and 36)
//   meditations      (private bucket)   every Premium week
//
// Inside both: maren/faith/week-07.m4a (Faith-centered) and maren/secular/week-07.m4a
// (Grounded). Free weeks download straight from the public bucket. A Premium week needs a
// short-lived link from the meditation-url function, which first checks with RevenueCat
// that this person owns Premium.

export type MeditationVersion = 'faith' | 'secular';

export const FREE_BUCKET = 'meditations-free';
export const PREMIUM_BUCKET = 'meditations';
export const FUNCTION_NAME = 'meditation-url';

export type ManifestEntry = {
  path: string; // e.g. maren/faith/week-07.m4a
  rev: string; // changes whenever the recording changes, so phones fetch the new one
  seconds?: number;
  bytes?: number;
  free?: boolean; // in the public bucket
};
export type Manifest = { format: 2; narrator: string; files: Record<MeditationVersion, Record<string, ManifestEntry>> };

export const pad = (w: number) => String(w).padStart(2, '0');

export function parseManifest(raw: unknown): Manifest | null {
  const m = raw as Manifest | null;
  if (!m || m.format !== 2 || typeof m.files !== 'object' || !m.files) return null;
  return { ...m, files: { faith: m.files.faith ?? {}, secular: m.files.secular ?? {} } };
}

export const entryFor = (m: Manifest | null, week: number, version: MeditationVersion): ManifestEntry | null =>
  m?.files[version]?.[String(week)] ?? null;

// Supabase addresses for a project URL like https://abcd1234.supabase.co
export function hostingUrls(projectUrl: string) {
  // Just the project address, even if a longer Supabase URL was pasted (…supabase.co/rest/v1/).
  const base = projectUrl.trim().replace(/^(https?:\/\/[^/]+).*$/, '$1');
  return {
    manifest: `${base}/storage/v1/object/public/${FREE_BUCKET}/manifest.json`,
    publicFile: (e: ManifestEntry) => `${base}/storage/v1/object/public/${FREE_BUCKET}/${e.path}?v=${e.rev}`,
    signer: `${base}/functions/v1/${FUNCTION_NAME}`,
  };
}

// A downloaded copy is out of date when the manifest lists a different recording.
// Copies saved before revisions were tracked (no rev) are kept as they are.
export const isStale = (savedRev: string | null, entry: ManifestEntry | null) => !!entry && !!savedRev && savedRev !== entry.rev;
