import * as Speech from 'expo-speech';
import { COACH_VOICES } from '../data/content';

// Text-to-speech fallback, used until a phrase has a recording. Each coach maps to a
// preferred built-in iPhone voice with her own pitch and pace.

let installed: Speech.Voice[] | null = null;
const loading = Speech.getAvailableVoicesAsync()
  // "super-compact" voices are listed but can't speak (iOS reports them as missing).
  .then(v => (installed = v.filter(x => x.language.startsWith('en') && !x.identifier.includes('super-compact'))))
  .catch(() => (installed = []));

function voiceFor(coach: number) {
  const prefs = COACH_VOICES[coach]?.voices ?? [];
  for (const name of prefs) {
    // Prefer the enhanced download of a voice when the person has it.
    const matches = (installed ?? []).filter(v => v.name === name || v.name.startsWith(name + ' '));
    const best = matches.find(v => v.quality === Speech.VoiceQuality.Enhanced) ?? matches[0];
    if (best) return best.identifier;
  }
  return undefined;
}

export async function speakText(text: string, coach: number, volume: number, onDone?: () => void) {
  await loading;
  const c = COACH_VOICES[coach] ?? COACH_VOICES[0];
  Speech.speak(text.replace(/[“”]/g, ''), {
    language: 'en-US',
    voice: voiceFor(coach),
    pitch: c.pitch,
    rate: c.rate,
    volume,
    onDone,
    onStopped: onDone,
    onError: onDone,
  });
}

export function stopSpeaking() {
  Speech.stop().catch(() => {});
}
