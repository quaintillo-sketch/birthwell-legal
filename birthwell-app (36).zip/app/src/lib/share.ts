import { Alert, Share } from 'react-native';

// Opens the iOS share sheet (Messages, Mail, Notes, AirDrop, Print…) with plain text.
export async function shareText(title: string, message: string) {
  try {
    await Share.share({ title, message });
  } catch {
    Alert.alert('Couldn’t open sharing', 'Please try again.');
  }
}
