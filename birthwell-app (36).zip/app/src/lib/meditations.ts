import { Directory, File, Paths } from 'expo-file-system';
import * as Network from 'expo-network';
import { useCallback, useEffect, useState } from 'react';
import { MEDITATION_PREVIEW_CODE, SUPABASE_URL, type MeditationVersion } from '../config/audio';
import type { Store } from './purchases';
import { entryFor, hostingUrls, isStale, pad, parseManifest, type Manifest, type ManifestEntry } from './meditationHosting';

// Downloadable weekly meditations: stored in the app's documents folder so they play
// offline, and kept until removed in Settings. Where they're hosted, and how Premium weeks
// are protected, is in meditationHosting.ts.

export const meditationsConfigured = () => SUPABASE_URL.length > 0;

// Development only: says in the Terminal why a meditation isn't playing its recording.
const devNote = (why: string) => {
  if (__DEV__) console.log(`[meditations] ${why}`);
};

const urls = () => hostingUrls(SUPABASE_URL);
const root = () => new Directory(Paths.document, 'meditations');

let manifest: Manifest | null = null;
async function loadManifest() {
  if (manifest) return manifest;
  try {
    const res = await fetch(urls().manifest);
    manifest = res.ok ? parseManifest(await res.json()) : null;
    if (!manifest) devNote(`couldn't read the manifest (HTTP ${res.status})`);
  } catch {
    manifest = null; // offline: try again next time
    devNote("couldn't reach Supabase for the manifest (offline?)");
  }
  return manifest;
}

// Set by the Premium provider once the store is ready, so Premium weeks can be unlocked.
let access: { storeKind: Store['kind']; appUserId: () => Promise<string | null> } | null = null;
export function setMeditationAccess(a: typeof access) {
  access = a;
}

// A short-lived link to a Premium week, from the meditation-url function. It answers only
// if RevenueCat confirms this customer owns Premium.
async function signedUrl(week: number, version: MeditationVersion): Promise<string | null> {
  if (!access) {
    devNote('Premium store not ready yet');
    return null;
  }
  const appUserId = await access.appUserId();
  const previewCode = __DEV__ && access.storeKind === 'simulated' && MEDITATION_PREVIEW_CODE ? MEDITATION_PREVIEW_CODE : undefined;
  if (!appUserId && !previewCode) {
    devNote('no RevenueCat customer and no preview code in .env');
    return null;
  }
  const abort = new AbortController();
  const timer = setTimeout(() => abort.abort(), 10000);
  try {
    const res = await fetch(urls().signer, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ week, version, appUserId, previewCode }),
      signal: abort.signal,
    });
    if (!res.ok) {
      devNote(`week ${week} ${version}: meditation-url answered ${res.status} ${await res.text()}`);
      return null;
    }
    const { url } = (await res.json()) as { url?: string };
    return url ?? null;
  } catch {
    devNote("couldn't reach the meditation-url function");
    return null;
  } finally {
    clearTimeout(timer);
  }
}

// Where to fetch a week from, or null if it isn't available (not uploaded yet, offline,
// or a Premium week without Premium).
async function remote(week: number, version: MeditationVersion): Promise<{ url: string; entry: ManifestEntry } | null> {
  const m = await loadManifest();
  const entry = entryFor(m, week, version);
  if (!entry) {
    if (m) devNote(`week ${week} ${version} isn't uploaded yet`);
    return null;
  }
  const url = entry.free ? urls().publicFile(entry) : await signedUrl(week, version);
  return url ? { url, entry } : null;
}

export function localFile(week: number, version: MeditationVersion): File | null {
  const dir = new Directory(root(), version);
  if (!dir.exists) return null;
  const f = dir.list().find(e => e instanceof File && /\.(m4a|mp3)$/.test(e.name) && e.name.startsWith(`week-${pad(week)}.`));
  return f instanceof File && f.exists ? f : null;
}

// Which recording a download is: saved next to it as week-07.rev.
const revFile = (week: number, version: MeditationVersion) => new File(new Directory(root(), version), `week-${pad(week)}.rev`);
function savedRev(week: number, version: MeditationVersion) {
  try {
    const f = revFile(week, version);
    return f.exists ? f.textSync().trim() : null;
  } catch {
    return null;
  }
}

// Where to play from: the downloaded file, else a streaming URL, else nothing.
export async function meditationSource(week: number, version: MeditationVersion) {
  const local = localFile(week, version);
  if (local) return { uri: local.uri, offline: true };
  if (!meditationsConfigured()) return null;
  const r = await remote(week, version);
  return r ? { uri: r.url, offline: false } : null;
}

const inFlight = new Map<string, Promise<boolean>>();

// Downloads a week, replacing an older recording of it if there is one.
export function downloadMeditation(week: number, version: MeditationVersion): Promise<boolean> {
  const key = `${version}/${week}`;
  if (inFlight.has(key)) return inFlight.get(key)!;
  const job = (async () => {
    if (!meditationsConfigured()) return !!localFile(week, version);
    const entry = entryFor(await loadManifest(), week, version);
    if (localFile(week, version) && (!entry || !isStale(savedRev(week, version), entry))) return true;
    const r = await remote(week, version);
    if (!r) return false;
    const ext = r.entry.path.split('.').pop() ?? 'm4a';
    const dir = new Directory(root(), version);
    dir.create({ intermediates: true, idempotent: true });
    // Download to a temporary name, then rename, so a dropped connection never leaves a
    // half-written file that looks complete.
    const partial = new File(dir, `week-${pad(week)}.${ext}.part`);
    try {
      if (partial.exists) partial.delete();
      await File.downloadFileAsync(r.url, partial, { idempotent: true });
      localFile(week, version)?.delete();
      partial.move(new File(dir, `week-${pad(week)}.${ext}`));
      await revFile(week, version).write(r.entry.rev);
      notify();
      return true;
    } catch {
      if (partial.exists) partial.delete();
      return false;
    }
  })().finally(() => inFlight.delete(key));
  inFlight.set(key, job);
  return job;
}

export async function onWifi() {
  try {
    const s = await Network.getNetworkStateAsync();
    return s.type === Network.NetworkStateType.WIFI && s.isInternetReachable !== false;
  } catch {
    return false;
  }
}

// Called when the app opens: fetch this week's meditation in the chosen version, on Wi-Fi
// only. Also replaces a download whose recording has since been updated.
export async function autoDownload(week: number, version: MeditationVersion) {
  if (!meditationsConfigured() || !(await onWifi())) return;
  const local = localFile(week, version);
  if (local && !isStale(savedRev(week, version), entryFor(await loadManifest(), week, version))) return;
  await downloadMeditation(week, version);
}

export type Download = { week: number; version: MeditationVersion; bytes: number; file: File };

export function listDownloads(): Download[] {
  const out: Download[] = [];
  for (const version of ['faith', 'secular'] as const) {
    const dir = new Directory(root(), version);
    if (!dir.exists) continue;
    for (const e of dir.list()) {
      const m = e instanceof File ? /^week-(\d+)\.(m4a|mp3)$/.exec(e.name) : null;
      if (m) out.push({ week: Number(m[1]), version, bytes: (e as File).size ?? 0, file: e as File });
    }
  }
  return out.sort((a, b) => b.week - a.week || a.version.localeCompare(b.version));
}

export function removeDownload(d: Download) {
  if (d.file.exists) d.file.delete();
  const rev = revFile(d.week, d.version);
  if (rev.exists) rev.delete();
  notify();
}

export function removeAllDownloads() {
  const dir = root();
  if (dir.exists) dir.delete();
  notify();
}

// Lets Settings refresh its list when downloads change.
const subscribers = new Set<() => void>();
function notify() {
  subscribers.forEach(s => s());
}
export function useDownloads() {
  const [list, setList] = useState<Download[]>(() => safeList());
  const refresh = useCallback(() => setList(safeList()), []);
  useEffect(() => {
    subscribers.add(refresh);
    return () => void subscribers.delete(refresh);
  }, [refresh]);
  return list;
}
function safeList() {
  try {
    return listDownloads();
  } catch {
    return [];
  }
}

export function formatBytes(n: number) {
  return n >= 1e6 ? `${(n / 1e6).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1e3))} KB`;
}
