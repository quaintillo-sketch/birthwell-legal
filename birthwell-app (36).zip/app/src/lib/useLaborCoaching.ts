import { useCallback, useEffect, useRef, useState } from 'react';
import { modeFor, scriptFor, type Phrase } from '../data/coaching';
import { useApp } from '../state/AppState';
import { usePremium } from '../state/Premium';
import { effectiveCoach, scriptForTier } from './access';
import { canStartRotating, fadeOutVoice, isSpeaking, lastEnded, playPhrase, remainingSeconds, stopVoice } from './coachVoice';
import { endTransition, MIN_ACK_CONTRACTION_S, nextSlot, pendingRest, pickPhrase, variationFor, type Moment } from './coachingEngine';

// Runs the coach during labor mode.
// - Start and end of a contraction come from the person's taps.
// - Rotating phrases come from the contraction's start timestamp. The 500ms check reads
//   the clock each time instead of counting ticks, so when iOS suspends JavaScript (phone
//   locked, nothing playing), nothing drifts: missed phrases are dropped, not replayed.
// - When a contraction ends, the coach says one thing: usually a short acknowledgment,
//   sometimes a resting phrase instead. A nearly finished phrase finishes first, a longer one
//   fades out; if the end phrase would come late it's skipped. Nothing for a mis-tap.
export function useLaborCoaching() {
  const { prefs, set } = useApp();
  const { premium } = usePremium();
  const isPremium = useRef(premium);
  isPremium.current = premium;
  const [shown, setShown] = useState<{ phrase: Phrase; moment: Moment } | null>(null);
  const rotation = useRef(prefs.rotation);
  const handled = useRef(-1);
  // Time of the end tap while its phrase waits for the previous one to finish.
  const afterEnd = useRef<number | null>(null);
  const latest = useRef(prefs);
  latest.current = prefs;

  const say = useCallback(
    (moment: Moment, elapsedS: number, interrupt: boolean) => {
      const p = latest.current;
      if (p.coaching === 'off') return;
      // Grounded or Faith-Centered library, following the daily encouragement choice.
      // Free: Maren's free selection. Premium: the chosen coach's full library.
      const coach = effectiveCoach(p.coach, isPremium.current);
      const picked = pickPhrase(scriptForTier(scriptFor(coach), isPremium.current), modeFor(p.faith), moment, elapsedS, rotation.current);
      if (!picked) return;
      if (!playPhrase(coach, picked.phrase, p.coachVolume, { interrupt })) return;
      rotation.current = picked.state;
      set({ rotation: picked.state });
      setShown({ phrase: picked.phrase, moment });
    },
    [set],
  );

  // New contraction: reset the slot counter. Mounting mid-contraction (e.g. reopening the
  // timer) also lands here, and stale slots are then skipped rather than played.
  useEffect(() => {
    handled.current = -1;
  }, [prefs.activeStart]);

  // The end phrase waiting for the previous phrase to finish (or fade).
  useEffect(() => {
    if (prefs.activeStart !== null) return;
    const id = setInterval(() => {
      const endTap = afterEnd.current;
      if (endTap === null) return;
      const d = pendingRest(Date.now() / 1000, endTap / 1000, !isSpeaking(), lastEnded() / 1000);
      if (d === 'wait') return;
      afterEnd.current = null;
      if (d === 'play') say('end', 0, false);
    }, 200);
    return () => clearInterval(id);
  }, [prefs.activeStart, say]);

  useEffect(() => {
    const start = prefs.activeStart;
    if (start === null || prefs.coaching === 'off' || prefs.coaching === 'edges') return;
    const id = setInterval(() => {
      const elapsed = (Date.now() - start) / 1000;
      const d = nextSlot(latest.current.coaching, elapsed, handled.current, variationFor(start));
      if (d.kind === 'skip') handled.current = d.slot;
      // If another phrase is still playing, leave the slot pending; it plays when the
      // channel frees up, or is dropped once it's more than a few seconds late.
      else if (d.kind === 'play' && canStartRotating()) {
        handled.current = d.slot;
        say('mid', elapsed, false);
      }
    }, 500);
    return () => clearInterval(id);
  }, [prefs.activeStart, prefs.coaching, say]);

  useEffect(() => stopVoice, []);

  return {
    shown,
    onContractionStart: () => {
      afterEnd.current = null;
      say('start', 0, true);
    },
    // `lengthS`: how long the contraction lasted.
    onContractionEnd: (lengthS: number) => {
      if (lengthS < MIN_ACK_CONTRACTION_S) {
        // Probably a mis-tap: say nothing, and gently end anything still playing.
        afterEnd.current = null;
        fadeOutVoice();
        return;
      }
      const t = endTransition(remainingSeconds());
      if (t === 'play-now') {
        afterEnd.current = null;
        return say('end', 0, true);
      }
      if (t === 'fade-then-play') fadeOutVoice();
      afterEnd.current = Date.now();
    },
  };
}
