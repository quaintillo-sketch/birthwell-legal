// Coaching logic with no React Native dependencies, so it can be unit-tested.
// Everything is driven by timestamps (contraction start time, now), never by counting
// timer ticks, because iOS can suspend JavaScript while the phone is locked.

import type { Category, CoachScript, Mode, Phrase } from '../data/coaching';

export type Frequency = 'off' | 'edges' | 'balanced' | 'more' | 'frequent';

export const FREQUENCIES: { value: Frequency; label: string; sub: string }[] = [
  { value: 'off', label: 'Silent', sub: 'No coaching voice. Ambience and haptics continue.' },
  { value: 'edges', label: 'Start & end only', sub: 'One phrase as a contraction begins, and one when it ends.' },
  { value: 'balanced', label: 'Balanced', sub: 'An opening phrase, usually one more if a contraction lasts past about 30–40 seconds, and a few warm words when it ends.' },
  { value: 'more', label: 'More guidance', sub: 'An opening phrase, then about every 25 seconds.' },
  { value: 'frequent', label: 'Frequent', sub: 'An opening phrase, then about every 15 seconds.' },
];

// A number in [0, 1) that stays the same for one contraction (derived from its start
// time), so its timing varies from contraction to contraction but never jumps around
// while it's in progress, even if the app restarts.
export function variationFor(contractionStartMs: number) {
  let x = Math.floor(contractionStartMs) | 0;
  x = Math.imul(x ^ (x >>> 16), 0x45d9f3b);
  x = Math.imul(x ^ (x >>> 16), 0x45d9f3b);
  x ^= x >>> 16;
  return (x >>> 0) / 2 ** 32;
}

// Roughly 1 in 6 Balanced contractions get only the opening phrase, so the coach
// doesn't follow the same pattern every time and some contractions stay quiet.
export const BALANCED_QUIET_SHARE = 0.16;

// Seconds into a contraction at which a rotating phrase is due. `variation` comes from
// variationFor(); 0.5 gives the middle of each range.
export function midOffsets(freq: Frequency, variation = 0.5): number[] {
  const second = (variation * 7919.37) % 1; // a second, independent-looking value
  switch (freq) {
    case 'balanced':
      // Anywhere from 30 to 42 seconds in, or not at all.
      return second < BALANCED_QUIET_SHARE ? [] : [30 + variation * 12];
    case 'more':
      return Array.from({ length: 24 }, (_, i) => 25 * (i + 1) + (variation - 0.5) * 6);
    case 'frequent':
      return Array.from({ length: 40 }, (_, i) => 15 * (i + 1) + (variation - 0.5) * 4);
    default:
      return [];
  }
}

// A due phrase that couldn't play within this window (another phrase was still playing,
// or the app was suspended) is dropped rather than played late, so nothing piles up.
export const STALE_AFTER_S = 6;
// Breathing room after one phrase ends before a rotating phrase may start.
export const MIN_GAP_S = 4;

export type SlotDecision = { kind: 'none' } | { kind: 'play'; slot: number } | { kind: 'skip'; slot: number };

// `handled` is the index of the last slot already played or skipped (-1 for none).
export function nextSlot(freq: Frequency, elapsedS: number, handled: number, variation = 0.5): SlotDecision {
  const offsets = midOffsets(freq, variation);
  let latest = -1;
  for (let i = 0; i < offsets.length && offsets[i] <= elapsedS; i++) latest = i;
  if (latest <= handled) return { kind: 'none' };
  // Earlier slots that were missed are skipped silently; only the latest can still play.
  return elapsedS - offsets[latest] > STALE_AFTER_S ? { kind: 'skip', slot: latest } : { kind: 'play', slot: latest };
}

// End of a contraction. The coach says one thing: usually a short acknowledgment
// ("You did wonderfully."), sometimes a resting phrase instead, never both.
// If a phrase is still playing:
// - if it will finish within FINISH_WITHIN_S, let it finish naturally;
// - otherwise fade it out quickly (never an abrupt cut).
// The end phrase follows after REST_PAUSE_S of quiet, but only if it can start within
// REST_STALE_S of the end tap; otherwise it's skipped, never played late or queued up.
// Nothing is said for a contraction shorter than MIN_ACK_CONTRACTION_S (likely a mis-tap).
export const FINISH_WITHIN_S = 3;
export const FADE_OUT_S = 0.4;
export const REST_PAUSE_S = 0.8;
export const REST_STALE_S = 8;
export const MIN_ACK_CONTRACTION_S = 12;

export function endTransition(remainingS: number): 'play-now' | 'finish-then-play' | 'fade-then-play' {
  if (remainingS <= 0) return 'play-now';
  return remainingS <= FINISH_WITHIN_S ? 'finish-then-play' : 'fade-then-play';
}

export function pendingRest(nowS: number, endTapS: number, channelFree: boolean, lastEndedS: number): 'wait' | 'play' | 'drop' {
  if (nowS - endTapS > REST_STALE_S) return 'drop';
  if (!channelFree || nowS - lastEndedS < REST_PAUSE_S) return 'wait';
  return 'play';
}

// Rough spoken length of a phrase, used when the real duration isn't known yet
// (the phone's voice, or a recording that's still loading).
export function estimateSeconds(text: string, wordsPerSecond = 2.3) {
  const words = text.split(/\s+/).filter(Boolean).length;
  const pauses = (text.match(/…/g) ?? []).length;
  return 0.6 + words / wordsPerSecond + pauses * 0.6;
}

export type Moment = 'start' | 'mid' | 'end';

// The same weights apply to both libraries; faith is woven through every category of the
// Faith-Centered library rather than being a category of its own.
export function weightsFor(moment: Moment, elapsedS: number): { category: Category; weight: number }[] {
  if (moment === 'start') return [{ category: 'start', weight: 1 }];
  // About 3 in 4 ends get an acknowledgment; the rest get a longer resting phrase instead.
  if (moment === 'end')
    return [
      { category: 'ack', weight: 3 },
      { category: 'rest', weight: 1 },
    ];
  // Mostly breathing guidance, sprinkled with small encouragements ("You're doing well."),
  // and now and then encouragement for hard moments or reassurance (or prayer), a little
  // more of those later in a long contraction.
  const later = elapsedS >= 30;
  return [
    { category: 'breathe', weight: 3 },
    { category: 'affirm', weight: 1.6 },
    { category: 'encourage', weight: later ? 1 : 0.5 },
    { category: 'ground', weight: later ? 0.5 : 0.25 },
  ];
}

// Shuffle bags: every phrase in a group plays once before any repeats. Persisted so
// restarting the app doesn't reset the rotation.
// `history` remembers each group's most recent phrases, so a refilled bag never brings one
// back too soon: in a group of 5, at least 4 others play before a phrase repeats.
// (`last` is the older, single-phrase form of the same thing, still read for saved state.)
export type RotationState = {
  bags: Record<string, string[]>;
  recent: string[];
  last?: Record<string, string>;
  history?: Record<string, string[]>;
};
export const EMPTY_ROTATION: RotationState = { bags: {}, recent: [], last: {}, history: {} };
const RECENT_MAX = 6;

function shuffle<T>(xs: T[], rand: () => number) {
  const a = [...xs];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// Minimum number of plays from a group before one of its phrases may repeat.
export function minRepeatGap(groupSize: number) {
  return groupSize <= 1 ? 1 : Math.max(2, groupSize - 1);
}

// A new random bag order in which recently played phrases sit far enough back.
function refill(ids: string[], history: string[], rand: () => number) {
  const gap = minRepeatGap(ids.length);
  // picksAgo: 1 for the phrase played last in this group, 2 for the one before, …
  const picksAgo = (id: string) => {
    const i = history.lastIndexOf(id);
    return i < 0 ? Infinity : history.length - i;
  };
  const ok = (bag: string[]) => bag.every((id, j) => picksAgo(id) - 1 + (j + 1) >= gap);
  for (let tries = 0; tries < 30; tries++) {
    const bag = shuffle(ids, rand);
    if (ok(bag)) return bag;
  }
  // Fallback: least recently played first.
  return [...ids].sort((a, b) => picksAgo(b) - picksAgo(a));
}

export function pickPhrase(
  script: CoachScript,
  mode: Mode,
  moment: Moment,
  elapsedS: number,
  state: RotationState,
  rand: () => number = Math.random,
): { phrase: Phrase; state: RotationState } | null {
  const groups = weightsFor(moment, elapsedS)
    .map(w => ({ ...w, phrases: script.phrases.filter(p => p.category === w.category && p.modes.includes(mode)) }))
    .filter(g => g.phrases.length > 0);
  if (!groups.length) return null;
  // A group whose only phrase was the last one heard would repeat it back to back (this
  // happens with small libraries, like the free one); skip it this time if anything else fits.
  const lastHeard = state.recent[0];
  const fresh = groups.filter(g => !g.phrases.every(p => `${script.slug}:${p.id}` === lastHeard));
  if (fresh.length) groups.splice(0, groups.length, ...fresh);

  // Weighted choice of group.
  const total = groups.reduce((s, g) => s + g.weight, 0);
  let r = rand() * total;
  const group = groups.find(g => (r -= g.weight) < 0) ?? groups[groups.length - 1];

  const key = `${script.slug}:${mode}:${group.category}`;
  const valid = new Set(group.phrases.map(p => p.id));
  const history = state.history?.[key] ?? (state.last?.[key] ? [state.last[key]] : []);
  let bag = (state.bags[key] ?? []).filter(id => valid.has(id));
  if (!bag.length) {
    bag = refill([...valid], history, rand);
    // Lines shared by both modes can also have been heard in the other mode just now.
    const heard = (id: string) => state.recent.indexOf(`${script.slug}:${id}`);
    if (bag.length > 1 && heard(bag[0]) === 0) [bag[0], bag[1]] = [bag[1], bag[0]];
  }
  const [id, ...rest] = bag;
  const phrase = group.phrases.find(p => p.id === id)!;
  return {
    phrase,
    state: {
      bags: { ...state.bags, [key]: rest },
      recent: [`${script.slug}:${id}`, ...state.recent].slice(0, RECENT_MAX),
      last: { ...state.last, [key]: id },
      history: { ...state.history, [key]: [...history, id].slice(-Math.max(1, valid.size - 1)) },
    },
  };
}
