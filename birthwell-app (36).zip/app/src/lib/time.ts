const DAY = 86400000;

export function fmtDuration(totalSeconds: number) {
  const s = Math.max(0, Math.round(totalSeconds));
  return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
}

export function fmtClock(ms: number) {
  const d = new Date(ms);
  const h = d.getHours() % 12 || 12;
  return `${h}:${String(d.getMinutes()).padStart(2, '0')} ${d.getHours() < 12 ? 'AM' : 'PM'}`;
}

export function startOfDay(d: Date) {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}

// A pregnancy is counted as 280 days (40 weeks) ending on the due date.
export function pregnancy(dueISO: string, now = new Date()) {
  const due = startOfDay(new Date(dueISO));
  const daysLeft = Math.round((due.getTime() - startOfDay(now).getTime()) / DAY);
  const day = 280 - daysLeft;
  const week = Math.max(1, Math.floor(day / 7));
  return { day, week, weeksToGo: Math.max(0, 40 - week) };
}

export function greeting(now = new Date()) {
  const h = now.getHours();
  return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
}
