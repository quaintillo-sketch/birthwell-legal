import { File, Paths } from 'expo-file-system';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import type { ComponentRef, RefObject } from 'react';
import { ActionSheetIOS, Alert, Platform, type View } from 'react-native';
import { captureRef } from 'react-native-view-shot';
import { shareText } from './share';

// Exporting a page three ways: a styled PDF (printable), a styled image (for Photos or
// Messages) and plain text. The PDF and image open the iOS share sheet, which includes
// Save to Files, Save Image, Print, Mail and Messages.

async function shareFile(uri: string, name: string, mimeType: string, UTI: string) {
  // Give the file a readable name ("BirthWell Birth Plan.pdf") before sharing it.
  const dest = new File(Paths.cache, name);
  if (dest.exists) dest.delete();
  new File(uri).copy(dest);
  await Sharing.shareAsync(dest.uri, { mimeType, UTI, dialogTitle: name });
}

export async function exportPdf(html: string, name: string) {
  try {
    const { uri } = await Print.printToFileAsync({ html, width: 612, height: 792 }); // US Letter
    await shareFile(uri, `${name}.pdf`, 'application/pdf', 'com.adobe.pdf');
  } catch {
    Alert.alert('Couldn’t create the PDF', 'Please try again.');
  }
}

// The native view a poster is drawn in, for capturing as an image.
export type PosterRef = ComponentRef<typeof View>;

export async function exportImage(ref: RefObject<PosterRef | null>, name: string) {
  try {
    const uri = await captureRef(ref, { format: 'jpg', quality: 0.95, result: 'tmpfile' });
    await shareFile(uri, `${name}.jpg`, 'image/jpeg', 'public.jpeg');
  } catch {
    Alert.alert('Couldn’t create the image', 'Please try again.');
  }
}

export function chooseExport(title: string, actions: { pdf: () => void; image: () => void; text: string }) {
  const options = ['Save as PDF', 'Save as image', 'Share as text', 'Cancel'];
  const run = (i: number) => {
    if (i === 0) actions.pdf();
    else if (i === 1) actions.image();
    else if (i === 2) shareText(title, actions.text);
  };
  if (Platform.OS === 'ios') {
    ActionSheetIOS.showActionSheetWithOptions({ title, options, cancelButtonIndex: 3 }, run);
    return;
  }
  Alert.alert(title, undefined, [
    { text: options[0], onPress: () => run(0) },
    { text: options[1], onPress: () => run(1) },
    { text: options[2], onPress: () => run(2) },
    { text: 'Cancel', style: 'cancel' },
  ]);
}

const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

// A printable page in the app's style: ivory paper, Instrument Serif headings, clay italics.
export function docHtml(title: [string, string], kicker: string, body: string) {
  return `<!doctype html><html><head><meta charset="utf-8">
<link href="https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Hanken+Grotesk:wght@400;500;600&display=swap" rel="stylesheet">
<style>
  @page { margin: 0; }
  html, body { margin: 0; background: #F4EFE7; }
  body { padding: 54px 60px; color: #2E2420; font: 13.5px/1.5 'Hanken Grotesk', -apple-system, Helvetica, sans-serif; -webkit-print-color-adjust: exact; }
  .serif { font-family: 'Instrument Serif', Georgia, serif; font-weight: 400; }
  h1 { font-family: 'Instrument Serif', Georgia, serif; font-weight: 400; font-size: 56px; line-height: 1; margin: 0; letter-spacing: -0.5px; }
  em { font-style: italic; color: #A96A4E; }
  .kicker { font-size: 9.5px; font-weight: 600; letter-spacing: 1.6px; text-transform: uppercase; color: #6F5F55; margin-top: 14px; }
  h2 { font-family: 'Instrument Serif', Georgia, serif; font-style: italic; font-weight: 400; font-size: 24px; margin: 26px 0 4px; break-after: avoid; }
  .row { display: flex; align-items: center; gap: 12px; padding: 9px 0; border-top: 1px solid rgba(46,36,32,0.1); break-inside: avoid; }
  .box { width: 14px; height: 14px; border-radius: 50%; border: 1.2px solid rgba(46,36,32,0.35); flex: none; display: flex; align-items: center; justify-content: center; font-size: 9px; color: #F4EFE7; }
  .on { background: #5E4450; border-color: #5E4450; }
  .done { color: #8E7E73; }
  .note { margin-left: auto; color: #8E7E73; font-size: 12px; }
  .label { color: #6F5F55; font-size: 12px; width: 150px; flex: none; }
  .notes { font-family: 'Instrument Serif', Georgia, serif; font-style: italic; font-size: 16px; color: #4F3E36; padding: 8px 0 2px; border-top: 1px solid rgba(46,36,32,0.1); }
  .foot { margin-top: 30px; font-family: 'Instrument Serif', Georgia, serif; font-style: italic; font-size: 15px; color: #6F5F55; }
  .brand { margin-top: 18px; font-size: 9.5px; font-weight: 600; letter-spacing: 1.6px; text-transform: uppercase; color: #A96A4E; }
</style></head><body>
<h1>${esc(title[0])} <em>${esc(title[1])}</em></h1>
<div class="kicker">${esc(kicker)}</div>
${body}
<div class="brand">Made with BirthWell</div>
</body></html>`;
}

export const html = {
  esc,
  check: (label: string, on: boolean, note = '') =>
    `<div class="row"><div class="box ${on ? 'on' : ''}">${on ? '✓' : ''}</div><div class="${on ? 'done' : ''}">${esc(label)}</div>${note ? `<div class="note">${esc(note)}</div>` : ''}</div>`,
  bullet: (label: string) => `<div class="row"><div class="box on">✓</div><div>${esc(label)}</div></div>`,
  field: (label: string, value: string) => `<div class="row"><div class="label">${esc(label)}</div><div>${esc(value)}</div></div>`,
};
