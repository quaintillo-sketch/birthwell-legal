import { createAudioPlayer, type AudioPlayer } from 'expo-audio';
import * as Speech from 'expo-speech';
import { COACH_SLUGS, type Phrase } from '../data/coaching';
import { VOICE_FILES } from '../data/voiceFiles';
import { estimateSeconds, FADE_OUT_S, MIN_GAP_S } from './coachingEngine';
import { speakText } from './voice';

// The single voice channel. Only one phrase plays at a time:
// - a recorded file from assets/voices when it exists, otherwise the phone's voice;
// - `interrupt: false` (rotating phrases) never cuts into a phrase that's playing;
// - `interrupt: true` (start / end of a contraction, previews) replaces it, because the
//   old phrase no longer fits the moment.
// Each recording gets its own short-lived player. If iOS interrupts it (a call, Siri), the
// player is discarded rather than resumed mid-sentence later.

type Current = {
  token: number;
  player?: AudioPlayer;
  tts?: boolean;
  startedAt: number;
  estimate: number; // seconds, until the recording's real duration is known
  fading?: boolean;
  timeout: ReturnType<typeof setTimeout>;
};

let current: Current | null = null;
let lastEndedAt = 0;
let counter = 0;
const listeners = new Set<(speaking: boolean) => void>();

export function onSpeakingChange(fn: (speaking: boolean) => void) {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}

export function isSpeaking() {
  return current !== null;
}

// True when a rotating phrase may start: nothing playing, and a short pause since the last.
export function canStartRotating(now = Date.now()) {
  return !current && now - lastEndedAt >= MIN_GAP_S * 1000;
}

export function lastEnded() {
  return lastEndedAt;
}

// Seconds left in the phrase that's playing (0 when nothing is).
export function remainingSeconds(now = Date.now()) {
  if (!current) return 0;
  const p = current.player;
  if (p && p.duration > 0) return Math.max(0, p.duration - p.currentTime);
  return Math.max(0.1, current.estimate - (now - current.startedAt) / 1000);
}

function finish(token: number) {
  if (!current || current.token !== token) return;
  const c = current;
  current = null;
  lastEndedAt = Date.now();
  clearTimeout(c.timeout);
  if (c.player) {
    try {
      c.player.pause();
      c.player.remove();
    } catch {}
  }
  listeners.forEach(l => l(false));
}

export function stopVoice() {
  if (!current) return;
  if (current.tts) Speech.stop().catch(() => {});
  finish(current.token);
}

// Ends the current phrase gently: a recording fades out over FADE_OUT_S; the phone's voice
// (which can't fade) stops. The channel stays busy until it's done, so nothing overlaps.
export function fadeOutVoice() {
  const c = current;
  if (!c || c.fading) return;
  c.fading = true;
  if (!c.player) {
    Speech.stop().catch(() => {});
    return finish(c.token);
  }
  const player = c.player;
  const from = player.volume;
  const steps = 8;
  for (let i = 1; i <= steps; i++)
    setTimeout(() => {
      if (current?.token !== c.token) return;
      if (i === steps) return finish(c.token);
      try {
        player.volume = from * (1 - i / steps);
      } catch {}
    }, (FADE_OUT_S * 1000 * i) / steps);
}

export function hasRecording(coachIndex: number, phraseId: string) {
  return !!VOICE_FILES[COACH_SLUGS[coachIndex]]?.[phraseId];
}

export function playPhrase(coachIndex: number, phrase: Phrase, volume: number, { interrupt }: { interrupt: boolean }) {
  if (current && !interrupt) return false;
  stopVoice();

  const token = ++counter;
  // Safety net: never let a stuck phrase block the channel.
  const timeout = setTimeout(() => finish(token), 25000);
  const source = VOICE_FILES[COACH_SLUGS[coachIndex]]?.[phrase.id];
  const startedAt = Date.now();
  const estimate = estimateSeconds(phrase.text);
  listeners.forEach(l => l(true));

  if (source) {
    const player = createAudioPlayer(source);
    current = { token, player, startedAt, estimate, timeout };
    let started = false;
    player.addListener('playbackStatusUpdate', status => {
      if (status.didJustFinish) return finish(token);
      if (status.playing) started = true;
      // Paused by iOS (call, Siri, headphones unplugged) rather than finishing: drop it.
      else if (started && status.isLoaded) finish(token);
    });
    player.volume = volume;
    player.play();
  } else {
    current = { token, tts: true, startedAt, estimate, timeout };
    speakText(phrase.text, coachIndex, volume, () => finish(token));
  }
  return true;
}
