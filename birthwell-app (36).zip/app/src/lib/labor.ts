import type { Rule } from '../data/content';

export type Contraction = { start: number; end: number };
export type Measure = 'start' | 'end';

// Gap between consecutive contractions, in seconds. `list` is newest first.
export function gaps(list: Contraction[], measure: Measure) {
  const out: number[] = [];
  for (let i = 0; i < list.length - 1; i++) {
    const next = list[i], prev = list[i + 1];
    out.push(((measure === 'start' ? next.start - prev.start : next.start - prev.end)) / 1000);
  }
  return out;
}

const avg = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0);

export function stats(list: Contraction[], measure: Measure) {
  const recent = list.slice(0, 6);
  return {
    avgLength: avg(recent.map(c => (c.end - c.start) / 1000)),
    avgApart: avg(gaps(recent, measure)),
  };
}

// Allow up to a minute over the target spacing, matching "every 5–6 minutes" in the design.
const APART_TOLERANCE = 60;

export function patternReached(list: Contraction[], rule: Rule, measure: Measure, now = Date.now()) {
  const windowStart = now - rule.f * 60000;
  const inWindow = list.filter(c => c.start >= windowStart - rule.a * 60000);
  if (inWindow.length < 3) return null;
  // The pattern must have held for roughly the whole window.
  if (inWindow[inWindow.length - 1].start > windowStart + rule.a * 60000) return null;
  const g = gaps(inWindow, measure);
  if (g.some(x => x > rule.a * 60 + APART_TOLERANCE)) return null;
  const lengths = inWindow.map(c => (c.end - c.start) / 1000);
  if (lengths.some(l => l < rule.l * 0.75)) return null;

  const lo = Math.floor(Math.min(...g) / 60), hi = Math.ceil(Math.max(...g) / 60);
  const meanLen = avg(lengths);
  const spacing = lo === hi ? `Every ${lo} minutes` : `Every ${lo}–${hi} minutes`;
  const lasting = Math.abs(meanLen - 60) <= 10 ? 'lasting about a minute' : `lasting about ${Math.round(meanLen / 5) * 5} seconds`;
  const span = rule.f === 60 ? 'for the past hour' : `for the past ${rule.f} minutes`;
  return `${spacing}, ${lasting}, ${span}.`;
}

// Sample session shown the first time labor mode opens, so the screens can be explored
// before labor begins. Ending the session clears it for good.
export function sampleSession(now = Date.now()) {
  const lengths = [61, 58, 64, 55, 62, 57, 60, 59, 63, 56, 58, 61];
  const aparts = [340, 330, 350, 325, 335, 345, 320, 330, 340, 335, 325];
  const list: Contraction[] = [];
  let start = now - 260000 - lengths[0] * 1000; // last one ended 4:20 ago
  for (let i = 0; i < lengths.length; i++) {
    list.push({ start, end: start + lengths[i] * 1000 });
    start -= (aparts[i] ?? 330) * 1000;
  }
  // …and a new one began 20 seconds ago, as on the live timer design (1h).
  return { contractions: list, activeStart: now - 20000 };
}

// Plain-text log for sharing with a provider or partner. `list` is newest first.
export function logText(list: Contraction[], measure: Measure, ruleShort: string, fmtClock: (ms: number) => string, fmtDuration: (s: number) => string) {
  const g = gaps(list, measure);
  const { avgLength, avgApart } = stats(list, measure);
  const first = list[list.length - 1], last = list[0];
  const day = (ms: number) => new Date(ms).toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
  const lines = [
    'Contraction log',
    first ? `${day(first.start)}, ${fmtClock(first.start)} – ${fmtClock(last.end)}` : '',
    `${list.length} contractions · guideline ${ruleShort} · apart measured ${measure === 'start' ? 'start to start' : 'end to start'}`,
    `Recent average: ${fmtDuration(avgLength)} long${list.length > 1 ? `, ${fmtDuration(avgApart)} apart` : ''}`,
    '',
    'Started    Length   Apart',
    ...list.map((c, i) => `${fmtClock(c.start).padEnd(10)} ${fmtDuration((c.end - c.start) / 1000).padEnd(8)} ${g[i] !== undefined ? fmtDuration(g[i]) : '—'}`),
    '',
    'Made with BirthWell',
  ];
  return lines.filter((l, i) => l !== '' || i > 2).join('\n');
}
