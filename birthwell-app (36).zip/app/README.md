# BirthWell (Expo app)

The BirthWell iOS app, built from the Claude Design handoff in `../project/BirthWell.dc.html`.
It uses Expo SDK 57, Expo Router and TypeScript.

## Run

```bash
npm install
npx expo start --tunnel   # scan the QR code with Expo Go, or press i for the iOS simulator
npm run typecheck
npm test                  # coaching logic and script checks
```

Background and locked-screen audio need a development build (`npx expo run:ios --device`); Expo Go ignores them. See `docs/audio-testing.md`.

## Screens → files

| Design | Route | File |
| --- | --- | --- |
| 1b Welcome | `/welcome` | `src/app/welcome.tsx` |
| 1c Due date | `/onboarding/due-date` | `src/app/onboarding/due-date.tsx` |
| 1d Encouragement | `/onboarding/encouragement` | `src/app/onboarding/encouragement.tsx` |
| 1e Choose your coach | `/onboarding/coach`, `/coach` (from Settings) | `src/components/CoachPicker.tsx` |
| 1f / 2a Home | `/` (Today tab) | `src/app/(tabs)/index.tsx` |
| 1g / 2b Weekly meditation | `/meditation` | `src/app/meditation.tsx` |
| 1h / 1i Contraction timer | `/labor` | `src/app/labor/index.tsx` |
| 1l Timer settings | `/labor/settings` | `src/app/labor/settings.tsx` |
| 1j / 2c Hospital bag | `/bag` (Bag tab) | `src/app/(tabs)/bag.tsx` |
| 1k / 2d Settings | `/settings` (the initial on Home) | `src/app/settings.tsx` |

## Audio

| What | Where |
| --- | --- |
| Coaching scripts: Grounded and Faith-Centered libraries, 31 Grounded and 33 Faith-Centered phrases per coach (269 unique recordings); the source of truth | `src/data/coaching.ts` → review copy in `docs/coaching-scripts.md` |
| Rotation, frequency and timing rules | `src/lib/coachingEngine.ts` (tested in `tests/`) |
| Voice channel (one phrase at a time, recordings or phone-voice fallback) | `src/lib/coachVoice.ts` |
| Labor-mode coaching | `src/lib/useLaborCoaching.ts` |
| Coach recordings | `assets/voices/<coach>/<id>.m4a` or `.mp3`, then `npm run voices` |
| Ambience loops | `assets/ambience/` (listed in `src/data/content.ts`) |
| Meditation downloads | `src/lib/meditations.ts`, hosted on Supabase (`EXPO_PUBLIC_SUPABASE_URL` in `.env`; see `docs/meditation-hosting.md`) |

Guides:
- `docs/elevenlabs-guide.md`: create, generate, name and import the coach voices.
- `docs/meditation-hosting.md`: Supabase Storage setup for weekly meditations.
- `docs/audio-testing.md`: how the audio behaves, what's verified, and the iPhone test checklist.

Scripts:
- `npm run scripts:export`: regenerate the review document and the ElevenLabs CSV after editing phrases.
- `npm run voices:generate -- --coach maren --dry-run`: ElevenLabs generation, one coach at a time (spends credits without `--dry-run`).
- `bash scripts/prepare-audio.sh <coach|all|ambience>`: trim, level and convert recordings into the app.
- `npm run voices`: register which recordings exist.

## Daily encouragement

- `src/data/reflections.ts`: the Grounded reflections (120) and Faith-Centered Scripture (134, World English Bible, public domain). One per day, matched to the stage of pregnancy, with nothing repeating for at least ten weeks.
- In the Scripture, "Yahweh" is shown as "the Lord" (and "Lord Yahweh" as "Lord God"); otherwise each quote is the WEB text word for word. `npm test` checks every quote against the WEB.
- Morning delivery (`src/lib/morningReminders.ts`) schedules the next 30 days as local notifications at the chosen time, and refreshes them each time the app opens. "Off" turns them off. Permission is asked once, when onboarding continues past the encouragement step or when a time is chosen in Settings.

## Still placeholders

- Coach names, personalities and photos come from the design.
- Until recordings exist, the iPhone's built-in voice reads the coaching phrases, and the ambience loops are synthetic.
- Until meditation hosting is connected, the meditation plays a simulated timeline with spoken cues.
- The first time labor mode opens, it loads a sample session; **End session → End and clear** removes it for good.
- The 4-1-1 and 3-1-1 guidelines and the pattern tolerance haven't been reviewed by a clinician.
- "Call Dr. Alvarez" opens the dialer with no number.
