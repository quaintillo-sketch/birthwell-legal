// BirthWell · meditation-url
// Gives the app a short-lived link to a Premium meditation, after checking with RevenueCat
// that this customer owns BirthWell Premium. Free weeks don't come here: they're in the
// public meditations-free bucket.
//
// The app sends:  POST { week: 7, version: "faith" | "secular", appUserId: "$RCAnonymousID:…" }
// It gets back:   200 { url, expiresIn }   or 403 (no Premium), 404 (not uploaded), 400, 502
//
// Secrets (Supabase → Edge Functions → Secrets):
//   REVENUECAT_SECRET_KEY     RevenueCat secret API key (V1). Never put this in the app.
//   MEDITATION_PREVIEW_CODE   optional, testing in Expo Go only. Delete it before launch.
// SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are provided by Supabase automatically.
//
// Deploy with "Verify JWT" turned OFF: the app has no Supabase login, and this function does
// its own check. Nothing here is logged except the outcome.

const ENTITLEMENT = 'premium';
const NARRATOR = 'maren';
const BUCKET = 'meditations'; // private
const FIRST_WEEK = 6;
const LAST_WEEK = 42;
const LINK_SECONDS = 6 * 60 * 60; // long enough to finish a paused stream

type Env = { get(name: string): string | undefined };
type Fetch = typeof fetch;

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'content-type, authorization, apikey, x-client-info',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const reply = (status: number, body: Record<string, unknown>) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } });

export async function hasPremium(appUserId: string, secretKey: string, fetchImpl: Fetch, now = Date.now()): Promise<boolean | 'error'> {
  const res = await fetchImpl(`https://api.revenuecat.com/v1/subscribers/${encodeURIComponent(appUserId)}`, {
    headers: { Authorization: `Bearer ${secretKey}`, Accept: 'application/json' },
  });
  if (!res.ok) return 'error';
  const data = await res.json();
  const e = data?.subscriber?.entitlements?.[ENTITLEMENT];
  if (!e) return false;
  // A one-time purchase never expires (expires_date is null).
  const until = [e.expires_date, e.grace_period_expires_date].filter(Boolean).map((d: string) => Date.parse(d));
  return e.expires_date == null || until.some((t: number) => t > now);
}

export async function handle(req: Request, env: Env, fetchImpl: Fetch = fetch): Promise<Response> {
  if (req.method === 'OPTIONS') return new Response(null, { headers: cors });
  if (req.method !== 'POST') return reply(405, { error: 'Use POST.' });

  let body: { week?: unknown; version?: unknown; appUserId?: unknown; previewCode?: unknown };
  try {
    body = await req.json();
  } catch {
    return reply(400, { error: 'Send JSON.' });
  }
  const week = Number(body.week);
  const version = body.version;
  if (!Number.isInteger(week) || week < FIRST_WEEK || week > LAST_WEEK) return reply(400, { error: 'Unknown week.' });
  if (version !== 'faith' && version !== 'secular') return reply(400, { error: 'Unknown version.' });

  // Who may have the link: a RevenueCat customer with Premium, or (testing only) the preview code.
  const preview = env.get('MEDITATION_PREVIEW_CODE') ?? '';
  const previewOk = preview.length >= 16 && body.previewCode === preview;
  if (!previewOk) {
    const id = typeof body.appUserId === 'string' ? body.appUserId : '';
    if (!id || id.length > 200) return reply(403, { error: 'Premium required.' });
    const key = env.get('REVENUECAT_SECRET_KEY');
    if (!key) return reply(500, { error: 'REVENUECAT_SECRET_KEY is not set.' });
    let premium: boolean | 'error';
    try {
      premium = await hasPremium(id, key, fetchImpl);
    } catch {
      premium = 'error';
    }
    if (premium === 'error') return reply(502, { error: 'Could not reach RevenueCat.' });
    if (!premium) return reply(403, { error: 'Premium required.' });
  }

  const base = (env.get('SUPABASE_URL') ?? '').replace(/\/+$/, '');
  const service = env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';
  const path = `${NARRATOR}/${version}/week-${String(week).padStart(2, '0')}.m4a`;
  const res = await fetchImpl(`${base}/storage/v1/object/sign/${BUCKET}/${path}`, {
    method: 'POST',
    // New-style secret keys (sb_secret_…) go in apikey only; legacy JWT keys also as a bearer token.
    headers: { apikey: service, ...(service.startsWith('eyJ') ? { Authorization: `Bearer ${service}` } : {}), 'Content-Type': 'application/json' },
    body: JSON.stringify({ expiresIn: LINK_SECONDS }),
  });
  if (!res.ok) return res.status === 400 || res.status === 404 ? reply(404, { error: 'Not uploaded yet.' }) : reply(502, { error: 'Storage error.' });
  const { signedURL } = await res.json();
  if (!signedURL) return reply(404, { error: 'Not uploaded yet.' });
  return reply(200, { url: `${base}/storage/v1${signedURL}`, expiresIn: LINK_SECONDS });
}

// @ts-ignore: Deno only. Tests import handle() without starting a server.
if (typeof Deno !== 'undefined') Deno.serve(req => handle(req, Deno.env));
